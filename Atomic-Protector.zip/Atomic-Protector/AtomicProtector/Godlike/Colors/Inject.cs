﻿using Atomic_Obfuscator;
using dnlib.DotNet;
using dnlib.DotNet.Emit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Protector.Godlike.Colors
{
    class Inject
    {
        //yes were obfuscating fucken colors lmao

        static Random random = new Random();

        public static MethodDef init;

        public static void InjectClass(ModuleDef module)
        {
            //We declare our Module, here we want to load the EncryptionHelper class
            ModuleDefMD typeModule = ModuleDefMD.Load(typeof(Runtime).Module);
            //We declare EncryptionHelper as a TypeDef using it's Metadata token (needed)
            TypeDef typeDef = typeModule.ResolveTypeDef(MDToken.ToRID(typeof(Runtime).MetadataToken));
            //We use confuserEX InjectHelper class to inject EncryptionHelper class into our target, under <Module>
            IEnumerable<IDnlibDef> members = InjectHelper.Inject(typeDef, module.GlobalType, module);
            //We find the Decrypt() Method in EncryptionHelper we just injected
            init = (MethodDef)members.Single(method => method.Name == "GetColor");
            //we will call this method later

            //We just have to remove .ctor method because otherwise it will
            //lead to Global constructor error (e.g [MD]: Error: Global item (field,method) must be Static. [token:0x06000002] / [MD]: Error: Global constructor. [token:0x06000002] )
            foreach (MethodDef md in module.GlobalType.Methods)
            {
                if (md.Name == ".ctor")
                {
                    module.GlobalType.Remove(md);
                    //Now we go out of this mess
                    break;
                }
            }
        }
        static int num;
        public static int Encrypt(int u)
        {
            return u * 923;

        }
        public static void Process(ModuleDef module)
        {
            InjectClass(module);
            foreach (TypeDef type in module.GetTypes())
            {
                //we dont want to obfuscate the <Module> class ;)
                if (type.IsGlobalModuleType) continue;
                if (type.Name.Contains("Resources")) continue;
                if (type.Name.Contains("Settings")) continue;
                foreach (MethodDef method in type.Methods)
                {
                    //check if method has a method.Body
                    if (!method.HasBody) continue;
                    //lets go to the method now
                    var instr = method.Body.Instructions;
                    for (int i = 0; i < instr.Count; i++)
                    {
                        if (instr[i].OpCode == OpCodes.Call)
                        {
                            try
                            {

                                if (instr[i].ToString().Contains("System.Drawing.Color::get_White"))
                                {
                                    instr[i].OpCode = OpCodes.Ldstr;
                                    instr[i].Operand = "I I I I I I I I I I I I";
                                    instr.Insert(i + 1, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 2, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 3, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 4, Instruction.Create(OpCodes.Call, init));


                                }
                                if (instr[i].ToString().Contains("System.Drawing.Color::get_Black"))
                                {
                                    instr[i].OpCode = OpCodes.Ldstr;
                                    instr[i].Operand = "I I I I I I I I I I I";
                                    instr.Insert(i + 1, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 2, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 3, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 4, Instruction.Create(OpCodes.Call, init));



                                }
                                if (instr[i].ToString().Contains("System.Drawing.Color::get_Transparent"))
                                {
                                    instr[i].OpCode = OpCodes.Ldstr;
                                    instr[i].Operand = "                          ";
                                    instr.Insert(i + 1, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 2, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 3, Instruction.Create(OpCodes.Ldc_I4, random.Next(int.MinValue, int.MaxValue)));
                                    instr.Insert(i + 4, Instruction.Create(OpCodes.Call, init));


                                }

                            }
                            catch
                            {

                            }












                        }
                    }
                }
            }
        }
    }
}
