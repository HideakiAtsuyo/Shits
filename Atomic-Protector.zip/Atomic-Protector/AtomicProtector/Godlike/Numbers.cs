﻿using dnlib.DotNet;
using dnlib.DotNet.Emit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Protector.Godlike
{
    class Numbers
    {
        public static Random rnd = new Random();
        public static void Protect(ModuleDef md)
        {
            foreach(TypeDef type in md.Types)
            {
                foreach(MethodDef method in type.Methods)
                {
                    var instr = method.Body.Instructions;
                    for (int i = 0; i < instr.Count; i++)
                    {
                        if(instr[i].OpCode == OpCodes.Ldc_I4)
                        {
                            int num = rnd.Next(1, 10000);
                            int num1 = rnd.Next(1, 10000);
                            int num2 = rnd.Next(1, 10000);
                            int num3 = rnd.Next(1, 10000);


                            instr[i].Operand = (int)instr[i].Operand + num + num1 + num2 + num3;

                            instr.Insert(i + 1, Instruction.Create(OpCodes.Ldc_I4, num));
                            instr.Insert(i + 2, Instruction.Create(OpCodes.Sub));

                            instr.Insert(i + 3, Instruction.Create(OpCodes.Ldc_I4, num1));
                            instr.Insert(i + 4, Instruction.Create(OpCodes.Sub));

                            instr.Insert(i + 5, Instruction.Create(OpCodes.Ldc_I4, num2));
                            instr.Insert(i + 6, Instruction.Create(OpCodes.Sub));



                            instr.Insert(i + 7, Instruction.Create(OpCodes.Ldc_I4, num3));
                            instr.Insert(i + 8, Instruction.Create(OpCodes.Sub));

                            i += 8;




                        }
                    }
                }
            }
        }
    }
}
