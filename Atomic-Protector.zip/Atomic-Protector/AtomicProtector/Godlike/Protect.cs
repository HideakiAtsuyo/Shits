﻿using dnlib.DotNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Protector.Godlike
{
    class Protect
    {
        public static void Obfuscate(ModuleDef md)
        {

            Atomic_Obfuscator.Weak.Fields.Protect(md);

            foreach (TypeDef type in md.Types)
            {
                foreach (MethodDef method in type.Methods.ToArray())
                {

                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);
                }
            }
            Strong.Proxy.Execute(md);

            foreach (TypeDef type in md.GetTypes())
            {
       

                foreach (MethodDef method in type.Methods)
                {

                    if (!method.HasBody) continue;


                    var instr = method.Body.Instructions;
                    for (int i = 0; i < instr.Count; i++)
                    {
                        if(instr[i].IsLdcI4())
                        Atomic_Obfuscator.Normal.Numbers.SqrtReplacer(method, instr[i], ref i);
                    }
                }
            }

            for (int i = 0; i < 3; i++)
            {
                Numbers.Protect(md);

            }

            Atomic_Obfuscator.Weak.Numbers.String(md);

            foreach (TypeDef type in md.GetTypes())
            {


                foreach (MethodDef method in type.Methods)
                {

                    if (!method.HasBody) continue;


                    var instr = method.Body.Instructions;
                    for (int i = 0; i < instr.Count; i++)
                    {
                        if (instr[i].IsLdcI4())
                            Atomic_Obfuscator.Normal.Numbers.SqrtReplacer(method, instr[i], ref i);
                    }
                }
            }
            foreach (TypeDef type in md.Types)
            {
                foreach (MethodDef method in type.Methods.ToArray())
                {
                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);
                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);
                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);
                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);
                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);
                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);
                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);

                    Atomic_Obfuscator.Weak.Numbers.IfInliner(method);
                }
            }
            foreach (TypeDef type in md.GetTypes())
            {


                foreach (MethodDef method in type.Methods)
                {

                    if (!method.HasBody) continue;


                    var instr = method.Body.Instructions;
                    for (int i = 0; i < instr.Count; i++)
                    {
                        if (instr[i].IsLdcI4())
                            Atomic_Obfuscator.Normal.Numbers.SqrtReplacer(method, instr[i], ref i);
                    }
                }
            }
            Atomic_Obfuscator.Normal.Numbers.Sizeof(md);
            Atomic_Obfuscator.Normal.Numbers.Sizeof(md);
            Atomic_Obfuscator.Normal.Numbers.Sizeof(md);
            Atomic_Obfuscator.Normal.Numbers.Sizeof(md);
            Atomic_Obfuscator.Normal.Numbers.Sizeof(md);
            Atomic_Obfuscator.Normal.Numbers.Sizeof(md);
            Colors.Inject.Process(md);

            Atomic_Obfuscator.Normal.Assembly.MarkAssembly(md);

        }
    }
}
