﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using DiscordRPC;
using Siticone.UI.AnimatorNS;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;

namespace AtomicProtector
{

	public partial class Form1 : Form
	{
	
		[DllImport("user32")]
		private static extern bool AnimateWindow(IntPtr hwnd, int time, Form1.AnimateWindowFlags flags);

	
		public Form1()
		{
			this.InitializeComponent();
			this.siticoneShadowForm.SetShadowForm(this);
		}


		private void siticoneCircleProgressBar1_ValueChanged(object sender, EventArgs e)
		{
		}

	
		private void pictureBox_Click(object sender, EventArgs e)
		{
		}

	
		private void siticoneLabel1_Click(object sender, EventArgs e)
		{
			
		}


		private void siticoneButton11_Click(object sender, EventArgs e)
		{
		}

	
		private void siticoneButton6_Click(object sender, EventArgs e)
		{
		}

		private void siticoneRoundedTextBox1_TextChanged(object sender, EventArgs e)
		{
		}


		private void siticoneRoundedTextBox1_DragDrop(object sender, DragEventArgs e)
		{
		}


		private void siticoneLabel2_Click(object sender, EventArgs e)
		{
		}


		private void siticoneRoundedTextBox1_TextChanged_1(object sender, EventArgs e)
		{
		}

	
		private void siticoneRoundedTextBox1_KeyDown(object sender, KeyEventArgs e)
		{
		}

		
		private void Form1_Load(object sender, EventArgs e)
		{
		}

		
		private void label1_Click(object sender, EventArgs e)
		{
		}

		public DiscordRpcClient client;
		void Initialize()
		{
			client = new DiscordRpcClient("697457882014154802");
			client.Initialize();
			client.SetPresence(new RichPresence()
			{
				Details = "CRACKED ATOMIC",
				State = "OUTBUILT.OOO",
				Assets = new Assets()
				{
					LargeImageKey = "atomic",
					LargeImageText = "CRACKED ATOMIC",
					SmallImageKey = ""
				}
			});

		}
		
		private void siticoneRoundedButton1_Click(object sender, EventArgs e)
		{
			MessageBox.Show("THIS IS A SHIT OBFUSCATOR, DO NOT BUY IT", "OUTBUILT.OOO");
			Form2 f2 = new Form2();
			this.Hide();
			f2.Show();
;			
		}


		private void siticoneControlBox1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

	
		private enum AnimateWindowFlags : uint
		{
		
			AW_HOR_POSITIVE = 1U,

			AW_HOR_NEGATIVE,
			
			AW_VER_POSITIVE = 4U,
		
			AW_VER_NEGATIVE = 8U,
	
			AW_CENTER = 16U,
		
			AW_HIDE = 65536U,
	
			AW_ACTIVATE = 131072U,
		
			AW_SLIDE = 262144U,
		
			AW_BLEND = 524288U
		}
	}
}
