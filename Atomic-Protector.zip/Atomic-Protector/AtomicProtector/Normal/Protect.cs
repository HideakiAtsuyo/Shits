﻿using dnlib.DotNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Obfuscator.Normal
{
    class Protect
    {
        public static void Obfuscate(ModuleDef md)
        {
            Numbers.Sizeof(md);

            CFlow.CFlowProtect.Execute(md);

            Numbers.Protect(md);
            Weak.Numbers.String(md);

            foreach(TypeDef type in md.Types)
            {
                foreach (MethodDef method in type.Methods.ToArray())
                {
                    Weak.Proxy.StringOutliner(method);

                }
            }
            Weak.Fields.Protect(md);

            Assembly.MarkAssembly(md);

        }
    }
}
