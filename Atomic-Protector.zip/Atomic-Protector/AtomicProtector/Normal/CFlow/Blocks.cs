﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Obfuscator.Normal.CFlow
{
    class Blocks
    {
        public Block getBlock(int id)
        {
            return this.blocks.Single((Block block) => block.ID == id);
        }

        // Token: 0x060001AF RID: 431 RVA: 0x0000A3A4 File Offset: 0x000085A4
        public void Scramble(out Blocks incGroups)
        {
            Blocks blocks = new Blocks();
            foreach (Block item in this.blocks)
            {
                blocks.blocks.Insert(new Random(Guid.NewGuid().GetHashCode()).Next(blocks.blocks.Count), item);
            }
            incGroups = blocks;
        }

        // Token: 0x04000068 RID: 104
        public List<Block> blocks = new List<Block>();
    }
}
