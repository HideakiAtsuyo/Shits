﻿using dnlib.DotNet.Emit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Obfuscator.Normal.CFlow
{
    class Block
    {
        // Token: 0x04000065 RID: 101
        public int ID = 0;

        // Token: 0x04000066 RID: 102
        public int nextBlock = 0;

        // Token: 0x04000067 RID: 103
        public List<Instruction> instructions = new List<Instruction>();
    }
}
