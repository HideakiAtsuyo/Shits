﻿using dnlib.DotNet;
using dnlib.DotNet.Emit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Obfuscator.Normal.CFlow
{
    class CFlowProtect
    {
        public static void Execute(ModuleDef md)
        {
            foreach (TypeDef type in md.Types)
            {


                foreach (MethodDef methodDef in type.Methods)
                {
                    CFHelper cfhelper = new CFHelper();
                    bool flag = methodDef.HasBody && methodDef.Body.Instructions.Count > 0 && !methodDef.IsConstructor;
                    if (flag)
                    {
                        bool flag2 = !cfhelper.HasUnsafeInstructions(methodDef);
                        if (flag2)
                        {
                            bool flag3 = cfhelper.Simplify(methodDef);
                            if (flag3)
                            {
                                Blocks blocks = cfhelper.GetBlocks(methodDef);
                                bool flag4 = blocks.blocks.Count != 1;
                                if (flag4)
                                {
                                    blocks.Scramble(out blocks);
                                    methodDef.Body.Instructions.Clear();
                                    Local local = new Local(md.CorLibTypes.Int32);
                                    methodDef.Body.Variables.Add(local);
                                    Instruction instruction = Instruction.Create(OpCodes.Nop);
                                    Instruction instruction2 = Instruction.Create(OpCodes.Br, instruction);
                                    foreach (Instruction item in cfhelper.Calc(0))
                                    {
                                        methodDef.Body.Instructions.Add(item);
                                    }
                                    methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Stloc, local));
                                    methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Br, instruction2));
                                    methodDef.Body.Instructions.Add(instruction);
                                    foreach (Block block in blocks.blocks)
                                    {
                                        bool flag5 = block != blocks.getBlock(blocks.blocks.Count - 1);
                                        if (flag5)
                                        {
                                            methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Ldloc, local));
                                            foreach (Instruction item2 in cfhelper.Calc(block.ID))
                                            {
                                                methodDef.Body.Instructions.Add(item2);
                                            }
                                            methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Ceq));
                                            Instruction instruction3 = Instruction.Create(OpCodes.Nop);
                                            methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Brfalse, instruction3));
                                            foreach (Instruction item3 in block.instructions)
                                            {
                                                methodDef.Body.Instructions.Add(item3);
                                            }
                                            foreach (Instruction item4 in cfhelper.Calc(block.nextBlock))
                                            {
                                                methodDef.Body.Instructions.Add(item4);
                                            }
                                            methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Stloc, local));
                                            methodDef.Body.Instructions.Add(instruction3);
                                        }
                                    }
                                    methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Ldloc, local));
                                    foreach (Instruction item5 in cfhelper.Calc(blocks.blocks.Count - 1))
                                    {
                                        methodDef.Body.Instructions.Add(item5);
                                    }
                                    methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Ceq));
                                    methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Brfalse, instruction2));
                                    methodDef.Body.Instructions.Add(Instruction.Create(OpCodes.Br, blocks.getBlock(blocks.blocks.Count - 1).instructions[0]));
                                    methodDef.Body.Instructions.Add(instruction2);
                                    foreach (Instruction item6 in blocks.getBlock(blocks.blocks.Count - 1).instructions)
                                    {
                                        methodDef.Body.Instructions.Add(item6);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

