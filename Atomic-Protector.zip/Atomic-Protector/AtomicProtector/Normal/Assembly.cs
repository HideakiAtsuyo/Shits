﻿using dnlib.DotNet;
using dnlib.DotNet.Emit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Obfuscator.Normal
{
    class Assembly
    {
        public static Random random = new Random();
        public static string Random(int length)
        {
            const string chars = "qwertyuiopasdfghjklzxcqwer1234590tyuiopasdfghjklz1234567890cvbnmqwertyuiopasdfghjklzxcvbnmqwertyuiopasdfghjklzxcvbnmvbnm";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        public static bool CanRename(TypeDef type)
        {
            if (type.IsGlobalModuleType)
                return false;
            try
            {
                if (type.Namespace.Contains("My"))
                    return false;
            }
            catch { }
            if (type.IsGlobalModuleType)
                return false;
            if (type.Name == "GeneratedInternalTypeHelper" || type.Name == "Resources" || type.Name == "Settings")
                return false;

            if (type.Interfaces.Count > 0)
                return false;
            if (type.IsSpecialName)
                return false;
            if (type.IsRuntimeSpecialName)
                return false;
            else
                return true;
        }
        public static bool CanRename(EventDef ev)
        {
            if (ev.IsRuntimeSpecialName)
                return false;
            else
                return true;
        }
        public static bool CanRename(MethodDef method)
        {
            if (method.IsConstructor)
                return false;
            /* if (method.GetType().GetInterfaces().Count() > 0)
                 return false; */
            if (method.IsFamily)
                return false;
            if (method.IsRuntimeSpecialName)
                return false;
            if (method.DeclaringType.IsForwarder)
                return false;
            else
                return true;
        }
        public static bool CanRename(FieldDef field)
        {

            if (field.IsFamily || field.IsFamilyOrAssembly || field.IsPublic)
                return false;

            if (field.IsRuntimeSpecialName)
                return false;


             
            if (field.DeclaringType.IsSerializable && !field.IsNotSerialized)
                return false;

            if (field.IsLiteral && field.DeclaringType.IsEnum)
                return false;
            else
                return true;
        }


        public static void MarkAssembly(ModuleDef md)
        {
            md.Name = "𝔄𝔱𝔬𝔪𝔦𝔠 𝔒𝔟𝔣𝔲𝔰𝔠𝔞𝔱𝔬𝔯";
            md.Assembly.Name = "𝔄𝔱𝔬𝔪𝔦𝔠 𝔒𝔟𝔣𝔲𝔰𝔠𝔞𝔱𝔬𝔯";

            md.EntryPoint.DeclaringType = md.GlobalType;

            md.EntryPoint.Name = "AtomicLoad";

            var oldType = md.GlobalType;
            var newType = new TypeDefUser(oldType.Name);
            oldType.Name = "Atomic";
            oldType.BaseType = md.CorLibTypes.GetTypeRef("System", "Object");
            md.Types.Insert(0, newType);

            var old_cctor = oldType.FindOrCreateStaticConstructor();
            var cctor = newType.FindOrCreateStaticConstructor();
            old_cctor.Name = "Atomic";
            old_cctor.IsRuntimeSpecialName = false;
            old_cctor.IsSpecialName = false;
            old_cctor.Access = MethodAttributes.PrivateScope;
            cctor.Body = new CilBody(true, new List<Instruction>
            {
                Instruction.Create(OpCodes.Call, old_cctor),
                Instruction.Create(OpCodes.Ret)
            }, new List<ExceptionHandler>(), new List<Local>());



            for (var i = 0; i < oldType.Methods.Count; i++)
            {
                var nativeMethod = oldType.Methods[i];
                if (nativeMethod.IsNative)
                {
                    var methodStub = new MethodDefUser(nativeMethod.Name, nativeMethod.MethodSig.Clone());
                    methodStub.Attributes = MethodAttributes.Assembly | MethodAttributes.Static;
                    methodStub.Body = new CilBody();
                    methodStub.Body.Instructions.Add(new Instruction(OpCodes.Jmp, nativeMethod));
                    methodStub.Body.Instructions.Add(new Instruction(OpCodes.Ret));

                    oldType.Methods[i] = methodStub;
                    newType.Methods.Add(nativeMethod);

                }
            }

            foreach (TypeDef type in md.Types)
            {





                foreach (FieldDef field in type.Fields)
                {
                    if (CanRename(field))
                    {
                        int i = 1;
                        field.Name = "Atomic" + i.ToString();
                        i++;
                    }
                }
                foreach (EventDef events in type.Events)
                {
                    if (CanRename(events))
                    {
                        int i = 1;
                        events.Name = "Atomic" + i.ToString();
                        i++;
                    }

                }
                foreach (MethodDef method in type.Methods)
                {
                    if (CanRename(method))
                    {
                        int i = 1;
                        method.Name = "Atomic" + i.ToString();
                        i++;

                    }



                    foreach (var param in method.Parameters)
                    {
                        int i = 1;
                        param.Name = "Atomic" + i.ToString();
                        i++;
                    }
                    if (method.HasBody)
                    {
                        foreach (var varible in method.Body.Variables)
                        {
                            int i = 1;
                            varible.Name = "Atomic" + i.ToString();
                            i++;
                        }
                    }

                    foreach (var param in ((MethodDef)method).GenericParameters)
                        param.Name = ((char)(param.Number + 1)).ToString();

                }
            }


        }
    }
}
