﻿using dnlib.DotNet;
using dnlib.DotNet.Emit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atomic_Obfuscator.Normal
{
    class Numbers
    {
        public static MethodDef init1;

        public static void InjectClass(ModuleDef module)
        {
            //We declare our Module, here we want to load the EncryptionHelper class
            ModuleDefMD typeModule = ModuleDefMD.Load(typeof(Runtime).Module);
            //We declare EncryptionHelper as a TypeDef using it's Metadata token (needed)
            TypeDef typeDef = typeModule.ResolveTypeDef(MDToken.ToRID(typeof(Runtime).MetadataToken));
            //We use confuserEX InjectHelper class to inject EncryptionHelper class into our target, under <Module>
            IEnumerable<IDnlibDef> members = InjectHelper.Inject(typeDef, module.GlobalType, module);
            //We find the Decrypt() Method in EncryptionHelper we just injected
            init1 = (MethodDef)members.Single(method => method.Name == "Double");

            //we will call this method later

            //We just have to remove .ctor method because otherwise it will
            //lead to Global constructor error (e.g [MD]: Error: Global item (field,method) must be Static. [token:0x06000002] / [MD]: Error: Global constructor. [token:0x06000002] )
            foreach (MethodDef md in module.GlobalType.Methods)
            {
                if (md.Name == ".ctor")
                {
                    module.GlobalType.Remove(md);
                    //Now we go out of this mess
                    break;
                }
            }
        }


        public static CilBody body;
        public static Random rndx = new Random();
        public static void Sizeof(ModuleDef md)
        {

            foreach (ModuleDef module in md.Assembly.Modules)
            {
                foreach (TypeDef type in module.Types)
                {

                    if (type.Namespace.Contains(".My")) continue;
                    foreach (MethodDef method in type.Methods)
                    {
                        if (method.HasBody && method.Body.HasInstructions)
                        {
                            for (int i = 0; i < method.Body.Instructions.Count; i++)
                            {
                                if (method.Body.Instructions[i].OpCode == OpCodes.Ldc_I4)
                                {
                                    body = method.Body;
                                    int atual = body.Instructions[i].GetLdcI4Value();
                                    int sub = rndx.Next(1, 3);
                                    int calculado = atual - sub;
                                    body.Instructions[i].Operand = calculado;
                                    Start(i, sub, calculado, md, method);
                                }
                            }
                        }
                    }
                }
            }
        }
        public static void Start(int i, int sub, int calculado, ModuleDef md, MethodDef method)
        {
            switch (sub)
            {
                case 1:
                    //CORRECT
                    Local local_1 = new Local(md.CorLibTypes.Object);
                    Local local_2 = new Local(md.CorLibTypes.Object);
                    Local local_3 = new Local(md.CorLibTypes.Object);
                    Local local_4 = new Local(md.CorLibTypes.Object);
                    method.Body.Variables.Add(local_1);
                    method.Body.Variables.Add(local_2);
                    method.Body.Variables.Add(local_3);
                    method.Body.Variables.Add(local_4);
                    body.Instructions.Insert(i + 1, new Instruction(OpCodes.Sizeof, md.Import(typeof(GCNotificationStatus))));
                    body.Instructions.Insert(i + 2, new Instruction(OpCodes.Stloc_S, local_1));
                    body.Instructions.Insert(i + 3, new Instruction(OpCodes.Ldloc_S, local_1));
                    body.Instructions.Insert(i + 4, OpCodes.Add.ToInstruction());
                    body.Instructions.Insert(i + 5, new Instruction(OpCodes.Sizeof, md.Import(typeof(SByte))));
                    body.Instructions.Insert(i + 6, new Instruction(OpCodes.Stloc_S, local_2));
                    body.Instructions.Insert(i + 7, new Instruction(OpCodes.Ldloc_S, local_2));
                    body.Instructions.Insert(i + 8, OpCodes.Sub.ToInstruction());
                    body.Instructions.Insert(i + 9, new Instruction(OpCodes.Sizeof, md.Import(typeof(SByte))));
                    body.Instructions.Insert(i + 10, new Instruction(OpCodes.Stloc_S, local_3));
                    body.Instructions.Insert(i + 11, new Instruction(OpCodes.Ldloc_S, local_3));
                    body.Instructions.Insert(i + 12, OpCodes.Sub.ToInstruction());
                    body.Instructions.Insert(i + 13, new Instruction(OpCodes.Sizeof, md.Import(typeof(SByte))));
                    body.Instructions.Insert(i + 14, new Instruction(OpCodes.Stloc_S, local_4));
                    body.Instructions.Insert(i + 15, new Instruction(OpCodes.Ldloc_S, local_4));
                    body.Instructions.Insert(i + 16, OpCodes.Sub.ToInstruction());
                    break;
                case 2:
                    //CORRECT
                    local_1 = new Local(md.CorLibTypes.Object);
                    method.Body.Variables.Add(local_1);

                    body.Instructions.Insert(i + 1, new Instruction(OpCodes.Sizeof, md.Import(typeof(char))));
                    body.Instructions.Insert(i + 2, new Instruction(OpCodes.Stloc_S, local_1));
                    body.Instructions.Insert(i + 3, new Instruction(OpCodes.Ldloc_S, local_1));
                    body.Instructions.Insert(i + 4, OpCodes.Add.ToInstruction());
                    break;
                case 3:
                    local_1 = new Local(md.CorLibTypes.Object);
                    local_2 = new Local(md.CorLibTypes.Object);
                    method.Body.Variables.Add(local_1);
                    method.Body.Variables.Add(local_2);
                    body.Instructions.Insert(i + 1, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(System.Int32))));
                    body.Instructions.Insert(i + 2, new Instruction(OpCodes.Stloc_S, local_1));
                    body.Instructions.Insert(i + 3, new Instruction(OpCodes.Ldloc_S, local_1));
                    body.Instructions.Insert(i + 4, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(byte))));
                    body.Instructions.Insert(i + 5, new Instruction(OpCodes.Stloc_S, local_2));
                    body.Instructions.Insert(i + 6, new Instruction(OpCodes.Ldloc_S, local_2));
                    body.Instructions.Insert(i + 7, Instruction.Create(OpCodes.Sub));
                    body.Instructions.Insert(i + 8, Instruction.Create(OpCodes.Add));
                    break;
                case 4:
                    local_1 = new Local(md.CorLibTypes.Object);
                    local_2 = new Local(md.CorLibTypes.Object);
                    local_3 = new Local(md.CorLibTypes.Object);
                    local_4 = new Local(md.CorLibTypes.Object);
                    method.Body.Variables.Add(local_1);
                    method.Body.Variables.Add(local_2);
                    method.Body.Variables.Add(local_3);
                    method.Body.Variables.Add(local_4);
                    body.Instructions.Insert(i + 1, Instruction.Create(OpCodes.Add));
                    body.Instructions.Insert(i + 2, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(System.Decimal))));
                    body.Instructions.Insert(i + 3, new Instruction(OpCodes.Stloc_S, local_1));
                    body.Instructions.Insert(i + 4, new Instruction(OpCodes.Ldloc_S, local_1));
                    body.Instructions.Insert(i + 5, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(System.GCCollectionMode))));
                    body.Instructions.Insert(i + 6, new Instruction(OpCodes.Stloc_S, local_2));
                    body.Instructions.Insert(i + 7, new Instruction(OpCodes.Ldloc_S, local_2));
                    body.Instructions.Insert(i + 8, Instruction.Create(OpCodes.Sub));
                    body.Instructions.Insert(i + 9, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(System.Int32))));
                    body.Instructions.Insert(i + 10, new Instruction(OpCodes.Stloc_S, local_3));
                    body.Instructions.Insert(i + 11, new Instruction(OpCodes.Ldloc_S, local_3));
                    body.Instructions.Insert(i + 12, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(byte))));
                    body.Instructions.Insert(i + 13, new Instruction(OpCodes.Stloc_S, local_4));
                    body.Instructions.Insert(i + 14, new Instruction(OpCodes.Ldloc_S, local_4));
                    body.Instructions.Insert(i + 15, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(byte))));
                    body.Instructions.Insert(i + 16, new Instruction(OpCodes.Stloc_S, local_1));
                    body.Instructions.Insert(i + 17, new Instruction(OpCodes.Ldloc_S, local_1));
                    body.Instructions.Insert(i + 18, Instruction.Create(OpCodes.Sub));
                    body.Instructions.Insert(i + 19, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(byte))));
                    body.Instructions.Insert(i + 20, new Instruction(OpCodes.Stloc_S, local_2));
                    body.Instructions.Insert(i + 21, new Instruction(OpCodes.Ldloc_S, local_2));
                    body.Instructions.Insert(i + 22, Instruction.Create(OpCodes.Sizeof, md.Import(typeof(byte))));
                    body.Instructions.Insert(i + 23, new Instruction(OpCodes.Stloc_S, local_2));
                    body.Instructions.Insert(i + 24, new Instruction(OpCodes.Ldloc_S, local_2));
                    body.Instructions.Insert(i + 25, Instruction.Create(OpCodes.Add));
                    break;
                case 5:
                    local_1 = new Local(md.CorLibTypes.Object);
                    local_2 = new Local(md.CorLibTypes.Object);
                    method.Body.Variables.Add(local_1);
                    method.Body.Variables.Add(local_2);
                    body.Instructions.Insert(i + 1, new Instruction(OpCodes.Sizeof, md.Import(typeof(System.EnvironmentVariableTarget))));
                    body.Instructions.Insert(i + 2, Instruction.Create(OpCodes.Stloc_S, local_1));
                    body.Instructions.Insert(i + 3, Instruction.Create(OpCodes.Ldloc_S, local_1));
                    body.Instructions.Insert(i + 4, OpCodes.Add.ToInstruction());
                    body.Instructions.Insert(i + 5, new Instruction(OpCodes.Sizeof, md.Import(typeof(SByte))));
                    body.Instructions.Insert(i + 6, Instruction.Create(OpCodes.Stloc_S, local_2));
                    body.Instructions.Insert(i + 7, Instruction.Create(OpCodes.Ldloc_S, local_2));
                    body.Instructions.Insert(i + 9, OpCodes.Add.ToInstruction());
                    break;

            }
        }
        private static Random rnd = new Random();
        public static bool CanObfuscateLDCI4(IList<Instruction> instructions, int i)
        {
            if (instructions[i + 1].GetOperand() != null)
                if (instructions[i + 1].Operand.ToString().Contains("bool"))
                    return false;
            if (instructions[i + 1].OpCode == OpCodes.Newobj)
                return false;
            if (instructions[i].GetLdcI4Value() == 0 || instructions[i].GetLdcI4Value() == 1)
                return false;


            return true;
        }
        public static void EmptyType(MethodDef method, ref int i)
        {
            if (method.Body.Instructions[i].IsLdcI4())
            {
                int operand = method.Body.Instructions[i].GetLdcI4Value();
                method.Body.Instructions[i].Operand = operand - Type.EmptyTypes.Length;
                method.Body.Instructions[i].OpCode = OpCodes.Ldc_I4;
                method.Body.Instructions.Insert(i + 1, OpCodes.Ldsfld.ToInstruction(method.Module.Import(typeof(Type).GetField("EmptyTypes"))));
                method.Body.Instructions.Insert(i + 2, Instruction.Create(OpCodes.Ldlen));
                method.Body.Instructions.Insert(i + 3, Instruction.Create(OpCodes.Add));
            }
        }
        public static void IfInliner(MethodDef method)
        {
            Local local = new Local(method.Module.ImportAsTypeSig(typeof(int)));
            method.Body.Variables.Add(local);
            for (int i = 0; i < method.Body.Instructions.Count; i++)
            {
                if (method.Body.Instructions[i].IsLdcI4())
                {
                    if (CanObfuscateLDCI4(method.Body.Instructions, i))
                    {
                        int numorig = rnd.Next();
                        int div = rnd.Next();
                        int num = numorig ^ div;

                        Instruction nop = OpCodes.Nop.ToInstruction();
                        method.Body.Instructions.Insert(i + 1, OpCodes.Stloc_S.ToInstruction(local));
                        method.Body.Instructions.Insert(i + 2, Instruction.Create(OpCodes.Ldc_I4, method.Body.Instructions[i].GetLdcI4Value() - sizeof(float)));
                        method.Body.Instructions.Insert(i + 3, Instruction.Create(OpCodes.Ldc_I4, num));
                        method.Body.Instructions.Insert(i + 4, Instruction.Create(OpCodes.Ldc_I4, div));
                        method.Body.Instructions.Insert(i + 5, Instruction.Create(OpCodes.Xor));
                        method.Body.Instructions.Insert(i + 6, Instruction.Create(OpCodes.Ldc_I4, numorig));
                        method.Body.Instructions.Insert(i + 7, Instruction.Create(OpCodes.Bne_Un, nop));
                        method.Body.Instructions.Insert(i + 8, Instruction.Create(OpCodes.Ldc_I4, 2));
                        method.Body.Instructions.Insert(i + 9, OpCodes.Stloc_S.ToInstruction(local));
                        method.Body.Instructions.Insert(i + 10, Instruction.Create(OpCodes.Sizeof, method.Module.Import(typeof(float))));
                        method.Body.Instructions.Insert(i + 11, Instruction.Create(OpCodes.Add));
                        method.Body.Instructions.Insert(i + 12, nop);
                        i += 12;
                    }
                }
            }
        }

        public static void SqrtReplacer(MethodDef method, Instruction instruction, ref int i)
        {
            try
            {
                if (instruction.Operand != null)
                    if (instruction.IsLdcI4())
                    {
                        if (instruction.GetLdcI4Value() < int.MaxValue)
                        {
                            if ((int)instruction.Operand > 1)
                            {
                                int orig = (int)instruction.Operand;
                                double m = (double)orig * orig;
                                instruction.OpCode = OpCodes.Ldc_R8;
                                instruction.Operand = m;
                                method.Body.Instructions.Insert(i + 1, OpCodes.Call.ToInstruction(method.Module.Import(typeof(Math).GetMethod("Sqrt", new Type[] { typeof(double) }))));
                                method.Body.Instructions.Insert(i + 2, OpCodes.Conv_I4.ToInstruction());
                            }
                        }
                    }
            }
            catch { }
        }


        public static void Protect(ModuleDef md)
        {
            InjectClass(md);
            foreach (TypeDef type in md.Types)
            {
                foreach (MethodDef method in type.Methods)
                {
                    if (!method.HasBody) continue;
                    //this makes shit goated will be saved for godlike
                    // IfInliner(method);

                  

                    var instr = method.Body.Instructions;
                    for (int i = 0; i < instr.Count; i++)
                    {
                        EmptyType(method, ref i);

                          SqrtReplacer(method, instr[i], ref i);


                    }

                    bool flag = method.FullName.Contains("My.");
                    if (!flag)
                    {
                        bool isConstructor = method.IsConstructor;
                        if (!isConstructor)
                        {
                            bool flag2 = !method.HasBody;
                            if (!flag2)
                            {
                                for (int i = 0; i < method.Body.Instructions.Count; i++)
                                {
                                 
                                  
                                        bool flag4 = method.Body.Instructions[i].OpCode == OpCodes.Ldc_I4_S;
                                        if (flag4)
                                        {
                                            string s2 = method.Body.Instructions[i].Operand.ToString();
                                            method.Body.Instructions[i].OpCode = OpCodes.Nop;
                                            method.Body.Instructions.Insert(++i, Instruction.Create(OpCodes.Ldstr, s2));
                                            method.Body.Instructions.Insert(++i, Instruction.Create(OpCodes.Call, method.Module.Import(typeof(short).GetMethod("Parse", new Type[]
                                            {
                                            typeof(string)
                                            }))));
                                        }
                                        else
                                        {
                                            bool flag5 = method.Body.Instructions[i].OpCode == OpCodes.Ldc_I8;
                                            if (flag5)
                                            {
                                                string s3 = method.Body.Instructions[i].Operand.ToString();
                                                method.Body.Instructions[i].OpCode = OpCodes.Nop;
                                                method.Body.Instructions.Insert(++i, Instruction.Create(OpCodes.Ldstr, s3));
                                                method.Body.Instructions.Insert(++i, Instruction.Create(OpCodes.Call, method.Module.Import(typeof(long).GetMethod("Parse", new Type[]
                                                {
                                                typeof(string)
                                                }))));
                                            }
                                          
                                            
                                        }
                                    
                                }
                            }
                        }
                    }

                }
            }
        }
    }
}
