﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Reflection;
using System.Windows.Forms;
using dnlib.DotNet;
using dnlib.DotNet.Writer;
using Siticone.UI.WinForms;
using Siticone.UI.WinForms.Enums;

namespace AtomicProtector
{
	
	public partial class Form2 : Form
	{

		public Form2()
		{
			this.InitializeComponent();
		}

	
		private void siticoneCheckBox1_CheckedChanged(object sender, EventArgs e)
		{
		}

	
		private void siticoneRoundedComboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

	
		private void siticoneRoundedTextBox1_TextChanged(object sender, EventArgs e)
		{
		}


	
		private void Form2_Load(object sender, EventArgs e)
		{
		}

	
		


		private void siticoneRoundedButton1_Click(object sender, EventArgs e)
		{
            if (siticoneRoundedTextBox1.Text == string.Empty)
            {
                MessageBox.Show("No application to obfuscate, please drag one in." ,"AtomicProtector", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ModuleDef md = ModuleDefMD.Load(siticoneRoundedTextBox1.Text);

            if (siticoneRoundedComboBox1.SelectedIndex == 0)
            {
				Atomic_Protector.Godlike.Protect.Obfuscate(md);


			}

			if (siticoneRoundedComboBox1.SelectedIndex == 1)
			{
				Atomic_Obfuscator.Normal.Protect.Obfuscate(md);
			}

			if (siticoneRoundedComboBox1.SelectedIndex == 2)
			{
				Atomic_Protector.Strong.Protect.Obfuscate(md);
			}

			if (siticoneRoundedComboBox1.SelectedIndex == 3)
			{
				Atomic_Obfuscator.Weak.Protect.Obfuscate(md);
			}
			if (checkBox1.Checked == true)
			{
				Atomic_Protector.Virt.Inject.InvalidMD(md);
			}

			md.Write(".\\AtomicProtected\\" + Path.GetFileName(this.siticoneRoundedTextBox1.Text), new ModuleWriterOptions(md)
			{
				PEHeadersOptions =
				{
					NumberOfRvaAndSizes = new uint?(13U)
				},
				MetaDataOptions =
				{
					TablesHeapOptions =
					{
						ExtraData = new uint?(4919U)
					}
				},
				Logger = DummyLogger.NoThrowInstance
			});


		}


        private void siticoneControlBox1_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

	
		private void siticoneLabel1_Click(object sender, EventArgs e)
		{
		}

        private void siticoneLabel3_Click(object sender, EventArgs e)
        {
        }

		private void siticoneLabel2_Click(object sender, EventArgs e)
		{

		}

		private void siticoneControlBox2_Click(object sender, EventArgs e)
		{

		}

		private void checkBox1_CheckedChanged(object sender, EventArgs e)
		{

		}

		private void siticoneRoundedTextBox1_DragDrop(object sender, DragEventArgs e)
		{
			try
			{
				Array array = (Array)e.Data.GetData(DataFormats.FileDrop);
				if (array != null)
				{
					string path = array.GetValue(0).ToString();
					int num = path.LastIndexOf(".");
					if (num != -1)
					{
						string extension = path.Substring(num).ToLower();
						if (extension == ".exe" || extension == ".dll")
						{
							Activate();
							siticoneRoundedTextBox1.Text = path;
						}
					}
				}
			}
			catch { }
		}

		private void siticoneRoundedTextBox1_DragEnter(object sender, DragEventArgs e)
		{
			if (e.Data.GetDataPresent(DataFormats.FileDrop))
				e.Effect = DragDropEffects.Copy;
			else
				e.Effect = DragDropEffects.None;
		}
	}
}
