﻿using System;

// Token: 0x02000001 RID: 1
internal class <Module>
{
	// Token: 0x06000002 RID: 2 RVA: 0x00002068 File Offset: 0x00000268
	private static void 59222B04()
	{
	}
}
