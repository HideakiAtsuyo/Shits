﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("AtomicProtector9.0")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyProduct("AtomicProtector9.0")]
[assembly: AssemblyTitle("AtomicProtector9.0")]
[assembly: AssemblyTrademark("AtomicProtector9.0")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: SuppressIldasm]
[assembly: ComVisible(false)]
[assembly: Guid("72a9a3cc-2760-4d44-9dee-7f0a7310d3ae")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
