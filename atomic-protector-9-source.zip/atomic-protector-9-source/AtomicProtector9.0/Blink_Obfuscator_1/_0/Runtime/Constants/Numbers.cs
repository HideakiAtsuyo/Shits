﻿using System;

namespace Blink_Obfuscator_1._0.Runtime.Constants
{
	// Token: 0x02000011 RID: 17
	internal class Numbers
	{
		// Token: 0x06000036 RID: 54 RVA: 0x00004224 File Offset: 0x00002424
		public static uint blinkobfuscator101010(uint num, string blink, string blink1)
		{
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num *= 69U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num /= 69U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num /= 69U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num = num / 2U * 2U / 2U * 2U;
			num /= 2U;
			return num;
		}

		// Token: 0x06000037 RID: 55 RVA: 0x000044CC File Offset: 0x000026CC
		public static float blinkobfuscator10101(float num, string blink, string blink1)
		{
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num *= 69f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num /= 69f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num /= 69f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num = num / 2f * 2f / 2f * 2f;
			num /= 2f;
			return num;
		}
	}
}
