﻿using System;

namespace Blink_Obfuscator_1._0
{
	// Token: 0x02000005 RID: 5
	internal class Settings
	{
		// Token: 0x04000009 RID: 9
		public static bool Constants = false;

		// Token: 0x0400000A RID: 10
		public static bool Constant_Mutation = false;

		// Token: 0x0400000B RID: 11
		public static bool Renamer = false;

		// Token: 0x0400000C RID: 12
		public static bool ControlFlow = false;

		// Token: 0x0400000D RID: 13
		public static bool StringEncryption = false;

		// Token: 0x0400000E RID: 14
		public static bool DisConstants = false;

		// Token: 0x0400000F RID: 15
		public static bool RefProxy = false;

		// Token: 0x04000010 RID: 16
		public static bool LocalToFields = false;

		// Token: 0x04000011 RID: 17
		public static bool AntiDe4dot = false;

		// Token: 0x04000012 RID: 18
		public static bool SizeOf = false;

		// Token: 0x04000013 RID: 19
		public static bool StackUnderflow = false;

		// Token: 0x04000014 RID: 20
		public static bool AntiILdasm = false;

		// Token: 0x04000015 RID: 21
		public static bool KoiVMFakeSig = false;

		// Token: 0x04000016 RID: 22
		public static bool Packer = false;

		// Token: 0x04000017 RID: 23
		public static bool AntiDump = false;

		// Token: 0x04000018 RID: 24
		public static bool NumberToString = false;

		// Token: 0x04000019 RID: 25
		public static bool InvalidMetadata = false;

		// Token: 0x0400001A RID: 26
		public static bool AntiHTTPDebugger = false;

		// Token: 0x0400001B RID: 27
		public static bool AntiFiddler = false;

		// Token: 0x0400001C RID: 28
		public static bool Calli = false;

		// Token: 0x0400001D RID: 29
		public static bool Strong = false;

		// Token: 0x0400001E RID: 30
		public static bool Weak = false;

		// Token: 0x0400001F RID: 31
		public static bool StrongRenamer = true;

		// Token: 0x04000020 RID: 32
		public static bool StrongLoadNumbers = true;

		// Token: 0x04000021 RID: 33
		public static bool StrongLoadStrings = true;

		// Token: 0x04000022 RID: 34
		public static bool StrongLoadField = true;

		// Token: 0x04000023 RID: 35
		public static bool StrongLoadMethods = true;

		// Token: 0x04000024 RID: 36
		public static bool StrongControlFlow = true;

		// Token: 0x04000025 RID: 37
		public static bool StrongEntryPoint = true;

		// Token: 0x04000026 RID: 38
		public static bool WeakRenamer = true;

		// Token: 0x04000027 RID: 39
		public static bool WeakLoadNumbers = true;

		// Token: 0x04000028 RID: 40
		public static bool WeakLoadStrings = true;

		// Token: 0x04000029 RID: 41
		public static bool WeakLoadField = true;

		// Token: 0x0400002A RID: 42
		public static bool WeakControlFlow = true;
	}
}
