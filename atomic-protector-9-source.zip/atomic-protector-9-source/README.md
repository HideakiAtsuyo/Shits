# atomic-protector-9-source
source posted since this guy is selling open source protections from other obfuscators, ConfuserEx, ConfuserEx Modded, etc
