/*     */ package club.minnced.opus.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NativeUtil
/*     */ {
/*     */   public NativeUtil() {
/*  39 */     this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void loadLibraryFromJar(Object youcangetnoinfoAHWWД8а3Р) throws IOException {
/*  55 */     if (!youcangetnoinfoAHWWД8а3Р.startsWith("/")) {
/*  56 */       throw new IllegalArgumentException("The path has to be absolute (start with '/').");
/*     */     }
/*     */ 
/*     */     
/*  60 */     Object youcangetnoinfoAHWXБ2фГщ = youcangetnoinfoAHWWД8а3Р.split("/");
/*  61 */     Object youcangetnoinfoAHWYЗ6Цзь = (youcangetnoinfoAHWXБ2фГщ.length > 1) ? youcangetnoinfoAHWXБ2фГщ[youcangetnoinfoAHWXБ2фГщ.length - 1] : null;
/*     */ 
/*     */     
/*  64 */     Object youcangetnoinfoAHWZалзмГ = "";
/*  65 */     Object youcangetnoinfoAHXAэБ1йФ = null;
/*  66 */     if (youcangetnoinfoAHWYЗ6Цзь != null) {
/*  67 */       youcangetnoinfoAHWXБ2фГщ = youcangetnoinfoAHWYЗ6Цзь.split("\\.", 2);
/*  68 */       youcangetnoinfoAHWZалзмГ = youcangetnoinfoAHWXБ2фГщ[0];
/*  69 */       youcangetnoinfoAHXAэБ1йФ = (youcangetnoinfoAHWXБ2фГщ.length > 1) ? ("." + youcangetnoinfoAHWXБ2фГщ[youcangetnoinfoAHWXБ2фГщ.length - 1]) : null;
/*     */     } 
/*     */ 
/*     */     
/*  73 */     if (youcangetnoinfoAHWYЗ6Цзь == null || youcangetnoinfoAHWZалзмГ.length() < 3) {
/*  74 */       throw new IllegalArgumentException("The filename has to be at least 3 characters long.");
/*     */     }
/*     */ 
/*     */     
/*  78 */     Object youcangetnoinfoAHXBаЦ5Кы = File.createTempFile((String)youcangetnoinfoAHWZалзмГ, (String)youcangetnoinfoAHXAэБ1йФ);
/*  79 */     youcangetnoinfoAHXBаЦ5Кы.deleteOnExit();
/*     */     
/*  81 */     if (!youcangetnoinfoAHXBаЦ5Кы.exists()) {
/*  82 */       throw new FileNotFoundException("File " + youcangetnoinfoAHXBаЦ5Кы.getAbsolutePath() + " does not exist.");
/*     */     }
/*     */ 
/*     */     
/*  86 */     Object youcangetnoinfoAHXCЩХБ1к = new byte[1024];
/*     */ 
/*     */ 
/*     */     
/*  90 */     Object youcangetnoinfoAHXEб1тКя = NativeUtil.class.getResourceAsStream((String)youcangetnoinfoAHWWД8а3Р);
/*  91 */     if (youcangetnoinfoAHXEб1тКя == null) {
/*  92 */       throw new FileNotFoundException("File " + youcangetnoinfoAHWWД8а3Р + " was not found inside JAR.");
/*     */     }
/*     */ 
/*     */     
/*  96 */     Object youcangetnoinfoAHXFНУнсВ = new FileOutputStream((File)youcangetnoinfoAHXBаЦ5Кы); try {
/*     */       int i;
/*  98 */       while ((i = youcangetnoinfoAHXEб1тКя.read((byte[])youcangetnoinfoAHXCЩХБ1к)) != -1) {
/*  99 */         youcangetnoinfoAHXFНУнсВ.write((byte[])youcangetnoinfoAHXCЩХБ1к, 0, i);
/*     */       }
/*     */     } finally {
/*     */       
/* 103 */       youcangetnoinfoAHXFНУнсВ.close();
/* 104 */       youcangetnoinfoAHXEб1тКя.close();
/*     */     } 
/*     */ 
/*     */     
/* 108 */     System.load(youcangetnoinfoAHXBаЦ5Кы.getAbsolutePath());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\club\minnced\opu\\util\NativeUtil.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */