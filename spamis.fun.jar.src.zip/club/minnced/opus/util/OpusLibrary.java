/*     */ package club.minnced.opus.util;
/*     */ 
/*     */ import com.sun.jna.Platform;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OpusLibrary
/*     */ {
/*     */   public static final Map<String, String> platforms;
/*     */   public static boolean initialized = false;
/*     */   public static final String SUPPORTED_SYSTEMS;
/*     */   
/*     */   static {
/*  32 */     platforms = new HashMap<>(10);
/*  33 */     platforms.put("darwin", "dylib");
/*  34 */     platforms.put("linux-arm", "so");
/*  35 */     platforms.put("linux-aarch64", "so");
/*  36 */     platforms.put("linux-x86", "so");
/*  37 */     platforms.put("linux-x86-64", "so");
/*  38 */     platforms.put("win32-x86", "dll");
/*  39 */     platforms.put("win32-x86-64", "dll");
/*  40 */     SUPPORTED_SYSTEMS = "Supported Systems: " + platforms.keySet() + "\nCurrent Operating system: " + Platform.RESOURCE_PREFIX;
/*     */   }
/*     */   public OpusLibrary() {
/*  43 */     this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List<String> getSupportedPlatforms() {
/*  52 */     return Collections.unmodifiableList(new ArrayList<>(platforms.keySet()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isSupportedPlatform() {
/*  61 */     return platforms.containsKey(Platform.RESOURCE_PREFIX);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean isInitialized() {
/*  71 */     return initialized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean loadFrom(Object youcangetnoinfoDPLRйржпы) {
/*  84 */     if (initialized)
/*  85 */       return false; 
/*  86 */     System.load((String)youcangetnoinfoDPLRйржпы);
/*  87 */     System.setProperty("opus.lib", (String)youcangetnoinfoDPLRйржпы);
/*  88 */     return initialized = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean loadFromJar() throws IOException {
/* 103 */     if (initialized)
/* 104 */       return false; 
/* 105 */     Object youcangetnoinfoAMUYГЙчжу = "";
/*     */ 
/*     */     
/*     */     try {
/* 109 */       Object youcangetnoinfoAMUVЦшж9Е = Platform.RESOURCE_PREFIX;
/* 110 */       Object youcangetnoinfoAMUWШпЦэц = platforms.get(youcangetnoinfoAMUVЦшж9Е);
/* 111 */       if (youcangetnoinfoAMUWШпЦэц == null) {
/* 112 */         throw new UnsupportedOperationException(SUPPORTED_SYSTEMS);
/*     */       }
/* 114 */       Object youcangetnoinfoAMUXыдЯеЬ = String.format("/natives/%s/libopus.%s", new Object[] { youcangetnoinfoAMUVЦшж9Е, youcangetnoinfoAMUWШпЦэц });
/* 115 */       NativeUtil.loadLibraryFromJar((String)youcangetnoinfoAMUXыдЯеЬ);
/* 116 */       youcangetnoinfoAMUYГЙчжу = youcangetnoinfoAMUXыдЯеЬ;
/* 117 */       initialized = true;
/*     */     } finally {
/* 119 */       System.setProperty("opus.lib", (String)youcangetnoinfoAMUYГЙчжу);
/*     */     } 
/* 121 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\club\minnced\opu\\util\OpusLibrary.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */