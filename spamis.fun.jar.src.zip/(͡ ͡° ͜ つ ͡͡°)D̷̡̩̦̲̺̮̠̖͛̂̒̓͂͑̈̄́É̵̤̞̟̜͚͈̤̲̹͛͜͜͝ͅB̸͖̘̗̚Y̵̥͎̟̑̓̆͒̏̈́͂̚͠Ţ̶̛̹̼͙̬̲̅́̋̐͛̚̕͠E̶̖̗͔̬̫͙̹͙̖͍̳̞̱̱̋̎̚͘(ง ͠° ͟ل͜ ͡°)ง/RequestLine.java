/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.net.Proxy;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RequestLine
/*    */ {
/*    */   public RequestLine() {
/* 24 */     this();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String get(Object youcangetnoinfoLZUчьоДу, Object youcangetnoinfoLZVЯП6Зы) {
/* 33 */     Object youcangetnoinfoLZW8ёЪ8Р = new StringBuilder();
/* 34 */     youcangetnoinfoLZW8ёЪ8Р.append(youcangetnoinfoLZUчьоДу.method());
/* 35 */     youcangetnoinfoLZW8ёЪ8Р.append(' ');
/*    */     
/* 37 */     if (includeAuthorityInRequestLine((Request)youcangetnoinfoLZUчьоДу, (Proxy.Type)youcangetnoinfoLZVЯП6Зы)) {
/* 38 */       youcangetnoinfoLZW8ёЪ8Р.append(youcangetnoinfoLZUчьоДу.url());
/*    */     } else {
/* 40 */       youcangetnoinfoLZW8ёЪ8Р.append(requestPath(youcangetnoinfoLZUчьоДу.url()));
/*    */     } 
/*    */     
/* 43 */     youcangetnoinfoLZW8ёЪ8Р.append(" HTTP/1.1");
/* 44 */     return youcangetnoinfoLZW8ёЪ8Р.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean includeAuthorityInRequestLine(Object youcangetnoinfoDAMEтЛнлЩ, Object youcangetnoinfoDAMFэМв6Ь) {
/* 52 */     return (!youcangetnoinfoDAMEтЛнлЩ.isHttps() && youcangetnoinfoDAMFэМв6Ь == Proxy.Type.HTTP);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String requestPath(Object youcangetnoinfoCPEOЙЯЗИЁ) {
/* 60 */     Object youcangetnoinfoCPEPЩС7Бг = youcangetnoinfoCPEOЙЯЗИЁ.encodedPath();
/* 61 */     Object youcangetnoinfoCPEQСЧъЗй = youcangetnoinfoCPEOЙЯЗИЁ.encodedQuery();
/* 62 */     return (youcangetnoinfoCPEQСЧъЗй != null) ? (youcangetnoinfoCPEPЩС7Бг + '?' + youcangetnoinfoCPEQСЧъЗй) : (String)youcangetnoinfoCPEPЩС7Бг;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RequestLine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */