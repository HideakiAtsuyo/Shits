/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CacheInterceptor
/*     */   implements Interceptor
/*     */ {
/*     */   @Nullable
/*     */   public final InternalCache cache;
/*     */   
/*     */   public CacheInterceptor(@Nullable Object youcangetnoinfoDGWёэДБН) {
/*  49 */     this();
/*  50 */     ((CacheInterceptor)super).cache = (InternalCache)youcangetnoinfoDGWёэДБН;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Response intercept(Object youcangetnoinfoDYRS2ЬИую) throws IOException {
/*  56 */     Object youcangetnoinfoDYRTрШг0г = (((CacheInterceptor)super).cache != null) ? ((CacheInterceptor)super).cache.get(youcangetnoinfoDYRS2ЬИую.request()) : null;
/*     */     
/*  58 */     long l = System.currentTimeMillis();
/*     */     
/*  60 */     Object youcangetnoinfoDYRVЬвгХЦ = (new CacheStrategy1(l, youcangetnoinfoDYRS2ЬИую.request(), (Response)youcangetnoinfoDYRTрШг0г)).get();
/*  61 */     Object youcangetnoinfoDYRW4фЙт5 = ((CacheStrategy)youcangetnoinfoDYRVЬвгХЦ).networkRequest;
/*  62 */     Object youcangetnoinfoDYRX3д5нЕ = ((CacheStrategy)youcangetnoinfoDYRVЬвгХЦ).cacheResponse;
/*     */     
/*  64 */     if (((CacheInterceptor)super).cache != null) {
/*  65 */       ((CacheInterceptor)super).cache.trackResponse((CacheStrategy)youcangetnoinfoDYRVЬвгХЦ);
/*     */     }
/*     */     
/*  68 */     if (youcangetnoinfoDYRTрШг0г != null && youcangetnoinfoDYRX3д5нЕ == null) {
/*  69 */       Util1.closeQuietly(youcangetnoinfoDYRTрШг0г.body());
/*     */     }
/*     */ 
/*     */     
/*  73 */     if (youcangetnoinfoDYRW4фЙт5 == null && youcangetnoinfoDYRX3д5нЕ == null) {
/*  74 */       return (new Response1())
/*  75 */         .request(youcangetnoinfoDYRS2ЬИую.request())
/*  76 */         .protocol(Protocol.HTTP_1_1)
/*  77 */         .code(504)
/*  78 */         .message("Unsatisfiable Request (only-if-cached)")
/*  79 */         .body(Util1.EMPTY_RESPONSE)
/*  80 */         .sentRequestAtMillis(-1L)
/*  81 */         .receivedResponseAtMillis(System.currentTimeMillis())
/*  82 */         .build();
/*     */     }
/*     */ 
/*     */     
/*  86 */     if (youcangetnoinfoDYRW4фЙт5 == null) {
/*  87 */       return youcangetnoinfoDYRX3д5нЕ.newBuilder()
/*  88 */         .cacheResponse(stripBody((Response)youcangetnoinfoDYRX3д5нЕ))
/*  89 */         .build();
/*     */     }
/*     */     
/*  92 */     Object youcangetnoinfoDYRY4ЮВле = null;
/*     */     try {
/*  94 */       youcangetnoinfoDYRY4ЮВле = youcangetnoinfoDYRS2ЬИую.proceed((Request)youcangetnoinfoDYRW4фЙт5);
/*     */     } finally {
/*     */       
/*  97 */       if (youcangetnoinfoDYRY4ЮВле == null && youcangetnoinfoDYRTрШг0г != null) {
/*  98 */         Util1.closeQuietly(youcangetnoinfoDYRTрШг0г.body());
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 103 */     if (youcangetnoinfoDYRX3д5нЕ != null) {
/* 104 */       if (youcangetnoinfoDYRY4ЮВле.code() == 304) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 111 */         Object youcangetnoinfoDYRPЭТЮбЮ = youcangetnoinfoDYRX3д5нЕ.newBuilder().headers(combine(youcangetnoinfoDYRX3д5нЕ.headers(), youcangetnoinfoDYRY4ЮВле.headers())).sentRequestAtMillis(youcangetnoinfoDYRY4ЮВле.sentRequestAtMillis()).receivedResponseAtMillis(youcangetnoinfoDYRY4ЮВле.receivedResponseAtMillis()).cacheResponse(stripBody((Response)youcangetnoinfoDYRX3д5нЕ)).networkResponse(stripBody((Response)youcangetnoinfoDYRY4ЮВле)).build();
/* 112 */         youcangetnoinfoDYRY4ЮВле.body().close();
/*     */ 
/*     */ 
/*     */         
/* 116 */         ((CacheInterceptor)super).cache.trackConditionalCacheHit();
/* 117 */         ((CacheInterceptor)super).cache.update((Response)youcangetnoinfoDYRX3д5нЕ, (Response)youcangetnoinfoDYRPЭТЮбЮ);
/* 118 */         return (Response)youcangetnoinfoDYRPЭТЮбЮ;
/*     */       } 
/* 120 */       Util1.closeQuietly(youcangetnoinfoDYRX3д5нЕ.body());
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     Object youcangetnoinfoDYRZ4ГЖэл = youcangetnoinfoDYRY4ЮВле.newBuilder().cacheResponse(stripBody((Response)youcangetnoinfoDYRX3д5нЕ)).networkResponse(stripBody((Response)youcangetnoinfoDYRY4ЮВле)).build();
/*     */     
/* 129 */     if (((CacheInterceptor)super).cache != null) {
/* 130 */       if (HttpHeaders.hasBody((Response)youcangetnoinfoDYRZ4ГЖэл) && CacheStrategy.isCacheable((Response)youcangetnoinfoDYRZ4ГЖэл, (Request)youcangetnoinfoDYRW4фЙт5)) {
/*     */         
/* 132 */         Object youcangetnoinfoDYRQ98ГаЬ = ((CacheInterceptor)super).cache.put((Response)youcangetnoinfoDYRZ4ГЖэл);
/* 133 */         return super.cacheWritingResponse((CacheRequest)youcangetnoinfoDYRQ98ГаЬ, (Response)youcangetnoinfoDYRZ4ГЖэл);
/*     */       } 
/*     */       
/* 136 */       if (HttpMethod.invalidatesCache(youcangetnoinfoDYRW4фЙт5.method())) {
/*     */         try {
/* 138 */           ((CacheInterceptor)super).cache.remove((Request)youcangetnoinfoDYRW4фЙт5);
/* 139 */         } catch (IOException iOException) {}
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 145 */     return (Response)youcangetnoinfoDYRZ4ГЖэл;
/*     */   }
/*     */   
/*     */   public static Response stripBody(Object youcangetnoinfoADUSУщЭЧ0) {
/* 149 */     return (youcangetnoinfoADUSУщЭЧ0 != null && youcangetnoinfoADUSУщЭЧ0.body() != null) ? 
/* 150 */       youcangetnoinfoADUSУщЭЧ0.newBuilder().body(null).build() : 
/* 151 */       (Response)youcangetnoinfoADUSУщЭЧ0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response cacheWritingResponse(Object youcangetnoinfoDVWDСь9хр, Object youcangetnoinfoDVWEРжпшр) throws IOException {
/* 162 */     if (youcangetnoinfoDVWDСь9хр == null) return (Response)youcangetnoinfoDVWEРжпшр; 
/* 163 */     Object youcangetnoinfoDVWFЮх5Цю = youcangetnoinfoDVWDСь9хр.body();
/* 164 */     if (youcangetnoinfoDVWFЮх5Цю == null) return (Response)youcangetnoinfoDVWEРжпшр;
/*     */     
/* 166 */     Object youcangetnoinfoDVWGЪ2аьё = youcangetnoinfoDVWEРжпшр.body().source();
/* 167 */     Object youcangetnoinfoDVWHЮеЯвю = Okio1.buffer((Sink)youcangetnoinfoDVWFЮх5Цю);
/*     */     
/* 169 */     Object youcangetnoinfoDVWIУ5вР8 = new CacheInterceptor1((CacheInterceptor)this, (BufferedSource)youcangetnoinfoDVWGЪ2аьё, (CacheRequest)youcangetnoinfoDVWDСь9хр, (BufferedSink)youcangetnoinfoDVWHЮеЯвю);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 211 */     Object youcangetnoinfoDVWJАЧЫУЛ = youcangetnoinfoDVWEРжпшр.header("Content-Type");
/* 212 */     long l = youcangetnoinfoDVWEРжпшр.body().contentLength();
/* 213 */     return youcangetnoinfoDVWEРжпшр.newBuilder()
/* 214 */       .body(new RealResponseBody((String)youcangetnoinfoDVWJАЧЫУЛ, l, Okio1.buffer((Source)youcangetnoinfoDVWIУ5вР8)))
/* 215 */       .build();
/*     */   }
/*     */ 
/*     */   
/*     */   public static Headers combine(Object youcangetnoinfoAXFJЧ3Йо7, Object youcangetnoinfoAXFKщ6Нше) {
/* 220 */     Object youcangetnoinfoAXFLОШНЭЗ = new Headers1(); byte b2;
/*     */     int j;
/* 222 */     for (b2 = 0, j = youcangetnoinfoAXFJЧ3Йо7.size(); b2 < j; b2++) {
/* 223 */       Object youcangetnoinfoAXFCтЩджЦ = youcangetnoinfoAXFJЧ3Йо7.name(b2);
/* 224 */       Object youcangetnoinfoAXFDькаТп = youcangetnoinfoAXFJЧ3Йо7.value(b2);
/* 225 */       if (!"Warning".equalsIgnoreCase((String)youcangetnoinfoAXFCтЩджЦ) || !youcangetnoinfoAXFDькаТп.startsWith("1"))
/*     */       {
/*     */         
/* 228 */         if (isContentSpecificHeader((String)youcangetnoinfoAXFCтЩджЦ) || 
/* 229 */           !isEndToEnd((String)youcangetnoinfoAXFCтЩджЦ) || youcangetnoinfoAXFKщ6Нше
/* 230 */           .get((String)youcangetnoinfoAXFCтЩджЦ) == null)
/* 231 */           Internal.instance.addLenient((Headers1)youcangetnoinfoAXFLОШНЭЗ, (String)youcangetnoinfoAXFCтЩджЦ, (String)youcangetnoinfoAXFDькаТп);  } 
/*     */     } 
/*     */     byte b1;
/*     */     int i;
/* 235 */     for (b1 = 0, i = youcangetnoinfoAXFKщ6Нше.size(); b1 < i; b1++) {
/* 236 */       Object youcangetnoinfoAXFGеГУл2 = youcangetnoinfoAXFKщ6Нше.name(b1);
/* 237 */       if (!isContentSpecificHeader((String)youcangetnoinfoAXFGеГУл2) && isEndToEnd((String)youcangetnoinfoAXFGеГУл2)) {
/* 238 */         Internal.instance.addLenient((Headers1)youcangetnoinfoAXFLОШНЭЗ, (String)youcangetnoinfoAXFGеГУл2, youcangetnoinfoAXFKщ6Нше.value(b1));
/*     */       }
/*     */     } 
/*     */     
/* 242 */     return youcangetnoinfoAXFLОШНЭЗ.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isEndToEnd(Object youcangetnoinfoEGCO3ЯЛж9) {
/* 250 */     return (!"Connection".equalsIgnoreCase((String)youcangetnoinfoEGCO3ЯЛж9) && 
/* 251 */       !"Keep-Alive".equalsIgnoreCase((String)youcangetnoinfoEGCO3ЯЛж9) && 
/* 252 */       !"Proxy-Authenticate".equalsIgnoreCase((String)youcangetnoinfoEGCO3ЯЛж9) && 
/* 253 */       !"Proxy-Authorization".equalsIgnoreCase((String)youcangetnoinfoEGCO3ЯЛж9) && 
/* 254 */       !"TE".equalsIgnoreCase((String)youcangetnoinfoEGCO3ЯЛж9) && 
/* 255 */       !"Trailers".equalsIgnoreCase((String)youcangetnoinfoEGCO3ЯЛж9) && 
/* 256 */       !"Transfer-Encoding".equalsIgnoreCase((String)youcangetnoinfoEGCO3ЯЛж9) && 
/* 257 */       !"Upgrade".equalsIgnoreCase((String)youcangetnoinfoEGCO3ЯЛж9));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isContentSpecificHeader(Object youcangetnoinfoAIMSТшшвя) {
/* 265 */     return ("Content-Length".equalsIgnoreCase((String)youcangetnoinfoAIMSТшшвя) || "Content-Encoding"
/* 266 */       .equalsIgnoreCase((String)youcangetnoinfoAIMSТшшвя) || "Content-Type"
/* 267 */       .equalsIgnoreCase((String)youcangetnoinfoAIMSТшшвя));
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\CacheInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */