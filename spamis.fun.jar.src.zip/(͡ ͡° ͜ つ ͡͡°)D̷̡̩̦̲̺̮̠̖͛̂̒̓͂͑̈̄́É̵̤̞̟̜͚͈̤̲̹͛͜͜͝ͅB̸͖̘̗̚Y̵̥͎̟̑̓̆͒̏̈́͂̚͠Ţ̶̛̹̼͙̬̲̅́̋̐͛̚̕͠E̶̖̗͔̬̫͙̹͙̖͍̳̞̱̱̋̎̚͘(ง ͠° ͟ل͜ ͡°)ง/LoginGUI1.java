/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import fun.spamis.spammer.SpamIsFun;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Toolkit;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import javax.crypto.BadPaddingException;
/*     */ import javax.crypto.IllegalBlockSizeException;
/*     */ import javax.crypto.NoSuchPaddingException;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoginGUI1
/*     */   extends JFrame
/*     */ {
/*     */   public static final long serialVersionUID = 1L;
/*     */   public JPasswordField password;
/*     */   public JPanel contentPane;
/*     */   public JTextField user;
/*     */   
/*     */   public LoginGUI1() throws NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, IOException, NoSuchPaddingException, BadPaddingException {
/*  57 */     setTitle("spamis.fun - version: " + SpamIsFun.version);
/*  58 */     setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/ui/icon.png")));
/*  59 */     setResizable(false);
/*  60 */     setDefaultCloseOperation(3);
/*  61 */     setBounds(100, 100, 458, 269);
/*  62 */     setLocationRelativeTo(null);
/*  63 */     ((LoginGUI1)super).contentPane = new JPanel();
/*  64 */     ((LoginGUI1)super).contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
/*  65 */     setContentPane(((LoginGUI1)super).contentPane);
/*  66 */     ((LoginGUI1)super).contentPane.setLayout((LayoutManager)null);
/*     */     
/*  68 */     Object youcangetnoinfoENZBФБглО = new JLabel("Username:");
/*  69 */     youcangetnoinfoENZBФБглО.setFont(new Font("Dialog", 0, 14));
/*  70 */     youcangetnoinfoENZBФБглО.setBounds(25, 21, 119, 23);
/*  71 */     ((LoginGUI1)super).contentPane.add((Component)youcangetnoinfoENZBФБглО);
/*     */     
/*  73 */     ((LoginGUI1)super).user = new JTextField();
/*  74 */     ((LoginGUI1)super).user.setColumns(10);
/*  75 */     ((LoginGUI1)super).user.setBounds(147, 12, 292, 32);
/*  76 */     ((LoginGUI1)super).contentPane.add(((LoginGUI1)super).user);
/*     */     
/*  78 */     Object youcangetnoinfoENZCЕЧяПО = new JLabel("Password:");
/*  79 */     youcangetnoinfoENZCЕЧяПО.setFont(new Font("Dialog", 0, 14));
/*  80 */     youcangetnoinfoENZCЕЧяПО.setBounds(25, 69, 119, 23);
/*  81 */     ((LoginGUI1)super).contentPane.add((Component)youcangetnoinfoENZCЕЧяПО);
/*     */     
/*  83 */     ((LoginGUI1)super).password = new JPasswordField();
/*  84 */     ((LoginGUI1)super).password.setBounds(147, 60, 292, 32);
/*  85 */     ((LoginGUI1)super).contentPane.add(((LoginGUI1)super).password);
/*     */     
/*  87 */     Object youcangetnoinfoENZDбй9Ще = new JLabel("Hardware-ID:");
/*  88 */     youcangetnoinfoENZDбй9Ще.setFont(new Font("Dialog", 0, 14));
/*  89 */     youcangetnoinfoENZDбй9Ще.setBounds(25, 116, 119, 23);
/*  90 */     ((LoginGUI1)super).contentPane.add((Component)youcangetnoinfoENZDбй9Ще);
/*     */     
/*  92 */     Object youcangetnoinfoENZEПуОШи = new JTextField(SecurityUtils.getHWID2());
/*  93 */     youcangetnoinfoENZEПуОШи.setColumns(10);
/*  94 */     youcangetnoinfoENZEПуОШи.setBounds(147, 107, 292, 32);
/*  95 */     youcangetnoinfoENZEПуОШи.setEditable(false);
/*  96 */     ((LoginGUI1)super).contentPane.add((Component)youcangetnoinfoENZEПуОШи);
/*     */     
/*  98 */     Object youcangetnoinfoENZFСвб6Ю = new JCheckBox("Remember me");
/*  99 */     youcangetnoinfoENZFСвб6Ю.setBounds(147, 157, 227, 23);
/* 100 */     ((LoginGUI1)super).contentPane.add((Component)youcangetnoinfoENZFСвб6Ю);
/*     */     
/* 102 */     Object youcangetnoinfoENZGауЩЧ3 = new JButton("Login");
/* 103 */     youcangetnoinfoENZGауЩЧ3.setBounds(25, 197, 414, 32);
/* 104 */     youcangetnoinfoENZGауЩЧ3.addActionListener(new LoginGUI2((LoginGUI1)this, (JButton)youcangetnoinfoENZGауЩЧ3, (JCheckBox)youcangetnoinfoENZFСвб6Ю));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 208 */     ((LoginGUI1)super).contentPane.add((Component)youcangetnoinfoENZGауЩЧ3);
/*     */ 
/*     */     
/* 211 */     if ((new File(SpamIsFun.homeDir + "remember.spamisfun")).exists())
/*     */       
/*     */       try {
/* 214 */         Object youcangetnoinfoENYY63цшЦ = FileUtils.readFile(SpamIsFun.homeDir + "remember.spamisfun").split("\n");
/* 215 */         ((LoginGUI1)super).user.setText(SecurityUtils.AESdecoder((String)youcangetnoinfoENYY63цшЦ[0]));
/* 216 */         ((LoginGUI1)super).password.setText(SecurityUtils.AESdecoder((String)youcangetnoinfoENYY63цшЦ[1]));
/* 217 */         youcangetnoinfoENZFСвб6Ю.setSelected(true);
/* 218 */       } catch (IOException|InvalidKeyException|NoSuchAlgorithmException|NoSuchPaddingException|IllegalBlockSizeException|BadPaddingException youcangetnoinfoENYZ2дын4) {
/*     */         
/* 220 */         youcangetnoinfoENYZ2дын4.printStackTrace();
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\LoginGUI1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */