/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import com.formdev.flatlaf.FlatLaf;
/*     */ import com.formdev.flatlaf.IntelliJTheme;
/*     */ import fun.spamis.spammer.SpamIsFun;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Toolkit;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JTabbedPane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SpamisfunGUI8
/*     */   extends JFrame
/*     */ {
/*     */   public final DMSpammer3 dmSpammerPanel;
/*     */   public final GuildJoiner1 guildJoinerPanel;
/*     */   public final TypingSpammer2 typingSpammerPanel;
/*  38 */   public static JTabbedPane tabbedPane = new JTabbedPane(); public static final long serialVersionUID = 1136343231045357257L; public final ReactionSpammer3 reactionSpammerPanel; public final FriendSpammer6 friendSpammerPanel;
/*     */   
/*     */   public SpamisfunGUI8() {
/*  41 */     ((SpamisfunGUI8)super).dashboardPanel = new Dashboard2();
/*  42 */     ((SpamisfunGUI8)super).guildJoinerPanel = new GuildJoiner1();
/*  43 */     ((SpamisfunGUI8)super).serverSpammerPanel = new ServerSpammer5();
/*  44 */     ((SpamisfunGUI8)super).friendSpammerPanel = new FriendSpammer6();
/*  45 */     ((SpamisfunGUI8)super).reactionSpammerPanel = new ReactionSpammer3();
/*  46 */     ((SpamisfunGUI8)super).typingSpammerPanel = new TypingSpammer2();
/*  47 */     ((SpamisfunGUI8)super).guildLeaverPanel = new GuildLeaver2();
/*  48 */     ((SpamisfunGUI8)super).dmSpammerPanel = new DMSpammer3();
/*     */ 
/*     */     
/*  51 */     super.initialize();
/*     */   }
/*     */   public final GuildLeaver2 guildLeaverPanel; public final Dashboard2 dashboardPanel; public final ServerSpammer5 serverSpammerPanel; public static JLabel logoLbl;
/*     */   public void initialize() {
/*  55 */     getContentPane().setLayout((LayoutManager)null);
/*  56 */     setTitle("spamis.fun - version: " + SpamIsFun.version);
/*  57 */     setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/ui/icon.png")));
/*  58 */     setBounds(100, 100, 581, 422);
/*  59 */     setResizable(false);
/*  60 */     setLocationRelativeTo(null);
/*  61 */     setDefaultCloseOperation(3);
/*     */ 
/*     */     
/*  64 */     Object youcangetnoinfoSHAн3z1z = new JMenuBar();
/*  65 */     setJMenuBar((JMenuBar)youcangetnoinfoSHAн3z1z);
/*  66 */     Object youcangetnoinfoSHBzЧ5Аь = new JMenu("Proxys");
/*  67 */     youcangetnoinfoSHAн3z1z.add((JMenu)youcangetnoinfoSHBzЧ5Аь);
/*  68 */     Object youcangetnoinfoSHCлЩЦБр = new JMenu("Tokens");
/*  69 */     youcangetnoinfoSHAн3z1z.add((JMenu)youcangetnoinfoSHCлЩЦБр);
/*  70 */     Object youcangetnoinfoSHDЪьэПя = new JMenu("Help");
/*  71 */     youcangetnoinfoSHAн3z1z.add((JMenu)youcangetnoinfoSHDЪьэПя);
/*     */     
/*  73 */     Object youcangetnoinfoSHE4мУзЁ = new JMenuItem("Manager");
/*  74 */     youcangetnoinfoSHE4мУзЁ.addActionListener(new SpamisfunGUI7((SpamisfunGUI8)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     youcangetnoinfoSHBzЧ5Аь.add((JMenuItem)youcangetnoinfoSHE4мУзЁ);
/*     */     
/*  83 */     Object youcangetnoinfoSHF8тъЦ4 = new JMenuItem("Manager");
/*  84 */     youcangetnoinfoSHF8тъЦ4.addActionListener(new SpamisfunGUI1((SpamisfunGUI8)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  91 */     youcangetnoinfoSHCлЩЦБр.add((JMenuItem)youcangetnoinfoSHF8тъЦ4);
/*     */     
/*  93 */     Object youcangetnoinfoSHGПюХак = new JMenuItem("How to create tokens?");
/*  94 */     youcangetnoinfoSHGПюХак.addActionListener(new SpamisfunGUI((SpamisfunGUI8)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     youcangetnoinfoSHDЪьэПя.add((JMenuItem)youcangetnoinfoSHGПюХак);
/* 107 */     Object youcangetnoinfoSHHцТ8тт = new JMenuItem("How to use this tool?");
/* 108 */     youcangetnoinfoSHHцТ8тт.addActionListener(new SpamisfunGUI6((SpamisfunGUI8)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     youcangetnoinfoSHDЪьэПя.add((JMenuItem)youcangetnoinfoSHHцТ8тт);
/* 121 */     youcangetnoinfoSHDЪьэПя.addSeparator();
/* 122 */     Object youcangetnoinfoSHIьГДпЙ = new JMenuItem("Free https proxies");
/* 123 */     youcangetnoinfoSHIьГДпЙ.addActionListener(new SpamisfunGUI3((SpamisfunGUI8)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     youcangetnoinfoSHDЪьэПя.add((JMenuItem)youcangetnoinfoSHIьГДпЙ);
/* 136 */     Object youcangetnoinfoSHJЗёДдв = new JMenuItem("Online proxy checker 1");
/* 137 */     youcangetnoinfoSHJЗёДдв.addActionListener(new SpamisfunGUI2((SpamisfunGUI8)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     youcangetnoinfoSHDЪьэПя.add((JMenuItem)youcangetnoinfoSHJЗёДдв);
/* 150 */     Object youcangetnoinfoSHKжбэКе = new JMenuItem("Online proxy checker 2");
/* 151 */     youcangetnoinfoSHKжбэКе.addActionListener(new SpamisfunGUI4((SpamisfunGUI8)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 163 */     youcangetnoinfoSHDЪьэПя.add((JMenuItem)youcangetnoinfoSHKжбэКе);
/* 164 */     youcangetnoinfoSHDЪьэПя.addSeparator();
/* 165 */     Object youcangetnoinfoSHLПбЗzв = new JMenuItem("Create support ticket");
/* 166 */     youcangetnoinfoSHLПбЗzв.addActionListener(new SpamisfunGUI5((SpamisfunGUI8)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     youcangetnoinfoSHDЪьэПя.add((JMenuItem)youcangetnoinfoSHLПбЗzв);
/*     */ 
/*     */     
/* 181 */     tabbedPane = new JTabbedPane(2);
/* 182 */     tabbedPane.setBounds(0, 0, 581, 373);
/* 183 */     tabbedPane.setTabPlacement(2);
/* 184 */     getContentPane().add(tabbedPane);
/*     */     
/* 186 */     tabbedPane.addTab("Home", new ImageIcon(getClass().getResource("/ui/home.png")), ((SpamisfunGUI8)super).dashboardPanel, "Look at your stats and change the program theme.");
/* 187 */     tabbedPane.addTab("Guild Joiner", new ImageIcon(getClass().getResource("/ui/join.png")), ((SpamisfunGUI8)super).guildJoinerPanel, "Invite the bots to a server.");
/* 188 */     tabbedPane.addTab("Guild Leaver", new ImageIcon(getClass().getResource("/ui/leave.png")), ((SpamisfunGUI8)super).guildLeaverPanel, "Let the bots leave a server.");
/* 189 */     tabbedPane.addTab("Server Spammer", new ImageIcon(getClass().getResource("/ui/serverspam.png")), ((SpamisfunGUI8)super).serverSpammerPanel, "Send messages to a server channel.");
/* 190 */     tabbedPane.addTab("Friend Spammer", new ImageIcon(getClass().getResource("/ui/friend.png")), ((SpamisfunGUI8)super).friendSpammerPanel, "Send friend requests to users.");
/* 191 */     tabbedPane.addTab("Reaction Spammer", new ImageIcon(getClass().getResource("/ui/like.png")), ((SpamisfunGUI8)super).reactionSpammerPanel, "Add reactions to messages.");
/* 192 */     tabbedPane.addTab("Typing Spammer", new ImageIcon(getClass().getResource("/ui/typing.png")), ((SpamisfunGUI8)super).typingSpammerPanel, "Let the bots send a typing event to a server channel.");
/*     */   }
/*     */ 
/*     */   
/*     */   public static void changeTheme(Object youcangetnoinfoDBWVСддс0) {
/* 197 */     IntelliJTheme.install(SpamIsFun.class.getResourceAsStream("/ui/" + youcangetnoinfoDBWVСддс0 + ".json"));
/* 198 */     FlatLaf.updateUI();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\SpamisfunGUI8.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */