/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class WebSocketListener
/*    */ {
/*    */   public WebSocketListener() {
/* 21 */     this();
/*    */   }
/*    */   
/*    */   public void onOpen(Object youcangetnoinfoUAZе1швЗ, Object youcangetnoinfoUBAАдЗС1) {}
/*    */   
/*    */   public void onMessage(Object youcangetnoinfoDXCJыш9аИ, Object youcangetnoinfoDXCKюШвтБ) {}
/*    */   
/*    */   public void onMessage(Object youcangetnoinfoBNBXрДПцщ, Object youcangetnoinfoBNBYШЗпЁТ) {}
/*    */   
/*    */   public void onClosing(Object youcangetnoinfoELKЛ24ЭЖ, Object youcangetnoinfoELLПБеёй, Object youcangetnoinfoELMыёеЮ5) {}
/*    */   
/*    */   public void onClosed(Object youcangetnoinfoACSCжХй0Б, Object youcangetnoinfoACSD4ЭэкЛ, Object youcangetnoinfoACSEЁтЮРф) {}
/*    */   
/*    */   public void onFailure(Object youcangetnoinfoAZELЧщЕЮz, Object youcangetnoinfoAZEMаПРУу, @Nullable Object youcangetnoinfoAZENЮьфМз) {}
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\WebSocketListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */