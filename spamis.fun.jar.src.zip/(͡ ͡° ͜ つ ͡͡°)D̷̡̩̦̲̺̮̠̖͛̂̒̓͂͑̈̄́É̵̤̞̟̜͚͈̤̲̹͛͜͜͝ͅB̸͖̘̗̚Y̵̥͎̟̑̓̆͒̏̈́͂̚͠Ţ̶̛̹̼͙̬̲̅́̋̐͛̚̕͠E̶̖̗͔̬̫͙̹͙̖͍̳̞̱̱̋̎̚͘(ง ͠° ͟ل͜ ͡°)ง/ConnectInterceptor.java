/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ConnectInterceptor
/*    */   implements Interceptor
/*    */ {
/*    */   public final OkHttpClient client;
/*    */   
/*    */   public ConnectInterceptor(Object youcangetnoinfoBRSN5лжЕз) {
/* 31 */     this();
/* 32 */     ((ConnectInterceptor)super).client = (OkHttpClient)youcangetnoinfoBRSN5лжЕз;
/*    */   }
/*    */   
/*    */   public Response intercept(Object youcangetnoinfoAUXZ9сНзЫ) throws IOException {
/* 36 */     Object youcangetnoinfoAUYAмшЛоЁ = youcangetnoinfoAUXZ9сНзЫ;
/* 37 */     Object youcangetnoinfoAUYB2Вед9 = youcangetnoinfoAUYAмшЛоЁ.request();
/* 38 */     Object youcangetnoinfoAUYCвЁХхЖ = youcangetnoinfoAUYAмшЛоЁ.streamAllocation();
/*    */ 
/*    */     
/* 41 */     boolean bool = !youcangetnoinfoAUYB2Вед9.method().equals("GET") ? true : false;
/* 42 */     Object youcangetnoinfoAUYEвЖЪвя = youcangetnoinfoAUYCвЁХхЖ.newStream(((ConnectInterceptor)super).client, (Interceptor1)youcangetnoinfoAUXZ9сНзЫ, bool);
/* 43 */     Object youcangetnoinfoAUYFЁПЁт9 = youcangetnoinfoAUYCвЁХхЖ.connection();
/*    */     
/* 45 */     return youcangetnoinfoAUYAмшЛоЁ.proceed((Request)youcangetnoinfoAUYB2Вед9, (StreamAllocation1)youcangetnoinfoAUYCвЁХхЖ, (HttpCodec)youcangetnoinfoAUYEвЖЪвя, (RealConnection1)youcangetnoinfoAUYFЁПЁт9);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ConnectInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */