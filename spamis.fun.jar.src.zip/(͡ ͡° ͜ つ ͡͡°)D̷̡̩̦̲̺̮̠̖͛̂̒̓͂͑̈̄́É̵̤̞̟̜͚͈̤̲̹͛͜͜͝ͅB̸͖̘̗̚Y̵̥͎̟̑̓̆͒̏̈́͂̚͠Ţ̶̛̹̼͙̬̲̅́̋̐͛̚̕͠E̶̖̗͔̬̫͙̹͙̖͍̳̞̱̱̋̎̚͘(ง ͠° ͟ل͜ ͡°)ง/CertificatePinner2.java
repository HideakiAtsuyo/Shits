/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CertificatePinner2
/*     */ {
/*     */   public static final String WILDCARD = "*.";
/*     */   public final String pattern;
/*     */   public final String canonicalHostname;
/*     */   public final String hashAlgorithm;
/*     */   public final ByteString hash;
/*     */   
/*     */   public CertificatePinner2(Object youcangetnoinfoCVKAцёЯоЩ, Object youcangetnoinfoCVKBФЛрНц) {
/* 268 */     this();
/* 269 */     ((CertificatePinner2)super).pattern = (String)youcangetnoinfoCVKAцёЯоЩ;
/* 270 */     ((CertificatePinner2)super)
/*     */       
/* 272 */       .canonicalHostname = youcangetnoinfoCVKAцёЯоЩ.startsWith("*.") ? HttpUrl1.get("http://" + youcangetnoinfoCVKAцёЯоЩ.substring("*.".length())).host() : HttpUrl1.get("http://" + youcangetnoinfoCVKAцёЯоЩ).host();
/* 273 */     if (youcangetnoinfoCVKBФЛрНц.startsWith("sha1/")) {
/* 274 */       ((CertificatePinner2)super).hashAlgorithm = "sha1/";
/* 275 */       ((CertificatePinner2)super).hash = ByteString.decodeBase64(youcangetnoinfoCVKBФЛрНц.substring("sha1/".length()));
/* 276 */     } else if (youcangetnoinfoCVKBФЛрНц.startsWith("sha256/")) {
/* 277 */       ((CertificatePinner2)super).hashAlgorithm = "sha256/";
/* 278 */       ((CertificatePinner2)super).hash = ByteString.decodeBase64(youcangetnoinfoCVKBФЛрНц.substring("sha256/".length()));
/*     */     } else {
/* 280 */       throw new IllegalArgumentException("pins must start with 'sha256/' or 'sha1/': " + youcangetnoinfoCVKBФЛрНц);
/*     */     } 
/*     */     
/* 283 */     if (((CertificatePinner2)super).hash == null) {
/* 284 */       throw new IllegalArgumentException("pins must be base64: " + youcangetnoinfoCVKBФЛрНц);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean matches(Object youcangetnoinfoNDXиНэта) {
/* 289 */     if (((CertificatePinner2)super).pattern.startsWith("*.")) {
/* 290 */       int i = youcangetnoinfoNDXиНэта.indexOf('.');
/* 291 */       return (youcangetnoinfoNDXиНэта.length() - i - 1 == ((CertificatePinner2)super).canonicalHostname.length() && youcangetnoinfoNDXиНэта
/* 292 */         .regionMatches(false, i + 1, ((CertificatePinner2)super).canonicalHostname, 0, ((CertificatePinner2)super).canonicalHostname
/* 293 */           .length()));
/*     */     } 
/*     */     
/* 296 */     return youcangetnoinfoNDXиНэта.equals(((CertificatePinner2)super).canonicalHostname);
/*     */   }
/*     */   
/*     */   public boolean equals(Object youcangetnoinfoEIJTЕнГЩz) {
/* 300 */     return (youcangetnoinfoEIJTЕнГЩz instanceof CertificatePinner2 && ((CertificatePinner2)super).pattern
/* 301 */       .equals(((CertificatePinner2)youcangetnoinfoEIJTЕнГЩz).pattern) && ((CertificatePinner2)super).hashAlgorithm
/* 302 */       .equals(((CertificatePinner2)youcangetnoinfoEIJTЕнГЩz).hashAlgorithm) && ((CertificatePinner2)super).hash
/* 303 */       .equals(((CertificatePinner2)youcangetnoinfoEIJTЕнГЩz).hash));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 307 */     int i = 17;
/* 308 */     i = 31 * i + ((CertificatePinner2)super).pattern.hashCode();
/* 309 */     i = 31 * i + ((CertificatePinner2)super).hashAlgorithm.hashCode();
/* 310 */     i = 31 * i + ((CertificatePinner2)super).hash.hashCode();
/* 311 */     return i;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 315 */     return ((CertificatePinner2)super).hashAlgorithm + ((CertificatePinner2)super).hash.base64();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\CertificatePinner2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */