/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebSocketProtocol
/*     */ {
/*     */   public static final int OPCODE_CONTROL_CLOSE = 8;
/*     */   public static final int B1_MASK_LENGTH = 127;
/*     */   public static final long PAYLOAD_SHORT_MAX = 65535L;
/*     */   public static final int OPCODE_CONTROL_PONG = 10;
/*     */   public static final int B1_FLAG_MASK = 128;
/*     */   public static final int OPCODE_TEXT = 1;
/*     */   public static final int PAYLOAD_SHORT = 126;
/*     */   public static final int B0_MASK_OPCODE = 15;
/*     */   public static final int OPCODE_CONTINUATION = 0;
/*     */   public static final int OPCODE_CONTROL_PING = 9;
/*     */   public static final long PAYLOAD_BYTE_MAX = 125L;
/*     */   public static final int CLOSE_CLIENT_GOING_AWAY = 1001;
/*     */   public static final int B0_FLAG_FIN = 128;
/*     */   public static final int OPCODE_BINARY = 2;
/*     */   public static final int CLOSE_NO_STATUS_CODE = 1005;
/*     */   public static final int B0_FLAG_RSV2 = 32;
/*     */   public static final int B0_FLAG_RSV3 = 16;
/*     */   public static final long CLOSE_MESSAGE_MAX = 123L;
/*     */   public static final int OPCODE_FLAG_CONTROL = 8;
/*     */   public static final int PAYLOAD_LONG = 127;
/*     */   public static final int B0_FLAG_RSV1 = 64;
/*     */   public static final String ACCEPT_MAGIC = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
/*     */   
/*     */   public static void toggleMask(Object youcangetnoinfoASBJяzЙЦЙ, Object youcangetnoinfoASBKувЭ3Б) {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_2
/*     */     //   2: aload_1
/*     */     //   3: arraylength
/*     */     //   4: istore_3
/*     */     //   5: aload_0
/*     */     //   6: getfield data : [B
/*     */     //   9: astore #4
/*     */     //   11: aload_0
/*     */     //   12: getfield start : I
/*     */     //   15: istore #5
/*     */     //   17: aload_0
/*     */     //   18: getfield end : I
/*     */     //   21: istore #6
/*     */     //   23: iload #5
/*     */     //   25: iload #6
/*     */     //   27: if_icmpge -> 58
/*     */     //   30: iload_2
/*     */     //   31: iload_3
/*     */     //   32: irem
/*     */     //   33: istore_2
/*     */     //   34: aload #4
/*     */     //   36: iload #5
/*     */     //   38: aload #4
/*     */     //   40: iload #5
/*     */     //   42: baload
/*     */     //   43: aload_1
/*     */     //   44: iload_2
/*     */     //   45: baload
/*     */     //   46: ixor
/*     */     //   47: i2b
/*     */     //   48: bastore
/*     */     //   49: iinc #5, 1
/*     */     //   52: iinc #2, 1
/*     */     //   55: goto -> 23
/*     */     //   58: aload_0
/*     */     //   59: invokevirtual next : ()I
/*     */     //   62: iconst_m1
/*     */     //   63: if_icmpne -> 5
/*     */     //   66: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #96	-> 0
/*     */     //   #97	-> 2
/*     */     //   #99	-> 5
/*     */     //   #100	-> 11
/*     */     //   #101	-> 30
/*     */     //   #102	-> 34
/*     */     //   #100	-> 49
/*     */     //   #104	-> 58
/*     */     //   #105	-> 66
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   17	41	5	youcangetnoinfoASBGхЦсяИ	Ljava/lang/Object;
/*     */     //   0	67	1	youcangetnoinfoASBKувЭ3Б	Ljava/lang/Object;
/*     */     //   23	35	6	youcangetnoinfoASBHВуЕшК	Ljava/lang/Object;
/*     */     //   2	65	2	youcangetnoinfoASBLВГУИЪ	Ljava/lang/Object;
/*     */     //   5	62	3	youcangetnoinfoASBMЛЬР6У	Ljava/lang/Object;
/*     */     //   11	47	4	youcangetnoinfoASBIЕчРу7	Ljava/lang/Object;
/*     */     //   0	67	0	youcangetnoinfoASBJяzЙЦЙ	Ljava/lang/Object;
/*     */   }
/*     */   
/*     */   public static String closeCodeExceptionMessage(Object youcangetnoinfoCPAOбМеНл) {
/* 108 */     if (youcangetnoinfoCPAOбМеНл < 'Ϩ' || youcangetnoinfoCPAOбМеНл >= 'ᎈ')
/* 109 */       return "Code must be in range [1000,5000): " + youcangetnoinfoCPAOбМеНл; 
/* 110 */     if ((youcangetnoinfoCPAOбМеНл >= 'Ϭ' && youcangetnoinfoCPAOбМеНл <= 'Ϯ') || (youcangetnoinfoCPAOбМеНл >= 'ϴ' && youcangetnoinfoCPAOбМеНл <= 'ஷ')) {
/* 111 */       return "Code " + youcangetnoinfoCPAOбМеНл + " is reserved and may not be used.";
/*     */     }
/* 113 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void validateCloseCode(Object youcangetnoinfoACJGмг7д9) {
/* 118 */     Object youcangetnoinfoACJH2zыеФ = closeCodeExceptionMessage(youcangetnoinfoACJGмг7д9);
/* 119 */     if (youcangetnoinfoACJH2zыеФ != null) throw new IllegalArgumentException(youcangetnoinfoACJH2zыеФ); 
/*     */   }
/*     */   
/*     */   public static String acceptHeader(Object youcangetnoinfoAESXЗгжКу) {
/* 123 */     return ByteString.encodeUtf8(youcangetnoinfoAESXЗгжКу + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").sha1().base64();
/*     */   }
/*     */   public WebSocketProtocol() {
/* 126 */     this();
/* 127 */     throw new AssertionError("No instances.");
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\WebSocketProtocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */