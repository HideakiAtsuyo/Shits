/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebSocketWriter1
/*     */   implements Sink
/*     */ {
/*     */   public long contentLength;
/*     */   public int formatOpcode;
/*     */   public boolean closed;
/*     */   public final WebSocketWriter this$0;
/*     */   public boolean isFirstFrame;
/*     */   
/*     */   public WebSocketWriter1() {
/* 215 */     this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(Object youcangetnoinfoDZRYцЫгТэ, Object youcangetnoinfoDZRZЩПмж3) throws IOException {
/* 222 */     if (((WebSocketWriter1)super).closed) throw new IOException("closed");
/*     */     
/* 224 */     ((WebSocketWriter1)super).this$0.buffer.write((Buffer2)youcangetnoinfoDZRYцЫгТэ, youcangetnoinfoDZRZЩПмж3);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 229 */     boolean bool = (((WebSocketWriter1)super).isFirstFrame && ((WebSocketWriter1)super).contentLength != -1L && ((WebSocketWriter1)super).this$0.buffer.size() > ((WebSocketWriter1)super).contentLength - 8192L) ? true : false;
/*     */     
/* 231 */     long l = ((WebSocketWriter1)super).this$0.buffer.completeSegmentByteCount();
/* 232 */     if (l > 0L && !bool) {
/* 233 */       ((WebSocketWriter1)super).this$0.writeMessageFrame(((WebSocketWriter1)super).formatOpcode, l, ((WebSocketWriter1)super).isFirstFrame, false);
/* 234 */       ((WebSocketWriter1)super).isFirstFrame = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 239 */     if (((WebSocketWriter1)super).closed) throw new IOException("closed");
/*     */     
/* 241 */     ((WebSocketWriter1)super).this$0.writeMessageFrame(((WebSocketWriter1)super).formatOpcode, ((WebSocketWriter1)super).this$0.buffer.size(), ((WebSocketWriter1)super).isFirstFrame, false);
/* 242 */     ((WebSocketWriter1)super).isFirstFrame = false;
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 246 */     return ((WebSocketWriter1)super).this$0.sink.timeout();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 250 */     if (((WebSocketWriter1)super).closed) throw new IOException("closed");
/*     */     
/* 252 */     ((WebSocketWriter1)super).this$0.writeMessageFrame(((WebSocketWriter1)super).formatOpcode, ((WebSocketWriter1)super).this$0.buffer.size(), ((WebSocketWriter1)super).isFirstFrame, true);
/* 253 */     ((WebSocketWriter1)super).closed = true;
/* 254 */     ((WebSocketWriter1)super).this$0.activeWriter = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\WebSocketWriter1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */