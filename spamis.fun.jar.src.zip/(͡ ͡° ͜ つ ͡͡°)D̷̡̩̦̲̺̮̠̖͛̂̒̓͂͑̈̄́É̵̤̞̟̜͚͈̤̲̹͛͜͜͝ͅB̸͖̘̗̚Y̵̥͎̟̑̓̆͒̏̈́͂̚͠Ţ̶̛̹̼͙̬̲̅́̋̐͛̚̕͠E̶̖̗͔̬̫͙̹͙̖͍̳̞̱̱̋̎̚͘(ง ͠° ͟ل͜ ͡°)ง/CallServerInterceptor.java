/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CallServerInterceptor
/*     */   implements Interceptor
/*     */ {
/*     */   public final boolean forWebSocket;
/*     */   
/*     */   public CallServerInterceptor(Object youcangetnoinfoCURDКПгАФ) {
/*  39 */     this();
/*  40 */     ((CallServerInterceptor)super).forWebSocket = youcangetnoinfoCURDКПгАФ;
/*     */   }
/*     */   
/*     */   public Response intercept(Object youcangetnoinfoDXMOЯЩЯЭБ) throws IOException {
/*  44 */     Object youcangetnoinfoDXMPПШзАЖ = youcangetnoinfoDXMOЯЩЯЭБ;
/*  45 */     Object youcangetnoinfoDXMQРохшИ = youcangetnoinfoDXMPПШзАЖ.call();
/*  46 */     Object youcangetnoinfoDXMRзЮънС = youcangetnoinfoDXMPПШзАЖ.httpStream();
/*  47 */     Object youcangetnoinfoDXMSкдП9ч = youcangetnoinfoDXMPПШзАЖ.streamAllocation();
/*  48 */     Object youcangetnoinfoDXMTбаЙен = youcangetnoinfoDXMPПШзАЖ.connection();
/*  49 */     Object youcangetnoinfoDXMUуРж6z = youcangetnoinfoDXMPПШзАЖ.request();
/*     */     
/*  51 */     long l = System.currentTimeMillis();
/*     */     
/*  53 */     youcangetnoinfoDXMPПШзАЖ.eventListener().requestHeadersStart((Call)youcangetnoinfoDXMQРохшИ);
/*  54 */     youcangetnoinfoDXMRзЮънС.writeRequestHeaders((Request)youcangetnoinfoDXMUуРж6z);
/*  55 */     youcangetnoinfoDXMPПШзАЖ.eventListener().requestHeadersEnd((Call)youcangetnoinfoDXMQРохшИ, (Request)youcangetnoinfoDXMUуРж6z);
/*     */     
/*  57 */     Object youcangetnoinfoDXMWС2ЩМФ = null;
/*  58 */     if (HttpMethod.permitsRequestBody(youcangetnoinfoDXMUуРж6z.method()) && youcangetnoinfoDXMUуРж6z.body() != null) {
/*     */ 
/*     */ 
/*     */       
/*  62 */       if ("100-continue".equalsIgnoreCase(youcangetnoinfoDXMUуРж6z.header("Expect"))) {
/*  63 */         youcangetnoinfoDXMRзЮънС.flushRequest();
/*  64 */         youcangetnoinfoDXMPПШзАЖ.eventListener().responseHeadersStart((Call)youcangetnoinfoDXMQРохшИ);
/*  65 */         youcangetnoinfoDXMWС2ЩМФ = youcangetnoinfoDXMRзЮънС.readResponseHeaders(true);
/*     */       } 
/*     */       
/*  68 */       if (youcangetnoinfoDXMWС2ЩМФ == null) {
/*  69 */         if (youcangetnoinfoDXMUуРж6z.body() instanceof DuplexRequestBody) {
/*     */           
/*  71 */           youcangetnoinfoDXMRзЮънС.flushRequest();
/*  72 */           Object youcangetnoinfoDXMIЧЯ0мЙ = new CallServerInterceptor1(youcangetnoinfoDXMRзЮънС.createRequestBody((Request)youcangetnoinfoDXMUуРж6z, -1L));
/*  73 */           Object youcangetnoinfoDXMJГъИжЫ = Okio1.buffer((Sink)youcangetnoinfoDXMIЧЯ0мЙ);
/*  74 */           youcangetnoinfoDXMUуРж6z.body().writeTo((BufferedSink)youcangetnoinfoDXMJГъИжЫ);
/*     */         } else {
/*     */           
/*  77 */           youcangetnoinfoDXMPПШзАЖ.eventListener().requestBodyStart((Call)youcangetnoinfoDXMQРохшИ);
/*  78 */           long l1 = youcangetnoinfoDXMUуРж6z.body().contentLength();
/*     */           
/*  80 */           Object youcangetnoinfoDXMLфЭПЪ6 = new CallServerInterceptor1(youcangetnoinfoDXMRзЮънС.createRequestBody((Request)youcangetnoinfoDXMUуРж6z, l1));
/*  81 */           Object youcangetnoinfoDXMMЗдЪДД = Okio1.buffer((Sink)youcangetnoinfoDXMLфЭПЪ6);
/*     */           
/*  83 */           youcangetnoinfoDXMUуРж6z.body().writeTo((BufferedSink)youcangetnoinfoDXMMЗдЪДД);
/*  84 */           youcangetnoinfoDXMMЗдЪДД.close();
/*  85 */           youcangetnoinfoDXMPПШзАЖ.eventListener().requestBodyEnd((Call)youcangetnoinfoDXMQРохшИ, ((CallServerInterceptor1)youcangetnoinfoDXMLфЭПЪ6).successfulCount);
/*     */         } 
/*  87 */       } else if (!youcangetnoinfoDXMTбаЙен.isMultiplexed()) {
/*     */ 
/*     */ 
/*     */         
/*  91 */         youcangetnoinfoDXMSкдП9ч.noNewStreams();
/*     */       } 
/*     */     } 
/*     */     
/*  95 */     if (!(youcangetnoinfoDXMUуРж6z.body() instanceof DuplexRequestBody)) {
/*  96 */       youcangetnoinfoDXMRзЮънС.finishRequest();
/*     */     }
/*     */     
/*  99 */     if (youcangetnoinfoDXMWС2ЩМФ == null) {
/* 100 */       youcangetnoinfoDXMPПШзАЖ.eventListener().responseHeadersStart((Call)youcangetnoinfoDXMQРохшИ);
/* 101 */       youcangetnoinfoDXMWС2ЩМФ = youcangetnoinfoDXMRзЮънС.readResponseHeaders(false);
/*     */     } 
/*     */     
/* 104 */     youcangetnoinfoDXMWС2ЩМФ
/* 105 */       .request((Request)youcangetnoinfoDXMUуРж6z)
/* 106 */       .handshake(youcangetnoinfoDXMSкдП9ч.connection().handshake())
/* 107 */       .sentRequestAtMillis(l)
/* 108 */       .receivedResponseAtMillis(System.currentTimeMillis());
/* 109 */     Internal.instance.initCodec((Response1)youcangetnoinfoDXMWС2ЩМФ, (HttpCodec)youcangetnoinfoDXMRзЮънС);
/* 110 */     Object youcangetnoinfoDXMXЩзОЁЕ = youcangetnoinfoDXMWС2ЩМФ.build();
/*     */     
/* 112 */     int i = youcangetnoinfoDXMXЩзОЁЕ.code();
/* 113 */     if (i == 100) {
/*     */ 
/*     */       
/* 116 */       youcangetnoinfoDXMWС2ЩМФ = youcangetnoinfoDXMRзЮънС.readResponseHeaders(false);
/*     */       
/* 118 */       youcangetnoinfoDXMWС2ЩМФ
/* 119 */         .request((Request)youcangetnoinfoDXMUуРж6z)
/* 120 */         .handshake(youcangetnoinfoDXMSкдП9ч.connection().handshake())
/* 121 */         .sentRequestAtMillis(l)
/* 122 */         .receivedResponseAtMillis(System.currentTimeMillis());
/* 123 */       Internal.instance.initCodec((Response1)youcangetnoinfoDXMWС2ЩМФ, (HttpCodec)youcangetnoinfoDXMRзЮънС);
/* 124 */       youcangetnoinfoDXMXЩзОЁЕ = youcangetnoinfoDXMWС2ЩМФ.build();
/*     */       
/* 126 */       i = youcangetnoinfoDXMXЩзОЁЕ.code();
/*     */     } 
/*     */     
/* 129 */     youcangetnoinfoDXMPПШзАЖ.eventListener().responseHeadersEnd((Call)youcangetnoinfoDXMQРохшИ, (Response)youcangetnoinfoDXMXЩзОЁЕ);
/*     */     
/* 131 */     if (((CallServerInterceptor)super).forWebSocket && i == 101) {
/*     */ 
/*     */ 
/*     */       
/* 135 */       youcangetnoinfoDXMXЩзОЁЕ = youcangetnoinfoDXMXЩзОЁЕ.newBuilder().body(Util1.EMPTY_RESPONSE).build();
/*     */     }
/*     */     else {
/*     */       
/* 139 */       youcangetnoinfoDXMXЩзОЁЕ = youcangetnoinfoDXMXЩзОЁЕ.newBuilder().body(youcangetnoinfoDXMRзЮънС.openResponseBody((Response)youcangetnoinfoDXMXЩзОЁЕ)).build();
/*     */     } 
/*     */     
/* 142 */     if ("close".equalsIgnoreCase(youcangetnoinfoDXMXЩзОЁЕ.request().header("Connection")) || "close"
/* 143 */       .equalsIgnoreCase(youcangetnoinfoDXMXЩзОЁЕ.header("Connection"))) {
/* 144 */       youcangetnoinfoDXMSкдП9ч.noNewStreams();
/*     */     }
/*     */     
/* 147 */     if ((i == 204 || i == 205) && youcangetnoinfoDXMXЩзОЁЕ.body().contentLength() > 0L) {
/* 148 */       throw new ProtocolException("HTTP " + i + " had non-zero Content-Length: " + youcangetnoinfoDXMXЩзОЁЕ
/* 149 */           .body().contentLength());
/*     */     }
/*     */     
/* 152 */     return (Response)youcangetnoinfoDXMXЩзОЁЕ;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\CallServerInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */