/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import fun.spamis.spammer.SpamIsFun;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.io.IOException;
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Paths;
/*    */ import javax.swing.table.DefaultTableModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ProxysGUI2
/*    */   implements ActionListener
/*    */ {
/*    */   public final DefaultTableModel val$proxyModel;
/*    */   public final ProxysGUI1 this$0;
/*    */   
/*    */   public ProxysGUI2() {
/* 69 */     this();
/*    */   }
/*    */   public void actionPerformed(Object youcangetnoinfoBEUMеЁнжь) {
/*    */     try {
/* 73 */       int i = SpamIsFun.proxys.size();
/* 74 */       Object youcangetnoinfoBEUKЫПУК9 = FileUtils.loadTextFile();
/* 75 */       for (String youcangetnoinfoBEUIхй7ТЧ : Files.readAllLines(Paths.get(youcangetnoinfoBEUKЫПУК9.toString(), new String[0]), 
/* 76 */           Charset.defaultCharset())) {
/* 77 */         i++;
/* 78 */         SpamIsFun.proxys.put(Integer.valueOf(i), youcangetnoinfoBEUIхй7ТЧ);
/* 79 */         proxyModel.addRow(new Object[] { Integer.valueOf(i), youcangetnoinfoBEUIхй7ТЧ });
/*    */       } 
/* 81 */       FileUtils.writeFile(SpamIsFun.homeDir + "proxys.spamisfun", youcangetnoinfoBEUKЫПУК9.getAbsolutePath());
/* 82 */     } catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ProxysGUI2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */