/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.net.IDN;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.concurrent.CountDownLatch;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class PublicSuffixDatabase
/*     */ {
/*     */   public static final String PUBLIC_SUFFIX_RESOURCE = "publicsuffixes.gz";
/*     */   public static final PublicSuffixDatabase instance;
/*     */   
/*     */   public PublicSuffixDatabase() {
/*  35 */     this();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  47 */     ((PublicSuffixDatabase)super).listRead = new AtomicBoolean(false);
/*     */ 
/*     */     
/*  50 */     ((PublicSuffixDatabase)super).readCompleteLatch = new CountDownLatch(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final byte[] WILDCARD_LABEL = new byte[] { 42 };
/*     */   public static final byte EXCEPTION_MARKER = 33;
/*     */   public static final String[] EMPTY_RULE = new String[0];
/*     */   public final CountDownLatch readCompleteLatch;
/*     */   
/*     */   public static PublicSuffixDatabase get() {
/*  60 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public static final String[] PREVAILING_RULE = new String[] { "*" };
/*     */   
/*     */   public byte[] publicSuffixExceptionListBytes;
/*     */   
/*     */   public byte[] publicSuffixListBytes;
/*     */   
/*     */   public final AtomicBoolean listRead;
/*     */ 
/*     */   
/*     */   static {
/*     */     instance = new PublicSuffixDatabase();
/*     */   }
/*     */   
/*     */   public String getEffectiveTldPlusOne(Object youcangetnoinfoDNIЦнЫхИ) {
/*     */     int i;
/*  79 */     if (youcangetnoinfoDNIЦнЫхИ == null) throw new NullPointerException("domain == null");
/*     */ 
/*     */     
/*  82 */     Object youcangetnoinfoDNJДкрЛй = IDN.toUnicode((String)youcangetnoinfoDNIЦнЫхИ);
/*  83 */     Object youcangetnoinfoDNKЮЧ2Ш7 = youcangetnoinfoDNJДкрЛй.split("\\.");
/*  84 */     Object youcangetnoinfoDNLЁ8кИА = super.findMatchingRule((String[])youcangetnoinfoDNKЮЧ2Ш7);
/*  85 */     if (youcangetnoinfoDNKЮЧ2Ш7.length == youcangetnoinfoDNLЁ8кИА.length && youcangetnoinfoDNLЁ8кИА[0].charAt(0) != '!')
/*     */     {
/*  87 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  91 */     if (youcangetnoinfoDNLЁ8кИА[0].charAt(0) == '!') {
/*     */       
/*  93 */       i = youcangetnoinfoDNKЮЧ2Ш7.length - youcangetnoinfoDNLЁ8кИА.length;
/*     */     } else {
/*     */       
/*  96 */       i = youcangetnoinfoDNKЮЧ2Ш7.length - youcangetnoinfoDNLЁ8кИА.length + 1;
/*     */     } 
/*     */     
/*  99 */     Object youcangetnoinfoDNNЙрщнЛ = new StringBuilder();
/* 100 */     Object youcangetnoinfoDNOйЖю7ж = youcangetnoinfoDNIЦнЫхИ.split("\\.");
/* 101 */     for (int j = i; j < youcangetnoinfoDNOйЖю7ж.length; j++) {
/* 102 */       youcangetnoinfoDNNЙрщнЛ.append((String)youcangetnoinfoDNOйЖю7ж[j]).append('.');
/*     */     }
/* 104 */     youcangetnoinfoDNNЙрщнЛ.deleteCharAt(youcangetnoinfoDNNЙрщнЛ.length() - 1);
/*     */     
/* 106 */     return youcangetnoinfoDNNЙрщнЛ.toString();
/*     */   }
/*     */   
/*     */   public String[] findMatchingRule(Object youcangetnoinfoAFNDЗЁя4Щ) {
/* 110 */     if (!((PublicSuffixDatabase)super).listRead.get() && ((PublicSuffixDatabase)super).listRead.compareAndSet(false, true)) {
/* 111 */       super.readTheListUninterruptibly();
/*     */     } else {
/*     */       try {
/* 114 */         ((PublicSuffixDatabase)super).readCompleteLatch.await();
/* 115 */       } catch (InterruptedException youcangetnoinfoAFMTИХжИк) {
/* 116 */         Thread.currentThread().interrupt();
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     synchronized (this) {
/* 121 */       if (((PublicSuffixDatabase)super).publicSuffixListBytes == null) {
/* 122 */         throw new IllegalStateException("Unable to load publicsuffixes.gz resource from the classpath.");
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 128 */     Object youcangetnoinfoAFNEЪйСЁФ = new byte[youcangetnoinfoAFNDЗЁя4Щ.length][];
/* 129 */     for (byte b1 = 0; b1 < youcangetnoinfoAFNDЗЁя4Щ.length; b1++) {
/* 130 */       youcangetnoinfoAFNEЪйСЁФ[b1] = youcangetnoinfoAFNDЗЁя4Щ[b1].getBytes(StandardCharsets.UTF_8);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 135 */     Object youcangetnoinfoAFNFМпсеё = null;
/* 136 */     for (byte b2 = 0; b2 < youcangetnoinfoAFNEЪйСЁФ.length; b2++) {
/* 137 */       Object youcangetnoinfoAFMVЭ4ВХФ = binarySearchBytes(((PublicSuffixDatabase)super).publicSuffixListBytes, (byte[][])youcangetnoinfoAFNEЪйСЁФ, b2);
/* 138 */       if (youcangetnoinfoAFMVЭ4ВХФ != null) {
/* 139 */         youcangetnoinfoAFNFМпсеё = youcangetnoinfoAFMVЭ4ВХФ;
/*     */ 
/*     */ 
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 149 */     Object youcangetnoinfoAFNGХЫШщр = null;
/* 150 */     if (youcangetnoinfoAFNEЪйСЁФ.length > 1) {
/* 151 */       Object youcangetnoinfoAFMZ6ЪОЕк = youcangetnoinfoAFNEЪйСЁФ.clone();
/* 152 */       for (byte b = 0; b < youcangetnoinfoAFMZ6ЪОЕк.length - 1; b++) {
/* 153 */         youcangetnoinfoAFMZ6ЪОЕк[b] = WILDCARD_LABEL;
/* 154 */         Object youcangetnoinfoAFMXфдл9ц = binarySearchBytes(((PublicSuffixDatabase)super).publicSuffixListBytes, (byte[][])youcangetnoinfoAFMZ6ЪОЕк, b);
/* 155 */         if (youcangetnoinfoAFMXфдл9ц != null) {
/* 156 */           youcangetnoinfoAFNGХЫШщр = youcangetnoinfoAFMXфдл9ц;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 163 */     Object youcangetnoinfoAFNHЧпШф5 = null;
/* 164 */     if (youcangetnoinfoAFNGХЫШщр != null) {
/* 165 */       for (byte b = 0; b < youcangetnoinfoAFNEЪйСЁФ.length - 1; b++) {
/* 166 */         Object youcangetnoinfoAFNAузЧош = binarySearchBytes(((PublicSuffixDatabase)super).publicSuffixExceptionListBytes, (byte[][])youcangetnoinfoAFNEЪйСЁФ, b);
/*     */         
/* 168 */         if (youcangetnoinfoAFNAузЧош != null) {
/* 169 */           youcangetnoinfoAFNHЧпШф5 = youcangetnoinfoAFNAузЧош;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 175 */     if (youcangetnoinfoAFNHЧпШф5 != null) {
/*     */       
/* 177 */       youcangetnoinfoAFNHЧпШф5 = "!" + youcangetnoinfoAFNHЧпШф5;
/* 178 */       return youcangetnoinfoAFNHЧпШф5.split("\\.");
/* 179 */     }  if (youcangetnoinfoAFNFМпсеё == null && youcangetnoinfoAFNGХЫШщр == null) {
/* 180 */       return PREVAILING_RULE;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 185 */     Object youcangetnoinfoAFNIашыУЫ = (youcangetnoinfoAFNFМпсеё != null) ? youcangetnoinfoAFNFМпсеё.split("\\.") : EMPTY_RULE;
/*     */ 
/*     */ 
/*     */     
/* 189 */     Object youcangetnoinfoAFNJЕКНшя = (youcangetnoinfoAFNGХЫШщр != null) ? youcangetnoinfoAFNGХЫШщр.split("\\.") : EMPTY_RULE;
/*     */     
/* 191 */     return (youcangetnoinfoAFNIашыУЫ.length > youcangetnoinfoAFNJЕКНшя.length) ? 
/* 192 */       (String[])youcangetnoinfoAFNIашыУЫ : 
/* 193 */       (String[])youcangetnoinfoAFNJЕКНшя;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String binarySearchBytes(Object youcangetnoinfoWUKЦЮубф, Object youcangetnoinfoWULХшЧёЗ, Object youcangetnoinfoWUMулаЭш) {
/*     */     // Byte code:
/*     */     //   0: iconst_0
/*     */     //   1: istore_3
/*     */     //   2: aload_0
/*     */     //   3: arraylength
/*     */     //   4: istore #4
/*     */     //   6: aconst_null
/*     */     //   7: astore #5
/*     */     //   9: iload_3
/*     */     //   10: iload #4
/*     */     //   12: if_icmpge -> 329
/*     */     //   15: iload_3
/*     */     //   16: iload #4
/*     */     //   18: iadd
/*     */     //   19: iconst_2
/*     */     //   20: idiv
/*     */     //   21: istore #6
/*     */     //   23: iload #6
/*     */     //   25: iconst_m1
/*     */     //   26: if_icmple -> 44
/*     */     //   29: aload_0
/*     */     //   30: iload #6
/*     */     //   32: baload
/*     */     //   33: bipush #10
/*     */     //   35: if_icmpeq -> 44
/*     */     //   38: iinc #6, -1
/*     */     //   41: goto -> 23
/*     */     //   44: iinc #6, 1
/*     */     //   47: iconst_1
/*     */     //   48: istore #7
/*     */     //   50: aload_0
/*     */     //   51: iload #6
/*     */     //   53: iload #7
/*     */     //   55: iadd
/*     */     //   56: baload
/*     */     //   57: bipush #10
/*     */     //   59: if_icmpeq -> 68
/*     */     //   62: iinc #7, 1
/*     */     //   65: goto -> 50
/*     */     //   68: iload #6
/*     */     //   70: iload #7
/*     */     //   72: iadd
/*     */     //   73: iload #6
/*     */     //   75: isub
/*     */     //   76: istore #8
/*     */     //   78: iload_2
/*     */     //   79: istore #10
/*     */     //   81: iconst_0
/*     */     //   82: istore #11
/*     */     //   84: iconst_0
/*     */     //   85: istore #12
/*     */     //   87: iconst_0
/*     */     //   88: istore #13
/*     */     //   90: iload #13
/*     */     //   92: ifeq -> 105
/*     */     //   95: bipush #46
/*     */     //   97: istore #14
/*     */     //   99: iconst_0
/*     */     //   100: istore #13
/*     */     //   102: goto -> 118
/*     */     //   105: aload_1
/*     */     //   106: iload #10
/*     */     //   108: aaload
/*     */     //   109: iload #11
/*     */     //   111: baload
/*     */     //   112: sipush #255
/*     */     //   115: iand
/*     */     //   116: istore #14
/*     */     //   118: aload_0
/*     */     //   119: iload #6
/*     */     //   121: iload #12
/*     */     //   123: iadd
/*     */     //   124: baload
/*     */     //   125: sipush #255
/*     */     //   128: iand
/*     */     //   129: istore #15
/*     */     //   131: iload #14
/*     */     //   133: iload #15
/*     */     //   135: isub
/*     */     //   136: istore #9
/*     */     //   138: iload #9
/*     */     //   140: ifeq -> 146
/*     */     //   143: goto -> 196
/*     */     //   146: iinc #12, 1
/*     */     //   149: iinc #11, 1
/*     */     //   152: iload #12
/*     */     //   154: iload #8
/*     */     //   156: if_icmpne -> 162
/*     */     //   159: goto -> 196
/*     */     //   162: aload_1
/*     */     //   163: iload #10
/*     */     //   165: aaload
/*     */     //   166: arraylength
/*     */     //   167: iload #11
/*     */     //   169: if_icmpne -> 193
/*     */     //   172: iload #10
/*     */     //   174: aload_1
/*     */     //   175: arraylength
/*     */     //   176: iconst_1
/*     */     //   177: isub
/*     */     //   178: if_icmpne -> 184
/*     */     //   181: goto -> 196
/*     */     //   184: iinc #10, 1
/*     */     //   187: iconst_m1
/*     */     //   188: istore #11
/*     */     //   190: iconst_1
/*     */     //   191: istore #13
/*     */     //   193: goto -> 90
/*     */     //   196: iload #9
/*     */     //   198: ifge -> 210
/*     */     //   201: iload #6
/*     */     //   203: iconst_1
/*     */     //   204: isub
/*     */     //   205: istore #4
/*     */     //   207: goto -> 326
/*     */     //   210: iload #9
/*     */     //   212: ifle -> 226
/*     */     //   215: iload #6
/*     */     //   217: iload #7
/*     */     //   219: iadd
/*     */     //   220: iconst_1
/*     */     //   221: iadd
/*     */     //   222: istore_3
/*     */     //   223: goto -> 326
/*     */     //   226: iload #8
/*     */     //   228: iload #12
/*     */     //   230: isub
/*     */     //   231: istore #14
/*     */     //   233: aload_1
/*     */     //   234: iload #10
/*     */     //   236: aaload
/*     */     //   237: arraylength
/*     */     //   238: iload #11
/*     */     //   240: isub
/*     */     //   241: istore #15
/*     */     //   243: iload #10
/*     */     //   245: iconst_1
/*     */     //   246: iadd
/*     */     //   247: istore #16
/*     */     //   249: iload #16
/*     */     //   251: aload_1
/*     */     //   252: arraylength
/*     */     //   253: if_icmpge -> 272
/*     */     //   256: iload #15
/*     */     //   258: aload_1
/*     */     //   259: iload #16
/*     */     //   261: aaload
/*     */     //   262: arraylength
/*     */     //   263: iadd
/*     */     //   264: istore #15
/*     */     //   266: iinc #16, 1
/*     */     //   269: goto -> 249
/*     */     //   272: iload #15
/*     */     //   274: iload #14
/*     */     //   276: if_icmpge -> 288
/*     */     //   279: iload #6
/*     */     //   281: iconst_1
/*     */     //   282: isub
/*     */     //   283: istore #4
/*     */     //   285: goto -> 326
/*     */     //   288: iload #15
/*     */     //   290: iload #14
/*     */     //   292: if_icmple -> 306
/*     */     //   295: iload #6
/*     */     //   297: iload #7
/*     */     //   299: iadd
/*     */     //   300: iconst_1
/*     */     //   301: iadd
/*     */     //   302: istore_3
/*     */     //   303: goto -> 326
/*     */     //   306: new java/lang/String
/*     */     //   309: dup
/*     */     //   310: aload_0
/*     */     //   311: iload #6
/*     */     //   313: iload #8
/*     */     //   315: getstatic java/nio/charset/StandardCharsets.UTF_8 : Ljava/nio/charset/Charset;
/*     */     //   318: invokespecial <init> : ([BIILjava/nio/charset/Charset;)V
/*     */     //   321: astore #5
/*     */     //   323: goto -> 329
/*     */     //   326: goto -> 9
/*     */     //   329: aload #5
/*     */     //   331: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #197	-> 0
/*     */     //   #198	-> 2
/*     */     //   #199	-> 6
/*     */     //   #200	-> 9
/*     */     //   #201	-> 15
/*     */     //   #204	-> 23
/*     */     //   #205	-> 38
/*     */     //   #207	-> 44
/*     */     //   #210	-> 47
/*     */     //   #211	-> 50
/*     */     //   #212	-> 62
/*     */     //   #214	-> 68
/*     */     //   #219	-> 78
/*     */     //   #220	-> 81
/*     */     //   #221	-> 84
/*     */     //   #223	-> 87
/*     */     //   #226	-> 90
/*     */     //   #227	-> 95
/*     */     //   #228	-> 99
/*     */     //   #230	-> 105
/*     */     //   #233	-> 118
/*     */     //   #235	-> 131
/*     */     //   #236	-> 138
/*     */     //   #238	-> 146
/*     */     //   #239	-> 149
/*     */     //   #240	-> 152
/*     */     //   #242	-> 162
/*     */     //   #245	-> 172
/*     */     //   #246	-> 181
/*     */     //   #248	-> 184
/*     */     //   #249	-> 187
/*     */     //   #250	-> 190
/*     */     //   #253	-> 193
/*     */     //   #255	-> 196
/*     */     //   #256	-> 201
/*     */     //   #257	-> 210
/*     */     //   #258	-> 215
/*     */     //   #261	-> 226
/*     */     //   #262	-> 233
/*     */     //   #263	-> 243
/*     */     //   #264	-> 256
/*     */     //   #263	-> 266
/*     */     //   #267	-> 272
/*     */     //   #268	-> 279
/*     */     //   #269	-> 288
/*     */     //   #270	-> 295
/*     */     //   #273	-> 306
/*     */     //   #274	-> 323
/*     */     //   #277	-> 326
/*     */     //   #278	-> 329
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   118	75	14	youcangetnoinfoWTXыЫЯжш	Ljava/lang/Object;
/*     */     //   9	323	5	youcangetnoinfoWUPлюКцч	Ljava/lang/Object;
/*     */     //   84	242	11	youcangetnoinfoWUHэЭМЗЕ	Ljava/lang/Object;
/*     */     //   23	303	6	youcangetnoinfoWUCжТий0	Ljava/lang/Object;
/*     */     //   2	330	3	youcangetnoinfoWUNфЗХЫС	Ljava/lang/Object;
/*     */     //   78	248	8	youcangetnoinfoWUEЮл8ш8	Ljava/lang/Object;
/*     */     //   0	332	1	youcangetnoinfoWULХшЧёЗ	Ljava/lang/Object;
/*     */     //   138	188	9	youcangetnoinfoWUFйАЖжж	Ljava/lang/Object;
/*     */     //   99	6	14	youcangetnoinfoWTWЕПз9Л	Ljava/lang/Object;
/*     */     //   243	83	15	youcangetnoinfoWUBЩЬэхъ	Ljava/lang/Object;
/*     */     //   87	239	12	youcangetnoinfoWUIаМХАЗ	Ljava/lang/Object;
/*     */     //   233	93	14	youcangetnoinfoWUA7Мхмы	Ljava/lang/Object;
/*     */     //   0	332	0	youcangetnoinfoWUKЦЮубф	Ljava/lang/Object;
/*     */     //   90	236	13	youcangetnoinfoWUJЫДТ3л	Ljava/lang/Object;
/*     */     //   0	332	2	youcangetnoinfoWUMулаЭш	Ljava/lang/Object;
/*     */     //   6	326	4	youcangetnoinfoWUOаяенц	Ljava/lang/Object;
/*     */     //   50	276	7	youcangetnoinfoWUDБюр0Д	Ljava/lang/Object;
/*     */     //   131	62	15	youcangetnoinfoWTY2чАЛн	Ljava/lang/Object;
/*     */     //   81	245	10	youcangetnoinfoWUGТФхжЮ	Ljava/lang/Object;
/*     */     //   249	23	16	youcangetnoinfoWTZ7Къчу	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readTheListUninterruptibly() {
/* 287 */     boolean bool = false;
/*     */     
/*     */     while (true) {
/*     */       try {
/* 291 */         super.readTheList();
/*     */         return;
/* 293 */       } catch (InterruptedIOException youcangetnoinfoDOAXПшзЩл) {
/* 294 */         Thread.interrupted();
/*     */       }
/* 296 */       catch (IOException youcangetnoinfoDOAYли1Йу) {
/* 297 */         Platform.get().log(5, "Failed to read public suffix list", (Throwable)youcangetnoinfoDOAYли1Йу);
/*     */ 
/*     */         
/*     */         return;
/*     */       } finally {
/* 302 */         if (bool) {
/* 303 */           Thread.currentThread().interrupt();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void readTheList() throws IOException {
/* 312 */     Object youcangetnoinfoBQTLфТь59, youcangetnoinfoBQTMЯИБ8э, youcangetnoinfoBQTRфЁ4оэ = PublicSuffixDatabase.class.getResourceAsStream("publicsuffixes.gz");
/* 313 */     if (youcangetnoinfoBQTRфЁ4оэ == null)
/*     */       return; 
/* 315 */     try (Object youcangetnoinfoBQTNд4ТТ1 = Okio1.buffer(new GzipSource(Okio1.source((InputStream)youcangetnoinfoBQTRфЁ4оэ)))) {
/* 316 */       int i = youcangetnoinfoBQTNд4ТТ1.readInt();
/* 317 */       youcangetnoinfoBQTLфТь59 = new byte[i];
/* 318 */       youcangetnoinfoBQTNд4ТТ1.readFully((byte[])youcangetnoinfoBQTLфТь59);
/*     */       
/* 320 */       int j = youcangetnoinfoBQTNд4ТТ1.readInt();
/* 321 */       youcangetnoinfoBQTMЯИБ8э = new byte[j];
/* 322 */       youcangetnoinfoBQTNд4ТТ1.readFully((byte[])youcangetnoinfoBQTMЯИБ8э);
/*     */     } 
/*     */     
/* 325 */     synchronized (this) {
/* 326 */       ((PublicSuffixDatabase)super).publicSuffixListBytes = (byte[])youcangetnoinfoBQTLфТь59;
/* 327 */       ((PublicSuffixDatabase)super).publicSuffixExceptionListBytes = (byte[])youcangetnoinfoBQTMЯИБ8э;
/*     */     } 
/*     */     
/* 330 */     ((PublicSuffixDatabase)super).readCompleteLatch.countDown();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setListBytes(Object youcangetnoinfoARAJзКлвШ, Object youcangetnoinfoARAKшМТшы) {
/* 335 */     ((PublicSuffixDatabase)super).publicSuffixListBytes = (byte[])youcangetnoinfoARAJзКлвШ;
/* 336 */     ((PublicSuffixDatabase)super).publicSuffixExceptionListBytes = (byte[])youcangetnoinfoARAKшМТшы;
/* 337 */     ((PublicSuffixDatabase)super).listRead.set(true);
/* 338 */     ((PublicSuffixDatabase)super).readCompleteLatch.countDown();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\PublicSuffixDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */