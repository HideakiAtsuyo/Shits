/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Okio2
/*     */   implements Source
/*     */ {
/*     */   public final Timeout val$timeout;
/*     */   public final InputStream val$in;
/*     */   
/*     */   public Okio2() {
/* 132 */     this();
/*     */   } public long read(Object youcangetnoinfoCGAAЙжЁЙе, Object youcangetnoinfoCGAB7яюну) throws IOException {
/* 134 */     if (youcangetnoinfoCGAB7яюну < 0L) throw new IllegalArgumentException("byteCount < 0: " + youcangetnoinfoCGAB7яюну); 
/* 135 */     if (youcangetnoinfoCGAB7яюну == 0L) return 0L; 
/*     */     try {
/* 137 */       timeout.throwIfReached();
/* 138 */       Object youcangetnoinfoCFZVдчГШЬ = youcangetnoinfoCGAAЙжЁЙе.writableSegment(1);
/* 139 */       int i = (int)Math.min(youcangetnoinfoCGAB7яюну, (8192 - ((Segment)youcangetnoinfoCFZVдчГШЬ).limit));
/* 140 */       int j = in.read(((Segment)youcangetnoinfoCFZVдчГШЬ).data, ((Segment)youcangetnoinfoCFZVдчГШЬ).limit, i);
/* 141 */       if (j == -1) return -1L; 
/* 142 */       ((Segment)youcangetnoinfoCFZVдчГШЬ).limit += j;
/* 143 */       ((Buffer2)youcangetnoinfoCGAAЙжЁЙе).size += j;
/* 144 */       return j;
/* 145 */     } catch (AssertionError youcangetnoinfoCFZYФныБИ) {
/* 146 */       if (Okio1.isAndroidGetsocknameError((AssertionError)youcangetnoinfoCFZYФныБИ)) throw new IOException(youcangetnoinfoCFZYФныБИ); 
/* 147 */       throw youcangetnoinfoCFZYФныБИ;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 152 */     in.close();
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 156 */     return timeout;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 160 */     return "source(" + in + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Okio2.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */