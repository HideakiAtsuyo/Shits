/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Request1
/*     */ {
/*     */   public Map<Class<?>, Object> tags;
/*     */   public Headers1 headers;
/*     */   @Nullable
/*     */   public RequestBody body;
/*     */   public String method;
/*     */   @Nullable
/*     */   public HttpUrl1 url;
/*     */   
/*     */   public Request1() {
/* 128 */     this(); ((Request1)super).tags = Collections.emptyMap();
/* 129 */     ((Request1)super).method = "GET";
/* 130 */     ((Request1)super).headers = new Headers1();
/*     */   }
/*     */   public Request1(Object youcangetnoinfoLTJяЭ9тЪ) {
/* 133 */     this(); ((Request1)super).tags = Collections.emptyMap();
/* 134 */     ((Request1)super).url = ((Request)youcangetnoinfoLTJяЭ9тЪ).url;
/* 135 */     ((Request1)super).method = ((Request)youcangetnoinfoLTJяЭ9тЪ).method;
/* 136 */     ((Request1)super).body = ((Request)youcangetnoinfoLTJяЭ9тЪ).body;
/* 137 */     ((Request1)super)
/*     */       
/* 139 */       .tags = ((Request)youcangetnoinfoLTJяЭ9тЪ).tags.isEmpty() ? Collections.<Class<?>, Object>emptyMap() : new LinkedHashMap<>(((Request)youcangetnoinfoLTJяЭ9тЪ).tags);
/* 140 */     ((Request1)super).headers = ((Request)youcangetnoinfoLTJяЭ9тЪ).headers.newBuilder();
/*     */   }
/*     */   
/*     */   public Request1 url(Object youcangetnoinfoCFJ2л3ЫЕ) {
/* 144 */     if (youcangetnoinfoCFJ2л3ЫЕ == null) throw new NullPointerException("url == null"); 
/* 145 */     ((Request1)super).url = (HttpUrl1)youcangetnoinfoCFJ2л3ЫЕ;
/* 146 */     return (Request1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request1 url(Object youcangetnoinfoGSEАУйЫЙ) {
/* 156 */     if (youcangetnoinfoGSEАУйЫЙ == null) throw new NullPointerException("url == null");
/*     */ 
/*     */     
/* 159 */     if (youcangetnoinfoGSEАУйЫЙ.regionMatches(true, 0, "ws:", 0, 3)) {
/* 160 */       youcangetnoinfoGSEАУйЫЙ = "http:" + youcangetnoinfoGSEАУйЫЙ.substring(3);
/* 161 */     } else if (youcangetnoinfoGSEАУйЫЙ.regionMatches(true, 0, "wss:", 0, 4)) {
/* 162 */       youcangetnoinfoGSEАУйЫЙ = "https:" + youcangetnoinfoGSEАУйЫЙ.substring(4);
/*     */     } 
/*     */     
/* 165 */     return super.url(HttpUrl1.get((String)youcangetnoinfoGSEАУйЫЙ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request1 url(Object youcangetnoinfoEQVО3йПы) {
/* 175 */     if (youcangetnoinfoEQVО3йПы == null) throw new NullPointerException("url == null"); 
/* 176 */     return super.url(HttpUrl1.get(youcangetnoinfoEQVО3йПы.toString()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request1 header(Object youcangetnoinfoEHXMнягН3, Object youcangetnoinfoEHXNЦазйб) {
/* 184 */     ((Request1)super).headers.set((String)youcangetnoinfoEHXMнягН3, (String)youcangetnoinfoEHXNЦазйб);
/* 185 */     return (Request1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request1 addHeader(Object youcangetnoinfoCGYRчХ4эь, Object youcangetnoinfoCGYSзуДы5) {
/* 196 */     ((Request1)super).headers.add((String)youcangetnoinfoCGYRчХ4эь, (String)youcangetnoinfoCGYSзуДы5);
/* 197 */     return (Request1)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Request1 removeHeader(Object youcangetnoinfoCNXA7ЩХ8Д) {
/* 202 */     ((Request1)super).headers.removeAll((String)youcangetnoinfoCNXA7ЩХ8Д);
/* 203 */     return (Request1)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Request1 headers(Object youcangetnoinfoDXISФ9В4ш) {
/* 208 */     ((Request1)super).headers = youcangetnoinfoDXISФ9В4ш.newBuilder();
/* 209 */     return (Request1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request1 cacheControl(Object youcangetnoinfoBJTJь1эб0) {
/* 218 */     Object youcangetnoinfoBJTKош8зФ = youcangetnoinfoBJTJь1эб0.toString();
/* 219 */     if (youcangetnoinfoBJTKош8зФ.isEmpty()) return super.removeHeader("Cache-Control"); 
/* 220 */     return super.header("Cache-Control", (String)youcangetnoinfoBJTKош8зФ);
/*     */   }
/*     */   
/*     */   public Request1 get() {
/* 224 */     return super.method("GET", null);
/*     */   }
/*     */   
/*     */   public Request1 head() {
/* 228 */     return super.method("HEAD", null);
/*     */   }
/*     */   
/*     */   public Request1 post(Object youcangetnoinfoBXEYнэМмз) {
/* 232 */     return super.method("POST", (RequestBody)youcangetnoinfoBXEYнэМмз);
/*     */   }
/*     */   
/*     */   public Request1 delete(@Nullable Object youcangetnoinfoEPGQСушДл) {
/* 236 */     return super.method("DELETE", (RequestBody)youcangetnoinfoEPGQСушДл);
/*     */   }
/*     */   
/*     */   public Request1 delete() {
/* 240 */     return super.delete(Util1.EMPTY_REQUEST);
/*     */   }
/*     */   
/*     */   public Request1 put(Object youcangetnoinfoCZXPлРИЗ4) {
/* 244 */     return super.method("PUT", (RequestBody)youcangetnoinfoCZXPлРИЗ4);
/*     */   }
/*     */   
/*     */   public Request1 patch(Object youcangetnoinfoSFЖл3Ъы) {
/* 248 */     return super.method("PATCH", (RequestBody)youcangetnoinfoSFЖл3Ъы);
/*     */   }
/*     */   
/*     */   public Request1 method(Object youcangetnoinfoAWQX25Мжу, @Nullable Object youcangetnoinfoAWQYДнЯсХ) {
/* 252 */     if (youcangetnoinfoAWQX25Мжу == null) throw new NullPointerException("method == null"); 
/* 253 */     if (youcangetnoinfoAWQX25Мжу.length() == 0) throw new IllegalArgumentException("method.length() == 0"); 
/* 254 */     if (youcangetnoinfoAWQYДнЯсХ != null && !HttpMethod.permitsRequestBody((String)youcangetnoinfoAWQX25Мжу)) {
/* 255 */       throw new IllegalArgumentException("method " + youcangetnoinfoAWQX25Мжу + " must not have a request body.");
/*     */     }
/* 257 */     if (youcangetnoinfoAWQYДнЯсХ == null && HttpMethod.requiresRequestBody((String)youcangetnoinfoAWQX25Мжу)) {
/* 258 */       throw new IllegalArgumentException("method " + youcangetnoinfoAWQX25Мжу + " must have a request body.");
/*     */     }
/* 260 */     ((Request1)super).method = (String)youcangetnoinfoAWQX25Мжу;
/* 261 */     ((Request1)super).body = (RequestBody)youcangetnoinfoAWQYДнЯсХ;
/* 262 */     return (Request1)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Request1 tag(@Nullable Object youcangetnoinfoAILAцСжбЕ) {
/* 267 */     return super.tag(Object.class, youcangetnoinfoAILAцСжбЕ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request1 tag(Object youcangetnoinfoCVTPюжЭзП, @Nullable Object youcangetnoinfoCVTQчЮКмЯ) {
/* 279 */     if (youcangetnoinfoCVTPюжЭзП == null) throw new NullPointerException("type == null");
/*     */     
/* 281 */     if (youcangetnoinfoCVTQчЮКмЯ == null) {
/* 282 */       ((Request1)super).tags.remove(youcangetnoinfoCVTPюжЭзП);
/*     */     } else {
/* 284 */       if (((Request1)super).tags.isEmpty()) ((Request1)super).tags = new LinkedHashMap<>(); 
/* 285 */       ((Request1)super).tags.put(youcangetnoinfoCVTPюжЭзП, youcangetnoinfoCVTPюжЭзП.cast(youcangetnoinfoCVTQчЮКмЯ));
/*     */     } 
/*     */     
/* 288 */     return (Request1)this;
/*     */   }
/*     */   
/*     */   public Request build() {
/* 292 */     if (((Request1)super).url == null) throw new IllegalStateException("url == null"); 
/* 293 */     return new Request((Request1)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Request1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */