/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.SocketAddress;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Security;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Platform
/*     */ {
/*     */   public static final int INFO = 4;
/*     */   
/*     */   public Platform() {
/*  76 */     this();
/*  77 */   } public static final Platform PLATFORM = findPlatform();
/*     */   
/*     */   public static final int WARN = 5;
/*  80 */   public static final Logger logger = Logger.getLogger(OkHttpClient.class.getName());
/*     */   
/*     */   public static Platform get() {
/*  83 */     return PLATFORM;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPrefix() {
/*  88 */     return "OkHttp";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public X509TrustManager trustManager(Object youcangetnoinfoEMQYФгБлб) {
/*     */     try {
/*  96 */       Object<?> youcangetnoinfoEMQUЕ0ичЦ = (Object<?>)Class.forName("sun.security.ssl.SSLContextImpl");
/*  97 */       Object youcangetnoinfoEMQVАШЮЛ0 = readFieldOrNull(youcangetnoinfoEMQYФгБлб, (Class<?>)youcangetnoinfoEMQUЕ0ичЦ, "context");
/*  98 */       if (youcangetnoinfoEMQVАШЮЛ0 == null) return null; 
/*  99 */       return readFieldOrNull(youcangetnoinfoEMQVАШЮЛ0, X509TrustManager.class, "trustManager");
/* 100 */     } catch (ClassNotFoundException youcangetnoinfoEMQWр5аМН) {
/* 101 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureTlsExtensions(Object youcangetnoinfoWZTэЫЧФф, @Nullable Object youcangetnoinfoWZUЪЭКбэ, Object youcangetnoinfoWZV5ъАФо) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterHandshake(Object youcangetnoinfoDQOWвЫЬнШ) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public String getSelectedProtocol(Object youcangetnoinfoDPGZВЬЗоц) {
/* 123 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connectSocket(Object youcangetnoinfoCXJGЮФ8ЮЩ, Object youcangetnoinfoCXJHрхЙ3У, Object youcangetnoinfoCXJIнЦс4у) throws IOException {
/* 128 */     youcangetnoinfoCXJGЮФ8ЮЩ.connect((SocketAddress)youcangetnoinfoCXJHрхЙ3У, youcangetnoinfoCXJIнЦс4у);
/*     */   }
/*     */   
/*     */   public void log(Object youcangetnoinfoAMPIБгйгД, Object youcangetnoinfoAMPJЪЖРПЁ, @Nullable Object youcangetnoinfoAMPKрСЛЭк) {
/* 132 */     Object youcangetnoinfoAMPLЩчЁрд = (youcangetnoinfoAMPIБгйгД == 5) ? Level.WARNING : Level.INFO;
/* 133 */     logger.log((Level)youcangetnoinfoAMPLЩчЁрд, (String)youcangetnoinfoAMPJЪЖРПЁ, (Throwable)youcangetnoinfoAMPKрСЛЭк);
/*     */   }
/*     */   
/*     */   public boolean isCleartextTrafficPermitted(Object youcangetnoinfoUOZъ2ЮШЦ) {
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object getStackTraceForCloseable(Object youcangetnoinfoBOHIыиzТй) {
/* 146 */     if (logger.isLoggable(Level.FINE)) {
/* 147 */       return new Throwable((String)youcangetnoinfoBOHIыиzТй);
/*     */     }
/* 149 */     return null;
/*     */   }
/*     */   
/*     */   public void logCloseableLeak(Object youcangetnoinfoELARПгЁРа, Object youcangetnoinfoELAS9кбщй) {
/* 153 */     if (youcangetnoinfoELAS9кбщй == null) {
/* 154 */       youcangetnoinfoELARПгЁРа = youcangetnoinfoELARПгЁРа + " To see where this was allocated, set the OkHttpClient logger level to FINE: Logger.getLogger(OkHttpClient.class.getName()).setLevel(Level.FINE);";
/*     */     }
/*     */     
/* 157 */     super.log(5, (String)youcangetnoinfoELARПгЁРа, (Throwable)youcangetnoinfoELAS9кбщй);
/*     */   }
/*     */   
/*     */   public static List alpnProtocolNames(Object youcangetnoinfoDRHP8ёКбя) {
/* 161 */     Object youcangetnoinfoDRHQмЮ2дл = new ArrayList(youcangetnoinfoDRHP8ёКбя.size()); byte b; int i;
/* 162 */     for (b = 0, i = youcangetnoinfoDRHP8ёКбя.size(); b < i; b++) {
/* 163 */       Object youcangetnoinfoDRHM40еКЖ = youcangetnoinfoDRHP8ёКбя.get(b);
/* 164 */       if (youcangetnoinfoDRHM40еКЖ != Protocol.HTTP_1_0)
/* 165 */         youcangetnoinfoDRHQмЮ2дл.add(youcangetnoinfoDRHM40еКЖ.toString()); 
/*     */     } 
/* 167 */     return (List)youcangetnoinfoDRHQмЮ2дл;
/*     */   }
/*     */   
/*     */   public CertificateChainCleaner buildCertificateChainCleaner(Object youcangetnoinfoCKBNДФЪ4Ъ) {
/* 171 */     return new BasicCertificateChainCleaner(youcangetnoinfoCKBNДФЪ4Ъ.getAcceptedIssuers());
/*     */   }
/*     */   
/*     */   public CertificateChainCleaner buildCertificateChainCleaner(Object youcangetnoinfoCGKXХхЖРи) {
/* 175 */     Object youcangetnoinfoCGKYщСйММ = super.trustManager((SSLSocketFactory)youcangetnoinfoCGKXХхЖРи);
/*     */     
/* 177 */     if (youcangetnoinfoCGKYщСйММ == null) {
/* 178 */       throw new IllegalStateException("Unable to extract the trust manager on " + 
/* 179 */           get() + ", sslSocketFactory is " + youcangetnoinfoCGKXХхЖРи
/*     */           
/* 181 */           .getClass());
/*     */     }
/*     */     
/* 184 */     return super.buildCertificateChainCleaner((X509TrustManager)youcangetnoinfoCGKYщСйММ);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isConscryptPreferred() {
/* 189 */     if ("conscrypt".equals(Util1.getSystemProperty("okhttp.platform", null))) {
/* 190 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 194 */     Object youcangetnoinfoAAXWЖЧШЁи = Security.getProviders()[0].getName();
/* 195 */     return "Conscrypt".equals(youcangetnoinfoAAXWЖЧШЁи);
/*     */   }
/*     */ 
/*     */   
/*     */   public static Platform findPlatform() {
/* 200 */     Object youcangetnoinfoCENRУхВЯц = AndroidPlatform2.buildIfSupported();
/*     */     
/* 202 */     if (youcangetnoinfoCENRУхВЯц != null) {
/* 203 */       return (Platform)youcangetnoinfoCENRУхВЯц;
/*     */     }
/*     */     
/* 206 */     if (isConscryptPreferred()) {
/* 207 */       Object youcangetnoinfoCENQмК8на = ConscryptPlatform.buildIfSupported();
/*     */       
/* 209 */       if (youcangetnoinfoCENQмК8на != null) {
/* 210 */         return (Platform)youcangetnoinfoCENQмК8на;
/*     */       }
/*     */     } 
/*     */     
/* 214 */     Object youcangetnoinfoCENSсЗлЬы = Jdk9Platform.buildIfSupported();
/*     */     
/* 216 */     if (youcangetnoinfoCENSсЗлЬы != null) {
/* 217 */       return (Platform)youcangetnoinfoCENSсЗлЬы;
/*     */     }
/*     */     
/* 220 */     Object youcangetnoinfoCENTКй0ИЮ = Jdk8WithJettyBootPlatform1.buildIfSupported();
/*     */     
/* 222 */     if (youcangetnoinfoCENTКй0ИЮ != null) {
/* 223 */       return (Platform)youcangetnoinfoCENTКй0ИЮ;
/*     */     }
/*     */ 
/*     */     
/* 227 */     return new Platform();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] concatLengthPrefixed(Object youcangetnoinfoBBIYюЬЦХш) {
/* 235 */     Object youcangetnoinfoBBIZфзьш4 = new Buffer2(); byte b; int i;
/* 236 */     for (b = 0, i = youcangetnoinfoBBIYюЬЦХш.size(); b < i; b++) {
/* 237 */       Object youcangetnoinfoBBIVВОКУ5 = youcangetnoinfoBBIYюЬЦХш.get(b);
/* 238 */       if (youcangetnoinfoBBIVВОКУ5 != Protocol.HTTP_1_0) {
/* 239 */         youcangetnoinfoBBIZфзьш4.writeByte(youcangetnoinfoBBIVВОКУ5.toString().length());
/* 240 */         youcangetnoinfoBBIZфзьш4.writeUtf8(youcangetnoinfoBBIVВОКУ5.toString());
/*     */       } 
/* 242 */     }  return youcangetnoinfoBBIZфзьш4.readByteArray();
/*     */   }
/*     */   @Nullable
/*     */   public static <T> T readFieldOrNull(Object youcangetnoinfoBIBMЯАОёХ, Object youcangetnoinfoBIBNуЖ3Ю3, Object youcangetnoinfoBIBOКрчГГ) {
/* 246 */     for (Object<?> youcangetnoinfoBIBKАэЮр6 = (Object<?>)youcangetnoinfoBIBMЯАОёХ.getClass(); youcangetnoinfoBIBKАэЮр6 != Object.class; youcangetnoinfoBIBKАэЮр6 = (Object<?>)youcangetnoinfoBIBKАэЮр6.getSuperclass()) {
/*     */       
/* 248 */       try { Object youcangetnoinfoBIBHлЧГЁь = youcangetnoinfoBIBKАэЮр6.getDeclaredField((String)youcangetnoinfoBIBOКрчГГ);
/* 249 */         youcangetnoinfoBIBHлЧГЁь.setAccessible(true);
/* 250 */         Object youcangetnoinfoBIBIемзфг = youcangetnoinfoBIBHлЧГЁь.get(youcangetnoinfoBIBMЯАОёХ);
/* 251 */         if (!youcangetnoinfoBIBNуЖ3Ю3.isInstance(youcangetnoinfoBIBIемзфг)) return null; 
/* 252 */         return youcangetnoinfoBIBNуЖ3Ю3.cast(youcangetnoinfoBIBIемзфг); }
/* 253 */       catch (NoSuchFieldException noSuchFieldException) {  }
/* 254 */       catch (IllegalAccessException youcangetnoinfoBIBJт9эжШ)
/* 255 */       { throw new AssertionError(); }
/*     */     
/*     */     } 
/*     */ 
/*     */     
/* 260 */     if (!youcangetnoinfoBIBOКрчГГ.equals("delegate")) {
/* 261 */       Object youcangetnoinfoBIBLёЯдэЫ = readFieldOrNull(youcangetnoinfoBIBMЯАОёХ, Object.class, "delegate");
/* 262 */       if (youcangetnoinfoBIBLёЯдэЫ != null) return readFieldOrNull(youcangetnoinfoBIBLёЯдэЫ, (Class<T>)youcangetnoinfoBIBNуЖ3Ю3, (String)youcangetnoinfoBIBOКрчГГ);
/*     */     
/*     */     } 
/* 265 */     return null;
/*     */   }
/*     */   
/*     */   public SSLContext getSSLContext() {
/*     */     try {
/* 270 */       return SSLContext.getInstance("TLS");
/* 271 */     } catch (NoSuchAlgorithmException youcangetnoinfoEKLFфэаял) {
/* 272 */       throw new IllegalStateException("No TLS provider", youcangetnoinfoEKLFфэаял);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureSslSocketFactory(Object youcangetnoinfoDGIF5нт8А) {}
/*     */   
/*     */   public String toString() {
/* 280 */     return getClass().getSimpleName();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Platform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */