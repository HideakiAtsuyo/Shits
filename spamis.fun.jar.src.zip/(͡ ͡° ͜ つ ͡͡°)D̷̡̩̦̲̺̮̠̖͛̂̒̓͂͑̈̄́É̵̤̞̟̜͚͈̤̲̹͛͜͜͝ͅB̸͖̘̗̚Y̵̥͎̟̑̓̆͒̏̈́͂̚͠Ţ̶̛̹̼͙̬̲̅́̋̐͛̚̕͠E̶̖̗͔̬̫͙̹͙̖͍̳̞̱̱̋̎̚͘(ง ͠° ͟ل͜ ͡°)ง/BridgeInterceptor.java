/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class BridgeInterceptor
/*     */   implements Interceptor
/*     */ {
/*     */   public final CookieJar cookieJar;
/*     */   
/*     */   public BridgeInterceptor(Object youcangetnoinfoELXWьЗэсЖ) {
/*  43 */     this();
/*  44 */     ((BridgeInterceptor)super).cookieJar = (CookieJar)youcangetnoinfoELXWьЗэсЖ;
/*     */   }
/*     */   
/*     */   public Response intercept(Object youcangetnoinfoDJCPШ0АяЗ) throws IOException {
/*  48 */     Object youcangetnoinfoDJCQк36б8 = youcangetnoinfoDJCPШ0АяЗ.request();
/*  49 */     Object youcangetnoinfoDJCRпшф1п = youcangetnoinfoDJCQк36б8.newBuilder();
/*     */     
/*  51 */     Object youcangetnoinfoDJCS3ПБкТ = youcangetnoinfoDJCQк36б8.body();
/*  52 */     if (youcangetnoinfoDJCS3ПБкТ != null) {
/*  53 */       Object youcangetnoinfoDJCJухдфн = youcangetnoinfoDJCS3ПБкТ.contentType();
/*  54 */       if (youcangetnoinfoDJCJухдфн != null) {
/*  55 */         youcangetnoinfoDJCRпшф1п.header("Content-Type", youcangetnoinfoDJCJухдфн.toString());
/*     */       }
/*     */       
/*  58 */       long l = youcangetnoinfoDJCS3ПБкТ.contentLength();
/*  59 */       if (l != -1L) {
/*  60 */         youcangetnoinfoDJCRпшф1п.header("Content-Length", Long.toString(l));
/*  61 */         youcangetnoinfoDJCRпшф1п.removeHeader("Transfer-Encoding");
/*     */       } else {
/*  63 */         youcangetnoinfoDJCRпшф1п.header("Transfer-Encoding", "chunked");
/*  64 */         youcangetnoinfoDJCRпшф1п.removeHeader("Content-Length");
/*     */       } 
/*     */     } 
/*     */     
/*  68 */     if (youcangetnoinfoDJCQк36б8.header("Host") == null) {
/*  69 */       youcangetnoinfoDJCRпшф1п.header("Host", Util1.hostHeader(youcangetnoinfoDJCQк36б8.url(), false));
/*     */     }
/*     */     
/*  72 */     if (youcangetnoinfoDJCQк36б8.header("Connection") == null) {
/*  73 */       youcangetnoinfoDJCRпшф1п.header("Connection", "Keep-Alive");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  78 */     boolean bool = false;
/*  79 */     if (youcangetnoinfoDJCQк36б8.header("Accept-Encoding") == null && youcangetnoinfoDJCQк36б8.header("Range") == null) {
/*  80 */       bool = true;
/*  81 */       youcangetnoinfoDJCRпшф1п.header("Accept-Encoding", "gzip");
/*     */     } 
/*     */     
/*  84 */     Object youcangetnoinfoDJCUВ7Мтп = ((BridgeInterceptor)super).cookieJar.loadForRequest(youcangetnoinfoDJCQк36б8.url());
/*  85 */     if (!youcangetnoinfoDJCUВ7Мтп.isEmpty()) {
/*  86 */       youcangetnoinfoDJCRпшф1п.header("Cookie", super.cookieHeader((List)youcangetnoinfoDJCUВ7Мтп));
/*     */     }
/*     */     
/*  89 */     if (youcangetnoinfoDJCQк36б8.header("User-Agent") == null) {
/*  90 */       youcangetnoinfoDJCRпшф1п.header("User-Agent", Version.userAgent());
/*     */     }
/*     */     
/*  93 */     Object youcangetnoinfoDJCV6тХЭ8 = youcangetnoinfoDJCPШ0АяЗ.proceed(youcangetnoinfoDJCRпшф1п.build());
/*     */     
/*  95 */     HttpHeaders.receiveHeaders(((BridgeInterceptor)super).cookieJar, youcangetnoinfoDJCQк36б8.url(), youcangetnoinfoDJCV6тХЭ8.headers());
/*     */ 
/*     */     
/*  98 */     Object youcangetnoinfoDJCWХуяф0 = youcangetnoinfoDJCV6тХЭ8.newBuilder().request((Request)youcangetnoinfoDJCQк36б8);
/*     */     
/* 100 */     if (bool && "gzip"
/* 101 */       .equalsIgnoreCase(youcangetnoinfoDJCV6тХЭ8.header("Content-Encoding")) && 
/* 102 */       HttpHeaders.hasBody((Response)youcangetnoinfoDJCV6тХЭ8)) {
/* 103 */       Object youcangetnoinfoDJCLнЦНЧи = new GzipSource(youcangetnoinfoDJCV6тХЭ8.body().source());
/*     */ 
/*     */ 
/*     */       
/* 107 */       Object youcangetnoinfoDJCMщЭэяы = youcangetnoinfoDJCV6тХЭ8.headers().newBuilder().removeAll("Content-Encoding").removeAll("Content-Length").build();
/* 108 */       youcangetnoinfoDJCWХуяф0.headers((Headers)youcangetnoinfoDJCMщЭэяы);
/* 109 */       Object youcangetnoinfoDJCNЯюЧ1й = youcangetnoinfoDJCV6тХЭ8.header("Content-Type");
/* 110 */       youcangetnoinfoDJCWХуяф0.body(new RealResponseBody((String)youcangetnoinfoDJCNЯюЧ1й, -1L, Okio1.buffer((Source)youcangetnoinfoDJCLнЦНЧи)));
/*     */     } 
/*     */     
/* 113 */     return youcangetnoinfoDJCWХуяф0.build();
/*     */   }
/*     */ 
/*     */   
/*     */   public String cookieHeader(Object youcangetnoinfoBZMJФ9зэо) {
/* 118 */     Object youcangetnoinfoBZMKтя06Ф = new StringBuilder(); byte b; int i;
/* 119 */     for (b = 0, i = youcangetnoinfoBZMJФ9зэо.size(); b < i; b++) {
/* 120 */       if (b > 0) {
/* 121 */         youcangetnoinfoBZMKтя06Ф.append("; ");
/*     */       }
/* 123 */       Object youcangetnoinfoBZMFЕКНръ = youcangetnoinfoBZMJФ9зэо.get(b);
/* 124 */       youcangetnoinfoBZMKтя06Ф.append(youcangetnoinfoBZMFЕКНръ.name()).append('=').append(youcangetnoinfoBZMFЕКНръ.value());
/*     */     } 
/* 126 */     return youcangetnoinfoBZMKтя06Ф.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\BridgeInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */