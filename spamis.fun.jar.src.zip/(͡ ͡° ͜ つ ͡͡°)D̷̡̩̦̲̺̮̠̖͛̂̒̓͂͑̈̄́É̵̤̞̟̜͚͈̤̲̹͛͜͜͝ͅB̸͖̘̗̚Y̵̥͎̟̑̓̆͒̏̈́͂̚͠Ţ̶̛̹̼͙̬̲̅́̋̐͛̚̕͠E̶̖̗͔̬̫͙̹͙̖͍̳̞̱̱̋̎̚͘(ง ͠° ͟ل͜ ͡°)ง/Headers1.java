/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Headers1
/*     */ {
/*     */   public final List<String> namesAndValues;
/*     */   
/*     */   public Headers1() {
/* 290 */     this();
/* 291 */     ((Headers1)super).namesAndValues = new ArrayList<>(20);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers1 addLenient(Object youcangetnoinfoEDPOВусРШ) {
/* 298 */     int i = youcangetnoinfoEDPOВусРШ.indexOf(":", 1);
/* 299 */     if (i != -1)
/* 300 */       return super.addLenient(youcangetnoinfoEDPOВусРШ.substring(0, i), youcangetnoinfoEDPOВусРШ.substring(i + 1)); 
/* 301 */     if (youcangetnoinfoEDPOВусРШ.startsWith(":"))
/*     */     {
/*     */       
/* 304 */       return super.addLenient("", youcangetnoinfoEDPOВусРШ.substring(1));
/*     */     }
/* 306 */     return super.addLenient("", (String)youcangetnoinfoEDPOВусРШ);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers1 add(Object youcangetnoinfoCRXKъШТзх) {
/* 312 */     int i = youcangetnoinfoCRXKъШТзх.indexOf(":");
/* 313 */     if (i == -1) {
/* 314 */       throw new IllegalArgumentException("Unexpected header: " + youcangetnoinfoCRXKъШТзх);
/*     */     }
/* 316 */     return super.add(youcangetnoinfoCRXKъШТзх.substring(0, i).trim(), youcangetnoinfoCRXKъШТзх.substring(i + 1));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers1 add(Object youcangetnoinfoCWPRЫёхбМ, Object youcangetnoinfoCWPSмЙ9Ё5) {
/* 323 */     Headers.checkName((String)youcangetnoinfoCWPRЫёхбМ);
/* 324 */     Headers.checkValue((String)youcangetnoinfoCWPSмЙ9Ё5, (String)youcangetnoinfoCWPRЫёхбМ);
/* 325 */     return super.addLenient((String)youcangetnoinfoCWPRЫёхбМ, (String)youcangetnoinfoCWPSмЙ9Ё5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers1 addUnsafeNonAscii(Object youcangetnoinfoADPSЁжСД3, Object youcangetnoinfoADPTЭЗйхЯ) {
/* 333 */     Headers.checkName((String)youcangetnoinfoADPSЁжСД3);
/* 334 */     return super.addLenient((String)youcangetnoinfoADPSЁжСД3, (String)youcangetnoinfoADPTЭЗйхЯ);
/*     */   }
/*     */ 
/*     */   
/*     */   public Headers1 addAll(Object youcangetnoinfoDDBBуэнЫс) {
/*     */     byte b;
/*     */     int i;
/* 341 */     for (b = 0, i = youcangetnoinfoDDBBуэнЫс.size(); b < i; b++) {
/* 342 */       super.addLenient(youcangetnoinfoDDBBуэнЫс.name(b), youcangetnoinfoDDBBуэнЫс.value(b));
/*     */     }
/*     */     
/* 345 */     return (Headers1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers1 add(Object youcangetnoinfoDUIBМтНПЙ, Object youcangetnoinfoDUIC3Л6яИ) {
/* 353 */     if (youcangetnoinfoDUIC3Л6яИ == null) throw new NullPointerException("value for name " + youcangetnoinfoDUIBМтНПЙ + " == null"); 
/* 354 */     super.add((String)youcangetnoinfoDUIBМтНПЙ, HttpDate.format((Date)youcangetnoinfoDUIC3Л6яИ));
/* 355 */     return (Headers1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @IgnoreJRERequirement
/*     */   public Headers1 add(Object youcangetnoinfoACQL5тАРэ, Object youcangetnoinfoACQM6С8ВТ) {
/* 364 */     if (youcangetnoinfoACQM6С8ВТ == null) throw new NullPointerException("value for name " + youcangetnoinfoACQL5тАРэ + " == null"); 
/* 365 */     return super.add((String)youcangetnoinfoACQL5тАРэ, new Date(youcangetnoinfoACQM6С8ВТ.toEpochMilli()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers1 set(Object youcangetnoinfoAETH7гЁ3ы, Object youcangetnoinfoAETIю9жтЗ) {
/* 373 */     if (youcangetnoinfoAETIю9жтЗ == null) throw new NullPointerException("value for name " + youcangetnoinfoAETH7гЁ3ы + " == null"); 
/* 374 */     super.set((String)youcangetnoinfoAETH7гЁ3ы, HttpDate.format((Date)youcangetnoinfoAETIю9жтЗ));
/* 375 */     return (Headers1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @IgnoreJRERequirement
/*     */   public Headers1 set(Object youcangetnoinfoCYJJвУСаЬ, Object youcangetnoinfoCYJKяхКВъ) {
/* 384 */     if (youcangetnoinfoCYJKяхКВъ == null) throw new NullPointerException("value for name " + youcangetnoinfoCYJJвУСаЬ + " == null"); 
/* 385 */     return super.set((String)youcangetnoinfoCYJJвУСаЬ, new Date(youcangetnoinfoCYJKяхКВъ.toEpochMilli()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers1 addLenient(Object youcangetnoinfoDRJYИазп9, Object youcangetnoinfoDRJZЁВЯяz) {
/* 393 */     ((Headers1)super).namesAndValues.add(youcangetnoinfoDRJYИазп9);
/* 394 */     ((Headers1)super).namesAndValues.add(youcangetnoinfoDRJZЁВЯяz.trim());
/* 395 */     return (Headers1)this;
/*     */   }
/*     */   
/*     */   public Headers1 removeAll(Object youcangetnoinfoECPI35ч2Ф) {
/* 399 */     for (byte b = 0; b < ((Headers1)super).namesAndValues.size(); b += 2) {
/* 400 */       if (youcangetnoinfoECPI35ч2Ф.equalsIgnoreCase(((Headers1)super).namesAndValues.get(b))) {
/* 401 */         ((Headers1)super).namesAndValues.remove(b);
/* 402 */         ((Headers1)super).namesAndValues.remove(b);
/* 403 */         b -= 2;
/*     */       } 
/*     */     } 
/* 406 */     return (Headers1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers1 set(Object youcangetnoinfoEIHUАКафШ, Object youcangetnoinfoEIHVЖНш6е) {
/* 414 */     Headers.checkName((String)youcangetnoinfoEIHUАКафШ);
/* 415 */     Headers.checkValue((String)youcangetnoinfoEIHVЖНш6е, (String)youcangetnoinfoEIHUАКафШ);
/* 416 */     super.removeAll((String)youcangetnoinfoEIHUАКафШ);
/* 417 */     super.addLenient((String)youcangetnoinfoEIHUАКафШ, (String)youcangetnoinfoEIHVЖНш6е);
/* 418 */     return (Headers1)this;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public String get(Object youcangetnoinfoDWEI9веюШ) {
/* 423 */     for (int i = ((Headers1)super).namesAndValues.size() - 2; i >= 0; i -= 2) {
/* 424 */       if (youcangetnoinfoDWEI9веюШ.equalsIgnoreCase(((Headers1)super).namesAndValues.get(i))) {
/* 425 */         return ((Headers1)super).namesAndValues.get(i + 1);
/*     */       }
/*     */     } 
/* 428 */     return null;
/*     */   }
/*     */   
/*     */   public Headers build() {
/* 432 */     return new Headers((Headers1)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Headers1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */