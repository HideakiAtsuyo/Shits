/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.zip.CRC32;
/*     */ import java.util.zip.Deflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GzipSink
/*     */   implements Sink
/*     */ {
/*     */   public final BufferedSink sink;
/*     */   public final Deflater deflater;
/*     */   public boolean closed;
/*     */   public final CRC32 crc;
/*     */   public final DeflaterSink deflaterSink;
/*     */   
/*     */   public GzipSink(Object youcangetnoinfoETQ4зэфТ) {
/*  56 */     this(); ((GzipSink)super).crc = new CRC32();
/*  57 */     if (youcangetnoinfoETQ4зэфТ == null) throw new IllegalArgumentException("sink == null"); 
/*  58 */     ((GzipSink)super).deflater = new Deflater(-1, true);
/*  59 */     ((GzipSink)super).sink = Okio1.buffer((Sink)youcangetnoinfoETQ4зэфТ);
/*  60 */     ((GzipSink)super).deflaterSink = new DeflaterSink(((GzipSink)super).sink, ((GzipSink)super).deflater);
/*     */     
/*  62 */     super.writeHeader();
/*     */   }
/*     */   
/*     */   public void write(Object youcangetnoinfoDKXYшЙ5рг, Object youcangetnoinfoDKXZАЧАМ4) throws IOException {
/*  66 */     if (youcangetnoinfoDKXZАЧАМ4 < 0L) throw new IllegalArgumentException("byteCount < 0: " + youcangetnoinfoDKXZАЧАМ4); 
/*  67 */     if (youcangetnoinfoDKXZАЧАМ4 == 0L)
/*     */       return; 
/*  69 */     super.updateCrc((Buffer2)youcangetnoinfoDKXYшЙ5рг, youcangetnoinfoDKXZАЧАМ4);
/*  70 */     ((GzipSink)super).deflaterSink.write((Buffer2)youcangetnoinfoDKXYшЙ5рг, youcangetnoinfoDKXZАЧАМ4);
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/*  74 */     ((GzipSink)super).deflaterSink.flush();
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/*  78 */     return ((GzipSink)super).sink.timeout();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  82 */     if (((GzipSink)super).closed) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  89 */     Object youcangetnoinfoEIDN3жУДш = null;
/*     */     try {
/*  91 */       ((GzipSink)super).deflaterSink.finishDeflate();
/*  92 */       super.writeFooter();
/*  93 */     } catch (Throwable youcangetnoinfoEIDJЛгРЗъ) {
/*  94 */       youcangetnoinfoEIDN3жУДш = youcangetnoinfoEIDJЛгРЗъ;
/*     */     } 
/*     */     
/*     */     try {
/*  98 */       ((GzipSink)super).deflater.end();
/*  99 */     } catch (Throwable youcangetnoinfoEIDKю4оОз) {
/* 100 */       if (youcangetnoinfoEIDN3жУДш == null) youcangetnoinfoEIDN3жУДш = youcangetnoinfoEIDKю4оОз;
/*     */     
/*     */     } 
/*     */     try {
/* 104 */       ((GzipSink)super).sink.close();
/* 105 */     } catch (Throwable youcangetnoinfoEIDLГ0Угд) {
/* 106 */       if (youcangetnoinfoEIDN3жУДш == null) youcangetnoinfoEIDN3жУДш = youcangetnoinfoEIDLГ0Угд; 
/*     */     } 
/* 108 */     ((GzipSink)super).closed = true;
/*     */     
/* 110 */     if (youcangetnoinfoEIDN3жУДш != null) Util.sneakyRethrow((Throwable)youcangetnoinfoEIDN3жУДш);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Deflater deflater() {
/* 118 */     return ((GzipSink)super).deflater;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeHeader() {
/* 123 */     Object youcangetnoinfoCNBVУzэ0ш = ((GzipSink)super).sink.buffer();
/* 124 */     youcangetnoinfoCNBVУzэ0ш.writeShort(8075);
/* 125 */     youcangetnoinfoCNBVУzэ0ш.writeByte(8);
/* 126 */     youcangetnoinfoCNBVУzэ0ш.writeByte(0);
/* 127 */     youcangetnoinfoCNBVУzэ0ш.writeInt(0);
/* 128 */     youcangetnoinfoCNBVУzэ0ш.writeByte(0);
/* 129 */     youcangetnoinfoCNBVУzэ0ш.writeByte(0);
/*     */   }
/*     */   
/*     */   public void writeFooter() throws IOException {
/* 133 */     ((GzipSink)super).sink.writeIntLe((int)((GzipSink)super).crc.getValue());
/* 134 */     ((GzipSink)super).sink.writeIntLe((int)((GzipSink)super).deflater.getBytesRead());
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateCrc(Object youcangetnoinfoBZCWф1ШсЯ, Object youcangetnoinfoBZCXэЦФяё) {
/* 139 */     for (Object youcangetnoinfoBZCUО55ДШ = ((Buffer2)youcangetnoinfoBZCWф1ШсЯ).head; youcangetnoinfoBZCXэЦФяё > 0L; youcangetnoinfoBZCUО55ДШ = ((Segment)youcangetnoinfoBZCUО55ДШ).next) {
/* 140 */       int i = (int)Math.min(youcangetnoinfoBZCXэЦФяё, (((Segment)youcangetnoinfoBZCUО55ДШ).limit - ((Segment)youcangetnoinfoBZCUО55ДШ).pos));
/* 141 */       ((GzipSink)super).crc.update(((Segment)youcangetnoinfoBZCUО55ДШ).data, ((Segment)youcangetnoinfoBZCUО55ДШ).pos, i);
/* 142 */       long l = youcangetnoinfoBZCXэЦФяё - i;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\GzipSink.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */