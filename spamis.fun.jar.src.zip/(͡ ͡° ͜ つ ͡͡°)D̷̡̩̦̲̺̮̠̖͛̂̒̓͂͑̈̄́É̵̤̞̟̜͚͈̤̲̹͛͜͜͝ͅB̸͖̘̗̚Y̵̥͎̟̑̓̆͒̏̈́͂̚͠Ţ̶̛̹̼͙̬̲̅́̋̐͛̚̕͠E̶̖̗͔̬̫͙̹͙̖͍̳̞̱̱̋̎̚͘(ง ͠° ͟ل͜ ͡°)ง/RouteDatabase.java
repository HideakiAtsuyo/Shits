/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.util.LinkedHashSet;
/*    */ import java.util.Set;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RouteDatabase
/*    */ {
/*    */   public final Set failedRoutes;
/*    */   
/*    */   public RouteDatabase() {
/* 28 */     this();
/* 29 */     ((RouteDatabase)super).failedRoutes = new LinkedHashSet();
/*    */   }
/*    */   
/*    */   public synchronized void failed(Object youcangetnoinfoBQBZюЫн5и) {
/* 33 */     ((RouteDatabase)super).failedRoutes.add(youcangetnoinfoBQBZюЫн5и);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized void connected(Object youcangetnoinfoOQQш6ьэы) {
/* 38 */     ((RouteDatabase)super).failedRoutes.remove(youcangetnoinfoOQQш6ьэы);
/*    */   }
/*    */ 
/*    */   
/*    */   public synchronized boolean shouldPostpone(Object youcangetnoinfoILYДкклЖ) {
/* 43 */     return ((RouteDatabase)super).failedRoutes.contains(youcangetnoinfoILYДкклЖ);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RouteDatabase.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */