/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PeekSource
/*    */   implements Source
/*    */ {
/*    */   public boolean closed;
/*    */   public final BufferedSource upstream;
/*    */   public Segment expectedSegment;
/*    */   public long pos;
/*    */   public final Buffer2 buffer;
/*    */   public int expectedPos;
/*    */   
/*    */   public PeekSource(Object youcangetnoinfoCCBHъузЙЪ) {
/* 39 */     this();
/* 40 */     ((PeekSource)super).upstream = (BufferedSource)youcangetnoinfoCCBHъузЙЪ;
/* 41 */     ((PeekSource)super).buffer = youcangetnoinfoCCBHъузЙЪ.buffer();
/* 42 */     ((PeekSource)super).expectedSegment = ((PeekSource)super).buffer.head;
/* 43 */     ((PeekSource)super).expectedPos = (((PeekSource)super).expectedSegment != null) ? ((PeekSource)super).expectedSegment.pos : -1;
/*    */   }
/*    */   
/*    */   public long read(Object youcangetnoinfoBUSBлрьиТ, Object youcangetnoinfoBUSCТлбЬш) throws IOException {
/* 47 */     if (((PeekSource)super).closed) throw new IllegalStateException("closed");
/*    */ 
/*    */ 
/*    */     
/* 51 */     if (((PeekSource)super).expectedSegment != null && (((PeekSource)super).expectedSegment != ((PeekSource)super).buffer.head || ((PeekSource)super).expectedPos != ((PeekSource)super).buffer.head.pos))
/*    */     {
/* 53 */       throw new IllegalStateException("Peek source is invalid because upstream source was used");
/*    */     }
/*    */     
/* 56 */     ((PeekSource)super).upstream.request(((PeekSource)super).pos + youcangetnoinfoBUSCТлбЬш);
/* 57 */     if (((PeekSource)super).expectedSegment == null && ((PeekSource)super).buffer.head != null) {
/*    */ 
/*    */ 
/*    */       
/* 61 */       ((PeekSource)super).expectedSegment = ((PeekSource)super).buffer.head;
/* 62 */       ((PeekSource)super).expectedPos = ((PeekSource)super).buffer.head.pos;
/*    */     } 
/*    */     
/* 65 */     long l = Math.min(youcangetnoinfoBUSCТлбЬш, ((PeekSource)super).buffer.size - ((PeekSource)super).pos);
/* 66 */     if (l <= 0L) return -1L;
/*    */     
/* 68 */     ((PeekSource)super).buffer.copyTo((Buffer2)youcangetnoinfoBUSBлрьиТ, ((PeekSource)super).pos, l);
/* 69 */     ((PeekSource)super).pos += l;
/* 70 */     return l;
/*    */   }
/*    */   
/*    */   public Timeout timeout() {
/* 74 */     return ((PeekSource)super).upstream.timeout();
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 78 */     ((PeekSource)super).closed = true;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\PeekSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */