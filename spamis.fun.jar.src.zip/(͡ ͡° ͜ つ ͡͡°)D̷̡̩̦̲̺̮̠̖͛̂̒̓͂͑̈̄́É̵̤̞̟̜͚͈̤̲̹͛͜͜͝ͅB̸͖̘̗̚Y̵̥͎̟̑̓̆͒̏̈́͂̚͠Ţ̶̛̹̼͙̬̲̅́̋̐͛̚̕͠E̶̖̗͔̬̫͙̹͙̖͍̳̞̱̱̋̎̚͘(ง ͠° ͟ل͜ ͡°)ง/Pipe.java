/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Pipe
/*    */ {
/*    */   @Nullable
/*    */   public Sink foldedSink;
/*    */   public final Source source;
/*    */   public final Sink sink;
/*    */   public final Buffer2 buffer;
/*    */   public final long maxBufferSize;
/*    */   public boolean sourceClosed;
/*    */   public boolean sinkClosed;
/*    */   
/*    */   public Pipe(Object youcangetnoinfoDASJф5йМе) {
/* 46 */     this(); ((Pipe)super).buffer = new Buffer2(); ((Pipe)super).sink = new Pipe1((Pipe)this); ((Pipe)super).source = new Pipe2((Pipe)this);
/* 47 */     if (youcangetnoinfoDASJф5йМе < 1L) {
/* 48 */       throw new IllegalArgumentException("maxBufferSize < 1: " + youcangetnoinfoDASJф5йМе);
/*    */     }
/* 50 */     ((Pipe)super).maxBufferSize = youcangetnoinfoDASJф5йМе;
/*    */   }
/*    */   
/*    */   public final Source source() {
/* 54 */     return ((Pipe)super).source;
/*    */   }
/*    */   
/*    */   public final Sink sink() {
/* 58 */     return ((Pipe)super).sink;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void fold(Object youcangetnoinfoDVIBСш2юы) throws IOException {
/*    */     while (true) {
/*    */       Object youcangetnoinfoDVHXЮЫЖЩн;
/* 72 */       synchronized (((Pipe)super).buffer) {
/* 73 */         if (((Pipe)super).foldedSink != null) throw new IllegalStateException("sink already folded");
/*    */         
/* 75 */         if (((Pipe)super).buffer.exhausted()) {
/* 76 */           ((Pipe)super).sourceClosed = true;
/* 77 */           ((Pipe)super).foldedSink = (Sink)youcangetnoinfoDVIBСш2юы;
/*    */           
/*    */           return;
/*    */         } 
/* 81 */         youcangetnoinfoDVHXЮЫЖЩн = new Buffer2();
/* 82 */         youcangetnoinfoDVHXЮЫЖЩн.write(((Pipe)super).buffer, ((Pipe)super).buffer.size);
/* 83 */         ((Pipe)super).buffer.notifyAll();
/*    */       } 
/*    */       
/* 86 */       boolean bool = false;
/*    */       try {
/* 88 */         youcangetnoinfoDVIBСш2юы.write((Buffer2)youcangetnoinfoDVHXЮЫЖЩн, ((Buffer2)youcangetnoinfoDVHXЮЫЖЩн).size);
/* 89 */         youcangetnoinfoDVIBСш2юы.flush();
/* 90 */         bool = true;
/*    */       } finally {
/* 92 */         if (!bool)
/* 93 */           synchronized (((Pipe)super).buffer) {
/* 94 */             ((Pipe)super).sourceClosed = true;
/* 95 */             ((Pipe)super).buffer.notifyAll();
/*    */           }  
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Pipe.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */