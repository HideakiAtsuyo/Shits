/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import fun.spamis.spammer.SpamIsFun;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.TableModel;
/*     */ import net.dv8tion.jda.core.JDA;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TokensGUI1
/*     */   extends JFrame
/*     */ {
/*     */   public JPanel contentPane;
/*     */   public static JDA jda;
/*     */   public static final long serialVersionUID = 1L;
/*     */   
/*     */   public TokensGUI1() {
/*  47 */     setResizable(false);
/*  48 */     setTitle("Token manager");
/*  49 */     setBounds(100, 100, 430, 414);
/*  50 */     setLocationRelativeTo(null);
/*  51 */     ((TokensGUI1)super).contentPane = new JPanel();
/*  52 */     ((TokensGUI1)super).contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
/*  53 */     setContentPane(((TokensGUI1)super).contentPane);
/*  54 */     ((TokensGUI1)super).contentPane.setLayout((LayoutManager)null);
/*     */     
/*  56 */     Object youcangetnoinfoBGTLдх31Г = new String[0];
/*  57 */     Object youcangetnoinfoBGTM7ь2Г0 = new Object[0][];
/*  58 */     Object youcangetnoinfoBGTNЮЫУию = new TokensGUI2((TokensGUI1)this, (Object[][])youcangetnoinfoBGTM7ь2Г0, (Object[])youcangetnoinfoBGTLдх31Г);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  65 */     youcangetnoinfoBGTNЮЫУию.setFont(new Font("Dialog", 0, 11));
/*  66 */     Object youcangetnoinfoBGTOёАэьШ = new DefaultTableModel((Object[])new String[] { "#", "Token" }, 0);
/*     */     
/*  68 */     youcangetnoinfoBGTNЮЫУию.setModel((TableModel)youcangetnoinfoBGTOёАэьШ);
/*  69 */     youcangetnoinfoBGTNЮЫУию.getTableHeader().setReorderingAllowed(false);
/*  70 */     youcangetnoinfoBGTNЮЫУию.getColumnModel().getColumn(1).setPreferredWidth(400);
/*  71 */     youcangetnoinfoBGTNЮЫУию.setAutoResizeMode(3);
/*     */     
/*  73 */     Object youcangetnoinfoBGTPодйГ3 = new JScrollPane((Component)youcangetnoinfoBGTNЮЫУию, 22, 30);
/*     */     
/*  75 */     youcangetnoinfoBGTPодйГ3.setBounds(-1, 86, 431, 298);
/*  76 */     ((TokensGUI1)super).contentPane.add((Component)youcangetnoinfoBGTPодйГ3);
/*     */     
/*  78 */     Object youcangetnoinfoBGTQЫёВэК = new JButton("IMPORT");
/*  79 */     youcangetnoinfoBGTQЫёВэК.setIcon(new ImageIcon(getClass().getResource("/ui/add.png")));
/*  80 */     youcangetnoinfoBGTQЫёВэК.setBounds(12, 12, 117, 25);
/*  81 */     youcangetnoinfoBGTQЫёВэК.addActionListener(new TokensGUI5((TokensGUI1)this, (DefaultTableModel)youcangetnoinfoBGTOёАэьШ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     ((TokensGUI1)super).contentPane.add((Component)youcangetnoinfoBGTQЫёВэК);
/*     */     
/* 100 */     Object youcangetnoinfoBGTRИЖцШ3 = new JButton("REMOVE ALL");
/* 101 */     youcangetnoinfoBGTRИЖцШ3.setIcon(new ImageIcon(getClass().getResource("/ui/remove.png")));
/* 102 */     youcangetnoinfoBGTRИЖцШ3.setBounds(141, 12, 126, 25);
/* 103 */     youcangetnoinfoBGTRИЖцШ3.addActionListener(new TokensGUI4((TokensGUI1)this, (DefaultTableModel)youcangetnoinfoBGTOёАэьШ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 112 */     ((TokensGUI1)super).contentPane.add((Component)youcangetnoinfoBGTRИЖцШ3);
/*     */     
/* 114 */     Object youcangetnoinfoBGTSМ1р3у = new JButton("EXPORT");
/* 115 */     youcangetnoinfoBGTSМ1р3у.setIcon(new ImageIcon(getClass().getResource("/ui/export.png")));
/* 116 */     youcangetnoinfoBGTSМ1р3у.setBounds(279, 12, 126, 25);
/* 117 */     youcangetnoinfoBGTSМ1р3у.addActionListener(new TokensGUI((TokensGUI1)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     ((TokensGUI1)super).contentPane.add((Component)youcangetnoinfoBGTSМ1р3у);
/*     */     
/* 144 */     Object youcangetnoinfoBGTTшЁаХ3 = new JButton("Activate tokens (Bypasses 'unauthorized')");
/* 145 */     youcangetnoinfoBGTTшЁаХ3.setIcon(new ImageIcon(getClass().getResource("/ui/activate.png")));
/* 146 */     youcangetnoinfoBGTTшЁаХ3.setBounds(12, 49, 393, 25);
/* 147 */     youcangetnoinfoBGTTшЁаХ3.addActionListener(new TokensGUI3((TokensGUI1)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 178 */     ((TokensGUI1)super).contentPane.add((Component)youcangetnoinfoBGTTшЁаХ3);
/*     */ 
/*     */ 
/*     */     
/* 182 */     Object youcangetnoinfoBGTUЧ8zёо = SpamIsFun.tokens.entrySet();
/* 183 */     Object youcangetnoinfoBGTVК2нШг = youcangetnoinfoBGTUЧ8zёо.iterator();
/* 184 */     while (youcangetnoinfoBGTVК2нШг.hasNext()) {
/* 185 */       Object youcangetnoinfoBGTJГЖМге = youcangetnoinfoBGTVК2нШг.next();
/* 186 */       youcangetnoinfoBGTOёАэьШ.addRow(new Object[] { youcangetnoinfoBGTJГЖМге.getKey(), youcangetnoinfoBGTJГЖМге.getValue() });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\TokensGUI1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */