/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Pipe1
/*     */   implements Sink
/*     */ {
/*     */   public final Pipe this$0;
/*     */   public final PushableTimeout timeout;
/*     */   
/*     */   public Pipe1() {
/* 102 */     this();
/* 103 */     ((Pipe1)super).timeout = new PushableTimeout();
/*     */   } public void write(Object youcangetnoinfoAIPUУЦцЬг, Object youcangetnoinfoAIPVжд5у3) throws IOException {
/*     */     long l;
/* 106 */     Object youcangetnoinfoAIPWПчямЕ = null;
/* 107 */     synchronized (((Pipe1)super).this$0.buffer) {
/* 108 */       if (((Pipe1)super).this$0.sinkClosed) throw new IllegalStateException("closed");
/*     */       
/* 110 */       while (youcangetnoinfoAIPVжд5у3 > 0L) {
/* 111 */         if (Pipe.access$000(((Pipe1)super).this$0) != null) {
/* 112 */           youcangetnoinfoAIPWПчямЕ = Pipe.access$000(((Pipe1)super).this$0);
/*     */           
/*     */           break;
/*     */         } 
/* 116 */         if (((Pipe1)super).this$0.sourceClosed) throw new IOException("source is closed");
/*     */         
/* 118 */         long l1 = ((Pipe1)super).this$0.maxBufferSize - ((Pipe1)super).this$0.buffer.size();
/* 119 */         if (l1 == 0L) {
/* 120 */           ((Pipe1)super).timeout.waitUntilNotified(((Pipe1)super).this$0.buffer);
/*     */           
/*     */           continue;
/*     */         } 
/* 124 */         long l2 = Math.min(l1, youcangetnoinfoAIPVжд5у3);
/* 125 */         ((Pipe1)super).this$0.buffer.write((Buffer2)youcangetnoinfoAIPUУЦцЬг, l2);
/* 126 */         l = youcangetnoinfoAIPVжд5у3 - l2;
/* 127 */         ((Pipe1)super).this$0.buffer.notifyAll();
/*     */       } 
/*     */     } 
/*     */     
/* 131 */     if (youcangetnoinfoAIPWПчямЕ != null) {
/* 132 */       ((Pipe1)super).timeout.push(youcangetnoinfoAIPWПчямЕ.timeout());
/*     */       try {
/* 134 */         youcangetnoinfoAIPWПчямЕ.write((Buffer2)youcangetnoinfoAIPUУЦцЬг, l);
/*     */       } finally {
/* 136 */         ((Pipe1)super).timeout.pop();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 142 */     Object youcangetnoinfoBMCW9ШНП9 = null;
/* 143 */     synchronized (((Pipe1)super).this$0.buffer) {
/* 144 */       if (((Pipe1)super).this$0.sinkClosed) throw new IllegalStateException("closed");
/*     */       
/* 146 */       if (Pipe.access$000(((Pipe1)super).this$0) != null) {
/* 147 */         youcangetnoinfoBMCW9ШНП9 = Pipe.access$000(((Pipe1)super).this$0);
/* 148 */       } else if (((Pipe1)super).this$0.sourceClosed && ((Pipe1)super).this$0.buffer.size() > 0L) {
/* 149 */         throw new IOException("source is closed");
/*     */       } 
/*     */     } 
/*     */     
/* 153 */     if (youcangetnoinfoBMCW9ШНП9 != null) {
/* 154 */       ((Pipe1)super).timeout.push(youcangetnoinfoBMCW9ШНП9.timeout());
/*     */       try {
/* 156 */         youcangetnoinfoBMCW9ШНП9.flush();
/*     */       } finally {
/* 158 */         ((Pipe1)super).timeout.pop();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 164 */     Object youcangetnoinfoEEYZТЪАое = null;
/* 165 */     synchronized (((Pipe1)super).this$0.buffer) {
/* 166 */       if (((Pipe1)super).this$0.sinkClosed)
/*     */         return; 
/* 168 */       if (Pipe.access$000(((Pipe1)super).this$0) != null) {
/* 169 */         youcangetnoinfoEEYZТЪАое = Pipe.access$000(((Pipe1)super).this$0);
/*     */       } else {
/* 171 */         if (((Pipe1)super).this$0.sourceClosed && ((Pipe1)super).this$0.buffer.size() > 0L) throw new IOException("source is closed"); 
/* 172 */         ((Pipe1)super).this$0.sinkClosed = true;
/* 173 */         ((Pipe1)super).this$0.buffer.notifyAll();
/*     */       } 
/*     */     } 
/*     */     
/* 177 */     if (youcangetnoinfoEEYZТЪАое != null) {
/* 178 */       ((Pipe1)super).timeout.push(youcangetnoinfoEEYZТЪАое.timeout());
/*     */       try {
/* 180 */         youcangetnoinfoEEYZТЪАое.close();
/*     */       } finally {
/* 182 */         ((Pipe1)super).timeout.pop();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 188 */     return ((Pipe1)super).timeout;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Pipe1.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */