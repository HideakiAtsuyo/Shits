/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactionSpammer4
/*     */   extends Thread
/*     */ {
/*     */   public final Map.Entry val$token;
/*     */   public final ReactionSpammer7 this$2;
/*     */   
/*     */   public void run() {
/* 100 */     boolean bool = true;
/* 101 */     while (bool) {
/*     */       try {
/* 103 */         Object youcangetnoinfoEGSJВЛн2б = SpamUtils.getRandomProxy();
/* 104 */         Object youcangetnoinfoEGSKвЁйЖ8 = SpamUtils.addReaction(reactChannelField.getText(), reactMessageField
/* 105 */             .getText(), reactEmojiField.getText(), token
/* 106 */             .getValue().toString(), (String)youcangetnoinfoEGSJВЛн2б);
/* 107 */         if (youcangetnoinfoEGSKвЁйЖ8 == null) {
/* 108 */           ConsoleGUI.log(youcangetnoinfoEGSJВЛн2б + "-> Token(" + token
/* 109 */               .getKey() + ")-> Reaction added");
/* 110 */           bool = false;
/* 111 */         } else if (youcangetnoinfoEGSKвЁйЖ8.startsWith("<")) {
/* 112 */           ConsoleGUI.log(youcangetnoinfoEGSJВЛн2б + "-> Token(" + token.getKey() + ")-> Proxy failed. Retrying");
/*     */         } else {
/*     */           
/* 115 */           ConsoleGUI.log(youcangetnoinfoEGSJВЛн2б + "-> Token(" + token.getKey() + ")-> Unknown error: " + youcangetnoinfoEGSKвЁйЖ8);
/*     */           
/* 117 */           bool = false;
/*     */         } 
/* 119 */       } catch (IOException youcangetnoinfoEGSLяёЕяЕ) {
/* 120 */         youcangetnoinfoEGSLяёЕяЕ.printStackTrace();
/*     */       } 
/*     */       try {
/* 123 */         Thread.sleep(100L);
/* 124 */       } catch (InterruptedException interruptedException) {}
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ReactionSpammer4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */