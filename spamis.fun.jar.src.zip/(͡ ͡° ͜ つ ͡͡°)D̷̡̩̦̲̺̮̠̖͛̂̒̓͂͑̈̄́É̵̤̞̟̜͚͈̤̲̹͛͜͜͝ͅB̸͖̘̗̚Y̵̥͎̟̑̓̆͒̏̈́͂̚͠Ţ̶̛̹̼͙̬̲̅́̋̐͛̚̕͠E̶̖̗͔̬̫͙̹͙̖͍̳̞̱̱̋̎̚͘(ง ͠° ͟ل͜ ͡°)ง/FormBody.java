/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormBody
/*     */   extends RequestBody
/*     */ {
/*     */   public final List<String> encodedNames;
/*  31 */   public static final MediaType CONTENT_TYPE = MediaType.get("application/x-www-form-urlencoded");
/*     */   
/*     */   public final List<String> encodedValues;
/*     */ 
/*     */   
/*     */   public FormBody(Object youcangetnoinfoDZFRщеПъФ, Object youcangetnoinfoDZFSСч6БЯ) {
/*  37 */     ((FormBody)super).encodedNames = Util1.immutableList((List<String>)youcangetnoinfoDZFRщеПъФ);
/*  38 */     ((FormBody)super).encodedValues = Util1.immutableList((List<String>)youcangetnoinfoDZFSСч6БЯ);
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  43 */     return ((FormBody)super).encodedNames.size();
/*     */   }
/*     */   
/*     */   public String encodedName(Object youcangetnoinfoEPQхзъац) {
/*  47 */     return ((FormBody)super).encodedNames.get(youcangetnoinfoEPQхзъац);
/*     */   }
/*     */   
/*     */   public String name(Object youcangetnoinfoANCI830Жк) {
/*  51 */     return HttpUrl1.percentDecode(super.encodedName(youcangetnoinfoANCI830Жк), true);
/*     */   }
/*     */   
/*     */   public String encodedValue(Object youcangetnoinfoDEDHнЫЩ84) {
/*  55 */     return ((FormBody)super).encodedValues.get(youcangetnoinfoDEDHнЫЩ84);
/*     */   }
/*     */   
/*     */   public String value(Object youcangetnoinfoAOIJфцШ1п) {
/*  59 */     return HttpUrl1.percentDecode(super.encodedValue(youcangetnoinfoAOIJфцШ1п), true);
/*     */   }
/*     */   
/*     */   public MediaType contentType() {
/*  63 */     return CONTENT_TYPE;
/*     */   }
/*     */   
/*     */   public long contentLength() {
/*  67 */     return super.writeOrCountBytes(null, true);
/*     */   }
/*     */   
/*     */   public void writeTo(Object youcangetnoinfoAULIЪпйИК) throws IOException {
/*  71 */     super.writeOrCountBytes((BufferedSink)youcangetnoinfoAULIЪпйИК, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long writeOrCountBytes(@Nullable Object youcangetnoinfoHXBх0ж48, Object youcangetnoinfoHXCЁнщ4М) {
/*     */     Object youcangetnoinfoHXEХзВ5З;
/*  81 */     long l = 0L;
/*     */ 
/*     */     
/*  84 */     if (youcangetnoinfoHXCЁнщ4М != null) {
/*  85 */       Object youcangetnoinfoHWXщёкzО = new Buffer2();
/*     */     } else {
/*  87 */       youcangetnoinfoHXEХзВ5З = youcangetnoinfoHXBх0ж48.buffer();
/*     */     }  byte b;
/*     */     int i;
/*  90 */     for (b = 0, i = ((FormBody)super).encodedNames.size(); b < i; b++) {
/*  91 */       if (b > 0) youcangetnoinfoHXEХзВ5З.writeByte(38); 
/*  92 */       youcangetnoinfoHXEХзВ5З.writeUtf8(((FormBody)super).encodedNames.get(b));
/*  93 */       youcangetnoinfoHXEХзВ5З.writeByte(61);
/*  94 */       youcangetnoinfoHXEХзВ5З.writeUtf8(((FormBody)super).encodedValues.get(b));
/*     */     } 
/*     */     
/*  97 */     if (youcangetnoinfoHXCЁнщ4М != null) {
/*  98 */       l = youcangetnoinfoHXEХзВ5З.size();
/*  99 */       youcangetnoinfoHXEХзВ5З.clear();
/*     */     } 
/*     */     
/* 102 */     return l;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\FormBody.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */