/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AndroidPlatform
/*     */ {
/*     */   public final Method openMethod;
/*     */   public final Method getMethod;
/*     */   public final Method warnIfOpenMethod;
/*     */   
/*     */   public AndroidPlatform(Object youcangetnoinfoFOJ80Вэч, Object youcangetnoinfoFOKХ7КПс, Object youcangetnoinfoFOL1вдгИ) {
/* 280 */     this();
/* 281 */     ((AndroidPlatform)super).getMethod = (Method)youcangetnoinfoFOJ80Вэч;
/* 282 */     ((AndroidPlatform)super).openMethod = (Method)youcangetnoinfoFOKХ7КПс;
/* 283 */     ((AndroidPlatform)super).warnIfOpenMethod = (Method)youcangetnoinfoFOL1вдгИ;
/*     */   }
/*     */   
/*     */   public Object createAndOpen(Object youcangetnoinfoAGCU6ёьща) {
/* 287 */     if (((AndroidPlatform)super).getMethod != null) {
/*     */       try {
/* 289 */         Object youcangetnoinfoAGCSйуЙЮЛ = ((AndroidPlatform)super).getMethod.invoke(null, new Object[0]);
/* 290 */         ((AndroidPlatform)super).openMethod.invoke(youcangetnoinfoAGCSйуЙЮЛ, new Object[] { youcangetnoinfoAGCU6ёьща });
/* 291 */         return youcangetnoinfoAGCSйуЙЮЛ;
/* 292 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/* 295 */     return null;
/*     */   }
/*     */   
/*     */   public boolean warnIfOpen(Object youcangetnoinfoCTZOкляМи) {
/* 299 */     boolean bool = false;
/* 300 */     if (youcangetnoinfoCTZOкляМи != null) {
/*     */       try {
/* 302 */         ((AndroidPlatform)super).warnIfOpenMethod.invoke(youcangetnoinfoCTZOкляМи, new Object[0]);
/* 303 */         bool = true;
/* 304 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/* 307 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public static AndroidPlatform get() {
/*     */     Object youcangetnoinfoDDдт0о4;
/*     */     Object youcangetnoinfoDEХрМбС;
/*     */     Object youcangetnoinfoDFообгя;
/*     */     try {
/* 316 */       Object<?> youcangetnoinfoCYёЭжЪС = (Object<?>)Class.forName("dalvik.system.CloseGuard");
/* 317 */       Object youcangetnoinfoCZРэоыФ = youcangetnoinfoCYёЭжЪС.getMethod("get", new Class[0]);
/* 318 */       Object youcangetnoinfoDAёЛШТД = youcangetnoinfoCYёЭжЪС.getMethod("open", new Class[] { String.class });
/* 319 */       Object youcangetnoinfoDBжДzля = youcangetnoinfoCYёЭжЪС.getMethod("warnIfOpen", new Class[0]);
/* 320 */     } catch (Exception youcangetnoinfoDCЕш40Б) {
/* 321 */       youcangetnoinfoDDдт0о4 = null;
/* 322 */       youcangetnoinfoDEХрМбС = null;
/* 323 */       youcangetnoinfoDFообгя = null;
/*     */     } 
/* 325 */     return new AndroidPlatform((Method)youcangetnoinfoDDдт0о4, (Method)youcangetnoinfoDEХрМбС, (Method)youcangetnoinfoDFообгя);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\AndroidPlatform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */