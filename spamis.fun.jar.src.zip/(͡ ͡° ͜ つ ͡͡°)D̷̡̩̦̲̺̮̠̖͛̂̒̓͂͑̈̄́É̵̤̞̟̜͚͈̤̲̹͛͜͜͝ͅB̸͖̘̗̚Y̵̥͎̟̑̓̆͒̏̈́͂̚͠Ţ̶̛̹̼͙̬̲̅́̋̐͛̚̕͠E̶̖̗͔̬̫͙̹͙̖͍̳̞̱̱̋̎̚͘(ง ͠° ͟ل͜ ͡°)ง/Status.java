/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.LayoutManager;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Status
/*    */   extends JPanel
/*    */ {
/*    */   public Status() {
/* 26 */     super.initialize();
/*    */   }
/*    */   
/*    */   public void initialize() {
/* 30 */     setLayout((LayoutManager)null);
/*    */     
/* 32 */     Object youcangetnoinfoCCCGЛШфЪУ = new JLabel("Channel id");
/* 33 */     youcangetnoinfoCCCGЛШфЪУ.setBounds(28, 12, 293, 15);
/* 34 */     add((Component)youcangetnoinfoCCCGЛШфЪУ);
/*    */     
/* 36 */     Object youcangetnoinfoCCCH1к06О = new JTextField();
/* 37 */     youcangetnoinfoCCCH1к06О.setColumns(10);
/* 38 */     youcangetnoinfoCCCH1к06О.setBounds(28, 27, 341, 32);
/* 39 */     add((Component)youcangetnoinfoCCCH1к06О);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Status.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */