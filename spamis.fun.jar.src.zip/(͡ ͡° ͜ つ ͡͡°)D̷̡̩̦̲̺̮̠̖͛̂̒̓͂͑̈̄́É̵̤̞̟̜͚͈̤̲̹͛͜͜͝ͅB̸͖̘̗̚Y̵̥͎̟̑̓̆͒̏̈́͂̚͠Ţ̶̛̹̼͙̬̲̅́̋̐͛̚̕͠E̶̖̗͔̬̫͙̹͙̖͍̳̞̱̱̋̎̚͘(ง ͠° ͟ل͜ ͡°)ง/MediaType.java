/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Locale;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MediaType
/*     */ {
/*     */   @Nullable
/*     */   public final String charset;
/*     */   public static final Pattern PARAMETER;
/*     */   public final String type;
/*  31 */   public static final Pattern TYPE_SUBTYPE = Pattern.compile("([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)/([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)"); static {
/*  32 */     PARAMETER = Pattern.compile(";\\s*(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)=(?:([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)|\"([^\"]*)\"))?");
/*     */   }
/*     */   public static final String TOKEN = "([a-zA-Z0-9-!#$%&'*+.^_`{|}~]+)";
/*     */   public final String subtype;
/*     */   public final String mediaType;
/*     */   public static final String QUOTED = "\"([^\"]*)\"";
/*     */   
/*     */   public MediaType(Object youcangetnoinfoCZHVшГМшН, Object youcangetnoinfoCZHWГМГГц, Object youcangetnoinfoCZHXвщ3юz, @Nullable Object youcangetnoinfoCZHYвыкьО) {
/*  40 */     this();
/*  41 */     ((MediaType)super).mediaType = (String)youcangetnoinfoCZHVшГМшН;
/*  42 */     ((MediaType)super).type = (String)youcangetnoinfoCZHWГМГГц;
/*  43 */     ((MediaType)super).subtype = (String)youcangetnoinfoCZHXвщ3юz;
/*  44 */     ((MediaType)super).charset = (String)youcangetnoinfoCZHYвыкьО;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static MediaType get(Object youcangetnoinfoBDYV3Ж9вч) {
/*  53 */     Object youcangetnoinfoBDYWбЫюнС = TYPE_SUBTYPE.matcher((CharSequence)youcangetnoinfoBDYV3Ж9вч);
/*  54 */     if (!youcangetnoinfoBDYWбЫюнС.lookingAt()) {
/*  55 */       throw new IllegalArgumentException("No subtype found for: \"" + youcangetnoinfoBDYV3Ж9вч + '"');
/*     */     }
/*  57 */     Object youcangetnoinfoBDYXЕЛСэЭ = youcangetnoinfoBDYWбЫюнС.group(1).toLowerCase(Locale.US);
/*  58 */     Object youcangetnoinfoBDYYышЖЫИ = youcangetnoinfoBDYWбЫюнС.group(2).toLowerCase(Locale.US);
/*     */     
/*  60 */     Object youcangetnoinfoBDYZТ7ъФС = null;
/*  61 */     Object youcangetnoinfoBDZAШЛечН = PARAMETER.matcher((CharSequence)youcangetnoinfoBDYV3Ж9вч); int i;
/*  62 */     for (i = youcangetnoinfoBDYWбЫюнС.end(); i < youcangetnoinfoBDYV3Ж9вч.length(); i = youcangetnoinfoBDZAШЛечН.end()) {
/*  63 */       youcangetnoinfoBDZAШЛечН.region(i, youcangetnoinfoBDYV3Ж9вч.length());
/*  64 */       if (!youcangetnoinfoBDZAШЛечН.lookingAt()) {
/*  65 */         throw new IllegalArgumentException("Parameter is not formatted correctly: \"" + youcangetnoinfoBDYV3Ж9вч
/*  66 */             .substring(i) + "\" for: \"" + youcangetnoinfoBDYV3Ж9вч + '"');
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  72 */       Object youcangetnoinfoBDYRЁлаХф = youcangetnoinfoBDZAШЛечН.group(1);
/*  73 */       if (youcangetnoinfoBDYRЁлаХф != null && youcangetnoinfoBDYRЁлаХф.equalsIgnoreCase("charset")) {
/*     */         
/*  75 */         Object youcangetnoinfoBDYS8Лъzъ, youcangetnoinfoBDYTХ2ГИ1 = youcangetnoinfoBDZAШЛечН.group(2);
/*  76 */         if (youcangetnoinfoBDYTХ2ГИ1 != null) {
/*     */ 
/*     */ 
/*     */           
/*  80 */           Object youcangetnoinfoBDYQюАьДГ = (youcangetnoinfoBDYTХ2ГИ1.startsWith("'") && youcangetnoinfoBDYTХ2ГИ1.endsWith("'") && youcangetnoinfoBDYTХ2ГИ1.length() > 2) ? youcangetnoinfoBDYTХ2ГИ1.substring(1, youcangetnoinfoBDYTХ2ГИ1.length() - 1) : youcangetnoinfoBDYTХ2ГИ1;
/*     */         } else {
/*     */           
/*  83 */           youcangetnoinfoBDYS8Лъzъ = youcangetnoinfoBDZAШЛечН.group(3);
/*     */         } 
/*  85 */         if (youcangetnoinfoBDYZТ7ъФС != null && !youcangetnoinfoBDYS8Лъzъ.equalsIgnoreCase((String)youcangetnoinfoBDYZТ7ъФС)) {
/*  86 */           throw new IllegalArgumentException("Multiple charsets defined: \"" + youcangetnoinfoBDYZТ7ъФС + "\" and: \"" + youcangetnoinfoBDYS8Лъzъ + "\" for: \"" + youcangetnoinfoBDYV3Ж9вч + '"');
/*     */         }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  94 */         youcangetnoinfoBDYZТ7ъФС = youcangetnoinfoBDYS8Лъzъ;
/*     */       } 
/*     */     } 
/*  97 */     return new MediaType((String)youcangetnoinfoBDYV3Ж9вч, (String)youcangetnoinfoBDYXЕЛСэЭ, (String)youcangetnoinfoBDYYышЖЫИ, (String)youcangetnoinfoBDYZТ7ъФС);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public static MediaType parse(Object youcangetnoinfoAGJC0ьмДБ) {
/*     */     try {
/* 106 */       return get((String)youcangetnoinfoAGJC0ьмДБ);
/* 107 */     } catch (IllegalArgumentException youcangetnoinfoAGJBДМШчЩ) {
/* 108 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String type() {
/* 117 */     return ((MediaType)super).type;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String subtype() {
/* 124 */     return ((MediaType)super).subtype;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Charset charset() {
/* 131 */     return super.charset(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Charset charset(@Nullable Object youcangetnoinfoAZEVТузЪ5) {
/*     */     try {
/* 140 */       return (((MediaType)super).charset != null) ? Charset.forName(((MediaType)super).charset) : (Charset)youcangetnoinfoAZEVТузЪ5;
/* 141 */     } catch (IllegalArgumentException youcangetnoinfoAZETуатВе) {
/* 142 */       return (Charset)youcangetnoinfoAZEVТузЪ5;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 151 */     return ((MediaType)super).mediaType;
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object youcangetnoinfoCVNYБЬМаь) {
/* 155 */     return (youcangetnoinfoCVNYБЬМаь instanceof MediaType && ((MediaType)youcangetnoinfoCVNYБЬМаь).mediaType.equals(((MediaType)super).mediaType));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 159 */     return ((MediaType)super).mediaType.hashCode();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\MediaType.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */