/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsyncTimeout2
/*     */   implements Sink
/*     */ {
/*     */   public final AsyncTimeout1 this$0;
/*     */   public final Sink val$sink;
/*     */   
/*     */   public AsyncTimeout2() {
/* 160 */     this();
/*     */   } public void write(Object youcangetnoinfoGDO4ДРАю, Object youcangetnoinfoGDPшДЮоД) throws IOException {
/* 162 */     Util.checkOffsetAndCount(((Buffer2)youcangetnoinfoGDO4ДРАю).size, 0L, youcangetnoinfoGDPшДЮоД);
/*     */     
/* 164 */     while (youcangetnoinfoGDPшДЮоД > 0L) {
/*     */       Object object1;
/* 166 */       long l = 0L;
/* 167 */       for (Object youcangetnoinfoGDJцЭдкз = ((Buffer2)youcangetnoinfoGDO4ДРАю).head; l < 65536L; youcangetnoinfoGDJцЭдкз = ((Segment)youcangetnoinfoGDJцЭдкз).next) {
/* 168 */         int i = ((Segment)youcangetnoinfoGDJцЭдкз).limit - ((Segment)youcangetnoinfoGDJцЭдкз).pos;
/* 169 */         l += i;
/* 170 */         if (l >= youcangetnoinfoGDPшДЮоД) {
/* 171 */           object1 = youcangetnoinfoGDPшДЮоД;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */       
/* 177 */       boolean bool = false;
/* 178 */       ((AsyncTimeout2)super).this$0.enter();
/*     */       try {
/* 180 */         sink.write((Buffer2)youcangetnoinfoGDO4ДРАю, object1);
/* 181 */         long l1 = youcangetnoinfoGDPшДЮоД - object1;
/* 182 */         bool = true;
/* 183 */       } catch (IOException youcangetnoinfoGDKэ0лАЬ) {
/* 184 */         throw super.this$0.exit(youcangetnoinfoGDKэ0лАЬ);
/*     */       } finally {
/* 186 */         ((AsyncTimeout2)super).this$0.exit(bool);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 192 */     boolean bool = false;
/* 193 */     ((AsyncTimeout2)super).this$0.enter();
/*     */     try {
/* 195 */       sink.flush();
/* 196 */       bool = true;
/* 197 */     } catch (IOException youcangetnoinfoAPXVОКЭЙЯ) {
/* 198 */       throw super.this$0.exit(youcangetnoinfoAPXVОКЭЙЯ);
/*     */     } finally {
/* 200 */       ((AsyncTimeout2)super).this$0.exit(bool);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 205 */     boolean bool = false;
/* 206 */     ((AsyncTimeout2)super).this$0.enter();
/*     */     try {
/* 208 */       sink.close();
/* 209 */       bool = true;
/* 210 */     } catch (IOException youcangetnoinfoABQXИЙеПФ) {
/* 211 */       throw super.this$0.exit(youcangetnoinfoABQXИЙеПФ);
/*     */     } finally {
/* 213 */       ((AsyncTimeout2)super).this$0.exit(bool);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 218 */     return ((AsyncTimeout2)super).this$0;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 222 */     return "AsyncTimeout.sink(" + sink + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\AsyncTimeout2.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */