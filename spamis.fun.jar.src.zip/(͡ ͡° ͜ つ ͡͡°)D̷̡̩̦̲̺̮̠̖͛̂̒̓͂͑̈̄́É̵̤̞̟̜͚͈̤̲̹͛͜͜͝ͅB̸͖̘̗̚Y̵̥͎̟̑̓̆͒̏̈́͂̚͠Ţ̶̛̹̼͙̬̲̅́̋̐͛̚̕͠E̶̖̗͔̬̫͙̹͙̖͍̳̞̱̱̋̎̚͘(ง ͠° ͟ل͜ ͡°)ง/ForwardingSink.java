/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ForwardingSink
/*    */   implements Sink
/*    */ {
/*    */   public final Sink delegate;
/*    */   
/*    */   public ForwardingSink(Object youcangetnoinfoDHXQЙиМИЬ) {
/* 24 */     this();
/* 25 */     if (youcangetnoinfoDHXQЙиМИЬ == null) throw new IllegalArgumentException("delegate == null"); 
/* 26 */     ((ForwardingSink)super).delegate = (Sink)youcangetnoinfoDHXQЙиМИЬ;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Sink delegate() {
/* 31 */     return ((ForwardingSink)super).delegate;
/*    */   }
/*    */   
/*    */   public void write(Object youcangetnoinfoATOAяргк0, Object youcangetnoinfoATOB83ЮНо) throws IOException {
/* 35 */     ((ForwardingSink)super).delegate.write((Buffer2)youcangetnoinfoATOAяргк0, youcangetnoinfoATOB83ЮНо);
/*    */   }
/*    */   
/*    */   public void flush() throws IOException {
/* 39 */     ((ForwardingSink)super).delegate.flush();
/*    */   }
/*    */   
/*    */   public Timeout timeout() {
/* 43 */     return ((ForwardingSink)super).delegate.timeout();
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 47 */     ((ForwardingSink)super).delegate.close();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 51 */     return getClass().getSimpleName() + "(" + ((ForwardingSink)super).delegate.toString() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ForwardingSink.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */