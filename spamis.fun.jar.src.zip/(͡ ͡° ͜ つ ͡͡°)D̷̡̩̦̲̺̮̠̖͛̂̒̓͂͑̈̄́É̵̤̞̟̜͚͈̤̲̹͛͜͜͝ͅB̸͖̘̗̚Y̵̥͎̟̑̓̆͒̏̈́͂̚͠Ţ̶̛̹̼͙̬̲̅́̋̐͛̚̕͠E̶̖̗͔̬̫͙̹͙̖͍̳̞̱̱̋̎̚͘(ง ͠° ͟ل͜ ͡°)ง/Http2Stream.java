/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Stream
/*     */   implements Source
/*     */ {
/*     */   public final Buffer2 receiveBuffer;
/*     */   public final Buffer2 readBuffer;
/*     */   public final Http2Stream2 this$0;
/*     */   public boolean closed;
/*     */   public final long maxByteCount;
/*     */   public Headers trailers;
/*     */   public static final boolean $assertionsDisabled;
/*     */   public boolean finished;
/*     */   
/*     */   public Http2Stream(Object youcangetnoinfoEDMRЯЯЧзЁ) {
/* 359 */     this(); ((Http2Stream)super).receiveBuffer = new Buffer2(); ((Http2Stream)super).readBuffer = new Buffer2();
/* 360 */     ((Http2Stream)super).maxByteCount = youcangetnoinfoEDMRЯЯЧзЁ;
/*     */   } public long read(Object youcangetnoinfoBXZDкУыЪ4, Object youcangetnoinfoBXZEО1хпЁ) throws IOException {
/*     */     long l;
/*     */     Object youcangetnoinfoBXZB1Ц9ГЩ;
/* 364 */     if (youcangetnoinfoBXZEО1хпЁ < 0L) throw new IllegalArgumentException("byteCount < 0: " + youcangetnoinfoBXZEО1хпЁ);
/*     */     
/*     */     while (true) {
/* 367 */       l = -1L;
/* 368 */       youcangetnoinfoBXZB1Ц9ГЩ = null;
/*     */ 
/*     */ 
/*     */       
/* 372 */       synchronized (Http2Stream2.this) {
/* 373 */         Http2Stream2.this.readTimeout.enter();
/*     */         
/* 375 */         try { if (Http2Stream2.this.errorCode != null)
/*     */           {
/* 377 */             youcangetnoinfoBXZB1Ц9ГЩ = Http2Stream2.this.errorCode;
/*     */           }
/*     */           
/* 380 */           if (((Http2Stream)super).closed) {
/* 381 */             throw new IOException("stream closed");
/*     */           }
/* 383 */           if (((Http2Stream)super).readBuffer.size() > 0L)
/*     */           
/* 385 */           { l = ((Http2Stream)super).readBuffer.read((Buffer2)youcangetnoinfoBXZDкУыЪ4, Math.min(youcangetnoinfoBXZEО1хпЁ, ((Http2Stream)super).readBuffer.size()));
/* 386 */             Http2Stream2.this.unacknowledgedBytesRead += l;
/*     */             
/* 388 */             if (youcangetnoinfoBXZB1Ц9ГЩ == null && Http2Stream2.this.unacknowledgedBytesRead >= (Http2Stream2.this.connection.okHttpSettings
/*     */               
/* 390 */               .getInitialWindowSize() / 2)) {
/*     */ 
/*     */               
/* 393 */               Http2Stream2.this.connection.writeWindowUpdateLater(Http2Stream2.this.id, Http2Stream2.this.unacknowledgedBytesRead);
/* 394 */               Http2Stream2.this.unacknowledgedBytesRead = 0L;
/*     */             }  }
/* 396 */           else if (!((Http2Stream)super).finished && youcangetnoinfoBXZB1Ц9ГЩ == null)
/*     */           
/* 398 */           { Http2Stream2.this.waitForIo();
/*     */ 
/*     */ 
/*     */             
/* 402 */             Http2Stream2.this.readTimeout.exitAndThrowIfTimedOut(); continue; }  } finally { Http2Stream2.this.readTimeout.exitAndThrowIfTimedOut(); }
/*     */       
/*     */       } 
/*     */       
/*     */       break;
/*     */     } 
/* 408 */     if (l != -1L) {
/*     */       
/* 410 */       super.updateConnectionFlowControl(l);
/* 411 */       return l;
/*     */     } 
/*     */     
/* 414 */     if (youcangetnoinfoBXZB1Ц9ГЩ != null)
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 419 */       throw new StreamResetException(youcangetnoinfoBXZB1Ц9ГЩ);
/*     */     }
/*     */     
/* 422 */     return -1L;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateConnectionFlowControl(Object youcangetnoinfoASPLЙ7Гд8) {
/* 427 */     assert !Thread.holdsLock(Http2Stream2.this);
/* 428 */     Http2Stream2.this.connection.updateConnectionFlowControl(youcangetnoinfoASPLЙ7Гд8);
/*     */   }
/*     */   
/*     */   public void receive(Object youcangetnoinfoATCWдяБЬ7, Object youcangetnoinfoATCXАвщ4О) throws IOException {
/* 432 */     assert !Thread.holdsLock(Http2Stream2.this);
/*     */     
/* 434 */     while (youcangetnoinfoATCXАвщ4О > 0L) {
/*     */       boolean bool;
/*     */       boolean bool1;
/* 437 */       synchronized (Http2Stream2.this) {
/* 438 */         bool = ((Http2Stream)super).finished;
/* 439 */         bool1 = (youcangetnoinfoATCXАвщ4О + ((Http2Stream)super).readBuffer.size() > ((Http2Stream)super).maxByteCount) ? true : false;
/*     */       } 
/*     */ 
/*     */       
/* 443 */       if (bool1) {
/* 444 */         youcangetnoinfoATCWдяБЬ7.skip(youcangetnoinfoATCXАвщ4О);
/* 445 */         Http2Stream2.this.closeLater(ErrorCode.FLOW_CONTROL_ERROR);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 450 */       if (bool) {
/* 451 */         youcangetnoinfoATCWдяБЬ7.skip(youcangetnoinfoATCXАвщ4О);
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 456 */       long l2 = youcangetnoinfoATCWдяБЬ7.read(((Http2Stream)super).receiveBuffer, youcangetnoinfoATCXАвщ4О);
/* 457 */       if (l2 == -1L) throw new EOFException(); 
/* 458 */       long l1 = youcangetnoinfoATCXАвщ4О - l2;
/*     */ 
/*     */       
/* 461 */       synchronized (Http2Stream2.this) {
/* 462 */         boolean bool2 = (((Http2Stream)super).readBuffer.size() == 0L) ? true : false;
/* 463 */         ((Http2Stream)super).readBuffer.writeAll(((Http2Stream)super).receiveBuffer);
/* 464 */         if (bool2) {
/* 465 */           Http2Stream2.this.notifyAll();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 472 */     return Http2Stream2.this.readTimeout;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*     */     long l;
/* 477 */     synchronized (Http2Stream2.this) {
/* 478 */       ((Http2Stream)super).closed = true;
/* 479 */       l = ((Http2Stream)super).readBuffer.size();
/* 480 */       ((Http2Stream)super).readBuffer.clear();
/* 481 */       Http2Stream2.this.notifyAll();
/*     */     } 
/* 483 */     if (l > 0L) {
/* 484 */       super.updateConnectionFlowControl(l);
/*     */     }
/* 486 */     Http2Stream2.this.cancelStreamIfNecessary();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http2Stream.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */