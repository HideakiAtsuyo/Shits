/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.UnknownServiceException;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectionSpecSelector
/*     */ {
/*     */   public boolean isFallbackPossible;
/*     */   public boolean isFallback;
/*     */   public int nextModeIndex;
/*     */   public final List connectionSpecs;
/*     */   
/*     */   public ConnectionSpecSelector(Object youcangetnoinfoDQIXТч2ЛК) {
/*  44 */     this();
/*  45 */     ((ConnectionSpecSelector)super).nextModeIndex = 0;
/*  46 */     ((ConnectionSpecSelector)super).connectionSpecs = (List)youcangetnoinfoDQIXТч2ЛК;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionSpec configureSecureSocket(Object youcangetnoinfoBLLOГЫ8рЮ) throws IOException {
/*  56 */     Object youcangetnoinfoBLLPЬуС6Я = null;
/*  57 */     for (int i = ((ConnectionSpecSelector)super).nextModeIndex, j = ((ConnectionSpecSelector)super).connectionSpecs.size(); i < j; i++) {
/*  58 */       Object youcangetnoinfoBLLK03флz = ((ConnectionSpecSelector)super).connectionSpecs.get(i);
/*  59 */       if (youcangetnoinfoBLLK03флz.isCompatible((SSLSocket)youcangetnoinfoBLLOГЫ8рЮ)) {
/*  60 */         youcangetnoinfoBLLPЬуС6Я = youcangetnoinfoBLLK03флz;
/*  61 */         ((ConnectionSpecSelector)super).nextModeIndex = i + 1;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/*  66 */     if (youcangetnoinfoBLLPЬуС6Я == null)
/*     */     {
/*     */ 
/*     */       
/*  70 */       throw new UnknownServiceException("Unable to find acceptable protocols. isFallback=" + super.isFallback + ", modes=" + super.connectionSpecs + ", supported protocols=" + 
/*     */ 
/*     */           
/*  73 */           Arrays.toString(youcangetnoinfoBLLOГЫ8рЮ.getEnabledProtocols()));
/*     */     }
/*     */     
/*  76 */     ((ConnectionSpecSelector)super).isFallbackPossible = super.isFallbackPossible((SSLSocket)youcangetnoinfoBLLOГЫ8рЮ);
/*     */     
/*  78 */     Internal.instance.apply((ConnectionSpec)youcangetnoinfoBLLPЬуС6Я, (SSLSocket)youcangetnoinfoBLLOГЫ8рЮ, ((ConnectionSpecSelector)super).isFallback);
/*     */     
/*  80 */     return (ConnectionSpec)youcangetnoinfoBLLPЬуС6Я;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean connectionFailed(Object youcangetnoinfoASUWМЛкЛэ) {
/*  92 */     ((ConnectionSpecSelector)super).isFallback = true;
/*     */     
/*  94 */     if (!((ConnectionSpecSelector)super).isFallbackPossible) {
/*  95 */       return false;
/*     */     }
/*     */ 
/*     */     
/*  99 */     if (youcangetnoinfoASUWМЛкЛэ instanceof java.net.ProtocolException) {
/* 100 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 106 */     if (youcangetnoinfoASUWМЛкЛэ instanceof java.io.InterruptedIOException) {
/* 107 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 112 */     if (youcangetnoinfoASUWМЛкЛэ instanceof javax.net.ssl.SSLHandshakeException)
/*     */     {
/* 114 */       if (youcangetnoinfoASUWМЛкЛэ.getCause() instanceof java.security.cert.CertificateException) {
/* 115 */         return false;
/*     */       }
/*     */     }
/* 118 */     if (youcangetnoinfoASUWМЛкЛэ instanceof javax.net.ssl.SSLPeerUnverifiedException)
/*     */     {
/* 120 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 124 */     return youcangetnoinfoASUWМЛкЛэ instanceof javax.net.ssl.SSLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFallbackPossible(Object youcangetnoinfoJNAКЫШдс) {
/* 133 */     for (int i = ((ConnectionSpecSelector)super).nextModeIndex; i < ((ConnectionSpecSelector)super).connectionSpecs.size(); i++) {
/* 134 */       if (((ConnectionSpec)((ConnectionSpecSelector)super).connectionSpecs.get(i)).isCompatible((SSLSocket)youcangetnoinfoJNAКЫШдс)) {
/* 135 */         return true;
/*     */       }
/*     */     } 
/* 138 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ConnectionSpecSelector.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */