/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ public final class CacheControl {
/*     */   public final int sMaxAgeSeconds;
/*     */   public final boolean isPrivate;
/*     */   public final boolean immutable;
/*     */   public final boolean isPublic;
/*     */   @Nullable
/*     */   public String headerValue;
/*     */   public final boolean noTransform;
/*     */   public final boolean noStore;
/*     */   public final int maxAgeSeconds;
/*     */   public final boolean mustRevalidate;
/*     */   public final int minFreshSeconds;
/*  18 */   public static final CacheControl FORCE_NETWORK = (new CacheControl1()).noCache().build();
/*     */ 
/*     */ 
/*     */   
/*     */   public final int maxStaleSeconds;
/*     */ 
/*     */   
/*  25 */   public static final CacheControl FORCE_CACHE = (new CacheControl1())
/*  26 */     .onlyIfCached()
/*  27 */     .maxStale(2147483647, TimeUnit.SECONDS)
/*  28 */     .build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean onlyIfCached;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean noCache;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl(Object youcangetnoinfoEBNIЪЧХЛа, Object youcangetnoinfoEBNJНиооЬ, Object youcangetnoinfoEBNKОДълО, Object youcangetnoinfoEBNLДФШсz, Object youcangetnoinfoEBNM7ргЧс, Object youcangetnoinfoEBNNиФэЛы, Object youcangetnoinfoEBNOФсВЪь, Object youcangetnoinfoEBNP2пЖВА, Object youcangetnoinfoEBNQ5ДЛц9, Object youcangetnoinfoEBNRАВ6Эы, Object youcangetnoinfoEBNSТй27Х, Object youcangetnoinfoEBNT6м9ёу, @Nullable Object youcangetnoinfoEBNUб7ЕщП) {
/*  48 */     this();
/*  49 */     ((CacheControl)super).noCache = youcangetnoinfoEBNIЪЧХЛа;
/*  50 */     ((CacheControl)super).noStore = youcangetnoinfoEBNJНиооЬ;
/*  51 */     ((CacheControl)super).maxAgeSeconds = youcangetnoinfoEBNKОДълО;
/*  52 */     ((CacheControl)super).sMaxAgeSeconds = youcangetnoinfoEBNLДФШсz;
/*  53 */     ((CacheControl)super).isPrivate = youcangetnoinfoEBNM7ргЧс;
/*  54 */     ((CacheControl)super).isPublic = youcangetnoinfoEBNNиФэЛы;
/*  55 */     ((CacheControl)super).mustRevalidate = youcangetnoinfoEBNOФсВЪь;
/*  56 */     ((CacheControl)super).maxStaleSeconds = youcangetnoinfoEBNP2пЖВА;
/*  57 */     ((CacheControl)super).minFreshSeconds = youcangetnoinfoEBNQ5ДЛц9;
/*  58 */     ((CacheControl)super).onlyIfCached = youcangetnoinfoEBNRАВ6Эы;
/*  59 */     ((CacheControl)super).noTransform = youcangetnoinfoEBNSТй27Х;
/*  60 */     ((CacheControl)super).immutable = youcangetnoinfoEBNT6м9ёу;
/*  61 */     ((CacheControl)super).headerValue = (String)youcangetnoinfoEBNUб7ЕщП;
/*     */   }
/*     */   public CacheControl(Object youcangetnoinfoGZU4ПэЩА) {
/*  64 */     this();
/*  65 */     ((CacheControl)super).noCache = ((CacheControl1)youcangetnoinfoGZU4ПэЩА).noCache;
/*  66 */     ((CacheControl)super).noStore = ((CacheControl1)youcangetnoinfoGZU4ПэЩА).noStore;
/*  67 */     ((CacheControl)super).maxAgeSeconds = ((CacheControl1)youcangetnoinfoGZU4ПэЩА).maxAgeSeconds;
/*  68 */     ((CacheControl)super).sMaxAgeSeconds = -1;
/*  69 */     ((CacheControl)super).isPrivate = false;
/*  70 */     ((CacheControl)super).isPublic = false;
/*  71 */     ((CacheControl)super).mustRevalidate = false;
/*  72 */     ((CacheControl)super).maxStaleSeconds = ((CacheControl1)youcangetnoinfoGZU4ПэЩА).maxStaleSeconds;
/*  73 */     ((CacheControl)super).minFreshSeconds = ((CacheControl1)youcangetnoinfoGZU4ПэЩА).minFreshSeconds;
/*  74 */     ((CacheControl)super).onlyIfCached = ((CacheControl1)youcangetnoinfoGZU4ПэЩА).onlyIfCached;
/*  75 */     ((CacheControl)super).noTransform = ((CacheControl1)youcangetnoinfoGZU4ПэЩА).noTransform;
/*  76 */     ((CacheControl)super).immutable = ((CacheControl1)youcangetnoinfoGZU4ПэЩА).immutable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean noCache() {
/*  87 */     return ((CacheControl)super).noCache;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean noStore() {
/*  92 */     return ((CacheControl)super).noStore;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int maxAgeSeconds() {
/*  99 */     return ((CacheControl)super).maxAgeSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int sMaxAgeSeconds() {
/* 107 */     return ((CacheControl)super).sMaxAgeSeconds;
/*     */   }
/*     */   
/*     */   public boolean isPrivate() {
/* 111 */     return ((CacheControl)super).isPrivate;
/*     */   }
/*     */   
/*     */   public boolean isPublic() {
/* 115 */     return ((CacheControl)super).isPublic;
/*     */   }
/*     */   
/*     */   public boolean mustRevalidate() {
/* 119 */     return ((CacheControl)super).mustRevalidate;
/*     */   }
/*     */   
/*     */   public int maxStaleSeconds() {
/* 123 */     return ((CacheControl)super).maxStaleSeconds;
/*     */   }
/*     */   
/*     */   public int minFreshSeconds() {
/* 127 */     return ((CacheControl)super).minFreshSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean onlyIfCached() {
/* 137 */     return ((CacheControl)super).onlyIfCached;
/*     */   }
/*     */   
/*     */   public boolean noTransform() {
/* 141 */     return ((CacheControl)super).noTransform;
/*     */   }
/*     */   
/*     */   public boolean immutable() {
/* 145 */     return ((CacheControl)super).immutable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static CacheControl parse(Object youcangetnoinfoTGX20о6Б) {
/* 153 */     boolean bool1 = false;
/* 154 */     boolean bool2 = false;
/* 155 */     int i = -1;
/* 156 */     int j = -1;
/* 157 */     boolean bool3 = false;
/* 158 */     boolean bool4 = false;
/* 159 */     boolean bool5 = false;
/* 160 */     int k = -1;
/* 161 */     int m = -1;
/* 162 */     boolean bool6 = false;
/* 163 */     boolean bool7 = false;
/* 164 */     boolean bool8 = false;
/*     */     
/* 166 */     boolean bool9 = true;
/* 167 */     Object youcangetnoinfoTHLзХБьЕ = null; byte b;
/*     */     int n;
/* 169 */     for (b = 0, n = youcangetnoinfoTGX20о6Б.size(); b < n; b++) {
/* 170 */       Object youcangetnoinfoTGSрЖ9цХ = youcangetnoinfoTGX20о6Б.name(b);
/* 171 */       Object youcangetnoinfoTGTГт03ш = youcangetnoinfoTGX20о6Б.value(b);
/*     */       
/* 173 */       if (youcangetnoinfoTGSрЖ9цХ.equalsIgnoreCase("Cache-Control")) {
/* 174 */         if (youcangetnoinfoTHLзХБьЕ != null) {
/*     */           
/* 176 */           bool9 = false;
/*     */         } else {
/* 178 */           youcangetnoinfoTHLзХБьЕ = youcangetnoinfoTGTГт03ш;
/*     */         } 
/* 180 */       } else if (youcangetnoinfoTGSрЖ9цХ.equalsIgnoreCase("Pragma")) {
/*     */         
/* 182 */         bool9 = false;
/*     */       } else {
/*     */         continue;
/*     */       } 
/*     */       
/* 187 */       int i1 = 0;
/* 188 */       while (i1 < youcangetnoinfoTGTГт03ш.length()) {
/* 189 */         Object youcangetnoinfoTGRИzЦщл; int i2 = i1;
/* 190 */         i1 = HttpHeaders.skipUntil((String)youcangetnoinfoTGTГт03ш, i1, "=,;");
/* 191 */         Object youcangetnoinfoTGQ7к4ЫЪ = youcangetnoinfoTGTГт03ш.substring(i2, i1).trim();
/*     */ 
/*     */         
/* 194 */         if (i1 == youcangetnoinfoTGTГт03ш.length() || youcangetnoinfoTGTГт03ш.charAt(i1) == ',' || youcangetnoinfoTGTГт03ш.charAt(i1) == ';') {
/* 195 */           i1++;
/* 196 */           Object youcangetnoinfoTGLЭчм7к = null;
/*     */         } else {
/* 198 */           i1++;
/* 199 */           i1 = HttpHeaders.skipWhitespace((String)youcangetnoinfoTGTГт03ш, i1);
/*     */ 
/*     */           
/* 202 */           if (i1 < youcangetnoinfoTGTГт03ш.length() && youcangetnoinfoTGTГт03ш.charAt(i1) == '"') {
/*     */             
/* 204 */             int i3 = ++i1;
/* 205 */             i1 = HttpHeaders.skipUntil((String)youcangetnoinfoTGTГт03ш, i1, "\"");
/* 206 */             Object youcangetnoinfoTGNЪдТьМ = youcangetnoinfoTGTГт03ш.substring(i3, i1);
/* 207 */             i1++;
/*     */           }
/*     */           else {
/*     */             
/* 211 */             int i3 = i1;
/* 212 */             i1 = HttpHeaders.skipUntil((String)youcangetnoinfoTGTГт03ш, i1, ",;");
/* 213 */             youcangetnoinfoTGRИzЦщл = youcangetnoinfoTGTГт03ш.substring(i3, i1).trim();
/*     */           } 
/*     */         } 
/*     */         
/* 217 */         if ("no-cache".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 218 */           bool1 = true; continue;
/* 219 */         }  if ("no-store".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 220 */           bool2 = true; continue;
/* 221 */         }  if ("max-age".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 222 */           i = HttpHeaders.parseSeconds((String)youcangetnoinfoTGRИzЦщл, -1); continue;
/* 223 */         }  if ("s-maxage".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 224 */           j = HttpHeaders.parseSeconds((String)youcangetnoinfoTGRИzЦщл, -1); continue;
/* 225 */         }  if ("private".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 226 */           bool3 = true; continue;
/* 227 */         }  if ("public".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 228 */           bool4 = true; continue;
/* 229 */         }  if ("must-revalidate".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 230 */           bool5 = true; continue;
/* 231 */         }  if ("max-stale".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 232 */           k = HttpHeaders.parseSeconds((String)youcangetnoinfoTGRИzЦщл, 2147483647); continue;
/* 233 */         }  if ("min-fresh".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 234 */           m = HttpHeaders.parseSeconds((String)youcangetnoinfoTGRИzЦщл, -1); continue;
/* 235 */         }  if ("only-if-cached".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 236 */           bool6 = true; continue;
/* 237 */         }  if ("no-transform".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 238 */           bool7 = true; continue;
/* 239 */         }  if ("immutable".equalsIgnoreCase((String)youcangetnoinfoTGQ7к4ЫЪ)) {
/* 240 */           bool8 = true;
/*     */         }
/*     */       } 
/*     */       continue;
/*     */     } 
/* 245 */     if (!bool9) {
/* 246 */       youcangetnoinfoTHLзХБьЕ = null;
/*     */     }
/* 248 */     return new CacheControl(bool1, bool2, i, j, bool3, bool4, bool5, k, m, bool6, bool7, bool8, (String)youcangetnoinfoTHLзХБьЕ);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 254 */     Object youcangetnoinfoCDFK8БШРЯ = ((CacheControl)super).headerValue;
/* 255 */     return (youcangetnoinfoCDFK8БШРЯ != null) ? (String)youcangetnoinfoCDFK8БШРЯ : (((CacheControl)super).headerValue = super.headerValue());
/*     */   }
/*     */   
/*     */   public String headerValue() {
/* 259 */     Object youcangetnoinfoEEQEствдч = new StringBuilder();
/* 260 */     if (((CacheControl)super).noCache) youcangetnoinfoEEQEствдч.append("no-cache, "); 
/* 261 */     if (((CacheControl)super).noStore) youcangetnoinfoEEQEствдч.append("no-store, "); 
/* 262 */     if (((CacheControl)super).maxAgeSeconds != -1) youcangetnoinfoEEQEствдч.append("max-age=").append(((CacheControl)super).maxAgeSeconds).append(", "); 
/* 263 */     if (((CacheControl)super).sMaxAgeSeconds != -1) youcangetnoinfoEEQEствдч.append("s-maxage=").append(((CacheControl)super).sMaxAgeSeconds).append(", "); 
/* 264 */     if (((CacheControl)super).isPrivate) youcangetnoinfoEEQEствдч.append("private, "); 
/* 265 */     if (((CacheControl)super).isPublic) youcangetnoinfoEEQEствдч.append("public, "); 
/* 266 */     if (((CacheControl)super).mustRevalidate) youcangetnoinfoEEQEствдч.append("must-revalidate, "); 
/* 267 */     if (((CacheControl)super).maxStaleSeconds != -1) youcangetnoinfoEEQEствдч.append("max-stale=").append(((CacheControl)super).maxStaleSeconds).append(", "); 
/* 268 */     if (((CacheControl)super).minFreshSeconds != -1) youcangetnoinfoEEQEствдч.append("min-fresh=").append(((CacheControl)super).minFreshSeconds).append(", "); 
/* 269 */     if (((CacheControl)super).onlyIfCached) youcangetnoinfoEEQEствдч.append("only-if-cached, "); 
/* 270 */     if (((CacheControl)super).noTransform) youcangetnoinfoEEQEствдч.append("no-transform, "); 
/* 271 */     if (((CacheControl)super).immutable) youcangetnoinfoEEQEствдч.append("immutable, "); 
/* 272 */     if (youcangetnoinfoEEQEствдч.length() == 0) return ""; 
/* 273 */     youcangetnoinfoEEQEствдч.delete(youcangetnoinfoEEQEствдч.length() - 2, youcangetnoinfoEEQEствдч.length());
/* 274 */     return youcangetnoinfoEEQEствдч.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\CacheControl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */