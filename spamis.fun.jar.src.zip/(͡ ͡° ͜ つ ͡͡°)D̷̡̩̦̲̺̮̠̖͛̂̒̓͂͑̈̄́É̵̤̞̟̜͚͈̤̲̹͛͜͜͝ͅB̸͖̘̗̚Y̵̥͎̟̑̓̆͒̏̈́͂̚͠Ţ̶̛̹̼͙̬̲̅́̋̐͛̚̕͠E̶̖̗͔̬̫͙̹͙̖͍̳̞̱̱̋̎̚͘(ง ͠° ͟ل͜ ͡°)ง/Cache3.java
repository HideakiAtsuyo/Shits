/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Cache3
/*     */   implements InternalCache
/*     */ {
/*     */   public final Cache6 this$0;
/*     */   
/*     */   public Cache3() {
/* 143 */     this(); } @Nullable
/*     */   public Response get(Object youcangetnoinfoNBJуыскz) throws IOException {
/* 145 */     return ((Cache3)super).this$0.get((Request)youcangetnoinfoNBJуыскz);
/*     */   }
/*     */   @Nullable
/*     */   public CacheRequest put(Object youcangetnoinfoCGTBбЬ3вЖ) throws IOException {
/* 149 */     return ((Cache3)super).this$0.put((Response)youcangetnoinfoCGTBбЬ3вЖ);
/*     */   }
/*     */   
/*     */   public void remove(Object youcangetnoinfoAPUV1РМВи) throws IOException {
/* 153 */     ((Cache3)super).this$0.remove((Request)youcangetnoinfoAPUV1РМВи);
/*     */   }
/*     */   
/*     */   public void update(Object youcangetnoinfoDLQUОрмит, Object youcangetnoinfoDLQVюрЁР9) {
/* 157 */     ((Cache3)super).this$0.update((Response)youcangetnoinfoDLQUОрмит, (Response)youcangetnoinfoDLQVюрЁР9);
/*     */   }
/*     */   
/*     */   public void trackConditionalCacheHit() {
/* 161 */     ((Cache3)super).this$0.trackConditionalCacheHit();
/*     */   }
/*     */   
/*     */   public void trackResponse(Object youcangetnoinfoCEKWйиРЦь) {
/* 165 */     ((Cache3)super).this$0.trackResponse((CacheStrategy)youcangetnoinfoCEKWйиРЦь);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Cache3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */