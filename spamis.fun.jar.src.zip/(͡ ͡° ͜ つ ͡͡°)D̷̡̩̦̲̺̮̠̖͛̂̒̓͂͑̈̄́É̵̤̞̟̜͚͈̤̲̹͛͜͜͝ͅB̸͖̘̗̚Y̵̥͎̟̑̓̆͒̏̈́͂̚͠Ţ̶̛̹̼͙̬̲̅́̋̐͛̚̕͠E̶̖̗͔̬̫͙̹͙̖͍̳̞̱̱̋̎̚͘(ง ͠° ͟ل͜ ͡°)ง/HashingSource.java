/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HashingSource
/*     */   extends ForwardingSource
/*     */ {
/*     */   public final MessageDigest messageDigest;
/*     */   public final Mac mac;
/*     */   
/*     */   public static HashingSource md5(Object youcangetnoinfoCNJJ1шр0т) {
/*  47 */     return new HashingSource((Source)youcangetnoinfoCNJJ1шр0т, "MD5");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSource sha1(Object youcangetnoinfoBHLIкэГТС) {
/*  52 */     return new HashingSource((Source)youcangetnoinfoBHLIкэГТС, "SHA-1");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSource sha256(Object youcangetnoinfoBOZDХ4жАд) {
/*  57 */     return new HashingSource((Source)youcangetnoinfoBOZDХ4жАд, "SHA-256");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSource hmacSha1(Object youcangetnoinfoBQUC0zМзЛ, Object youcangetnoinfoBQUDКууфш) {
/*  62 */     return new HashingSource((Source)youcangetnoinfoBQUC0zМзЛ, (ByteString)youcangetnoinfoBQUDКууфш, "HmacSHA1");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSource hmacSha256(Object youcangetnoinfoBTDIТа8ь1, Object youcangetnoinfoBTDJ3Й8Ш3) {
/*  67 */     return new HashingSource((Source)youcangetnoinfoBTDIТа8ь1, (ByteString)youcangetnoinfoBTDJ3Й8Ш3, "HmacSHA256");
/*     */   }
/*     */   
/*     */   public HashingSource(Object youcangetnoinfoEILRф1Хщф, Object youcangetnoinfoEILSЬюЭВш) {
/*  71 */     super((Source)youcangetnoinfoEILRф1Хщф);
/*     */     try {
/*  73 */       ((HashingSource)super).messageDigest = MessageDigest.getInstance((String)youcangetnoinfoEILSЬюЭВш);
/*  74 */       ((HashingSource)super).mac = null;
/*  75 */     } catch (NoSuchAlgorithmException youcangetnoinfoEILPйЦярК) {
/*  76 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */   
/*     */   public HashingSource(Object youcangetnoinfoVVхдЫЫК, Object youcangetnoinfoVWЛибЬъ, Object youcangetnoinfoVX9КЛхТ) {
/*  81 */     super((Source)youcangetnoinfoVVхдЫЫК);
/*     */     try {
/*  83 */       ((HashingSource)super).mac = Mac.getInstance((String)youcangetnoinfoVX9КЛхТ);
/*  84 */       ((HashingSource)super).mac.init(new SecretKeySpec(youcangetnoinfoVWЛибЬъ.toByteArray(), (String)youcangetnoinfoVX9КЛхТ));
/*  85 */       ((HashingSource)super).messageDigest = null;
/*  86 */     } catch (NoSuchAlgorithmException youcangetnoinfoVSгН1щд) {
/*  87 */       throw new AssertionError();
/*  88 */     } catch (InvalidKeyException youcangetnoinfoVTЮЙгХк) {
/*  89 */       throw new IllegalArgumentException(youcangetnoinfoVTЮЙгХк);
/*     */     } 
/*     */   }
/*     */   
/*     */   public long read(Object youcangetnoinfoCCMZЗПи4о, Object youcangetnoinfoCCNAнЗСЦБ) throws IOException {
/*  94 */     long l = super.read((Buffer2)youcangetnoinfoCCMZЗПи4о, youcangetnoinfoCCNAнЗСЦБ);
/*     */     
/*  96 */     if (l != -1L) {
/*  97 */       long l1 = ((Buffer2)youcangetnoinfoCCMZЗПи4о).size - l;
/*     */ 
/*     */       
/* 100 */       long l2 = ((Buffer2)youcangetnoinfoCCMZЗПи4о).size;
/* 101 */       Object youcangetnoinfoCCMXzУи8И = ((Buffer2)youcangetnoinfoCCMZЗПи4о).head;
/* 102 */       while (l2 > l1) {
/* 103 */         youcangetnoinfoCCMXzУи8И = ((Segment)youcangetnoinfoCCMXzУи8И).prev;
/* 104 */         l2 -= (((Segment)youcangetnoinfoCCMXzУи8И).limit - ((Segment)youcangetnoinfoCCMXzУи8И).pos);
/*     */       } 
/*     */ 
/*     */       
/* 108 */       while (l2 < ((Buffer2)youcangetnoinfoCCMZЗПи4о).size) {
/* 109 */         int i = (int)(((Segment)youcangetnoinfoCCMXzУи8И).pos + l1 - l2);
/* 110 */         if (((HashingSource)super).messageDigest != null) {
/* 111 */           ((HashingSource)super).messageDigest.update(((Segment)youcangetnoinfoCCMXzУи8И).data, i, ((Segment)youcangetnoinfoCCMXzУи8И).limit - i);
/*     */         } else {
/* 113 */           ((HashingSource)super).mac.update(((Segment)youcangetnoinfoCCMXzУи8И).data, i, ((Segment)youcangetnoinfoCCMXzУи8И).limit - i);
/*     */         } 
/* 115 */         l2 += (((Segment)youcangetnoinfoCCMXzУи8И).limit - ((Segment)youcangetnoinfoCCMXzУи8И).pos);
/* 116 */         l1 = l2;
/* 117 */         youcangetnoinfoCCMXzУи8И = ((Segment)youcangetnoinfoCCMXzУи8И).next;
/*     */       } 
/*     */     } 
/*     */     
/* 121 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteString hash() {
/* 131 */     Object youcangetnoinfoCTDWх2zЛз = (((HashingSource)super).messageDigest != null) ? ((HashingSource)super).messageDigest.digest() : ((HashingSource)super).mac.doFinal();
/* 132 */     return ByteString.of((byte[])youcangetnoinfoCTDWх2zЛз);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\HashingSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */