/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Base64
/*     */ {
/*     */   public static final byte[] URL_MAP;
/*     */   
/*     */   public Base64() {
/*  26 */     this();
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] decode(Object youcangetnoinfoLVJКЫьЙг) {
/*  31 */     int i = youcangetnoinfoLVJКЫьЙг.length();
/*  32 */     for (; i > 0; i--) {
/*  33 */       char c = youcangetnoinfoLVJКЫьЙг.charAt(i - 1);
/*  34 */       if (c != '=' && c != '\n' && c != '\r' && c != ' ' && c != '\t') {
/*     */         break;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  40 */     Object youcangetnoinfoLVLЧ8Ом6 = new byte[(int)(i * 6L / 8L)];
/*  41 */     byte b1 = 0;
/*  42 */     byte b2 = 0;
/*     */     
/*  44 */     int j = 0;
/*  45 */     byte b3 = 0; while (true) { if (b3 < i)
/*  46 */       { byte b; char c = youcangetnoinfoLVJКЫьЙг.charAt(b3);
/*     */ 
/*     */         
/*  49 */         if (c >= 'A' && c <= 'Z')
/*     */         
/*     */         { 
/*     */           
/*  53 */           b = c - 65; }
/*  54 */         else if (c >= 'a' && c <= 'z')
/*     */         
/*     */         { 
/*     */           
/*  58 */           b = c - 71; }
/*  59 */         else if (c >= '0' && c <= '9')
/*     */         
/*     */         { 
/*     */           
/*  63 */           b = c + 4; }
/*  64 */         else if (c == '+' || c == '-')
/*  65 */         { b = 62; }
/*  66 */         else if (c == '/' || c == '_')
/*  67 */         { b = 63; }
/*  68 */         else { if (c != '\n' && c != '\r' && c != ' ' && c != '\t')
/*     */           {
/*     */             
/*  71 */             return null;
/*     */           }
/*     */           b3++; }
/*     */         
/*  75 */         j = j << 6 | (byte)b;
/*     */ 
/*     */         
/*  78 */         b2++;
/*  79 */         if (b2 % 4 == 0) {
/*  80 */           youcangetnoinfoLVLЧ8Ом6[b1++] = (byte)(j >> 16);
/*  81 */           youcangetnoinfoLVLЧ8Ом6[b1++] = (byte)(j >> 8);
/*  82 */           youcangetnoinfoLVLЧ8Ом6[b1++] = (byte)j;
/*     */         }  }
/*     */       else { break; }
/*     */        b3++; }
/*  86 */      int k = b2 % 4;
/*  87 */     if (k == 1)
/*     */     {
/*  89 */       return null; } 
/*  90 */     if (k == 2) {
/*     */       
/*  92 */       j <<= 12;
/*  93 */       youcangetnoinfoLVLЧ8Ом6[b1++] = (byte)(j >> 16);
/*  94 */     } else if (k == 3) {
/*     */       
/*  96 */       j <<= 6;
/*  97 */       youcangetnoinfoLVLЧ8Ом6[b1++] = (byte)(j >> 16);
/*  98 */       youcangetnoinfoLVLЧ8Ом6[b1++] = (byte)(j >> 8);
/*     */     } 
/*     */ 
/*     */     
/* 102 */     if (b1 == youcangetnoinfoLVLЧ8Ом6.length) return (byte[])youcangetnoinfoLVLЧ8Ом6;
/*     */ 
/*     */     
/* 105 */     Object youcangetnoinfoLVQя3Жжу = new byte[b1];
/* 106 */     System.arraycopy(youcangetnoinfoLVLЧ8Ом6, 0, youcangetnoinfoLVQя3Жжу, 0, b1);
/* 107 */     return (byte[])youcangetnoinfoLVQя3Жжу;
/*     */   }
/*     */   
/* 110 */   public static final byte[] MAP = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 117 */     URL_MAP = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 45, 95 };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String encode(Object youcangetnoinfoCLBCо9Ы2Й) {
/* 125 */     return encode((byte[])youcangetnoinfoCLBCо9Ы2Й, MAP);
/*     */   }
/*     */   
/*     */   public static String encodeUrl(Object youcangetnoinfoDENMмЬ55И) {
/* 129 */     return encode((byte[])youcangetnoinfoDENMмЬ55И, URL_MAP);
/*     */   }
/*     */   
/*     */   public static String encode(Object youcangetnoinfoDNNHЮзБщЯ, Object youcangetnoinfoDNNIищсЩз) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: arraylength
/*     */     //   2: iconst_2
/*     */     //   3: iadd
/*     */     //   4: iconst_3
/*     */     //   5: idiv
/*     */     //   6: iconst_4
/*     */     //   7: imul
/*     */     //   8: istore_2
/*     */     //   9: iload_2
/*     */     //   10: newarray byte
/*     */     //   12: astore_3
/*     */     //   13: iconst_0
/*     */     //   14: istore #4
/*     */     //   16: aload_0
/*     */     //   17: arraylength
/*     */     //   18: aload_0
/*     */     //   19: arraylength
/*     */     //   20: iconst_3
/*     */     //   21: irem
/*     */     //   22: isub
/*     */     //   23: istore #5
/*     */     //   25: iconst_0
/*     */     //   26: istore #6
/*     */     //   28: iload #6
/*     */     //   30: iload #5
/*     */     //   32: if_icmpge -> 142
/*     */     //   35: aload_3
/*     */     //   36: iload #4
/*     */     //   38: iinc #4, 1
/*     */     //   41: aload_1
/*     */     //   42: aload_0
/*     */     //   43: iload #6
/*     */     //   45: baload
/*     */     //   46: sipush #255
/*     */     //   49: iand
/*     */     //   50: iconst_2
/*     */     //   51: ishr
/*     */     //   52: baload
/*     */     //   53: bastore
/*     */     //   54: aload_3
/*     */     //   55: iload #4
/*     */     //   57: iinc #4, 1
/*     */     //   60: aload_1
/*     */     //   61: aload_0
/*     */     //   62: iload #6
/*     */     //   64: baload
/*     */     //   65: iconst_3
/*     */     //   66: iand
/*     */     //   67: iconst_4
/*     */     //   68: ishl
/*     */     //   69: aload_0
/*     */     //   70: iload #6
/*     */     //   72: iconst_1
/*     */     //   73: iadd
/*     */     //   74: baload
/*     */     //   75: sipush #255
/*     */     //   78: iand
/*     */     //   79: iconst_4
/*     */     //   80: ishr
/*     */     //   81: ior
/*     */     //   82: baload
/*     */     //   83: bastore
/*     */     //   84: aload_3
/*     */     //   85: iload #4
/*     */     //   87: iinc #4, 1
/*     */     //   90: aload_1
/*     */     //   91: aload_0
/*     */     //   92: iload #6
/*     */     //   94: iconst_1
/*     */     //   95: iadd
/*     */     //   96: baload
/*     */     //   97: bipush #15
/*     */     //   99: iand
/*     */     //   100: iconst_2
/*     */     //   101: ishl
/*     */     //   102: aload_0
/*     */     //   103: iload #6
/*     */     //   105: iconst_2
/*     */     //   106: iadd
/*     */     //   107: baload
/*     */     //   108: sipush #255
/*     */     //   111: iand
/*     */     //   112: bipush #6
/*     */     //   114: ishr
/*     */     //   115: ior
/*     */     //   116: baload
/*     */     //   117: bastore
/*     */     //   118: aload_3
/*     */     //   119: iload #4
/*     */     //   121: iinc #4, 1
/*     */     //   124: aload_1
/*     */     //   125: aload_0
/*     */     //   126: iload #6
/*     */     //   128: iconst_2
/*     */     //   129: iadd
/*     */     //   130: baload
/*     */     //   131: bipush #63
/*     */     //   133: iand
/*     */     //   134: baload
/*     */     //   135: bastore
/*     */     //   136: iinc #6, 3
/*     */     //   139: goto -> 28
/*     */     //   142: aload_0
/*     */     //   143: arraylength
/*     */     //   144: iconst_3
/*     */     //   145: irem
/*     */     //   146: lookupswitch default -> 307, 1 -> 172, 2 -> 229
/*     */     //   172: aload_3
/*     */     //   173: iload #4
/*     */     //   175: iinc #4, 1
/*     */     //   178: aload_1
/*     */     //   179: aload_0
/*     */     //   180: iload #5
/*     */     //   182: baload
/*     */     //   183: sipush #255
/*     */     //   186: iand
/*     */     //   187: iconst_2
/*     */     //   188: ishr
/*     */     //   189: baload
/*     */     //   190: bastore
/*     */     //   191: aload_3
/*     */     //   192: iload #4
/*     */     //   194: iinc #4, 1
/*     */     //   197: aload_1
/*     */     //   198: aload_0
/*     */     //   199: iload #5
/*     */     //   201: baload
/*     */     //   202: iconst_3
/*     */     //   203: iand
/*     */     //   204: iconst_4
/*     */     //   205: ishl
/*     */     //   206: baload
/*     */     //   207: bastore
/*     */     //   208: aload_3
/*     */     //   209: iload #4
/*     */     //   211: iinc #4, 1
/*     */     //   214: bipush #61
/*     */     //   216: bastore
/*     */     //   217: aload_3
/*     */     //   218: iload #4
/*     */     //   220: iinc #4, 1
/*     */     //   223: bipush #61
/*     */     //   225: bastore
/*     */     //   226: goto -> 307
/*     */     //   229: aload_3
/*     */     //   230: iload #4
/*     */     //   232: iinc #4, 1
/*     */     //   235: aload_1
/*     */     //   236: aload_0
/*     */     //   237: iload #5
/*     */     //   239: baload
/*     */     //   240: sipush #255
/*     */     //   243: iand
/*     */     //   244: iconst_2
/*     */     //   245: ishr
/*     */     //   246: baload
/*     */     //   247: bastore
/*     */     //   248: aload_3
/*     */     //   249: iload #4
/*     */     //   251: iinc #4, 1
/*     */     //   254: aload_1
/*     */     //   255: aload_0
/*     */     //   256: iload #5
/*     */     //   258: baload
/*     */     //   259: iconst_3
/*     */     //   260: iand
/*     */     //   261: iconst_4
/*     */     //   262: ishl
/*     */     //   263: aload_0
/*     */     //   264: iload #5
/*     */     //   266: iconst_1
/*     */     //   267: iadd
/*     */     //   268: baload
/*     */     //   269: sipush #255
/*     */     //   272: iand
/*     */     //   273: iconst_4
/*     */     //   274: ishr
/*     */     //   275: ior
/*     */     //   276: baload
/*     */     //   277: bastore
/*     */     //   278: aload_3
/*     */     //   279: iload #4
/*     */     //   281: iinc #4, 1
/*     */     //   284: aload_1
/*     */     //   285: aload_0
/*     */     //   286: iload #5
/*     */     //   288: iconst_1
/*     */     //   289: iadd
/*     */     //   290: baload
/*     */     //   291: bipush #15
/*     */     //   293: iand
/*     */     //   294: iconst_2
/*     */     //   295: ishl
/*     */     //   296: baload
/*     */     //   297: bastore
/*     */     //   298: aload_3
/*     */     //   299: iload #4
/*     */     //   301: iinc #4, 1
/*     */     //   304: bipush #61
/*     */     //   306: bastore
/*     */     //   307: new java/lang/String
/*     */     //   310: dup
/*     */     //   311: aload_3
/*     */     //   312: ldc 'US-ASCII'
/*     */     //   314: invokespecial <init> : ([BLjava/lang/String;)V
/*     */     //   317: areturn
/*     */     //   318: astore #6
/*     */     //   320: new java/lang/AssertionError
/*     */     //   323: dup
/*     */     //   324: aload #6
/*     */     //   326: invokespecial <init> : (Ljava/lang/Object;)V
/*     */     //   329: athrow
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #133	-> 0
/*     */     //   #134	-> 9
/*     */     //   #135	-> 13
/*     */     //   #136	-> 25
/*     */     //   #137	-> 35
/*     */     //   #138	-> 54
/*     */     //   #139	-> 84
/*     */     //   #140	-> 118
/*     */     //   #136	-> 136
/*     */     //   #142	-> 142
/*     */     //   #144	-> 172
/*     */     //   #145	-> 191
/*     */     //   #146	-> 208
/*     */     //   #147	-> 217
/*     */     //   #148	-> 226
/*     */     //   #150	-> 229
/*     */     //   #151	-> 248
/*     */     //   #152	-> 278
/*     */     //   #153	-> 298
/*     */     //   #157	-> 307
/*     */     //   #158	-> 318
/*     */     //   #159	-> 320
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   28	114	6	youcangetnoinfoDNNFПУЯХН	Ljava/lang/Object;
/*     */     //   320	10	6	youcangetnoinfoDNNGНгЛЮа	Ljava/lang/Object;
/*     */     //   0	330	1	youcangetnoinfoDNNIищсЩз	Ljava/lang/Object;
/*     */     //   13	317	3	youcangetnoinfoDNNKшДыВЧ	Ljava/lang/Object;
/*     */     //   16	314	4	youcangetnoinfoDNNLЪл6И5	Ljava/lang/Object;
/*     */     //   0	330	0	youcangetnoinfoDNNHЮзБщЯ	Ljava/lang/Object;
/*     */     //   9	321	2	youcangetnoinfoDNNJ4й7св	Ljava/lang/Object;
/*     */     //   25	305	5	youcangetnoinfoDNNMымЖГэ	Ljava/lang/Object;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   307	317	318	java/io/UnsupportedEncodingException
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Base64.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */