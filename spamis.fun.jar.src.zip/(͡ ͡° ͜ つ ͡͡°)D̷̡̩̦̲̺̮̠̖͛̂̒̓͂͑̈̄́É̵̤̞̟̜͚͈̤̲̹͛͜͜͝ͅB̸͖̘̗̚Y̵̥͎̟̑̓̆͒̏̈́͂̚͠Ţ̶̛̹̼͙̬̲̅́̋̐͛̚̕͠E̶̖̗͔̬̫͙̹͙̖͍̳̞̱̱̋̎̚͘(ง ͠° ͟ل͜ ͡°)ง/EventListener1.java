/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class EventListener1
/*    */ {
/*    */   public EventListener1() {
/* 52 */     this();
/* 53 */   } public static final EventListener1 NONE = new EventListener();
/*    */ 
/*    */   
/*    */   public static EventListener1 lambda$factory$0(Object youcangetnoinfoARFLЯЗ7ъл, Object youcangetnoinfoARFMЖхдщъ) {
/* 57 */     return (EventListener1)youcangetnoinfoARFLЯЗ7ъл; } public static EventListener2 factory(Object youcangetnoinfoEOFZлЬяНц) { return youcangetnoinfoEOFZлЬяНц::lambda$factory$0; }
/*    */ 
/*    */   
/*    */   public void callStart(Object youcangetnoinfoBIFCЭЭНуА) {}
/*    */   
/*    */   public void dnsStart(Object youcangetnoinfoJNMхЁ1ЯЭ, Object youcangetnoinfoJNN2ДДИУ) {}
/*    */   
/*    */   public void dnsEnd(Object youcangetnoinfoKIOЯ6ц5Ц, Object youcangetnoinfoKIPфдеъя, Object youcangetnoinfoKIQРЯЫФЛ) {}
/*    */   
/*    */   public void connectStart(Object youcangetnoinfoBSXPыБМДв, Object youcangetnoinfoBSXQ7М79И, Object youcangetnoinfoBSXRЖдо3И) {}
/*    */   
/*    */   public void secureConnectStart(Object youcangetnoinfoDCQUмЪвцЫ) {}
/*    */   
/*    */   public void secureConnectEnd(Object youcangetnoinfoCCLR56Неь, @Nullable Object youcangetnoinfoCCLSкЭблЗ) {}
/*    */   
/*    */   public void connectEnd(Object youcangetnoinfoEKNQИиыИл, Object youcangetnoinfoEKNRеЛъАЛ, Object youcangetnoinfoEKNSОЪпЗ0, @Nullable Object youcangetnoinfoEKNTябдЕН) {}
/*    */   
/*    */   public void connectFailed(Object youcangetnoinfoDJIOрбХДГ, Object youcangetnoinfoDJIPШЫДоВ, Object youcangetnoinfoDJIQЬЗтЁУ, @Nullable Object youcangetnoinfoDJIRг2АНЕ, Object youcangetnoinfoDJISчИЖэк) {}
/*    */   
/*    */   public void connectionAcquired(Object youcangetnoinfoDUXRвтЛкз, Object youcangetnoinfoDUXSкащОл) {}
/*    */   
/*    */   public void connectionReleased(Object youcangetnoinfoRBEЬШснк, Object youcangetnoinfoRBFщ21ИЗ) {}
/*    */   
/*    */   public void requestHeadersStart(Object youcangetnoinfoAYTB2Ни2Ч) {}
/*    */   
/*    */   public void requestHeadersEnd(Object youcangetnoinfoAILJИхёбР, Object youcangetnoinfoAILK9шВЖЁ) {}
/*    */   
/*    */   public void requestBodyStart(Object youcangetnoinfoAMBRЛ4юъ2) {}
/*    */   
/*    */   public void requestBodyEnd(Object youcangetnoinfoCCZPФт78Е, Object youcangetnoinfoCCZQЧНцР8) {}
/*    */   
/*    */   public void responseHeadersStart(Object youcangetnoinfoBDGFЕ8гёэ) {}
/*    */   
/*    */   public void responseHeadersEnd(Object youcangetnoinfoAOFMФ3УЖх, Object youcangetnoinfoAOFN31лЦп) {}
/*    */   
/*    */   public void responseBodyStart(Object youcangetnoinfoBXNJГаблД) {}
/*    */   
/*    */   public void responseBodyEnd(Object youcangetnoinfoCXIFёпемъ, Object youcangetnoinfoCXIG0уь4Ъ) {}
/*    */   
/*    */   public void callEnd(Object youcangetnoinfoULZ4ШzЫш) {}
/*    */   
/*    */   public void callFailed(Object youcangetnoinfoOYМР2зЕ, Object youcangetnoinfoOZНГул9) {}
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\EventListener1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */