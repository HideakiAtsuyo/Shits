/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Font;
/*    */ import java.awt.GridLayout;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.event.WindowListener;
/*    */ import java.sql.Timestamp;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTextArea;
/*    */ import javax.swing.border.EmptyBorder;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ConsoleGUI
/*    */   extends JFrame
/*    */   implements WindowListener
/*    */ {
/*    */   public JPanel contentPane;
/*    */   public static final long serialVersionUID = 1L;
/*    */   public static boolean open;
/*    */   public static JTextArea logArea;
/*    */   
/*    */   public ConsoleGUI() {
/* 33 */     setTitle("Console");
/* 34 */     setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/ui/console.png")));
/* 35 */     setBounds(100, 100, 584, 328);
/* 36 */     setLocationRelativeTo(null);
/* 37 */     addWindowListener((WindowListener)this);
/* 38 */     ((ConsoleGUI)super).contentPane = new JPanel();
/* 39 */     ((ConsoleGUI)super).contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
/* 40 */     setContentPane(((ConsoleGUI)super).contentPane);
/*    */     
/* 42 */     logArea = new JTextArea();
/* 43 */     logArea.setFont(new Font("Dialog", 0, 11));
/* 44 */     logArea.setEditable(false);
/* 45 */     Object youcangetnoinfoCRBKУЧЙце = logArea.getCaret();
/* 46 */     youcangetnoinfoCRBKУЧЙце.setUpdatePolicy(8);
/* 47 */     ((ConsoleGUI)super).contentPane.setLayout(new GridLayout(0, 1, 0, 0));
/*    */     
/* 49 */     Object youcangetnoinfoCRBLП8Сдэ = new JScrollPane(logArea, 22, 30);
/*    */     
/* 51 */     ((ConsoleGUI)super).contentPane.add((Component)youcangetnoinfoCRBLП8Сдэ);
/*    */   }
/*    */   
/*    */   public static void log(Object youcangetnoinfoDEJUЁшёню) {
/* 55 */     Object youcangetnoinfoDEJVжЁрыК = new Timestamp(System.currentTimeMillis());
/* 56 */     logArea.append("[" + youcangetnoinfoDEJVжЁрыК + "] " + youcangetnoinfoDEJUЁшёню + "\n");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void windowActivated(Object youcangetnoinfoAURNюУбМЛ) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void windowClosed(Object youcangetnoinfoAFSУХЮО6) {}
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void windowClosing(Object youcangetnoinfoBUEV8ЗЫФч) {
/* 73 */     open = false;
/*    */   }
/*    */   
/*    */   public void windowDeactivated(Object youcangetnoinfoEAGOПсбРш) {}
/*    */   
/*    */   public void windowDeiconified(Object youcangetnoinfoENGQе8ннК) {}
/*    */   
/*    */   public void windowIconified(Object youcangetnoinfoACQPШХЧХб) {}
/*    */   
/*    */   public void windowOpened(Object youcangetnoinfoQROзАЮрн) {}
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ConsoleGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */