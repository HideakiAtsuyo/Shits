/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactionSpammer3
/*     */   extends JPanel
/*     */ {
/*     */   public static final long serialVersionUID = 6656969284984841812L;
/*     */   
/*     */   public ReactionSpammer3() {
/*  32 */     super.initialize();
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  36 */     setLayout((LayoutManager)null);
/*     */     
/*  38 */     Object youcangetnoinfoCUUDнвСй2 = new JLabel("Channel id");
/*  39 */     youcangetnoinfoCUUDнвСй2.setBounds(28, 12, 293, 15);
/*  40 */     add((Component)youcangetnoinfoCUUDнвСй2);
/*     */     
/*  42 */     Object youcangetnoinfoCUUE43ПщШ = new JTextField();
/*  43 */     youcangetnoinfoCUUE43ПщШ.setColumns(10);
/*  44 */     youcangetnoinfoCUUE43ПщШ.setBounds(28, 27, 341, 32);
/*  45 */     add((Component)youcangetnoinfoCUUE43ПщШ);
/*     */     
/*  47 */     Object youcangetnoinfoCUUFчнРу7 = new JLabel("Message id");
/*  48 */     youcangetnoinfoCUUFчнРу7.setBounds(28, 70, 293, 15);
/*  49 */     add((Component)youcangetnoinfoCUUFчнРу7);
/*     */     
/*  51 */     Object youcangetnoinfoCUUGД4мпр = new JTextField();
/*  52 */     youcangetnoinfoCUUGД4мпр.setColumns(10);
/*  53 */     youcangetnoinfoCUUGД4мпр.setBounds(28, 85, 341, 32);
/*  54 */     add((Component)youcangetnoinfoCUUGД4мпр);
/*     */     
/*  56 */     Object youcangetnoinfoCUUHд2Т8щ = new JLabel("Emoji unicode");
/*  57 */     youcangetnoinfoCUUHд2Т8щ.setBounds(28, 129, 119, 15);
/*  58 */     add((Component)youcangetnoinfoCUUHд2Т8щ);
/*     */     
/*  60 */     Object youcangetnoinfoCUUI2ДЫуШ = new JLabel("Copy emojis from here");
/*  61 */     youcangetnoinfoCUUI2ДЫуШ.setBounds(202, 129, 167, 15);
/*  62 */     youcangetnoinfoCUUI2ДЫуШ.setForeground(Color.BLUE);
/*  63 */     youcangetnoinfoCUUI2ДЫуШ.setCursor(new Cursor(12));
/*  64 */     youcangetnoinfoCUUI2ДЫуШ.addMouseListener(new ReactionSpammer5((ReactionSpammer3)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     add((Component)youcangetnoinfoCUUI2ДЫуШ);
/*     */     
/*  75 */     Object youcangetnoinfoCUUJы3мУЮ = new JTextField();
/*  76 */     youcangetnoinfoCUUJы3мУЮ.setColumns(10);
/*  77 */     youcangetnoinfoCUUJы3мУЮ.setBounds(28, 144, 341, 32);
/*  78 */     add((Component)youcangetnoinfoCUUJы3мУЮ);
/*     */     
/*  80 */     Object youcangetnoinfoCUUKЪЮ5ёв = new JButton("Add");
/*  81 */     youcangetnoinfoCUUKЪЮ5ёв.setBounds(28, 188, 157, 32);
/*  82 */     youcangetnoinfoCUUKЪЮ5ёв.setIcon(new ImageIcon(getClass().getResource("/ui/add.png")));
/*  83 */     youcangetnoinfoCUUKЪЮ5ёв.addActionListener(new ReactionSpammer6((ReactionSpammer3)this, (JTextField)youcangetnoinfoCUUE43ПщШ, (JTextField)youcangetnoinfoCUUGД4мпр, (JTextField)youcangetnoinfoCUUJы3мУЮ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     add((Component)youcangetnoinfoCUUKЪЮ5ёв);
/*     */     
/* 136 */     Object youcangetnoinfoCUULб63ВЦ = new JButton("Remove");
/* 137 */     youcangetnoinfoCUULб63ВЦ.setBounds(212, 188, 157, 32);
/* 138 */     youcangetnoinfoCUULб63ВЦ.setIcon(new ImageIcon(getClass().getResource("/ui/remove.png")));
/* 139 */     youcangetnoinfoCUULб63ВЦ.addActionListener(new ReactionSpammer((ReactionSpammer3)this, (JTextField)youcangetnoinfoCUUE43ПщШ, (JTextField)youcangetnoinfoCUUGД4мпр, (JTextField)youcangetnoinfoCUUJы3мУЮ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     add((Component)youcangetnoinfoCUULб63ВЦ);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ReactionSpammer3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */