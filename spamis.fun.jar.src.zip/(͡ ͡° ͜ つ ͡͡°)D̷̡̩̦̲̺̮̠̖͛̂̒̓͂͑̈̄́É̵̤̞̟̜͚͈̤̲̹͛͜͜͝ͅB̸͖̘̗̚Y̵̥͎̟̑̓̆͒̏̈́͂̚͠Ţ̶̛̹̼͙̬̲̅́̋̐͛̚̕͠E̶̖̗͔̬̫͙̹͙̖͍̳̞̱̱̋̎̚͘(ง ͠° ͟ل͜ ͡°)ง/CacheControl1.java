/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CacheControl1
/*     */ {
/*     */   public int minFreshSeconds;
/*     */   public boolean noCache;
/*     */   public int maxAgeSeconds;
/*     */   public boolean noTransform;
/*     */   public boolean onlyIfCached;
/*     */   public boolean immutable;
/*     */   public boolean noStore;
/*     */   public int maxStaleSeconds;
/*     */   
/*     */   public CacheControl1() {
/* 278 */     this();
/*     */ 
/*     */     
/* 281 */     ((CacheControl1)super).maxAgeSeconds = -1;
/* 282 */     ((CacheControl1)super).maxStaleSeconds = -1;
/* 283 */     ((CacheControl1)super).minFreshSeconds = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl1 noCache() {
/* 290 */     ((CacheControl1)super).noCache = true;
/* 291 */     return (CacheControl1)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public CacheControl1 noStore() {
/* 296 */     ((CacheControl1)super).noStore = true;
/* 297 */     return (CacheControl1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl1 maxAge(Object youcangetnoinfoEKZNйджОи, Object youcangetnoinfoEKZOьоцпю) {
/* 308 */     if (youcangetnoinfoEKZNйджОи < null) throw new IllegalArgumentException("maxAge < 0: " + youcangetnoinfoEKZNйджОи); 
/* 309 */     long l = youcangetnoinfoEKZOьоцпю.toSeconds(youcangetnoinfoEKZNйджОи);
/* 310 */     ((CacheControl1)super)
/*     */       
/* 312 */       .maxAgeSeconds = (l > 2147483647L) ? Integer.MAX_VALUE : (int)l;
/* 313 */     return (CacheControl1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl1 maxStale(Object youcangetnoinfoBTYGпкАДЩ, Object youcangetnoinfoBTYHЬЁЙтз) {
/* 324 */     if (youcangetnoinfoBTYGпкАДЩ < null) throw new IllegalArgumentException("maxStale < 0: " + youcangetnoinfoBTYGпкАДЩ); 
/* 325 */     long l = youcangetnoinfoBTYHЬЁЙтз.toSeconds(youcangetnoinfoBTYGпкАДЩ);
/* 326 */     ((CacheControl1)super)
/*     */       
/* 328 */       .maxStaleSeconds = (l > 2147483647L) ? Integer.MAX_VALUE : (int)l;
/* 329 */     return (CacheControl1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl1 minFresh(Object youcangetnoinfoABRIЯешя5, Object youcangetnoinfoABRJЖБеым) {
/* 341 */     if (youcangetnoinfoABRIЯешя5 < null) throw new IllegalArgumentException("minFresh < 0: " + youcangetnoinfoABRIЯешя5); 
/* 342 */     long l = youcangetnoinfoABRJЖБеым.toSeconds(youcangetnoinfoABRIЯешя5);
/* 343 */     ((CacheControl1)super)
/*     */       
/* 345 */       .minFreshSeconds = (l > 2147483647L) ? Integer.MAX_VALUE : (int)l;
/* 346 */     return (CacheControl1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl1 onlyIfCached() {
/* 354 */     ((CacheControl1)super).onlyIfCached = true;
/* 355 */     return (CacheControl1)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public CacheControl1 noTransform() {
/* 360 */     ((CacheControl1)super).noTransform = true;
/* 361 */     return (CacheControl1)this;
/*     */   }
/*     */   
/*     */   public CacheControl1 immutable() {
/* 365 */     ((CacheControl1)super).immutable = true;
/* 366 */     return (CacheControl1)this;
/*     */   }
/*     */   
/*     */   public CacheControl build() {
/* 370 */     return new CacheControl((CacheControl1)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\CacheControl1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */