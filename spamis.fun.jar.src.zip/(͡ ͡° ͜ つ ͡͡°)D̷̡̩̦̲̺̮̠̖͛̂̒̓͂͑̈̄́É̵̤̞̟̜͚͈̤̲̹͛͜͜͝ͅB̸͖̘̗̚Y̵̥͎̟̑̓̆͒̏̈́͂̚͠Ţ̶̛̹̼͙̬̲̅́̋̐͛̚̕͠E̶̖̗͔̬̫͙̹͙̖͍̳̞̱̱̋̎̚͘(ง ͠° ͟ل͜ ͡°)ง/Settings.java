/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Settings
/*     */ {
/*     */   public final int[] values;
/*     */   public static final int INITIAL_WINDOW_SIZE = 7;
/*     */   public static final int COUNT = 10;
/*     */   public static final int MAX_HEADER_LIST_SIZE = 6;
/*     */   public static final int ENABLE_PUSH = 2;
/*     */   public int set;
/*     */   public static final int MAX_FRAME_SIZE = 5;
/*     */   public static final int HEADER_TABLE_SIZE = 1;
/*     */   public static final int MAX_CONCURRENT_STREAMS = 4;
/*     */   public static final int DEFAULT_INITIAL_WINDOW_SIZE = 65535;
/*     */   
/*     */   public Settings() {
/*  24 */     this();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     ((Settings)super).values = new int[10];
/*     */   }
/*     */   public void clear() {
/*  54 */     ((Settings)super).set = 0;
/*  55 */     Arrays.fill(((Settings)super).values, 0);
/*     */   }
/*     */   
/*     */   public Settings set(Object youcangetnoinfoCHUOЗоа4Ъ, Object youcangetnoinfoCHUPщшщДУ) {
/*  59 */     if (youcangetnoinfoCHUOЗоа4Ъ < null || youcangetnoinfoCHUOЗоа4Ъ >= ((Settings)super).values.length) {
/*  60 */       return (Settings)this;
/*     */     }
/*     */     
/*  63 */     int i = 1 << youcangetnoinfoCHUOЗоа4Ъ;
/*  64 */     ((Settings)super).set |= i;
/*  65 */     ((Settings)super).values[youcangetnoinfoCHUOЗоа4Ъ] = youcangetnoinfoCHUPщшщДУ;
/*  66 */     return (Settings)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isSet(Object youcangetnoinfoDUHFюшЪЁ1) {
/*  71 */     int i = 1 << youcangetnoinfoDUHFюшЪЁ1;
/*  72 */     return ((((Settings)super).set & i) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int get(Object youcangetnoinfoDUIHЙётлФ) {
/*  77 */     return ((Settings)super).values[youcangetnoinfoDUIHЙётлФ];
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  82 */     return Integer.bitCount(((Settings)super).set);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getHeaderTableSize() {
/*  87 */     byte b = 2;
/*  88 */     return ((b & ((Settings)super).set) != 0) ? ((Settings)super).values[1] : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getEnablePush(Object youcangetnoinfoHKSЪРидЮ) {
/*  93 */     byte b = 4;
/*  94 */     return ((((b & ((Settings)super).set) != 0) ? ((Settings)super).values[2] : ((youcangetnoinfoHKSЪРидЮ != null) ? true : false)) == true);
/*     */   }
/*     */   
/*     */   public int getMaxConcurrentStreams(Object youcangetnoinfoAYYXдКжАп) {
/*  98 */     byte b = 16;
/*  99 */     return ((b & ((Settings)super).set) != 0) ? ((Settings)super).values[4] : youcangetnoinfoAYYXдКжАп;
/*     */   }
/*     */   
/*     */   public int getMaxFrameSize(Object youcangetnoinfoDTOTъ6БИм) {
/* 103 */     byte b = 32;
/* 104 */     return ((b & ((Settings)super).set) != 0) ? ((Settings)super).values[5] : youcangetnoinfoDTOTъ6БИм;
/*     */   }
/*     */   
/*     */   public int getMaxHeaderListSize(Object youcangetnoinfoAYOSтыДба) {
/* 108 */     byte b = 64;
/* 109 */     return ((b & ((Settings)super).set) != 0) ? ((Settings)super).values[6] : youcangetnoinfoAYOSтыДба;
/*     */   }
/*     */   
/*     */   public int getInitialWindowSize() {
/* 113 */     char c = '';
/* 114 */     return ((c & ((Settings)super).set) != 0) ? ((Settings)super).values[7] : 65535;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void merge(Object youcangetnoinfoDULHХэ0к7) {
/* 122 */     for (byte b = 0; b < 10; b++) {
/* 123 */       if (youcangetnoinfoDULHХэ0к7.isSet(b))
/* 124 */         super.set(b, youcangetnoinfoDULHХэ0к7.get(b)); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Settings.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */