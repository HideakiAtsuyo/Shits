/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MultipartBody
/*     */   extends RequestBody
/*     */ {
/*     */   public static final MediaType ALTERNATIVE;
/*     */   public static final MediaType FORM;
/*  35 */   public static final MediaType MIXED = MediaType.get("multipart/mixed"); public static final MediaType DIGEST;
/*     */   public static final MediaType PARALLEL;
/*     */   public long contentLength;
/*     */   public final MediaType originalType;
/*     */   public static final byte[] DASHDASH;
/*     */   
/*     */   static {
/*  42 */     ALTERNATIVE = MediaType.get("multipart/alternative");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  49 */     DIGEST = MediaType.get("multipart/digest");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  55 */     PARALLEL = MediaType.get("multipart/parallel");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     FORM = MediaType.get("multipart/form-data");
/*     */     
/*  64 */     COLONSPACE = new byte[] { 58, 32 };
/*  65 */     CRLF = new byte[] { 13, 10 };
/*  66 */     DASHDASH = new byte[] { 45, 45 };
/*     */   }
/*     */   public final ByteString boundary;
/*     */   public static final byte[] CRLF;
/*     */   
/*     */   public MultipartBody(Object youcangetnoinfoEGWPтЩЛЭФ, Object youcangetnoinfoEGWQК7ъяЁ, Object youcangetnoinfoEGWRвЙЮан) {
/*  72 */     ((MultipartBody)super).contentLength = -1L;
/*     */ 
/*     */     
/*  75 */     ((MultipartBody)super).boundary = (ByteString)youcangetnoinfoEGWPтЩЛЭФ;
/*  76 */     ((MultipartBody)super).originalType = (MediaType)youcangetnoinfoEGWQК7ъяЁ;
/*  77 */     ((MultipartBody)super).contentType = MediaType.get(youcangetnoinfoEGWQК7ъяЁ + "; boundary=" + youcangetnoinfoEGWPтЩЛЭФ.utf8());
/*  78 */     ((MultipartBody)super).parts = Util1.immutableList((List<?>)youcangetnoinfoEGWRвЙЮан);
/*     */   }
/*     */   public final List parts; public static final byte[] COLONSPACE; public final MediaType contentType;
/*     */   public MediaType type() {
/*  82 */     return ((MultipartBody)super).originalType;
/*     */   }
/*     */   
/*     */   public String boundary() {
/*  86 */     return ((MultipartBody)super).boundary.utf8();
/*     */   }
/*     */ 
/*     */   
/*     */   public int size() {
/*  91 */     return ((MultipartBody)super).parts.size();
/*     */   }
/*     */   
/*     */   public List parts() {
/*  95 */     return ((MultipartBody)super).parts;
/*     */   }
/*     */   
/*     */   public MultipartBody2 part(Object youcangetnoinfoAHAW7ипДь) {
/*  99 */     return ((MultipartBody)super).parts.get(youcangetnoinfoAHAW7ипДь);
/*     */   }
/*     */ 
/*     */   
/*     */   public MediaType contentType() {
/* 104 */     return ((MultipartBody)super).contentType;
/*     */   }
/*     */   
/*     */   public long contentLength() throws IOException {
/* 108 */     long l = ((MultipartBody)super).contentLength;
/* 109 */     if (l != -1L) return l; 
/* 110 */     return ((MultipartBody)super).contentLength = super.writeOrCountBytes(null, true);
/*     */   }
/*     */   
/*     */   public void writeTo(Object youcangetnoinfoCAPGгНЮЬЯ) throws IOException {
/* 114 */     super.writeOrCountBytes((BufferedSink)youcangetnoinfoCAPGгНЮЬЯ, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long writeOrCountBytes(@Nullable Object youcangetnoinfoAIGIоРЩОУ, Object youcangetnoinfoAIGJЛЭЖДё) throws IOException {
/* 125 */     long l = 0L;
/*     */     
/* 127 */     Object youcangetnoinfoAIGLьЮПле = null;
/* 128 */     if (youcangetnoinfoAIGJЛЭЖДё != null)
/* 129 */       youcangetnoinfoAIGIоРЩОУ = youcangetnoinfoAIGLьЮПле = new Buffer2(); 
/*     */     byte b;
/*     */     int i;
/* 132 */     for (b = 0, i = ((MultipartBody)super).parts.size(); b < i; b++) {
/* 133 */       Object youcangetnoinfoAIGAПВЭуА = ((MultipartBody)super).parts.get(b);
/* 134 */       Object youcangetnoinfoAIGB03юЁъ = ((MultipartBody2)youcangetnoinfoAIGAПВЭуА).headers;
/* 135 */       Object youcangetnoinfoAIGCГмЗёМ = ((MultipartBody2)youcangetnoinfoAIGAПВЭуА).body;
/*     */       
/* 137 */       youcangetnoinfoAIGIоРЩОУ.write(DASHDASH);
/* 138 */       youcangetnoinfoAIGIоРЩОУ.write(((MultipartBody)super).boundary);
/* 139 */       youcangetnoinfoAIGIоРЩОУ.write(CRLF);
/*     */       
/* 141 */       if (youcangetnoinfoAIGB03юЁъ != null) {
/* 142 */         byte b1; int j; for (b1 = 0, j = youcangetnoinfoAIGB03юЁъ.size(); b1 < j; b1++) {
/* 143 */           youcangetnoinfoAIGIоРЩОУ.writeUtf8(youcangetnoinfoAIGB03юЁъ.name(b1))
/* 144 */             .write(COLONSPACE)
/* 145 */             .writeUtf8(youcangetnoinfoAIGB03юЁъ.value(b1))
/* 146 */             .write(CRLF);
/*     */         }
/*     */       } 
/*     */       
/* 150 */       Object youcangetnoinfoAIGDЯ6Аю6 = youcangetnoinfoAIGCГмЗёМ.contentType();
/* 151 */       if (youcangetnoinfoAIGDЯ6Аю6 != null) {
/* 152 */         youcangetnoinfoAIGIоРЩОУ.writeUtf8("Content-Type: ")
/* 153 */           .writeUtf8(youcangetnoinfoAIGDЯ6Аю6.toString())
/* 154 */           .write(CRLF);
/*     */       }
/*     */       
/* 157 */       long l1 = youcangetnoinfoAIGCГмЗёМ.contentLength();
/* 158 */       if (l1 != -1L) {
/* 159 */         youcangetnoinfoAIGIоРЩОУ.writeUtf8("Content-Length: ")
/* 160 */           .writeDecimalLong(l1)
/* 161 */           .write(CRLF);
/* 162 */       } else if (youcangetnoinfoAIGJЛЭЖДё != null) {
/*     */         
/* 164 */         youcangetnoinfoAIGLьЮПле.clear();
/* 165 */         return -1L;
/*     */       } 
/*     */       
/* 168 */       youcangetnoinfoAIGIоРЩОУ.write(CRLF);
/*     */       
/* 170 */       if (youcangetnoinfoAIGJЛЭЖДё != null) {
/* 171 */         l += l1;
/*     */       } else {
/* 173 */         youcangetnoinfoAIGCГмЗёМ.writeTo((BufferedSink)youcangetnoinfoAIGIоРЩОУ);
/*     */       } 
/*     */       
/* 176 */       youcangetnoinfoAIGIоРЩОУ.write(CRLF);
/*     */     } 
/*     */     
/* 179 */     youcangetnoinfoAIGIоРЩОУ.write(DASHDASH);
/* 180 */     youcangetnoinfoAIGIоРЩОУ.write(((MultipartBody)super).boundary);
/* 181 */     youcangetnoinfoAIGIоРЩОУ.write(DASHDASH);
/* 182 */     youcangetnoinfoAIGIоРЩОУ.write(CRLF);
/*     */     
/* 184 */     if (youcangetnoinfoAIGJЛЭЖДё != null) {
/* 185 */       l += youcangetnoinfoAIGLьЮПле.size();
/* 186 */       youcangetnoinfoAIGLьЮПле.clear();
/*     */     } 
/*     */     
/* 189 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void appendQuotedString(Object youcangetnoinfoEREЯэ6ГЁ, Object youcangetnoinfoERF8ЖжВз) {
/* 203 */     youcangetnoinfoEREЯэ6ГЁ.append('"'); byte b; int i;
/* 204 */     for (b = 0, i = youcangetnoinfoERF8ЖжВз.length(); b < i; b++) {
/* 205 */       char c = youcangetnoinfoERF8ЖжВз.charAt(b);
/* 206 */       switch (c) {
/*     */         case '\n':
/* 208 */           youcangetnoinfoEREЯэ6ГЁ.append("%0A");
/*     */           break;
/*     */         case '\r':
/* 211 */           youcangetnoinfoEREЯэ6ГЁ.append("%0D");
/*     */           break;
/*     */         case '"':
/* 214 */           youcangetnoinfoEREЯэ6ГЁ.append("%22");
/*     */           break;
/*     */         default:
/* 217 */           youcangetnoinfoEREЯэ6ГЁ.append(c);
/*     */           break;
/*     */       } 
/*     */     } 
/* 221 */     youcangetnoinfoEREЯэ6ГЁ.append('"');
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\MultipartBody.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */