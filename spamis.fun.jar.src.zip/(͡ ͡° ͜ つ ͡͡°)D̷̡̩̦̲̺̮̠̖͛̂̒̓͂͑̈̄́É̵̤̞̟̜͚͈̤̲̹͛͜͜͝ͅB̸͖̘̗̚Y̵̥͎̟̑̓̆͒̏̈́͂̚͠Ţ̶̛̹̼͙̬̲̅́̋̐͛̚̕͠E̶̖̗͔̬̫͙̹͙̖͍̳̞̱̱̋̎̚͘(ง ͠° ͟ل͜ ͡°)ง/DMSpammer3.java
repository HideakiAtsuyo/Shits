/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DMSpammer3
/*     */   extends JPanel
/*     */ {
/*     */   public static JButton serverSpamStartBtn;
/*     */   public static boolean enabled = false;
/*     */   public static JButton serverSpamStopBtn;
/*     */   
/*     */   public DMSpammer3() {
/*  32 */     super.initialize();
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  36 */     setLayout((LayoutManager)null);
/*     */     
/*  38 */     Object youcangetnoinfoCRZJЩюйон = new JLabel("User id");
/*  39 */     youcangetnoinfoCRZJЩюйон.setBounds(28, 12, 249, 15);
/*  40 */     add((Component)youcangetnoinfoCRZJЩюйон);
/*     */     
/*  42 */     Object youcangetnoinfoCRZKл1КХЬ = new JTextField();
/*  43 */     youcangetnoinfoCRZKл1КХЬ.setColumns(10);
/*  44 */     youcangetnoinfoCRZKл1КХЬ.setBounds(28, 27, 341, 32);
/*  45 */     add((Component)youcangetnoinfoCRZKл1КХЬ);
/*     */     
/*  47 */     Object youcangetnoinfoCRZLБьОпК = new JLabel("Text (Live)");
/*  48 */     youcangetnoinfoCRZLБьОпК.setBounds(28, 71, 249, 15);
/*  49 */     add((Component)youcangetnoinfoCRZLБьОпК);
/*     */     
/*  51 */     Object youcangetnoinfoCRZM8ЪТ69 = new JTextArea();
/*  52 */     Object youcangetnoinfoCRZN5ЧдтП = new JScrollPane((Component)youcangetnoinfoCRZM8ЪТ69, 22, 30);
/*     */     
/*  54 */     youcangetnoinfoCRZN5ЧдтП.setBounds(28, 86, 341, 115);
/*  55 */     add((Component)youcangetnoinfoCRZN5ЧдтП);
/*     */     
/*  57 */     Object youcangetnoinfoCRZOУЫфжи = new JLabel("Delay: 100ms");
/*  58 */     youcangetnoinfoCRZOУЫфжи.setBounds(38, 214, 293, 15);
/*  59 */     add((Component)youcangetnoinfoCRZOУЫфжи);
/*     */     
/*  61 */     Object youcangetnoinfoCRZPёЙОЗ0 = new JSlider();
/*  62 */     youcangetnoinfoCRZPёЙОЗ0.setValue(100);
/*  63 */     youcangetnoinfoCRZPёЙОЗ0.setMinimum(50);
/*  64 */     youcangetnoinfoCRZPёЙОЗ0.setMaximum(1000);
/*  65 */     youcangetnoinfoCRZPёЙОЗ0.setBounds(38, 230, 331, 32);
/*  66 */     youcangetnoinfoCRZPёЙОЗ0.addChangeListener(new DMSpammer5((DMSpammer3)this, (JLabel)youcangetnoinfoCRZOУЫфжи, (JSlider)youcangetnoinfoCRZPёЙОЗ0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  72 */     add((Component)youcangetnoinfoCRZPёЙОЗ0);
/*     */     
/*  74 */     Object youcangetnoinfoCRZQЛ5дШЛ = new JCheckBox("Text to speech (/tts)");
/*  75 */     youcangetnoinfoCRZQЛ5дШЛ.setBounds(38, 264, 307, 23);
/*  76 */     add((Component)youcangetnoinfoCRZQЛ5дШЛ);
/*     */     
/*  78 */     serverSpamStartBtn = new JButton("Start");
/*  79 */     serverSpamStartBtn.setIcon(new ImageIcon(getClass().getResource("/ui/start.png")));
/*  80 */     serverSpamStartBtn.setBounds(28, 310, 157, 32);
/*  81 */     serverSpamStartBtn.addActionListener(new DMSpammer((DMSpammer3)this, (JSlider)youcangetnoinfoCRZPёЙОЗ0));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     add(serverSpamStartBtn);
/*     */     
/* 122 */     serverSpamStopBtn = new JButton("Stop");
/* 123 */     serverSpamStopBtn.setIcon(new ImageIcon(getClass().getResource("/ui/stop.png")));
/* 124 */     serverSpamStopBtn.setEnabled(false);
/* 125 */     serverSpamStopBtn.setBounds(212, 310, 157, 32);
/* 126 */     serverSpamStopBtn.addActionListener(new DMSpammer1((DMSpammer3)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     add(serverSpamStopBtn);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\DMSpammer3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */