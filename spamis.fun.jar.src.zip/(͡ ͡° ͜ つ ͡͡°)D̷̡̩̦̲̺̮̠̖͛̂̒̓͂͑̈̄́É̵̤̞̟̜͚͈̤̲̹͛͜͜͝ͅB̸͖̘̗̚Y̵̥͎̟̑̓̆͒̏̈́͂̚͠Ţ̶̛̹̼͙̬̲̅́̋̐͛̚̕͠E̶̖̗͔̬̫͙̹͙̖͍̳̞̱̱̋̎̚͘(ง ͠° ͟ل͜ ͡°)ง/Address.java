/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.net.Proxy;
/*     */ import java.net.ProxySelector;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Address
/*     */ {
/*     */   @Nullable
/*     */   public final Proxy proxy;
/*     */   public final HttpUrl1 url;
/*     */   public final Dns dns;
/*     */   public final SocketFactory socketFactory;
/*     */   @Nullable
/*     */   public final HostnameVerifier hostnameVerifier;
/*     */   public final Authenticator proxyAuthenticator;
/*     */   public final List connectionSpecs;
/*     */   @Nullable
/*     */   public final SSLSocketFactory sslSocketFactory;
/*     */   public final ProxySelector proxySelector;
/*     */   @Nullable
/*     */   public final CertificatePinner1 certificatePinner;
/*     */   public final List protocols;
/*     */   
/*     */   public Address(Object youcangetnoinfoXUZшЪЯдг, Object youcangetnoinfoXVAьТ6тМ, Object youcangetnoinfoXVBШнАрШ, Object youcangetnoinfoXVCРфНЗТ, @Nullable Object youcangetnoinfoXVDщЧ4ж6, @Nullable Object youcangetnoinfoXVEТ5бГк, @Nullable Object youcangetnoinfoXVFzгч5ь, Object youcangetnoinfoXVGл2Ваф, @Nullable Object youcangetnoinfoXVHцz7рм, Object youcangetnoinfoXVI9ЬХбУ, Object youcangetnoinfoXVJшб3В8, Object youcangetnoinfoXVKБЙОНЦ) {
/*  54 */     this();
/*  55 */     ((Address)super)
/*     */ 
/*     */ 
/*     */       
/*  59 */       .url = (new HttpUrl()).scheme((youcangetnoinfoXVDщЧ4ж6 != null) ? "https" : "http").host((String)youcangetnoinfoXUZшЪЯдг).port(youcangetnoinfoXVAьТ6тМ).build();
/*     */     
/*  61 */     if (youcangetnoinfoXVBШнАрШ == null) throw new NullPointerException("dns == null"); 
/*  62 */     ((Address)super).dns = (Dns)youcangetnoinfoXVBШнАрШ;
/*     */     
/*  64 */     if (youcangetnoinfoXVCРфНЗТ == null) throw new NullPointerException("socketFactory == null"); 
/*  65 */     ((Address)super).socketFactory = (SocketFactory)youcangetnoinfoXVCРфНЗТ;
/*     */     
/*  67 */     if (youcangetnoinfoXVGл2Ваф == null) {
/*  68 */       throw new NullPointerException("proxyAuthenticator == null");
/*     */     }
/*  70 */     ((Address)super).proxyAuthenticator = (Authenticator)youcangetnoinfoXVGл2Ваф;
/*     */     
/*  72 */     if (youcangetnoinfoXVI9ЬХбУ == null) throw new NullPointerException("protocols == null"); 
/*  73 */     ((Address)super).protocols = Util1.immutableList((List<?>)youcangetnoinfoXVI9ЬХбУ);
/*     */     
/*  75 */     if (youcangetnoinfoXVJшб3В8 == null) throw new NullPointerException("connectionSpecs == null"); 
/*  76 */     ((Address)super).connectionSpecs = Util1.immutableList((List<?>)youcangetnoinfoXVJшб3В8);
/*     */     
/*  78 */     if (youcangetnoinfoXVKБЙОНЦ == null) throw new NullPointerException("proxySelector == null"); 
/*  79 */     ((Address)super).proxySelector = (ProxySelector)youcangetnoinfoXVKБЙОНЦ;
/*     */     
/*  81 */     ((Address)super).proxy = (Proxy)youcangetnoinfoXVHцz7рм;
/*  82 */     ((Address)super).sslSocketFactory = (SSLSocketFactory)youcangetnoinfoXVDщЧ4ж6;
/*  83 */     ((Address)super).hostnameVerifier = (HostnameVerifier)youcangetnoinfoXVEТ5бГк;
/*  84 */     ((Address)super).certificatePinner = (CertificatePinner1)youcangetnoinfoXVFzгч5ь;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public HttpUrl1 url() {
/*  92 */     return ((Address)super).url;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dns dns() {
/*  97 */     return ((Address)super).dns;
/*     */   }
/*     */ 
/*     */   
/*     */   public SocketFactory socketFactory() {
/* 102 */     return ((Address)super).socketFactory;
/*     */   }
/*     */ 
/*     */   
/*     */   public Authenticator proxyAuthenticator() {
/* 107 */     return ((Address)super).proxyAuthenticator;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List protocols() {
/* 115 */     return ((Address)super).protocols;
/*     */   }
/*     */   
/*     */   public List connectionSpecs() {
/* 119 */     return ((Address)super).connectionSpecs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ProxySelector proxySelector() {
/* 127 */     return ((Address)super).proxySelector;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Proxy proxy() {
/* 135 */     return ((Address)super).proxy;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public SSLSocketFactory sslSocketFactory() {
/* 140 */     return ((Address)super).sslSocketFactory;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public HostnameVerifier hostnameVerifier() {
/* 145 */     return ((Address)super).hostnameVerifier;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public CertificatePinner1 certificatePinner() {
/* 150 */     return ((Address)super).certificatePinner;
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object youcangetnoinfoEEPXЮВ8СР) {
/* 154 */     return (youcangetnoinfoEEPXЮВ8СР instanceof Address && ((Address)super).url
/* 155 */       .equals(((Address)youcangetnoinfoEEPXЮВ8СР).url) && super
/* 156 */       .equalsNonHost((Address)youcangetnoinfoEEPXЮВ8СР));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 160 */     int i = 17;
/* 161 */     i = 31 * i + ((Address)super).url.hashCode();
/* 162 */     i = 31 * i + ((Address)super).dns.hashCode();
/* 163 */     i = 31 * i + ((Address)super).proxyAuthenticator.hashCode();
/* 164 */     i = 31 * i + ((Address)super).protocols.hashCode();
/* 165 */     i = 31 * i + ((Address)super).connectionSpecs.hashCode();
/* 166 */     i = 31 * i + ((Address)super).proxySelector.hashCode();
/* 167 */     i = 31 * i + Objects.hashCode(((Address)super).proxy);
/* 168 */     i = 31 * i + Objects.hashCode(((Address)super).sslSocketFactory);
/* 169 */     i = 31 * i + Objects.hashCode(((Address)super).hostnameVerifier);
/* 170 */     i = 31 * i + Objects.hashCode(((Address)super).certificatePinner);
/* 171 */     return i;
/*     */   }
/*     */   
/*     */   public boolean equalsNonHost(Object youcangetnoinfoDSAY4ък3Ё) {
/* 175 */     return (((Address)super).dns.equals(((Address)youcangetnoinfoDSAY4ък3Ё).dns) && ((Address)super).proxyAuthenticator
/* 176 */       .equals(((Address)youcangetnoinfoDSAY4ък3Ё).proxyAuthenticator) && ((Address)super).protocols
/* 177 */       .equals(((Address)youcangetnoinfoDSAY4ък3Ё).protocols) && ((Address)super).connectionSpecs
/* 178 */       .equals(((Address)youcangetnoinfoDSAY4ък3Ё).connectionSpecs) && ((Address)super).proxySelector
/* 179 */       .equals(((Address)youcangetnoinfoDSAY4ък3Ё).proxySelector) && 
/* 180 */       Objects.equals(((Address)super).proxy, ((Address)youcangetnoinfoDSAY4ък3Ё).proxy) && 
/* 181 */       Objects.equals(((Address)super).sslSocketFactory, ((Address)youcangetnoinfoDSAY4ък3Ё).sslSocketFactory) && 
/* 182 */       Objects.equals(((Address)super).hostnameVerifier, ((Address)youcangetnoinfoDSAY4ък3Ё).hostnameVerifier) && 
/* 183 */       Objects.equals(((Address)super).certificatePinner, ((Address)youcangetnoinfoDSAY4ък3Ё).certificatePinner) && super
/* 184 */       .url().port() == youcangetnoinfoDSAY4ък3Ё.url().port());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 190 */     Object youcangetnoinfoDENOиБЫЦФ = (new StringBuilder()).append("Address{").append(((Address)super).url.host()).append(":").append(((Address)super).url.port());
/*     */     
/* 192 */     if (((Address)super).proxy != null) {
/* 193 */       youcangetnoinfoDENOиБЫЦФ.append(", proxy=").append(((Address)super).proxy);
/*     */     } else {
/* 195 */       youcangetnoinfoDENOиБЫЦФ.append(", proxySelector=").append(((Address)super).proxySelector);
/*     */     } 
/*     */     
/* 198 */     youcangetnoinfoDENOиБЫЦФ.append("}");
/* 199 */     return youcangetnoinfoDENOиБЫЦФ.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Address.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */