/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class HttpMethod
/*    */ {
/*    */   public static boolean invalidatesCache(Object youcangetnoinfoCRKDйиЯщЭ) {
/* 20 */     return (youcangetnoinfoCRKDйиЯщЭ.equals("POST") || youcangetnoinfoCRKDйиЯщЭ
/* 21 */       .equals("PATCH") || youcangetnoinfoCRKDйиЯщЭ
/* 22 */       .equals("PUT") || youcangetnoinfoCRKDйиЯщЭ
/* 23 */       .equals("DELETE") || youcangetnoinfoCRKDйиЯщЭ
/* 24 */       .equals("MOVE"));
/*    */   }
/*    */   
/*    */   public static boolean requiresRequestBody(Object youcangetnoinfoCMIKчщЯК3) {
/* 28 */     return (youcangetnoinfoCMIKчщЯК3.equals("POST") || youcangetnoinfoCMIKчщЯК3
/* 29 */       .equals("PUT") || youcangetnoinfoCMIKчщЯК3
/* 30 */       .equals("PATCH") || youcangetnoinfoCMIKчщЯК3
/* 31 */       .equals("PROPPATCH") || youcangetnoinfoCMIKчщЯК3
/* 32 */       .equals("REPORT"));
/*    */   }
/*    */   
/*    */   public static boolean permitsRequestBody(Object youcangetnoinfoBCSLМРЖКШ) {
/* 36 */     return (!youcangetnoinfoBCSLМРЖКШ.equals("GET") && !youcangetnoinfoBCSLМРЖКШ.equals("HEAD"));
/*    */   }
/*    */   
/*    */   public static boolean redirectsWithBody(Object youcangetnoinfoUBTХНКиы) {
/* 40 */     return youcangetnoinfoUBTХНКиы.equals("PROPFIND");
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean redirectsToGet(Object youcangetnoinfoBNDNЧеАС9) {
/* 45 */     return !youcangetnoinfoBNDNЧеАС9.equals("PROPFIND");
/*    */   }
/*    */   public HttpMethod() {
/* 48 */     this();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\HttpMethod.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */