/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class RequestBody
/*     */ {
/*     */   public RequestBody() {
/*  30 */     this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long contentLength() throws IOException {
/*  39 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RequestBody create(@Nullable Object youcangetnoinfoEGTQцнХшь, Object youcangetnoinfoEGTRфРКЖС) {
/*  50 */     Object youcangetnoinfoEGTSЭ7мЙь = StandardCharsets.UTF_8;
/*  51 */     if (youcangetnoinfoEGTQцнХшь != null) {
/*  52 */       youcangetnoinfoEGTSЭ7мЙь = youcangetnoinfoEGTQцнХшь.charset();
/*  53 */       if (youcangetnoinfoEGTSЭ7мЙь == null) {
/*  54 */         youcangetnoinfoEGTSЭ7мЙь = StandardCharsets.UTF_8;
/*  55 */         youcangetnoinfoEGTQцнХшь = MediaType.parse(youcangetnoinfoEGTQцнХшь + "; charset=utf-8");
/*     */       } 
/*     */     } 
/*  58 */     Object youcangetnoinfoEGTTОЪдиЙ = youcangetnoinfoEGTRфРКЖС.getBytes((Charset)youcangetnoinfoEGTSЭ7мЙь);
/*  59 */     return create((MediaType)youcangetnoinfoEGTQцнХшь, (byte[])youcangetnoinfoEGTTОЪдиЙ);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static RequestBody create(@Nullable Object youcangetnoinfoAREZЫЯЩ0Г, Object youcangetnoinfoARFAГЗЖгу) {
/*  65 */     return new RequestBody2((MediaType)youcangetnoinfoAREZЫЯЩ0Г, (ByteString)youcangetnoinfoARFAГЗЖгу);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RequestBody create(@Nullable Object youcangetnoinfoCJSRО9ЧЯ4, Object youcangetnoinfoCJSSмВусЁ) {
/*  82 */     return create((MediaType)youcangetnoinfoCJSRО9ЧЯ4, (byte[])youcangetnoinfoCJSSмВусЁ, 0, youcangetnoinfoCJSSмВусЁ.length);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static RequestBody create(@Nullable Object youcangetnoinfoBKHOДММэЩ, Object youcangetnoinfoBKHPр8яьн, Object youcangetnoinfoBKHQэзёУШ, Object youcangetnoinfoBKHRф1Чя8) {
/*  88 */     if (youcangetnoinfoBKHPр8яьн == null) throw new NullPointerException("content == null"); 
/*  89 */     Util1.checkOffsetAndCount(youcangetnoinfoBKHPр8яьн.length, youcangetnoinfoBKHQэзёУШ, youcangetnoinfoBKHRф1Чя8);
/*  90 */     return new RequestBody3((MediaType)youcangetnoinfoBKHOДММэЩ, youcangetnoinfoBKHRф1Чя8, (byte[])youcangetnoinfoBKHPр8яьн, youcangetnoinfoBKHQэзёУШ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static RequestBody create(@Nullable Object youcangetnoinfoEHBZЖкпЗЮ, Object youcangetnoinfoEHCAzЛиб4) {
/* 107 */     if (youcangetnoinfoEHCAzЛиб4 == null) throw new NullPointerException("file == null");
/*     */     
/* 109 */     return new RequestBody1((MediaType)youcangetnoinfoEHBZЖкпЗЮ, (File)youcangetnoinfoEHCAzЛиб4);
/*     */   }
/*     */   
/*     */   public abstract void writeTo(BufferedSink paramBufferedSink) throws IOException;
/*     */   
/*     */   @Nullable
/*     */   public abstract MediaType contentType();
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RequestBody.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */