/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Reader2
/*     */   implements Closeable
/*     */ {
/*     */   public final BufferedSource source;
/*  60 */   public static final Logger logger = Logger.getLogger(Http2.class.getName());
/*     */   
/*     */   public final Hpack hpackReader;
/*     */   
/*     */   public final boolean client;
/*     */   
/*     */   public final Http2Reader continuation;
/*     */ 
/*     */   
/*     */   public Http2Reader2(Object youcangetnoinfoECEMмЮбИЩ, Object youcangetnoinfoECENУвцз4) {
/*  70 */     this();
/*  71 */     ((Http2Reader2)super).source = (BufferedSource)youcangetnoinfoECEMмЮбИЩ;
/*  72 */     ((Http2Reader2)super).client = youcangetnoinfoECENУвцз4;
/*  73 */     ((Http2Reader2)super).continuation = new Http2Reader(((Http2Reader2)super).source);
/*  74 */     ((Http2Reader2)super).hpackReader = new Hpack(4096, ((Http2Reader2)super).continuation);
/*     */   }
/*     */   
/*     */   public void readConnectionPreface(Object youcangetnoinfoDKTHлЬтЗы) throws IOException {
/*  78 */     if (((Http2Reader2)super).client) {
/*     */       
/*  80 */       if (!super.nextFrame(true, (Http2Reader1)youcangetnoinfoDKTHлЬтЗы)) {
/*  81 */         throw Http2.ioException("Required SETTINGS preface not received", new Object[0]);
/*     */       }
/*     */     } else {
/*     */       
/*  85 */       Object youcangetnoinfoDKTFрйЮТщ = ((Http2Reader2)super).source.readByteString(Http2.CONNECTION_PREFACE.size());
/*  86 */       if (logger.isLoggable(Level.FINE)) logger.fine(Util1.format("<< CONNECTION %s", new Object[] { youcangetnoinfoDKTFрйЮТщ.hex() })); 
/*  87 */       if (!Http2.CONNECTION_PREFACE.equals(youcangetnoinfoDKTFрйЮТщ)) {
/*  88 */         throw Http2.ioException("Expected a connection header but was %s", new Object[] { youcangetnoinfoDKTFрйЮТщ.utf8() });
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean nextFrame(Object youcangetnoinfoCKFUёЫГяе, Object youcangetnoinfoCKFV4СШФ4) throws IOException {
/*     */     try {
/*  95 */       ((Http2Reader2)super).source.require(9L);
/*  96 */     } catch (IOException youcangetnoinfoCKFSЛя7сЗ) {
/*  97 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     int i = readMedium(((Http2Reader2)super).source);
/* 112 */     if (i < 0 || i > 16384) {
/* 113 */       throw Http2.ioException("FRAME_SIZE_ERROR: %s", new Object[] { Integer.valueOf(i) });
/*     */     }
/* 115 */     byte b1 = (byte)(((Http2Reader2)super).source.readByte() & 0xFF);
/* 116 */     if (youcangetnoinfoCKFUёЫГяе != null && b1 != 4) {
/* 117 */       throw Http2.ioException("Expected a SETTINGS frame but was %s", new Object[] { Byte.valueOf(b1) });
/*     */     }
/* 119 */     byte b2 = (byte)(((Http2Reader2)super).source.readByte() & 0xFF);
/* 120 */     int j = ((Http2Reader2)super).source.readInt() & Integer.MAX_VALUE;
/* 121 */     if (logger.isLoggable(Level.FINE)) logger.fine(Http2.frameLog(true, j, i, b1, b2));
/*     */     
/* 123 */     switch (b1)
/*     */     { case 0:
/* 125 */         super.readData((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 164 */         return true;case 1: super.readHeaders((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j); return true;case 2: super.readPriority((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j); return true;case 3: super.readRstStream((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j); return true;case 4: super.readSettings((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j); return true;case 5: super.readPushPromise((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j); return true;case 6: super.readPing((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j); return true;case 7: super.readGoAway((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j); return true;case 8: super.readWindowUpdate((Http2Reader1)youcangetnoinfoCKFV4СШФ4, i, b2, j); return true; }  ((Http2Reader2)super).source.skip(i); return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readHeaders(Object youcangetnoinfoADULЩнеъР, Object youcangetnoinfoADUMЮ25еБ, Object youcangetnoinfoADUNШЛОюЕ, Object youcangetnoinfoADUOкяЕЫ2) throws IOException {
/*     */     // Byte code:
/*     */     //   0: iload #4
/*     */     //   2: ifne -> 15
/*     */     //   5: ldc 'PROTOCOL_ERROR: TYPE_HEADERS streamId == 0'
/*     */     //   7: iconst_0
/*     */     //   8: anewarray java/lang/Object
/*     */     //   11: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   14: athrow
/*     */     //   15: iload_3
/*     */     //   16: iconst_1
/*     */     //   17: iand
/*     */     //   18: ifeq -> 25
/*     */     //   21: iconst_1
/*     */     //   22: goto -> 26
/*     */     //   25: iconst_0
/*     */     //   26: istore #5
/*     */     //   28: iload_3
/*     */     //   29: bipush #8
/*     */     //   31: iand
/*     */     //   32: ifeq -> 52
/*     */     //   35: aload_0
/*     */     //   36: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   39: invokeinterface readByte : ()B
/*     */     //   44: sipush #255
/*     */     //   47: iand
/*     */     //   48: i2s
/*     */     //   49: goto -> 53
/*     */     //   52: iconst_0
/*     */     //   53: istore #6
/*     */     //   55: iload_3
/*     */     //   56: bipush #32
/*     */     //   58: iand
/*     */     //   59: ifeq -> 72
/*     */     //   62: aload_0
/*     */     //   63: aload_1
/*     */     //   64: iload #4
/*     */     //   66: invokespecial readPriority : (L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Http2Reader1;I)V
/*     */     //   69: iinc #2, -5
/*     */     //   72: iload_2
/*     */     //   73: iload_3
/*     */     //   74: iload #6
/*     */     //   76: invokestatic lengthWithoutPadding : (IBS)I
/*     */     //   79: istore_2
/*     */     //   80: aload_0
/*     */     //   81: iload_2
/*     */     //   82: iload #6
/*     */     //   84: iload_3
/*     */     //   85: iload #4
/*     */     //   87: invokespecial readHeaderBlock : (ISBI)Ljava/util/List;
/*     */     //   90: astore #7
/*     */     //   92: aload_1
/*     */     //   93: iload #5
/*     */     //   95: iload #4
/*     */     //   97: iconst_m1
/*     */     //   98: aload #7
/*     */     //   100: invokeinterface headers : (ZIILjava/util/List;)V
/*     */     //   105: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #169	-> 0
/*     */     //   #171	-> 15
/*     */     //   #173	-> 28
/*     */     //   #175	-> 55
/*     */     //   #176	-> 62
/*     */     //   #177	-> 69
/*     */     //   #180	-> 72
/*     */     //   #182	-> 80
/*     */     //   #184	-> 92
/*     */     //   #185	-> 105
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	106	3	youcangetnoinfoADUNШЛОюЕ	Ljava/lang/Object;
/*     */     //   0	106	0	youcangetnoinfoADUKЕеЙТ5	Ljava/lang/Object;
/*     */     //   55	51	6	youcangetnoinfoADUQпрк6Т	Ljava/lang/Object;
/*     */     //   0	106	4	youcangetnoinfoADUOкяЕЫ2	Ljava/lang/Object;
/*     */     //   0	106	2	youcangetnoinfoADUMЮ25еБ	Ljava/lang/Object;
/*     */     //   0	106	1	youcangetnoinfoADULЩнеъР	Ljava/lang/Object;
/*     */     //   92	14	7	youcangetnoinfoADURкиЬШё	Ljava/lang/Object;
/*     */     //   28	78	5	youcangetnoinfoADUPЧЭЁЬТ	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List readHeaderBlock(Object youcangetnoinfoDVQIэмбЬЮ, Object youcangetnoinfoDVQJаЁбЪх, Object youcangetnoinfoDVQK9бчю1, Object youcangetnoinfoDVQLиептр) throws IOException {
/* 189 */     ((Http2Reader2)super).continuation.length = ((Http2Reader2)super).continuation.left = youcangetnoinfoDVQIэмбЬЮ;
/* 190 */     ((Http2Reader2)super).continuation.padding = youcangetnoinfoDVQJаЁбЪх;
/* 191 */     ((Http2Reader2)super).continuation.flags = youcangetnoinfoDVQK9бчю1;
/* 192 */     ((Http2Reader2)super).continuation.streamId = youcangetnoinfoDVQLиептр;
/*     */ 
/*     */ 
/*     */     
/* 196 */     ((Http2Reader2)super).hpackReader.readHeaders();
/* 197 */     return ((Http2Reader2)super).hpackReader.getAndResetHeaderList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readData(Object youcangetnoinfoJOJ7яжо5, Object youcangetnoinfoJOK8ч3ЫС, Object youcangetnoinfoJOLЛШхщц, Object youcangetnoinfoJOMдчйеР) throws IOException {
/*     */     // Byte code:
/*     */     //   0: iload #4
/*     */     //   2: ifne -> 16
/*     */     //   5: ldc_w 'PROTOCOL_ERROR: TYPE_DATA streamId == 0'
/*     */     //   8: iconst_0
/*     */     //   9: anewarray java/lang/Object
/*     */     //   12: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   15: athrow
/*     */     //   16: iload_3
/*     */     //   17: iconst_1
/*     */     //   18: iand
/*     */     //   19: ifeq -> 26
/*     */     //   22: iconst_1
/*     */     //   23: goto -> 27
/*     */     //   26: iconst_0
/*     */     //   27: istore #5
/*     */     //   29: iload_3
/*     */     //   30: bipush #32
/*     */     //   32: iand
/*     */     //   33: ifeq -> 40
/*     */     //   36: iconst_1
/*     */     //   37: goto -> 41
/*     */     //   40: iconst_0
/*     */     //   41: istore #6
/*     */     //   43: iload #6
/*     */     //   45: ifeq -> 59
/*     */     //   48: ldc_w 'PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA'
/*     */     //   51: iconst_0
/*     */     //   52: anewarray java/lang/Object
/*     */     //   55: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   58: athrow
/*     */     //   59: iload_3
/*     */     //   60: bipush #8
/*     */     //   62: iand
/*     */     //   63: ifeq -> 83
/*     */     //   66: aload_0
/*     */     //   67: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   70: invokeinterface readByte : ()B
/*     */     //   75: sipush #255
/*     */     //   78: iand
/*     */     //   79: i2s
/*     */     //   80: goto -> 84
/*     */     //   83: iconst_0
/*     */     //   84: istore #7
/*     */     //   86: iload_2
/*     */     //   87: iload_3
/*     */     //   88: iload #7
/*     */     //   90: invokestatic lengthWithoutPadding : (IBS)I
/*     */     //   93: istore_2
/*     */     //   94: aload_1
/*     */     //   95: iload #5
/*     */     //   97: iload #4
/*     */     //   99: aload_0
/*     */     //   100: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   103: iload_2
/*     */     //   104: invokeinterface data : (ZIL(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;I)V
/*     */     //   109: aload_0
/*     */     //   110: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   113: iload #7
/*     */     //   115: i2l
/*     */     //   116: invokeinterface skip : (J)V
/*     */     //   121: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #202	-> 0
/*     */     //   #205	-> 16
/*     */     //   #206	-> 29
/*     */     //   #207	-> 43
/*     */     //   #208	-> 48
/*     */     //   #211	-> 59
/*     */     //   #212	-> 86
/*     */     //   #214	-> 94
/*     */     //   #215	-> 109
/*     */     //   #216	-> 121
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   29	93	5	youcangetnoinfoJONаШВфю	Ljava/lang/Object;
/*     */     //   0	122	2	youcangetnoinfoJOK8ч3ЫС	Ljava/lang/Object;
/*     */     //   0	122	4	youcangetnoinfoJOMдчйеР	Ljava/lang/Object;
/*     */     //   0	122	1	youcangetnoinfoJOJ7яжо5	Ljava/lang/Object;
/*     */     //   86	36	7	youcangetnoinfoJOPщУЩОБ	Ljava/lang/Object;
/*     */     //   43	79	6	youcangetnoinfoJOOz5zёу	Ljava/lang/Object;
/*     */     //   0	122	3	youcangetnoinfoJOLЛШхщц	Ljava/lang/Object;
/*     */     //   0	122	0	youcangetnoinfoJOIЧрьшД	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readPriority(Object youcangetnoinfoCEBZЪор4Ц, Object youcangetnoinfoCECAЬдмЮШ, Object youcangetnoinfoCECBкЧбэЧ, Object youcangetnoinfoCECCы4л9Ч) throws IOException {
/* 220 */     if (youcangetnoinfoCECAЬдмЮШ != 5) throw Http2.ioException("TYPE_PRIORITY length: %d != 5", new Object[] { Integer.valueOf(youcangetnoinfoCECAЬдмЮШ) }); 
/* 221 */     if (youcangetnoinfoCECCы4л9Ч == null) throw Http2.ioException("TYPE_PRIORITY streamId == 0", new Object[0]); 
/* 222 */     super.readPriority((Http2Reader1)youcangetnoinfoCEBZЪор4Ц, youcangetnoinfoCECCы4л9Ч);
/*     */   }
/*     */   
/*     */   public void readPriority(Object youcangetnoinfoZTн4Ь09, Object youcangetnoinfoZUЩмувД) throws IOException {
/* 226 */     int i = ((Http2Reader2)super).source.readInt();
/* 227 */     boolean bool = ((i & Integer.MIN_VALUE) != 0) ? true : false;
/* 228 */     int j = i & Integer.MAX_VALUE;
/* 229 */     int k = (((Http2Reader2)super).source.readByte() & 0xFF) + 1;
/* 230 */     youcangetnoinfoZTн4Ь09.priority(youcangetnoinfoZUЩмувД, j, k, bool);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readRstStream(Object youcangetnoinfoCIQQ5цт48, Object youcangetnoinfoCIQRЖдццz, Object youcangetnoinfoCIQS75ДОД, Object youcangetnoinfoCIQTпеДПа) throws IOException {
/* 235 */     if (youcangetnoinfoCIQRЖдццz != 4) throw Http2.ioException("TYPE_RST_STREAM length: %d != 4", new Object[] { Integer.valueOf(youcangetnoinfoCIQRЖдццz) }); 
/* 236 */     if (youcangetnoinfoCIQTпеДПа == null) throw Http2.ioException("TYPE_RST_STREAM streamId == 0", new Object[0]); 
/* 237 */     int i = ((Http2Reader2)super).source.readInt();
/* 238 */     Object youcangetnoinfoCIQVъгКжй = ErrorCode.fromHttp2(i);
/* 239 */     if (youcangetnoinfoCIQVъгКжй == null) {
/* 240 */       throw Http2.ioException("TYPE_RST_STREAM unexpected error code: %d", new Object[] { Integer.valueOf(i) });
/*     */     }
/* 242 */     youcangetnoinfoCIQQ5цт48.rstStream(youcangetnoinfoCIQTпеДПа, (ErrorCode)youcangetnoinfoCIQVъгКжй);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readSettings(Object youcangetnoinfoEEUAэи8що, Object youcangetnoinfoEEUBНктыГ, Object youcangetnoinfoEEUCБмЙПъ, Object youcangetnoinfoEEUDЖТЪвЩ) throws IOException {
/*     */     // Byte code:
/*     */     //   0: iload #4
/*     */     //   2: ifeq -> 16
/*     */     //   5: ldc_w 'TYPE_SETTINGS streamId != 0'
/*     */     //   8: iconst_0
/*     */     //   9: anewarray java/lang/Object
/*     */     //   12: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   15: athrow
/*     */     //   16: iload_3
/*     */     //   17: iconst_1
/*     */     //   18: iand
/*     */     //   19: ifeq -> 44
/*     */     //   22: iload_2
/*     */     //   23: ifeq -> 37
/*     */     //   26: ldc_w 'FRAME_SIZE_ERROR ack frame should be empty!'
/*     */     //   29: iconst_0
/*     */     //   30: anewarray java/lang/Object
/*     */     //   33: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   36: athrow
/*     */     //   37: aload_1
/*     */     //   38: invokeinterface ackSettings : ()V
/*     */     //   43: return
/*     */     //   44: iload_2
/*     */     //   45: bipush #6
/*     */     //   47: irem
/*     */     //   48: ifeq -> 69
/*     */     //   51: ldc_w 'TYPE_SETTINGS length %% 6 != 0: %s'
/*     */     //   54: iconst_1
/*     */     //   55: anewarray java/lang/Object
/*     */     //   58: dup
/*     */     //   59: iconst_0
/*     */     //   60: iload_2
/*     */     //   61: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   64: aastore
/*     */     //   65: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   68: athrow
/*     */     //   69: new (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Settings
/*     */     //   72: dup
/*     */     //   73: invokespecial <init> : ()V
/*     */     //   76: astore #5
/*     */     //   78: iconst_0
/*     */     //   79: istore #6
/*     */     //   81: iload #6
/*     */     //   83: iload_2
/*     */     //   84: if_icmpge -> 257
/*     */     //   87: aload_0
/*     */     //   88: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   91: invokeinterface readShort : ()S
/*     */     //   96: ldc_w 65535
/*     */     //   99: iand
/*     */     //   100: istore #7
/*     */     //   102: aload_0
/*     */     //   103: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   106: invokeinterface readInt : ()I
/*     */     //   111: istore #8
/*     */     //   113: iload #7
/*     */     //   115: tableswitch default -> 241, 1 -> 152, 2 -> 155, 3 -> 177, 4 -> 183, 5 -> 203, 6 -> 238
/*     */     //   152: goto -> 241
/*     */     //   155: iload #8
/*     */     //   157: ifeq -> 241
/*     */     //   160: iload #8
/*     */     //   162: iconst_1
/*     */     //   163: if_icmpeq -> 241
/*     */     //   166: ldc_w 'PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1'
/*     */     //   169: iconst_0
/*     */     //   170: anewarray java/lang/Object
/*     */     //   173: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   176: athrow
/*     */     //   177: iconst_4
/*     */     //   178: istore #7
/*     */     //   180: goto -> 241
/*     */     //   183: bipush #7
/*     */     //   185: istore #7
/*     */     //   187: iload #8
/*     */     //   189: ifge -> 241
/*     */     //   192: ldc_w 'PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1'
/*     */     //   195: iconst_0
/*     */     //   196: anewarray java/lang/Object
/*     */     //   199: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   202: athrow
/*     */     //   203: iload #8
/*     */     //   205: sipush #16384
/*     */     //   208: if_icmplt -> 219
/*     */     //   211: iload #8
/*     */     //   213: ldc_w 16777215
/*     */     //   216: if_icmple -> 241
/*     */     //   219: ldc_w 'PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: %s'
/*     */     //   222: iconst_1
/*     */     //   223: anewarray java/lang/Object
/*     */     //   226: dup
/*     */     //   227: iconst_0
/*     */     //   228: iload #8
/*     */     //   230: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   233: aastore
/*     */     //   234: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   237: athrow
/*     */     //   238: goto -> 241
/*     */     //   241: aload #5
/*     */     //   243: iload #7
/*     */     //   245: iload #8
/*     */     //   247: invokevirtual set : (II)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Settings;
/*     */     //   250: pop
/*     */     //   251: iinc #6, 6
/*     */     //   254: goto -> 81
/*     */     //   257: aload_1
/*     */     //   258: iconst_0
/*     */     //   259: aload #5
/*     */     //   261: invokeinterface settings : (ZL(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Settings;)V
/*     */     //   266: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #247	-> 0
/*     */     //   #248	-> 16
/*     */     //   #249	-> 22
/*     */     //   #250	-> 37
/*     */     //   #251	-> 43
/*     */     //   #254	-> 44
/*     */     //   #255	-> 69
/*     */     //   #256	-> 78
/*     */     //   #257	-> 87
/*     */     //   #258	-> 102
/*     */     //   #260	-> 113
/*     */     //   #262	-> 152
/*     */     //   #264	-> 155
/*     */     //   #265	-> 166
/*     */     //   #269	-> 177
/*     */     //   #270	-> 180
/*     */     //   #272	-> 183
/*     */     //   #273	-> 187
/*     */     //   #274	-> 192
/*     */     //   #278	-> 203
/*     */     //   #279	-> 219
/*     */     //   #283	-> 238
/*     */     //   #287	-> 241
/*     */     //   #256	-> 251
/*     */     //   #289	-> 257
/*     */     //   #290	-> 266
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	267	3	youcangetnoinfoEEUCБмЙПъ	Ljava/lang/Object;
/*     */     //   102	149	7	youcangetnoinfoEETWАДОАР	Ljava/lang/Object;
/*     */     //   0	267	2	youcangetnoinfoEEUBНктыГ	Ljava/lang/Object;
/*     */     //   0	267	4	youcangetnoinfoEEUDЖТЪвЩ	Ljava/lang/Object;
/*     */     //   113	138	8	youcangetnoinfoEETXФБмзу	Ljava/lang/Object;
/*     */     //   0	267	1	youcangetnoinfoEEUAэи8що	Ljava/lang/Object;
/*     */     //   81	176	6	youcangetnoinfoEETYТятСС	Ljava/lang/Object;
/*     */     //   0	267	0	youcangetnoinfoEETZЕщюкс	Ljava/lang/Object;
/*     */     //   78	189	5	youcangetnoinfoEEUEЯвЯчэ	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readPushPromise(Object youcangetnoinfoFFU7Ж9Щш, Object youcangetnoinfoFFVАэЖПГ, Object youcangetnoinfoFFWоЙЮмл, Object youcangetnoinfoFFXб2Чгэ) throws IOException {
/*     */     // Byte code:
/*     */     //   0: iload #4
/*     */     //   2: ifne -> 16
/*     */     //   5: ldc_w 'PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0'
/*     */     //   8: iconst_0
/*     */     //   9: anewarray java/lang/Object
/*     */     //   12: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   15: athrow
/*     */     //   16: iload_3
/*     */     //   17: bipush #8
/*     */     //   19: iand
/*     */     //   20: ifeq -> 40
/*     */     //   23: aload_0
/*     */     //   24: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   27: invokeinterface readByte : ()B
/*     */     //   32: sipush #255
/*     */     //   35: iand
/*     */     //   36: i2s
/*     */     //   37: goto -> 41
/*     */     //   40: iconst_0
/*     */     //   41: istore #5
/*     */     //   43: aload_0
/*     */     //   44: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   47: invokeinterface readInt : ()I
/*     */     //   52: ldc 2147483647
/*     */     //   54: iand
/*     */     //   55: istore #6
/*     */     //   57: iinc #2, -4
/*     */     //   60: iload_2
/*     */     //   61: iload_3
/*     */     //   62: iload #5
/*     */     //   64: invokestatic lengthWithoutPadding : (IBS)I
/*     */     //   67: istore_2
/*     */     //   68: aload_0
/*     */     //   69: iload_2
/*     */     //   70: iload #5
/*     */     //   72: iload_3
/*     */     //   73: iload #4
/*     */     //   75: invokespecial readHeaderBlock : (ISBI)Ljava/util/List;
/*     */     //   78: astore #7
/*     */     //   80: aload_1
/*     */     //   81: iload #4
/*     */     //   83: iload #6
/*     */     //   85: aload #7
/*     */     //   87: invokeinterface pushPromise : (IILjava/util/List;)V
/*     */     //   92: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #294	-> 0
/*     */     //   #295	-> 5
/*     */     //   #297	-> 16
/*     */     //   #298	-> 43
/*     */     //   #299	-> 57
/*     */     //   #300	-> 60
/*     */     //   #301	-> 68
/*     */     //   #302	-> 80
/*     */     //   #303	-> 92
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   80	13	7	youcangetnoinfoFGAэлШяо	Ljava/lang/Object;
/*     */     //   43	50	5	youcangetnoinfoFFYшф90z	Ljava/lang/Object;
/*     */     //   0	93	0	youcangetnoinfoFFTв6ЖМК	Ljava/lang/Object;
/*     */     //   0	93	1	youcangetnoinfoFFU7Ж9Щш	Ljava/lang/Object;
/*     */     //   0	93	4	youcangetnoinfoFFXб2Чгэ	Ljava/lang/Object;
/*     */     //   57	36	6	youcangetnoinfoFFZэ6ЧЪХ	Ljava/lang/Object;
/*     */     //   0	93	2	youcangetnoinfoFFVАэЖПГ	Ljava/lang/Object;
/*     */     //   0	93	3	youcangetnoinfoFFWоЙЮмл	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readPing(Object youcangetnoinfoBAUXЭхЩ8г, Object youcangetnoinfoBAUYХБяов, Object youcangetnoinfoBAUZчМГёж, Object youcangetnoinfoBAVA6еЭля) throws IOException {
/*     */     // Byte code:
/*     */     //   0: iload_2
/*     */     //   1: bipush #8
/*     */     //   3: if_icmpeq -> 24
/*     */     //   6: ldc_w 'TYPE_PING length != 8: %s'
/*     */     //   9: iconst_1
/*     */     //   10: anewarray java/lang/Object
/*     */     //   13: dup
/*     */     //   14: iconst_0
/*     */     //   15: iload_2
/*     */     //   16: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   19: aastore
/*     */     //   20: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   23: athrow
/*     */     //   24: iload #4
/*     */     //   26: ifeq -> 40
/*     */     //   29: ldc_w 'TYPE_PING streamId != 0'
/*     */     //   32: iconst_0
/*     */     //   33: anewarray java/lang/Object
/*     */     //   36: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   39: athrow
/*     */     //   40: aload_0
/*     */     //   41: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   44: invokeinterface readInt : ()I
/*     */     //   49: istore #5
/*     */     //   51: aload_0
/*     */     //   52: getfield source : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSource;
/*     */     //   55: invokeinterface readInt : ()I
/*     */     //   60: istore #6
/*     */     //   62: iload_3
/*     */     //   63: iconst_1
/*     */     //   64: iand
/*     */     //   65: ifeq -> 72
/*     */     //   68: iconst_1
/*     */     //   69: goto -> 73
/*     */     //   72: iconst_0
/*     */     //   73: istore #7
/*     */     //   75: aload_1
/*     */     //   76: iload #7
/*     */     //   78: iload #5
/*     */     //   80: iload #6
/*     */     //   82: invokeinterface ping : (ZII)V
/*     */     //   87: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #307	-> 0
/*     */     //   #308	-> 24
/*     */     //   #309	-> 40
/*     */     //   #310	-> 51
/*     */     //   #311	-> 62
/*     */     //   #312	-> 75
/*     */     //   #313	-> 87
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   62	26	6	youcangetnoinfoBAVCш2ощъ	Ljava/lang/Object;
/*     */     //   0	88	4	youcangetnoinfoBAVA6еЭля	Ljava/lang/Object;
/*     */     //   0	88	0	youcangetnoinfoBAUWВ1мЧв	Ljava/lang/Object;
/*     */     //   0	88	2	youcangetnoinfoBAUYХБяов	Ljava/lang/Object;
/*     */     //   51	37	5	youcangetnoinfoBAVBщПиЪг	Ljava/lang/Object;
/*     */     //   0	88	1	youcangetnoinfoBAUXЭхЩ8г	Ljava/lang/Object;
/*     */     //   0	88	3	youcangetnoinfoBAUZчМГёж	Ljava/lang/Object;
/*     */     //   75	13	7	youcangetnoinfoBAVD0вЮжЮ	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readGoAway(Object youcangetnoinfoBLUAфЯ2нШ, Object youcangetnoinfoBLUBьБЮЁС, Object youcangetnoinfoBLUCхюЬма, Object youcangetnoinfoBLUDРцЬцН) throws IOException {
/* 317 */     if (youcangetnoinfoBLUBьБЮЁС < 8) throw Http2.ioException("TYPE_GOAWAY length < 8: %s", new Object[] { Integer.valueOf(youcangetnoinfoBLUBьБЮЁС) }); 
/* 318 */     if (youcangetnoinfoBLUDРцЬцН != null) throw Http2.ioException("TYPE_GOAWAY streamId != 0", new Object[0]); 
/* 319 */     int i = ((Http2Reader2)super).source.readInt();
/* 320 */     int j = ((Http2Reader2)super).source.readInt();
/* 321 */     int k = youcangetnoinfoBLUBьБЮЁС - 8;
/* 322 */     Object youcangetnoinfoBLUHё8вх6 = ErrorCode.fromHttp2(j);
/* 323 */     if (youcangetnoinfoBLUHё8вх6 == null) {
/* 324 */       throw Http2.ioException("TYPE_GOAWAY unexpected error code: %d", new Object[] { Integer.valueOf(j) });
/*     */     }
/* 326 */     Object youcangetnoinfoBLUIЕЬ6Шс = ByteString.EMPTY;
/* 327 */     if (k > 0) {
/* 328 */       youcangetnoinfoBLUIЕЬ6Шс = ((Http2Reader2)super).source.readByteString(k);
/*     */     }
/* 330 */     youcangetnoinfoBLUAфЯ2нШ.goAway(i, (ErrorCode)youcangetnoinfoBLUHё8вх6, (ByteString)youcangetnoinfoBLUIЕЬ6Шс);
/*     */   }
/*     */ 
/*     */   
/*     */   public void readWindowUpdate(Object youcangetnoinfoBGND3Ка2Ю, Object youcangetnoinfoBGNEЦшъя6, Object youcangetnoinfoBGNFя3ых8, Object youcangetnoinfoBGNGшЁлыг) throws IOException {
/* 335 */     if (youcangetnoinfoBGNEЦшъя6 != 4) throw Http2.ioException("TYPE_WINDOW_UPDATE length !=4: %s", new Object[] { Integer.valueOf(youcangetnoinfoBGNEЦшъя6) }); 
/* 336 */     long l = ((Http2Reader2)super).source.readInt() & 0x7FFFFFFFL;
/* 337 */     if (l == 0L) throw Http2.ioException("windowSizeIncrement was 0", new Object[] { Long.valueOf(l) }); 
/* 338 */     youcangetnoinfoBGND3Ка2Ю.windowUpdate(youcangetnoinfoBGNGшЁлыг, l);
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 342 */     ((Http2Reader2)super).source.close();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int readMedium(Object youcangetnoinfoDUMЪэуэч) throws IOException {
/* 399 */     return (youcangetnoinfoDUMЪэуэч.readByte() & 0xFF) << 16 | (youcangetnoinfoDUMЪэуэч
/* 400 */       .readByte() & 0xFF) << 8 | youcangetnoinfoDUMЪэуэч
/* 401 */       .readByte() & 0xFF;
/*     */   }
/*     */   
/*     */   public static int lengthWithoutPadding(Object youcangetnoinfoDCLNДГЪыж, Object youcangetnoinfoDCLO0ИзН3, Object youcangetnoinfoDCLP7кяНо) throws IOException {
/*     */     // Byte code:
/*     */     //   0: iload_1
/*     */     //   1: bipush #8
/*     */     //   3: iand
/*     */     //   4: ifeq -> 10
/*     */     //   7: iinc #0, -1
/*     */     //   10: iload_2
/*     */     //   11: iload_0
/*     */     //   12: if_icmple -> 40
/*     */     //   15: ldc_w 'PROTOCOL_ERROR padding %s > remaining length %s'
/*     */     //   18: iconst_2
/*     */     //   19: anewarray java/lang/Object
/*     */     //   22: dup
/*     */     //   23: iconst_0
/*     */     //   24: iload_2
/*     */     //   25: invokestatic valueOf : (S)Ljava/lang/Short;
/*     */     //   28: aastore
/*     */     //   29: dup
/*     */     //   30: iconst_1
/*     */     //   31: iload_0
/*     */     //   32: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   35: aastore
/*     */     //   36: invokestatic ioException : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/io/IOException;
/*     */     //   39: athrow
/*     */     //   40: iload_0
/*     */     //   41: iload_2
/*     */     //   42: isub
/*     */     //   43: i2s
/*     */     //   44: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #406	-> 0
/*     */     //   #407	-> 10
/*     */     //   #408	-> 15
/*     */     //   #410	-> 40
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	45	1	youcangetnoinfoDCLO0ИзН3	Ljava/lang/Object;
/*     */     //   0	45	0	youcangetnoinfoDCLNДГЪыж	Ljava/lang/Object;
/*     */     //   0	45	2	youcangetnoinfoDCLP7кяНо	Ljava/lang/Object;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http2Reader2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */