/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import fun.spamis.spammer.SpamIsFun;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.border.EmptyBorder;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.TableModel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxysGUI1
/*     */   extends JFrame
/*     */ {
/*     */   public static final long serialVersionUID = 1L;
/*     */   public JPanel contentPane;
/*     */   
/*     */   public ProxysGUI1() {
/*  35 */     setResizable(false);
/*  36 */     setTitle("Proxy manager");
/*  37 */     setBounds(100, 100, 406, 411);
/*  38 */     setLocationRelativeTo(null);
/*  39 */     ((ProxysGUI1)super).contentPane = new JPanel();
/*  40 */     ((ProxysGUI1)super).contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
/*  41 */     setContentPane(((ProxysGUI1)super).contentPane);
/*  42 */     ((ProxysGUI1)super).contentPane.setLayout((LayoutManager)null);
/*     */     
/*  44 */     Object youcangetnoinfoDBSMиэ8Чо = new String[0];
/*  45 */     Object youcangetnoinfoDBSNП46жЦ = new Object[0][];
/*  46 */     Object youcangetnoinfoDBSOАуАбК = new ProxysGUI((ProxysGUI1)this, (Object[][])youcangetnoinfoDBSNП46жЦ, (Object[])youcangetnoinfoDBSMиэ8Чо);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  53 */     youcangetnoinfoDBSOАуАбК.setFont(new Font("Dialog", 0, 11));
/*  54 */     Object youcangetnoinfoDBSP4А419 = new DefaultTableModel((Object[])new String[] { "#", "Proxy" }, 0);
/*     */     
/*  56 */     youcangetnoinfoDBSOАуАбК.setModel((TableModel)youcangetnoinfoDBSP4А419);
/*  57 */     youcangetnoinfoDBSOАуАбК.getTableHeader().setReorderingAllowed(false);
/*  58 */     youcangetnoinfoDBSOАуАбК.getColumnModel().getColumn(1).setPreferredWidth(400);
/*  59 */     youcangetnoinfoDBSOАуАбК.setAutoResizeMode(3);
/*     */     
/*  61 */     Object youcangetnoinfoDBSQв7анЦ = new JScrollPane((Component)youcangetnoinfoDBSOАуАбК, 22, 30);
/*     */     
/*  63 */     youcangetnoinfoDBSQв7анЦ.setBounds(0, 86, 406, 298);
/*  64 */     ((ProxysGUI1)super).contentPane.add((Component)youcangetnoinfoDBSQв7анЦ);
/*     */     
/*  66 */     Object youcangetnoinfoDBSRш5УОз = new JButton("IMPORT");
/*  67 */     youcangetnoinfoDBSRш5УОз.setIcon(new ImageIcon(getClass().getResource("/ui/add.png")));
/*  68 */     youcangetnoinfoDBSRш5УОз.setBounds(12, 12, 117, 25);
/*  69 */     youcangetnoinfoDBSRш5УОз.addActionListener(new ProxysGUI2((ProxysGUI1)this, (DefaultTableModel)youcangetnoinfoDBSP4А419));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  85 */     ((ProxysGUI1)super).contentPane.add((Component)youcangetnoinfoDBSRш5УОз);
/*     */     
/*  87 */     Object youcangetnoinfoDBSS9Ё6Ёи = new JButton("REMOVE ALL");
/*  88 */     youcangetnoinfoDBSS9Ё6Ёи.setIcon(new ImageIcon(getClass().getResource("/ui/remove.png")));
/*  89 */     youcangetnoinfoDBSS9Ё6Ёи.setBounds(141, 12, 126, 25);
/*  90 */     youcangetnoinfoDBSS9Ё6Ёи.addActionListener(new ProxysGUI3((ProxysGUI1)this, (DefaultTableModel)youcangetnoinfoDBSP4А419));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     ((ProxysGUI1)super).contentPane.add((Component)youcangetnoinfoDBSS9Ё6Ёи);
/*     */     
/* 101 */     Object youcangetnoinfoDBSTЭ0щПй = new JLabel("* You need https proxys.");
/* 102 */     youcangetnoinfoDBSTЭ0щПй.setFont(new Font("Dialog", 1, 10));
/* 103 */     youcangetnoinfoDBSTЭ0щПй.setBounds(12, 50, 375, 15);
/* 104 */     ((ProxysGUI1)super).contentPane.add((Component)youcangetnoinfoDBSTЭ0щПй);
/*     */     
/* 106 */     Object youcangetnoinfoDBSUЙпzчЕ = new JLabel("Don't forget to check the proxys with a proxy checker,");
/* 107 */     youcangetnoinfoDBSUЙпzчЕ.setFont(new Font("Dialog", 1, 10));
/* 108 */     youcangetnoinfoDBSUЙпzчЕ.setBounds(12, 65, 375, 15);
/* 109 */     ((ProxysGUI1)super).contentPane.add((Component)youcangetnoinfoDBSUЙпzчЕ);
/*     */ 
/*     */ 
/*     */     
/* 113 */     Object youcangetnoinfoDBSVАБ6Ме = SpamIsFun.proxys.entrySet();
/* 114 */     Object youcangetnoinfoDBSWсЙЛШ8 = youcangetnoinfoDBSVАБ6Ме.iterator();
/* 115 */     while (youcangetnoinfoDBSWсЙЛШ8.hasNext()) {
/* 116 */       Object youcangetnoinfoDBSKъВНzч = youcangetnoinfoDBSWсЙЛШ8.next();
/* 117 */       youcangetnoinfoDBSP4А419.addRow(new Object[] { youcangetnoinfoDBSKъВНzч.getKey(), youcangetnoinfoDBSKъВНzч.getValue() });
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ProxysGUI1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */