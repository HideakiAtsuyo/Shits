/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Http1Codec6
/*     */   extends Http1Codec4
/*     */ {
/*     */   public final Http1Codec7 this$0;
/*     */   public static final long NO_CHUNK_YET = -1L;
/*     */   public boolean hasMoreChunks;
/*     */   public final HttpUrl1 url;
/*     */   public long bytesRemainingInChunk;
/*     */   
/*     */   public Http1Codec6(Object youcangetnoinfoBRYCоЁМНе) {
/* 450 */     super(paramHttp1Codec7, null); ((Http1Codec6)super).bytesRemainingInChunk = -1L; ((Http1Codec6)super).hasMoreChunks = true;
/* 451 */     ((Http1Codec6)super).url = (HttpUrl1)youcangetnoinfoBRYCоЁМНе;
/*     */   }
/*     */   
/*     */   public long read(Object youcangetnoinfoCCFЭОц1г, Object youcangetnoinfoCCG4рzйЖ) throws IOException {
/* 455 */     if (youcangetnoinfoCCG4рzйЖ < 0L) throw new IllegalArgumentException("byteCount < 0: " + youcangetnoinfoCCG4рzйЖ); 
/* 456 */     if (((Http1Codec6)this).closed) throw new IllegalStateException("closed"); 
/* 457 */     if (!((Http1Codec6)super).hasMoreChunks) return -1L;
/*     */     
/* 459 */     if (((Http1Codec6)super).bytesRemainingInChunk == 0L || ((Http1Codec6)super).bytesRemainingInChunk == -1L) {
/* 460 */       super.readChunkSize();
/* 461 */       if (!((Http1Codec6)super).hasMoreChunks) return -1L;
/*     */     
/*     */     } 
/* 464 */     long l = super.read((Buffer2)youcangetnoinfoCCFЭОц1г, Math.min(youcangetnoinfoCCG4рzйЖ, ((Http1Codec6)super).bytesRemainingInChunk));
/* 465 */     if (l == -1L) {
/* 466 */       Object youcangetnoinfoCCDЭЁЮви = new ProtocolException("unexpected end of stream");
/* 467 */       endOfInput(false, (IOException)youcangetnoinfoCCDЭЁЮви);
/* 468 */       throw youcangetnoinfoCCDЭЁЮви;
/*     */     } 
/* 470 */     ((Http1Codec6)super).bytesRemainingInChunk -= l;
/* 471 */     return l;
/*     */   }
/*     */ 
/*     */   
/*     */   public void readChunkSize() throws IOException {
/* 476 */     if (((Http1Codec6)super).bytesRemainingInChunk != -1L) {
/* 477 */       Http1Codec7.this.source.readUtf8LineStrict();
/*     */     }
/*     */     try {
/* 480 */       ((Http1Codec6)super).bytesRemainingInChunk = Http1Codec7.this.source.readHexadecimalUnsignedLong();
/* 481 */       Object youcangetnoinfoCDJGЙ3zяд = Http1Codec7.this.source.readUtf8LineStrict().trim();
/* 482 */       if (((Http1Codec6)super).bytesRemainingInChunk < 0L || (!youcangetnoinfoCDJGЙ3zяд.isEmpty() && !youcangetnoinfoCDJGЙ3zяд.startsWith(";"))) {
/* 483 */         throw new ProtocolException("expected chunk size and optional extensions but was \"" + super.bytesRemainingInChunk + youcangetnoinfoCDJGЙ3zяд + "\"");
/*     */       }
/*     */     }
/* 486 */     catch (NumberFormatException youcangetnoinfoCDJHКСибШ) {
/* 487 */       throw new ProtocolException(youcangetnoinfoCDJHКСибШ.getMessage());
/*     */     } 
/* 489 */     if (((Http1Codec6)super).bytesRemainingInChunk == 0L) {
/* 490 */       ((Http1Codec6)super).hasMoreChunks = false;
/* 491 */       Http1Codec7.access$102(Http1Codec7.this, Http1Codec7.this.readHeaders());
/* 492 */       HttpHeaders.receiveHeaders(Http1Codec7.this.client.cookieJar(), ((Http1Codec6)super).url, Http1Codec7.access$100(Http1Codec7.this));
/* 493 */       endOfInput(true, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 498 */     if (((Http1Codec6)this).closed)
/* 499 */       return;  if (((Http1Codec6)super).hasMoreChunks && !Util1.discard((Source)this, 100, TimeUnit.MILLISECONDS)) {
/* 500 */       endOfInput(false, null);
/*     */     }
/* 502 */     ((Http1Codec6)this).closed = true;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http1Codec6.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */