/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class CacheStrategy
/*     */ {
/*     */   @Nullable
/*     */   public final Response cacheResponse;
/*     */   @Nullable
/*     */   public final Request networkRequest;
/*     */   
/*     */   public CacheStrategy(Object youcangetnoinfoDZRH9мzЁт, Object youcangetnoinfoDZRIзЦдЪz) {
/*  57 */     this();
/*  58 */     ((CacheStrategy)super).networkRequest = (Request)youcangetnoinfoDZRH9мzЁт;
/*  59 */     ((CacheStrategy)super).cacheResponse = (Response)youcangetnoinfoDZRIзЦдЪz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isCacheable(Object youcangetnoinfoDODOёОБКУ, Object youcangetnoinfoDODPГюйТд) {
/*  66 */     switch (youcangetnoinfoDODOёОБКУ.code()) {
/*     */       case 200:
/*     */       case 203:
/*     */       case 204:
/*     */       case 300:
/*     */       case 301:
/*     */       case 308:
/*     */       case 404:
/*     */       case 405:
/*     */       case 410:
/*     */       case 414:
/*     */       case 501:
/*     */         break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 302:
/*     */       case 307:
/*  86 */         if (youcangetnoinfoDODOёОБКУ.header("Expires") != null || youcangetnoinfoDODOёОБКУ
/*  87 */           .cacheControl().maxAgeSeconds() != -1 || youcangetnoinfoDODOёОБКУ
/*  88 */           .cacheControl().isPublic() || youcangetnoinfoDODOёОБКУ
/*  89 */           .cacheControl().isPrivate()) {
/*     */           break;
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       default:
/*  96 */         return false;
/*     */     } 
/*     */ 
/*     */     
/* 100 */     return (!youcangetnoinfoDODOёОБКУ.cacheControl().noStore() && !youcangetnoinfoDODPГюйТд.cacheControl().noStore());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\CacheStrategy.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */