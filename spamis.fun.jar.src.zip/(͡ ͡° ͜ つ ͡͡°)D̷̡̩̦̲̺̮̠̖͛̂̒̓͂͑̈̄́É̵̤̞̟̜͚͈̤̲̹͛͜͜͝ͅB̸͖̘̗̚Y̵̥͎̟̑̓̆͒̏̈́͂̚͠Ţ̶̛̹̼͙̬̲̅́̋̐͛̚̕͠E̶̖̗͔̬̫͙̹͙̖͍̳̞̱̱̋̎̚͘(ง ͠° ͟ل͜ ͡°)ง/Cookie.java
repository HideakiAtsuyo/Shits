/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Cookie
/*     */ {
/*     */   @Nullable
/*     */   public String value;
/*     */   public boolean persistent;
/*     */   public String path;
/*     */   @Nullable
/*     */   public String domain;
/*     */   public boolean httpOnly;
/*     */   public boolean secure;
/*     */   public long expiresAt;
/*     */   @Nullable
/*     */   public String name;
/*     */   public boolean hostOnly;
/*     */   
/*     */   public Cookie() {
/* 460 */     this();
/*     */ 
/*     */     
/* 463 */     ((Cookie)super).expiresAt = 253402300799999L;
/*     */     
/* 465 */     ((Cookie)super).path = "/";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie name(Object youcangetnoinfoDLXBШйсцг) {
/* 472 */     if (youcangetnoinfoDLXBШйсцг == null) throw new NullPointerException("name == null"); 
/* 473 */     if (!youcangetnoinfoDLXBШйсцг.trim().equals(youcangetnoinfoDLXBШйсцг)) throw new IllegalArgumentException("name is not trimmed"); 
/* 474 */     ((Cookie)super).name = (String)youcangetnoinfoDLXBШйсцг;
/* 475 */     return (Cookie)this;
/*     */   }
/*     */   
/*     */   public Cookie value(Object youcangetnoinfoFLH6фЬ2щ) {
/* 479 */     if (youcangetnoinfoFLH6фЬ2щ == null) throw new NullPointerException("value == null"); 
/* 480 */     if (!youcangetnoinfoFLH6фЬ2щ.trim().equals(youcangetnoinfoFLH6фЬ2щ)) throw new IllegalArgumentException("value is not trimmed"); 
/* 481 */     ((Cookie)super).value = (String)youcangetnoinfoFLH6фЬ2щ;
/* 482 */     return (Cookie)this;
/*     */   }
/*     */   public Cookie expiresAt(Object youcangetnoinfoDYIVРчРшЧ) {
/*     */     long l;
/* 486 */     if (youcangetnoinfoDYIVРчРшЧ <= 0L) l = Long.MIN_VALUE; 
/* 487 */     if (l > 253402300799999L) l = 253402300799999L; 
/* 488 */     ((Cookie)super).expiresAt = l;
/* 489 */     ((Cookie)super).persistent = true;
/* 490 */     return (Cookie)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie domain(Object youcangetnoinfoEMYIzъпум) {
/* 498 */     return super.domain((String)youcangetnoinfoEMYIzъпум, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Cookie hostOnlyDomain(Object youcangetnoinfoMCAб3ВШш) {
/* 506 */     return super.domain((String)youcangetnoinfoMCAб3ВШш, true);
/*     */   }
/*     */   
/*     */   public Cookie domain(Object youcangetnoinfoALJBчЛОБЧ, Object youcangetnoinfoALJCККтЁЙ) {
/* 510 */     if (youcangetnoinfoALJBчЛОБЧ == null) throw new NullPointerException("domain == null"); 
/* 511 */     Object youcangetnoinfoALJDйД94Н = Util1.canonicalizeHost((String)youcangetnoinfoALJBчЛОБЧ);
/* 512 */     if (youcangetnoinfoALJDйД94Н == null) {
/* 513 */       throw new IllegalArgumentException("unexpected domain: " + youcangetnoinfoALJBчЛОБЧ);
/*     */     }
/* 515 */     ((Cookie)super).domain = (String)youcangetnoinfoALJDйД94Н;
/* 516 */     ((Cookie)super).hostOnly = youcangetnoinfoALJCККтЁЙ;
/* 517 */     return (Cookie)this;
/*     */   }
/*     */   
/*     */   public Cookie path(Object youcangetnoinfoBCGJУЦИйМ) {
/* 521 */     if (!youcangetnoinfoBCGJУЦИйМ.startsWith("/")) throw new IllegalArgumentException("path must start with '/'"); 
/* 522 */     ((Cookie)super).path = (String)youcangetnoinfoBCGJУЦИйМ;
/* 523 */     return (Cookie)this;
/*     */   }
/*     */   
/*     */   public Cookie secure() {
/* 527 */     ((Cookie)super).secure = true;
/* 528 */     return (Cookie)this;
/*     */   }
/*     */   
/*     */   public Cookie httpOnly() {
/* 532 */     ((Cookie)super).httpOnly = true;
/* 533 */     return (Cookie)this;
/*     */   }
/*     */   
/*     */   public Cookie1 build() {
/* 537 */     return new Cookie1((Cookie)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Cookie.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */