/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.util.zip.DataFormatException;
/*     */ import java.util.zip.Inflater;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class InflaterSource
/*     */   implements Source
/*     */ {
/*     */   public int bufferBytesHeldByInflater;
/*     */   public final BufferedSource source;
/*     */   public final Inflater inflater;
/*     */   public boolean closed;
/*     */   
/*     */   public InflaterSource(Object youcangetnoinfoAMSMФъеоы, Object youcangetnoinfoAMSNГэФту) {
/*  40 */     super(Okio1.buffer((Source)youcangetnoinfoAMSMФъеоы), (Inflater)youcangetnoinfoAMSNГэФту);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InflaterSource(Object youcangetnoinfoCYWWшжЗ1П, Object youcangetnoinfoCYWXЦдАць) {
/*  48 */     this();
/*  49 */     if (youcangetnoinfoCYWWшжЗ1П == null) throw new IllegalArgumentException("source == null"); 
/*  50 */     if (youcangetnoinfoCYWXЦдАць == null) throw new IllegalArgumentException("inflater == null"); 
/*  51 */     ((InflaterSource)super).source = (BufferedSource)youcangetnoinfoCYWWшжЗ1П;
/*  52 */     ((InflaterSource)super).inflater = (Inflater)youcangetnoinfoCYWXЦдАць;
/*     */   }
/*     */ 
/*     */   
/*     */   public long read(Object youcangetnoinfoCHGNТ5м2ф, Object youcangetnoinfoCHGOКЭМшЩ) throws IOException {
/*  57 */     if (youcangetnoinfoCHGOКЭМшЩ < 0L) throw new IllegalArgumentException("byteCount < 0: " + youcangetnoinfoCHGOКЭМшЩ); 
/*  58 */     if (((InflaterSource)super).closed) throw new IllegalStateException("closed"); 
/*  59 */     if (youcangetnoinfoCHGOКЭМшЩ == 0L) return 0L;
/*     */     
/*     */     while (true) {
/*  62 */       boolean bool = super.refill();
/*     */ 
/*     */       
/*     */       try {
/*  66 */         Object youcangetnoinfoCHGHЁЬмШД = youcangetnoinfoCHGNТ5м2ф.writableSegment(1);
/*  67 */         int i = (int)Math.min(youcangetnoinfoCHGOКЭМшЩ, (8192 - ((Segment)youcangetnoinfoCHGHЁЬмШД).limit));
/*  68 */         int j = ((InflaterSource)super).inflater.inflate(((Segment)youcangetnoinfoCHGHЁЬмШД).data, ((Segment)youcangetnoinfoCHGHЁЬмШД).limit, i);
/*  69 */         if (j > 0) {
/*  70 */           ((Segment)youcangetnoinfoCHGHЁЬмШД).limit += j;
/*  71 */           ((Buffer2)youcangetnoinfoCHGNТ5м2ф).size += j;
/*  72 */           return j;
/*     */         } 
/*  74 */         if (((InflaterSource)super).inflater.finished() || ((InflaterSource)super).inflater.needsDictionary()) {
/*  75 */           super.releaseInflatedBytes();
/*  76 */           if (((Segment)youcangetnoinfoCHGHЁЬмШД).pos == ((Segment)youcangetnoinfoCHGHЁЬмШД).limit) {
/*     */             
/*  78 */             ((Buffer2)youcangetnoinfoCHGNТ5м2ф).head = youcangetnoinfoCHGHЁЬмШД.pop();
/*  79 */             SegmentPool.recycle((Segment)youcangetnoinfoCHGHЁЬмШД);
/*     */           } 
/*  81 */           return -1L;
/*     */         } 
/*  83 */         if (bool) throw new EOFException("source exhausted prematurely"); 
/*  84 */       } catch (DataFormatException youcangetnoinfoCHGKЯ7Язк) {
/*  85 */         throw new IOException(youcangetnoinfoCHGKЯ7Язк);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final boolean refill() throws IOException {
/*  96 */     if (!((InflaterSource)super).inflater.needsInput()) return false;
/*     */     
/*  98 */     super.releaseInflatedBytes();
/*  99 */     if (((InflaterSource)super).inflater.getRemaining() != 0) throw new IllegalStateException("?");
/*     */ 
/*     */     
/* 102 */     if (((InflaterSource)super).source.exhausted()) return true;
/*     */ 
/*     */     
/* 105 */     Object youcangetnoinfoBBEF8СвдК = (((InflaterSource)super).source.buffer()).head;
/* 106 */     ((InflaterSource)super).bufferBytesHeldByInflater = ((Segment)youcangetnoinfoBBEF8СвдК).limit - ((Segment)youcangetnoinfoBBEF8СвдК).pos;
/* 107 */     ((InflaterSource)super).inflater.setInput(((Segment)youcangetnoinfoBBEF8СвдК).data, ((Segment)youcangetnoinfoBBEF8СвдК).pos, ((InflaterSource)super).bufferBytesHeldByInflater);
/* 108 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void releaseInflatedBytes() throws IOException {
/* 113 */     if (((InflaterSource)super).bufferBytesHeldByInflater == 0)
/* 114 */       return;  int i = ((InflaterSource)super).bufferBytesHeldByInflater - ((InflaterSource)super).inflater.getRemaining();
/* 115 */     ((InflaterSource)super).bufferBytesHeldByInflater -= i;
/* 116 */     ((InflaterSource)super).source.skip(i);
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 120 */     return ((InflaterSource)super).source.timeout();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 124 */     if (((InflaterSource)super).closed)
/* 125 */       return;  ((InflaterSource)super).inflater.end();
/* 126 */     ((InflaterSource)super).closed = true;
/* 127 */     ((InflaterSource)super).source.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\InflaterSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */