/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Dispatcher
/*     */ {
/*     */   public int maxRequests;
/*     */   @Nullable
/*     */   public ExecutorService executorService;
/*     */   public static final boolean $assertionsDisabled;
/*     */   public final Deque runningAsyncCalls;
/*     */   @Nullable
/*     */   public Runnable idleCallback;
/*     */   public final Deque runningSyncCalls;
/*     */   public int maxRequestsPerHost;
/*     */   public final Deque readyAsyncCalls;
/*     */   
/*     */   public Dispatcher(Object youcangetnoinfoBFCNлйБаК) {
/*  56 */     this(); ((Dispatcher)super).maxRequests = 64; ((Dispatcher)super).maxRequestsPerHost = 5; ((Dispatcher)super).readyAsyncCalls = new ArrayDeque(); ((Dispatcher)super).runningAsyncCalls = new ArrayDeque(); ((Dispatcher)super).runningSyncCalls = new ArrayDeque();
/*  57 */     ((Dispatcher)super).executorService = (ExecutorService)youcangetnoinfoBFCNлйБаК;
/*     */   }
/*     */   
/*  60 */   public Dispatcher() { this(); ((Dispatcher)super).maxRequests = 64;
/*     */     ((Dispatcher)super).maxRequestsPerHost = 5;
/*     */     ((Dispatcher)super).readyAsyncCalls = new ArrayDeque();
/*     */     ((Dispatcher)super).runningAsyncCalls = new ArrayDeque();
/*  64 */     ((Dispatcher)super).runningSyncCalls = new ArrayDeque(); } public synchronized ExecutorService executorService() { if (((Dispatcher)super).executorService == null) {
/*  65 */       ((Dispatcher)super)
/*  66 */         .executorService = new ThreadPoolExecutor(0, 2147483647, 60L, TimeUnit.SECONDS, new SynchronousQueue<>(), Util1.threadFactory("OkHttp Dispatcher", false));
/*     */     }
/*  68 */     return ((Dispatcher)super).executorService; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxRequests(Object youcangetnoinfoEPDJЕъУб0) {
/*  79 */     if (youcangetnoinfoEPDJЕъУб0 < true) {
/*  80 */       throw new IllegalArgumentException("max < 1: " + youcangetnoinfoEPDJЕъУб0);
/*     */     }
/*  82 */     synchronized (this) {
/*  83 */       ((Dispatcher)super).maxRequests = youcangetnoinfoEPDJЕъУб0;
/*     */     } 
/*  85 */     super.promoteAndExecute();
/*     */   }
/*     */   
/*     */   public synchronized int getMaxRequests() {
/*  89 */     return ((Dispatcher)super).maxRequests;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMaxRequestsPerHost(Object youcangetnoinfoECPMЬЁэТФ) {
/* 104 */     if (youcangetnoinfoECPMЬЁэТФ < true) {
/* 105 */       throw new IllegalArgumentException("max < 1: " + youcangetnoinfoECPMЬЁэТФ);
/*     */     }
/* 107 */     synchronized (this) {
/* 108 */       ((Dispatcher)super).maxRequestsPerHost = youcangetnoinfoECPMЬЁэТФ;
/*     */     } 
/* 110 */     super.promoteAndExecute();
/*     */   }
/*     */   
/*     */   public synchronized int getMaxRequestsPerHost() {
/* 114 */     return ((Dispatcher)super).maxRequestsPerHost;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setIdleCallback(@Nullable Object youcangetnoinfoALZOёвъзП) {
/* 130 */     ((Dispatcher)super).idleCallback = (Runnable)youcangetnoinfoALZOёвъзП;
/*     */   }
/*     */   
/*     */   public void enqueue(Object youcangetnoinfoEFDTиКнЧТ) {
/* 134 */     synchronized (this) {
/* 135 */       ((Dispatcher)super).readyAsyncCalls.add(youcangetnoinfoEFDTиКнЧТ);
/*     */ 
/*     */ 
/*     */       
/* 139 */       if (!(youcangetnoinfoEFDTиКнЧТ.get()).forWebSocket) {
/* 140 */         Object youcangetnoinfoEFDRЮвыЬш = super.findExistingCallWithHost(youcangetnoinfoEFDTиКнЧТ.host());
/* 141 */         if (youcangetnoinfoEFDRЮвыЬш != null) youcangetnoinfoEFDTиКнЧТ.reuseCallsPerHostFrom((RealCall)youcangetnoinfoEFDRЮвыЬш); 
/*     */       } 
/*     */     } 
/* 144 */     super.promoteAndExecute();
/*     */   }
/*     */   @Nullable
/*     */   public RealCall findExistingCallWithHost(Object youcangetnoinfoECDF0ЦЯ5Щ) {
/* 148 */     for (Object youcangetnoinfoECDCэ5гдю : ((Dispatcher)super).runningAsyncCalls) {
/* 149 */       if (youcangetnoinfoECDCэ5гдю.host().equals(youcangetnoinfoECDF0ЦЯ5Щ)) return (RealCall)youcangetnoinfoECDCэ5гдю; 
/*     */     } 
/* 151 */     for (Object youcangetnoinfoECDDяzф1м : ((Dispatcher)super).readyAsyncCalls) {
/* 152 */       if (youcangetnoinfoECDDяzф1м.host().equals(youcangetnoinfoECDF0ЦЯ5Щ)) return (RealCall)youcangetnoinfoECDDяzф1м; 
/*     */     } 
/* 154 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void cancelAll() {
/* 162 */     for (Object youcangetnoinfoDYKVтЪэ4о : ((Dispatcher)super).readyAsyncCalls) {
/* 163 */       youcangetnoinfoDYKVтЪэ4о.get().cancel();
/*     */     }
/*     */     
/* 166 */     for (Object youcangetnoinfoDYKWЧ3ЪЁz : ((Dispatcher)super).runningAsyncCalls) {
/* 167 */       youcangetnoinfoDYKWЧ3ЪЁz.get().cancel();
/*     */     }
/*     */     
/* 170 */     for (Object youcangetnoinfoDYKXЙЙС4о : ((Dispatcher)super).runningSyncCalls) {
/* 171 */       youcangetnoinfoDYKXЙЙС4о.cancel();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean promoteAndExecute() {
/*     */     boolean bool;
/* 183 */     assert !Thread.holdsLock(this);
/*     */     
/* 185 */     Object youcangetnoinfoZPEютЩКТ = new ArrayList();
/*     */     
/* 187 */     synchronized (this) {
/* 188 */       for (Object youcangetnoinfoZOYс9йЫ5 = ((Dispatcher)super).readyAsyncCalls.iterator(); youcangetnoinfoZOYс9йЫ5.hasNext(); ) {
/* 189 */         Object youcangetnoinfoZOXАЕиУР = youcangetnoinfoZOYс9йЫ5.next();
/*     */         
/* 191 */         if (((Dispatcher)super).runningAsyncCalls.size() >= ((Dispatcher)super).maxRequests)
/* 192 */           break;  if (youcangetnoinfoZOXАЕиУР.callsPerHost().get() >= ((Dispatcher)super).maxRequestsPerHost)
/*     */           continue; 
/* 194 */         youcangetnoinfoZOYс9йЫ5.remove();
/* 195 */         youcangetnoinfoZOXАЕиУР.callsPerHost().incrementAndGet();
/* 196 */         youcangetnoinfoZPEютЩКТ.add(youcangetnoinfoZOXАЕиУР);
/* 197 */         ((Dispatcher)super).runningAsyncCalls.add(youcangetnoinfoZOXАЕиУР);
/*     */       } 
/* 199 */       bool = (super.runningCallsCount() > 0) ? true : false;
/*     */     }  byte b;
/*     */     int i;
/* 202 */     for (b = 0, i = youcangetnoinfoZPEютЩКТ.size(); b < i; b++) {
/* 203 */       Object youcangetnoinfoZPAрzКгч = youcangetnoinfoZPEютЩКТ.get(b);
/* 204 */       youcangetnoinfoZPAрzКгч.executeOn(super.executorService());
/*     */     } 
/*     */     
/* 207 */     return bool;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void executed(Object youcangetnoinfoACOLОпААж) {
/* 212 */     ((Dispatcher)super).runningSyncCalls.add(youcangetnoinfoACOLОпААж);
/*     */   }
/*     */ 
/*     */   
/*     */   public void finished(Object youcangetnoinfoKVIгЁвёё) {
/* 217 */     youcangetnoinfoKVIгЁвёё.callsPerHost().decrementAndGet();
/* 218 */     super.finished(((Dispatcher)super).runningAsyncCalls, youcangetnoinfoKVIгЁвёё);
/*     */   }
/*     */ 
/*     */   
/*     */   public void finished(Object youcangetnoinfoDYUW8ЙИсЖ) {
/* 223 */     super.finished(((Dispatcher)super).runningSyncCalls, youcangetnoinfoDYUW8ЙИсЖ);
/*     */   }
/*     */   
/*     */   public <T> void finished(Object youcangetnoinfoEFIN8мъЛд, Object youcangetnoinfoEFIOигЧчз) {
/*     */     Object youcangetnoinfoEFIL1НУ1б;
/* 228 */     synchronized (this) {
/* 229 */       if (!youcangetnoinfoEFIN8мъЛд.remove(youcangetnoinfoEFIOигЧчз)) throw new AssertionError("Call wasn't in-flight!"); 
/* 230 */       youcangetnoinfoEFIL1НУ1б = ((Dispatcher)super).idleCallback;
/*     */     } 
/*     */     
/* 233 */     boolean bool = super.promoteAndExecute();
/*     */     
/* 235 */     if (!bool && youcangetnoinfoEFIL1НУ1б != null) {
/* 236 */       youcangetnoinfoEFIL1НУ1б.run();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized List queuedCalls() {
/* 242 */     Object youcangetnoinfoBCSZъ3УЧм = new ArrayList();
/* 243 */     for (Object youcangetnoinfoBCSXС8етг : ((Dispatcher)super).readyAsyncCalls) {
/* 244 */       youcangetnoinfoBCSZъ3УЧм.add(youcangetnoinfoBCSXС8етг.get());
/*     */     }
/* 246 */     return Collections.unmodifiableList((List<?>)youcangetnoinfoBCSZъ3УЧм);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized List runningCalls() {
/* 251 */     Object youcangetnoinfoCVZQфЪаЧ8 = new ArrayList();
/* 252 */     youcangetnoinfoCVZQфЪаЧ8.addAll(((Dispatcher)super).runningSyncCalls);
/* 253 */     for (Object youcangetnoinfoCVZOкк3Шз : ((Dispatcher)super).runningAsyncCalls) {
/* 254 */       youcangetnoinfoCVZQфЪаЧ8.add(youcangetnoinfoCVZOкк3Шз.get());
/*     */     }
/* 256 */     return Collections.unmodifiableList((List<?>)youcangetnoinfoCVZQфЪаЧ8);
/*     */   }
/*     */   
/*     */   public synchronized int queuedCallsCount() {
/* 260 */     return ((Dispatcher)super).readyAsyncCalls.size();
/*     */   }
/*     */   
/*     */   public synchronized int runningCallsCount() {
/* 264 */     return ((Dispatcher)super).runningAsyncCalls.size() + ((Dispatcher)super).runningSyncCalls.size();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Dispatcher.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */