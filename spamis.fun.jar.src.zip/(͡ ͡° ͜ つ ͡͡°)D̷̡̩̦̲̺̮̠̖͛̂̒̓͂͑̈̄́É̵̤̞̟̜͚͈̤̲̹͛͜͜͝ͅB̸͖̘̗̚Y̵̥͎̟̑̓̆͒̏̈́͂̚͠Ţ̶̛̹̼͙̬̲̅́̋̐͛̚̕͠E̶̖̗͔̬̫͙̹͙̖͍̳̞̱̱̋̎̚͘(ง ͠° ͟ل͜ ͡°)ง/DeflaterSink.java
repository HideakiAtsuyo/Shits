/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.zip.Deflater;
/*     */ import org.codehaus.mojo.animal_sniffer.IgnoreJRERequirement;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DeflaterSink
/*     */   implements Sink
/*     */ {
/*     */   public final Deflater deflater;
/*     */   public boolean closed;
/*     */   public final BufferedSink sink;
/*     */   
/*     */   public DeflaterSink(Object youcangetnoinfoEGOWьБп3ю, Object youcangetnoinfoEGOXьюЬЗЦ) {
/*  44 */     super(Okio1.buffer((Sink)youcangetnoinfoEGOWьБп3ю), (Deflater)youcangetnoinfoEGOXьюЬЗЦ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DeflaterSink(Object youcangetnoinfoDFTD5РЦтт, Object youcangetnoinfoDFTEаЧЭдн) {
/*  52 */     this();
/*  53 */     if (youcangetnoinfoDFTD5РЦтт == null) throw new IllegalArgumentException("source == null"); 
/*  54 */     if (youcangetnoinfoDFTEаЧЭдн == null) throw new IllegalArgumentException("inflater == null"); 
/*  55 */     ((DeflaterSink)super).sink = (BufferedSink)youcangetnoinfoDFTD5РЦтт;
/*  56 */     ((DeflaterSink)super).deflater = (Deflater)youcangetnoinfoDFTEаЧЭдн;
/*     */   }
/*     */   
/*     */   public void write(Object youcangetnoinfoBNNJзХнщЕ, Object youcangetnoinfoBNNKуюйЯе) throws IOException {
/*  60 */     Util.checkOffsetAndCount(((Buffer2)youcangetnoinfoBNNJзХнщЕ).size, 0L, youcangetnoinfoBNNKуюйЯе);
/*  61 */     while (youcangetnoinfoBNNKуюйЯе > 0L) {
/*     */       
/*  63 */       Object youcangetnoinfoBNNGЁ0zсщ = ((Buffer2)youcangetnoinfoBNNJзХнщЕ).head;
/*  64 */       int i = (int)Math.min(youcangetnoinfoBNNKуюйЯе, (((Segment)youcangetnoinfoBNNGЁ0zсщ).limit - ((Segment)youcangetnoinfoBNNGЁ0zсщ).pos));
/*  65 */       ((DeflaterSink)super).deflater.setInput(((Segment)youcangetnoinfoBNNGЁ0zсщ).data, ((Segment)youcangetnoinfoBNNGЁ0zсщ).pos, i);
/*     */ 
/*     */       
/*  68 */       super.deflate(false);
/*     */ 
/*     */       
/*  71 */       ((Buffer2)youcangetnoinfoBNNJзХнщЕ).size -= i;
/*  72 */       ((Segment)youcangetnoinfoBNNGЁ0zсщ).pos += i;
/*  73 */       if (((Segment)youcangetnoinfoBNNGЁ0zсщ).pos == ((Segment)youcangetnoinfoBNNGЁ0zсщ).limit) {
/*  74 */         ((Buffer2)youcangetnoinfoBNNJзХнщЕ).head = youcangetnoinfoBNNGЁ0zсщ.pop();
/*  75 */         SegmentPool.recycle((Segment)youcangetnoinfoBNNGЁ0zсщ);
/*     */       } 
/*     */       
/*  78 */       long l = youcangetnoinfoBNNKуюйЯе - i;
/*     */     } 
/*     */   }
/*     */   
/*     */   @IgnoreJRERequirement
/*     */   public void deflate(Object youcangetnoinfoELIJУЁзКМ) throws IOException {
/*  84 */     Object youcangetnoinfoELIKЧК15ц = ((DeflaterSink)super).sink.buffer();
/*     */     while (true) {
/*  86 */       Object youcangetnoinfoELIGаГ6гЧ = youcangetnoinfoELIKЧК15ц.writableSegment(1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  94 */       int i = (youcangetnoinfoELIJУЁзКМ != null) ? ((DeflaterSink)super).deflater.deflate(((Segment)youcangetnoinfoELIGаГ6гЧ).data, ((Segment)youcangetnoinfoELIGаГ6гЧ).limit, 8192 - ((Segment)youcangetnoinfoELIGаГ6гЧ).limit, 2) : ((DeflaterSink)super).deflater.deflate(((Segment)youcangetnoinfoELIGаГ6гЧ).data, ((Segment)youcangetnoinfoELIGаГ6гЧ).limit, 8192 - ((Segment)youcangetnoinfoELIGаГ6гЧ).limit);
/*     */       
/*  96 */       if (i > 0) {
/*  97 */         ((Segment)youcangetnoinfoELIGаГ6гЧ).limit += i;
/*  98 */         ((Buffer2)youcangetnoinfoELIKЧК15ц).size += i;
/*  99 */         ((DeflaterSink)super).sink.emitCompleteSegments(); continue;
/* 100 */       }  if (((DeflaterSink)super).deflater.needsInput()) {
/* 101 */         if (((Segment)youcangetnoinfoELIGаГ6гЧ).pos == ((Segment)youcangetnoinfoELIGаГ6гЧ).limit) {
/*     */           
/* 103 */           ((Buffer2)youcangetnoinfoELIKЧК15ц).head = youcangetnoinfoELIGаГ6гЧ.pop();
/* 104 */           SegmentPool.recycle((Segment)youcangetnoinfoELIGаГ6гЧ);
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 112 */     super.deflate(true);
/* 113 */     ((DeflaterSink)super).sink.flush();
/*     */   }
/*     */   
/*     */   public void finishDeflate() throws IOException {
/* 117 */     ((DeflaterSink)super).deflater.finish();
/* 118 */     super.deflate(false);
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 122 */     if (((DeflaterSink)super).closed) {
/*     */       return;
/*     */     }
/*     */     
/* 126 */     Object youcangetnoinfoAXTNъсеЧь = null;
/*     */     try {
/* 128 */       super.finishDeflate();
/* 129 */     } catch (Throwable youcangetnoinfoAXTJчЛМЩк) {
/* 130 */       youcangetnoinfoAXTNъсеЧь = youcangetnoinfoAXTJчЛМЩк;
/*     */     } 
/*     */     
/*     */     try {
/* 134 */       ((DeflaterSink)super).deflater.end();
/* 135 */     } catch (Throwable youcangetnoinfoAXTKьб8Та) {
/* 136 */       if (youcangetnoinfoAXTNъсеЧь == null) youcangetnoinfoAXTNъсеЧь = youcangetnoinfoAXTKьб8Та;
/*     */     
/*     */     } 
/*     */     try {
/* 140 */       ((DeflaterSink)super).sink.close();
/* 141 */     } catch (Throwable youcangetnoinfoAXTLДЖЖЧ2) {
/* 142 */       if (youcangetnoinfoAXTNъсеЧь == null) youcangetnoinfoAXTNъсеЧь = youcangetnoinfoAXTLДЖЖЧ2; 
/*     */     } 
/* 144 */     ((DeflaterSink)super).closed = true;
/*     */     
/* 146 */     if (youcangetnoinfoAXTNъсеЧь != null) Util.sneakyRethrow((Throwable)youcangetnoinfoAXTNъсеЧь); 
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 150 */     return ((DeflaterSink)super).sink.timeout();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 154 */     return "DeflaterSink(" + ((DeflaterSink)super).sink + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\DeflaterSink.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */