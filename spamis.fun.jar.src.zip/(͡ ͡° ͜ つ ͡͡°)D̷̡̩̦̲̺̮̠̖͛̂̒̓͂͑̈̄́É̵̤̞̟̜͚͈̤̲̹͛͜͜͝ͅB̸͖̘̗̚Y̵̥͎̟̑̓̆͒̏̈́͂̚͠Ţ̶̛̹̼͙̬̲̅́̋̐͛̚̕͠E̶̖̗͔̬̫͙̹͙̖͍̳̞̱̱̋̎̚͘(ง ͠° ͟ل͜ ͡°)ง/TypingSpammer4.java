/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TypingSpammer4
/*    */   extends Thread
/*    */ {
/*    */   public final TypingSpammer1 this$2;
/*    */   public final Map.Entry val$token;
/*    */   
/*    */   public void run() {
/* 63 */     while (TypingSpammer2.access$000(((TypingSpammer4)super).this$2.this$1.this$0)) {
/*    */       try {
/* 65 */         Object youcangetnoinfoDSGEнгБьВ = SpamUtils.getRandomProxy();
/* 66 */         Object youcangetnoinfoDSGFЗряь3 = SpamUtils.typing(typingField.getText(), token
/* 67 */             .getValue().toString(), (String)youcangetnoinfoDSGEнгБьВ);
/* 68 */         if (youcangetnoinfoDSGFЗряь3 == null) {
/*    */           
/* 70 */           ConsoleGUI.log(youcangetnoinfoDSGEнгБьВ + "-> Token(" + token.getKey() + ")-> Typing sent.");
/* 71 */         } else if (youcangetnoinfoDSGFЗряь3.startsWith("<")) {
/* 72 */           ConsoleGUI.log(youcangetnoinfoDSGEнгБьВ + "-> Token(" + token.getKey() + ")-> Proxy failed. Retrying");
/*    */         } else {
/*    */           
/* 75 */           ConsoleGUI.log(youcangetnoinfoDSGEнгБьВ + "-> Token(" + token.getKey() + ")-> Unknown error: " + youcangetnoinfoDSGFЗряь3);
/*    */         }
/*    */       
/* 78 */       } catch (IOException youcangetnoinfoDSGGЧлф99) {
/* 79 */         youcangetnoinfoDSGGЧлф99.printStackTrace();
/*    */       } 
/*    */       try {
/* 82 */         Thread.sleep(3000L);
/* 83 */       } catch (InterruptedException youcangetnoinfoDSGHз2ТкЁ) {
/* 84 */         youcangetnoinfoDSGHз2ТкЁ.printStackTrace();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\TypingSpammer4.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */