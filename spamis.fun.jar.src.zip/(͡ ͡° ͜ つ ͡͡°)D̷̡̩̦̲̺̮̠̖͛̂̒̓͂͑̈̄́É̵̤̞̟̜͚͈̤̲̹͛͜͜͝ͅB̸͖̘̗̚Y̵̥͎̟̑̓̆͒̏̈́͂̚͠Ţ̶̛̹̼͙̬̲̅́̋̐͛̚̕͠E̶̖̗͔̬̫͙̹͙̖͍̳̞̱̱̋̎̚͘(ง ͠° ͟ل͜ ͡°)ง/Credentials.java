/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.charset.StandardCharsets;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Credentials
/*    */ {
/*    */   public Credentials() {
/* 25 */     this();
/*    */   }
/*    */ 
/*    */   
/*    */   public static String basic(Object youcangetnoinfoEDNGюо6zь, Object youcangetnoinfoEDNH0екЕа) {
/* 30 */     return basic((String)youcangetnoinfoEDNGюо6zь, (String)youcangetnoinfoEDNH0екЕа, StandardCharsets.ISO_8859_1);
/*    */   }
/*    */   
/*    */   public static String basic(Object youcangetnoinfoELWXЦ2ЗЖу, Object youcangetnoinfoELWYЁГПАД, Object youcangetnoinfoELWZ2т4Чт) {
/* 34 */     Object youcangetnoinfoELXAЩюЪмГ = youcangetnoinfoELWXЦ2ЗЖу + ":" + youcangetnoinfoELWYЁГПАД;
/* 35 */     Object youcangetnoinfoELXBбчХРЩ = ByteString.encodeString((String)youcangetnoinfoELXAЩюЪмГ, (Charset)youcangetnoinfoELWZ2т4Чт).base64();
/* 36 */     return "Basic " + youcangetnoinfoELXBбчХРЩ;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Credentials.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */