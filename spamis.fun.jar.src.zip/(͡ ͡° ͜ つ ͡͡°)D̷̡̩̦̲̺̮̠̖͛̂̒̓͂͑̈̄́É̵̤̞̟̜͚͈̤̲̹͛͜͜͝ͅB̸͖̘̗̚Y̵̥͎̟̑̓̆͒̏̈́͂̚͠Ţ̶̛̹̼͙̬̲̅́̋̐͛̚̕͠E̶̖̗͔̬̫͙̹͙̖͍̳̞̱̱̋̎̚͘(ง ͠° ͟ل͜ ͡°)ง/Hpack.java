/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Hpack
/*     */ {
/*     */   public final BufferedSource source;
/*     */   public int nextHeaderIndex;
/*     */   public final List headerList;
/*     */   public Header[] dynamicTable;
/*     */   public final int headerTableSizeSetting;
/*     */   public int headerCount;
/*     */   public int maxDynamicTableByteCount;
/*     */   public int dynamicTableByteCount;
/*     */   
/*     */   public Hpack(Object youcangetnoinfoWTEЗвЗ9й, Object youcangetnoinfoWTF6н9ТФ) {
/* 131 */     super(youcangetnoinfoWTEЗвЗ9й, youcangetnoinfoWTEЗвЗ9й, (Source)youcangetnoinfoWTF6н9ТФ);
/*     */   }
/*     */   public Hpack(Object youcangetnoinfoEHRAтяесЮ, Object youcangetnoinfoEHRBтшя5Я, Object youcangetnoinfoEHRCъыРсЗ) {
/* 134 */     this(); ((Hpack)super).headerList = new ArrayList(); ((Hpack)super).dynamicTable = new Header[8]; ((Hpack)super).nextHeaderIndex = ((Hpack)super).dynamicTable.length - 1; ((Hpack)super).headerCount = 0; ((Hpack)super).dynamicTableByteCount = 0;
/* 135 */     ((Hpack)super).headerTableSizeSetting = youcangetnoinfoEHRAтяесЮ;
/* 136 */     ((Hpack)super).maxDynamicTableByteCount = youcangetnoinfoEHRBтшя5Я;
/* 137 */     ((Hpack)super).source = Okio1.buffer((Source)youcangetnoinfoEHRCъыРсЗ);
/*     */   }
/*     */   
/*     */   public int maxDynamicTableByteCount() {
/* 141 */     return ((Hpack)super).maxDynamicTableByteCount;
/*     */   }
/*     */   
/*     */   public void adjustDynamicTableByteCount() {
/* 145 */     if (((Hpack)super).maxDynamicTableByteCount < ((Hpack)super).dynamicTableByteCount) {
/* 146 */       if (((Hpack)super).maxDynamicTableByteCount == 0) {
/* 147 */         super.clearDynamicTable();
/*     */       } else {
/* 149 */         super.evictToRecoverBytes(((Hpack)super).dynamicTableByteCount - ((Hpack)super).maxDynamicTableByteCount);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void clearDynamicTable() {
/* 155 */     Arrays.fill((Object[])((Hpack)super).dynamicTable, (Object)null);
/* 156 */     ((Hpack)super).nextHeaderIndex = ((Hpack)super).dynamicTable.length - 1;
/* 157 */     ((Hpack)super).headerCount = 0;
/* 158 */     ((Hpack)super).dynamicTableByteCount = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int evictToRecoverBytes(Object youcangetnoinfoDOLVэуЮЭо) {
/* 163 */     byte b = 0;
/* 164 */     if (youcangetnoinfoDOLVэуЮЭо > null) {
/*     */       
/* 166 */       for (int i = ((Hpack)super).dynamicTable.length - 1; i >= ((Hpack)super).nextHeaderIndex && youcangetnoinfoDOLVэуЮЭо > null; i--) {
/* 167 */         int j = youcangetnoinfoDOLVэуЮЭо - (((Hpack)super).dynamicTable[i]).hpackSize;
/* 168 */         ((Hpack)super).dynamicTableByteCount -= (((Hpack)super).dynamicTable[i]).hpackSize;
/* 169 */         ((Hpack)super).headerCount--;
/* 170 */         b++;
/*     */       } 
/* 172 */       System.arraycopy(((Hpack)super).dynamicTable, ((Hpack)super).nextHeaderIndex + 1, ((Hpack)super).dynamicTable, ((Hpack)super).nextHeaderIndex + 1 + b, ((Hpack)super).headerCount);
/*     */       
/* 174 */       ((Hpack)super).nextHeaderIndex += b;
/*     */     } 
/* 176 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readHeaders() throws IOException {
/* 184 */     while (!((Hpack)super).source.exhausted()) {
/* 185 */       int i = ((Hpack)super).source.readByte() & 0xFF;
/* 186 */       if (i == 128)
/* 187 */         throw new IOException("index == 0"); 
/* 188 */       if ((i & 0x80) == 128) {
/* 189 */         int k = super.readInt(i, 127);
/* 190 */         super.readIndexedHeader(k - 1); continue;
/* 191 */       }  if (i == 64) {
/* 192 */         super.readLiteralHeaderWithIncrementalIndexingNewName(); continue;
/* 193 */       }  if ((i & 0x40) == 64) {
/* 194 */         int k = super.readInt(i, 63);
/* 195 */         super.readLiteralHeaderWithIncrementalIndexingIndexedName(k - 1); continue;
/* 196 */       }  if ((i & 0x20) == 32) {
/* 197 */         ((Hpack)super).maxDynamicTableByteCount = super.readInt(i, 31);
/* 198 */         if (((Hpack)super).maxDynamicTableByteCount < 0 || ((Hpack)super).maxDynamicTableByteCount > ((Hpack)super).headerTableSizeSetting)
/*     */         {
/* 200 */           throw new IOException("Invalid dynamic table size update " + super.maxDynamicTableByteCount);
/*     */         }
/* 202 */         super.adjustDynamicTableByteCount(); continue;
/* 203 */       }  if (i == 16 || i == 0) {
/* 204 */         super.readLiteralHeaderWithoutIndexingNewName(); continue;
/*     */       } 
/* 206 */       int j = super.readInt(i, 15);
/* 207 */       super.readLiteralHeaderWithoutIndexingIndexedName(j - 1);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public List getAndResetHeaderList() {
/* 213 */     Object youcangetnoinfoCXKHСЖЗаЮ = new ArrayList(((Hpack)super).headerList);
/* 214 */     ((Hpack)super).headerList.clear();
/* 215 */     return (List)youcangetnoinfoCXKHСЖЗаЮ;
/*     */   }
/*     */   
/*     */   public void readIndexedHeader(Object youcangetnoinfoEKFMеИ9цШ) throws IOException {
/* 219 */     if (super.isStaticHeader(youcangetnoinfoEKFMеИ9цШ)) {
/* 220 */       Object youcangetnoinfoEKFJЭ8Кхz = Hpack1.STATIC_HEADER_TABLE[youcangetnoinfoEKFMеИ9цШ];
/* 221 */       ((Hpack)super).headerList.add(youcangetnoinfoEKFJЭ8Кхz);
/*     */     } else {
/* 223 */       int i = super.dynamicTableIndex(youcangetnoinfoEKFMеИ9цШ - Hpack1.STATIC_HEADER_TABLE.length);
/* 224 */       if (i < 0 || i >= ((Hpack)super).dynamicTable.length) {
/* 225 */         throw new IOException("Header index too large " + (youcangetnoinfoEKFMеИ9цШ + 1));
/*     */       }
/* 227 */       ((Hpack)super).headerList.add(((Hpack)super).dynamicTable[i]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int dynamicTableIndex(Object youcangetnoinfoASEVРё71Ц) {
/* 233 */     return ((Hpack)super).nextHeaderIndex + 1 + youcangetnoinfoASEVРё71Ц;
/*     */   }
/*     */   
/*     */   public void readLiteralHeaderWithoutIndexingIndexedName(Object youcangetnoinfoENDSГЬДЩТ) throws IOException {
/* 237 */     Object youcangetnoinfoENDTшше0С = super.getName(youcangetnoinfoENDSГЬДЩТ);
/* 238 */     Object youcangetnoinfoENDUеЦгЙд = super.readByteString();
/* 239 */     ((Hpack)super).headerList.add(new Header((ByteString)youcangetnoinfoENDTшше0С, (ByteString)youcangetnoinfoENDUеЦгЙд));
/*     */   }
/*     */   
/*     */   public void readLiteralHeaderWithoutIndexingNewName() throws IOException {
/* 243 */     Object youcangetnoinfoBVVPгсЭЬЫ = Hpack1.checkLowercase(super.readByteString());
/* 244 */     Object youcangetnoinfoBVVQ4Пкэ1 = super.readByteString();
/* 245 */     ((Hpack)super).headerList.add(new Header((ByteString)youcangetnoinfoBVVPгсЭЬЫ, (ByteString)youcangetnoinfoBVVQ4Пкэ1));
/*     */   }
/*     */ 
/*     */   
/*     */   public void readLiteralHeaderWithIncrementalIndexingIndexedName(Object youcangetnoinfoBQSYййэЦс) throws IOException {
/* 250 */     Object youcangetnoinfoBQSZЬЕэ4ю = super.getName(youcangetnoinfoBQSYййэЦс);
/* 251 */     Object youcangetnoinfoBQTAШЧЬгР = super.readByteString();
/* 252 */     super.insertIntoDynamicTable(-1, new Header((ByteString)youcangetnoinfoBQSZЬЕэ4ю, (ByteString)youcangetnoinfoBQTAШЧЬгР));
/*     */   }
/*     */   
/*     */   public void readLiteralHeaderWithIncrementalIndexingNewName() throws IOException {
/* 256 */     Object youcangetnoinfoDIED5УЗФМ = Hpack1.checkLowercase(super.readByteString());
/* 257 */     Object youcangetnoinfoDIEEгЛАсч = super.readByteString();
/* 258 */     super.insertIntoDynamicTable(-1, new Header((ByteString)youcangetnoinfoDIED5УЗФМ, (ByteString)youcangetnoinfoDIEEгЛАсч));
/*     */   }
/*     */   
/*     */   public ByteString getName(Object youcangetnoinfoDHNOФЛх1ц) throws IOException {
/* 262 */     if (super.isStaticHeader(youcangetnoinfoDHNOФЛх1ц)) {
/* 263 */       return (Hpack1.STATIC_HEADER_TABLE[youcangetnoinfoDHNOФЛх1ц]).name;
/*     */     }
/* 265 */     int i = super.dynamicTableIndex(youcangetnoinfoDHNOФЛх1ц - Hpack1.STATIC_HEADER_TABLE.length);
/* 266 */     if (i < 0 || i >= ((Hpack)super).dynamicTable.length) {
/* 267 */       throw new IOException("Header index too large " + (youcangetnoinfoDHNOФЛх1ц + 1));
/*     */     }
/*     */     
/* 270 */     return (((Hpack)super).dynamicTable[i]).name;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isStaticHeader(Object youcangetnoinfoECXBзУАЁЁ) {
/* 275 */     return (youcangetnoinfoECXBзУАЁЁ >= null && youcangetnoinfoECXBзУАЁЁ <= Hpack1.STATIC_HEADER_TABLE.length - 1);
/*     */   }
/*     */   
/*     */   public void insertIntoDynamicTable(Object youcangetnoinfoQT5цЖИЛ, Object youcangetnoinfoQU7бниб) {
/*     */     int i;
/* 280 */     ((Hpack)super).headerList.add(youcangetnoinfoQU7бниб);
/*     */     
/* 282 */     int j = ((Header)youcangetnoinfoQU7бниб).hpackSize;
/* 283 */     if (youcangetnoinfoQT5цЖИЛ != -1) {
/* 284 */       j -= (((Hpack)super).dynamicTable[super.dynamicTableIndex(youcangetnoinfoQT5цЖИЛ)]).hpackSize;
/*     */     }
/*     */ 
/*     */     
/* 288 */     if (j > ((Hpack)super).maxDynamicTableByteCount) {
/* 289 */       super.clearDynamicTable();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 294 */     int k = ((Hpack)super).dynamicTableByteCount + j - ((Hpack)super).maxDynamicTableByteCount;
/* 295 */     int m = super.evictToRecoverBytes(k);
/*     */     
/* 297 */     if (youcangetnoinfoQT5цЖИЛ == -1) {
/* 298 */       if (((Hpack)super).headerCount + 1 > ((Hpack)super).dynamicTable.length) {
/* 299 */         Object youcangetnoinfoQRхИащи = new Header[((Hpack)super).dynamicTable.length * 2];
/* 300 */         System.arraycopy(((Hpack)super).dynamicTable, 0, youcangetnoinfoQRхИащи, ((Hpack)super).dynamicTable.length, ((Hpack)super).dynamicTable.length);
/* 301 */         ((Hpack)super).nextHeaderIndex = ((Hpack)super).dynamicTable.length - 1;
/* 302 */         ((Hpack)super).dynamicTable = (Header[])youcangetnoinfoQRхИащи;
/*     */       } 
/* 304 */       i = ((Hpack)super).nextHeaderIndex--;
/* 305 */       ((Hpack)super).dynamicTable[i] = (Header)youcangetnoinfoQU7бниб;
/* 306 */       ((Hpack)super).headerCount++;
/*     */     } else {
/* 308 */       i += super.dynamicTableIndex(i) + m;
/* 309 */       ((Hpack)super).dynamicTable[i] = (Header)youcangetnoinfoQU7бниб;
/*     */     } 
/* 311 */     ((Hpack)super).dynamicTableByteCount += j;
/*     */   }
/*     */   
/*     */   public int readByte() throws IOException {
/* 315 */     return ((Hpack)super).source.readByte() & 0xFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int readInt(Object youcangetnoinfoEOBNУб4гЛ, Object youcangetnoinfoEOBOётЧ8С) throws IOException {
/*     */     // Byte code:
/*     */     //   0: iload_1
/*     */     //   1: iload_2
/*     */     //   2: iand
/*     */     //   3: istore_3
/*     */     //   4: iload_3
/*     */     //   5: iload_2
/*     */     //   6: if_icmpge -> 11
/*     */     //   9: iload_3
/*     */     //   10: ireturn
/*     */     //   11: iload_2
/*     */     //   12: istore #4
/*     */     //   14: iconst_0
/*     */     //   15: istore #5
/*     */     //   17: aload_0
/*     */     //   18: invokespecial readByte : ()I
/*     */     //   21: istore #6
/*     */     //   23: iload #6
/*     */     //   25: sipush #128
/*     */     //   28: iand
/*     */     //   29: ifeq -> 51
/*     */     //   32: iload #4
/*     */     //   34: iload #6
/*     */     //   36: bipush #127
/*     */     //   38: iand
/*     */     //   39: iload #5
/*     */     //   41: ishl
/*     */     //   42: iadd
/*     */     //   43: istore #4
/*     */     //   45: iinc #5, 7
/*     */     //   48: goto -> 64
/*     */     //   51: iload #4
/*     */     //   53: iload #6
/*     */     //   55: iload #5
/*     */     //   57: ishl
/*     */     //   58: iadd
/*     */     //   59: istore #4
/*     */     //   61: goto -> 67
/*     */     //   64: goto -> 17
/*     */     //   67: iload #4
/*     */     //   69: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #319	-> 0
/*     */     //   #320	-> 4
/*     */     //   #321	-> 9
/*     */     //   #325	-> 11
/*     */     //   #326	-> 14
/*     */     //   #328	-> 17
/*     */     //   #329	-> 23
/*     */     //   #330	-> 32
/*     */     //   #331	-> 45
/*     */     //   #333	-> 51
/*     */     //   #334	-> 61
/*     */     //   #336	-> 64
/*     */     //   #337	-> 67
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	70	0	youcangetnoinfoEOBMъйэ7а	Ljava/lang/Object;
/*     */     //   14	56	4	youcangetnoinfoEOBQыОЬяс	Ljava/lang/Object;
/*     */     //   17	53	5	youcangetnoinfoEOBRотРа3	Ljava/lang/Object;
/*     */     //   23	41	6	youcangetnoinfoEOBLсчжНЕ	Ljava/lang/Object;
/*     */     //   4	66	3	youcangetnoinfoEOBP9ьлЖе	Ljava/lang/Object;
/*     */     //   0	70	2	youcangetnoinfoEOBOётЧ8С	Ljava/lang/Object;
/*     */     //   0	70	1	youcangetnoinfoEOBNУб4гЛ	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteString readByteString() throws IOException {
/* 342 */     int i = super.readByte();
/* 343 */     boolean bool = ((i & 0x80) == 128) ? true : false;
/* 344 */     int j = super.readInt(i, 127);
/*     */     
/* 346 */     if (bool) {
/* 347 */       return ByteString.of(Huffman.get().decode(((Hpack)super).source.readByteArray(j)));
/*     */     }
/* 349 */     return ((Hpack)super).source.readByteString(j);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Hpack.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */