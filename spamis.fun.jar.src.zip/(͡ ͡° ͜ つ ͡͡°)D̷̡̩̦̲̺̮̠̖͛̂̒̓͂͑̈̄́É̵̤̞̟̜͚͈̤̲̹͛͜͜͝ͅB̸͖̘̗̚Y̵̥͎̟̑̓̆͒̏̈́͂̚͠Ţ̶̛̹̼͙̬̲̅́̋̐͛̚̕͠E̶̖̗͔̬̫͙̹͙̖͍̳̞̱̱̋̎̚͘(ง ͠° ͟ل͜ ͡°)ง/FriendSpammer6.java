/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FriendSpammer6
/*     */   extends JPanel
/*     */ {
/*     */   public static final long serialVersionUID = -166226435206966756L;
/*     */   
/*     */   public FriendSpammer6() {
/*  26 */     super.initialize();
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  30 */     setLayout((LayoutManager)null);
/*     */     
/*  32 */     Object youcangetnoinfoBPDLzЦоЧэ = new JLabel("User id");
/*  33 */     youcangetnoinfoBPDLzЦоЧэ.setBounds(28, 12, 293, 15);
/*  34 */     add((Component)youcangetnoinfoBPDLzЦоЧэ);
/*     */     
/*  36 */     Object youcangetnoinfoBPDMй1яЙэ = new JTextField();
/*  37 */     youcangetnoinfoBPDMй1яЙэ.setColumns(10);
/*  38 */     youcangetnoinfoBPDMй1яЙэ.setBounds(28, 27, 341, 32);
/*  39 */     add((Component)youcangetnoinfoBPDMй1яЙэ);
/*     */     
/*  41 */     Object youcangetnoinfoBPDNТитЮь = new JButton("Add");
/*  42 */     youcangetnoinfoBPDNТитЮь.setIcon(new ImageIcon(getClass().getResource("/ui/add.png")));
/*  43 */     youcangetnoinfoBPDNТитЮь.setBounds(28, 71, 157, 32);
/*  44 */     youcangetnoinfoBPDNТитЮь.addActionListener(new FriendSpammer4((FriendSpammer6)this, (JTextField)youcangetnoinfoBPDMй1яЙэ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     add((Component)youcangetnoinfoBPDNТитЮь);
/*     */     
/*  96 */     Object youcangetnoinfoBPDO5Хшщк = new JButton("Remove");
/*  97 */     youcangetnoinfoBPDO5Хшщк.setIcon(new ImageIcon(getClass().getResource("/ui/remove.png")));
/*  98 */     youcangetnoinfoBPDO5Хшщк.setBounds(212, 71, 157, 32);
/*  99 */     youcangetnoinfoBPDO5Хшщк.addActionListener(new FriendSpammer3((FriendSpammer6)this, (JTextField)youcangetnoinfoBPDMй1яЙэ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 149 */     add((Component)youcangetnoinfoBPDO5Хшщк);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\FriendSpammer6.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */