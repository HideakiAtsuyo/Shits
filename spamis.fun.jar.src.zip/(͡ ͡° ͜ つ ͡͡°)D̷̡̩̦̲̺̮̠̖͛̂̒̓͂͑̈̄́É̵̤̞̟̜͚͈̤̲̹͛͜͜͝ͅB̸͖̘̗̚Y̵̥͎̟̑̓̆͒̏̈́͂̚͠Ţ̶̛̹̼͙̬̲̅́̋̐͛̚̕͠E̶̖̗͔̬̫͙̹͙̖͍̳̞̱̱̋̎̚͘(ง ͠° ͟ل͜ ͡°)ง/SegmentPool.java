/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SegmentPool
/*    */ {
/*    */   public static long byteCount;
/*    */   @Nullable
/*    */   public static Segment next;
/*    */   public static final long MAX_SIZE = 65536L;
/*    */   
/*    */   public SegmentPool() {
/* 35 */     this();
/*    */   }
/*    */   
/*    */   public static Segment take() {
/* 39 */     synchronized (SegmentPool.class) {
/* 40 */       if (next != null) {
/* 41 */         Object youcangetnoinfoBBSAхЭэЗА = next;
/* 42 */         next = ((Segment)youcangetnoinfoBBSAхЭэЗА).next;
/* 43 */         ((Segment)youcangetnoinfoBBSAхЭэЗА).next = null;
/* 44 */         byteCount -= 8192L;
/* 45 */         return (Segment)youcangetnoinfoBBSAхЭэЗА;
/*    */       } 
/*    */     } 
/* 48 */     return new Segment();
/*    */   }
/*    */   
/*    */   public static void recycle(Object youcangetnoinfoCAZCяОШМ0) {
/* 52 */     if (((Segment)youcangetnoinfoCAZCяОШМ0).next != null || ((Segment)youcangetnoinfoCAZCяОШМ0).prev != null) throw new IllegalArgumentException(); 
/* 53 */     if (((Segment)youcangetnoinfoCAZCяОШМ0).shared)
/* 54 */       return;  synchronized (SegmentPool.class) {
/* 55 */       if (byteCount + 8192L > 65536L)
/* 56 */         return;  byteCount += 8192L;
/* 57 */       ((Segment)youcangetnoinfoCAZCяОШМ0).next = next;
/* 58 */       ((Segment)youcangetnoinfoCAZCяОШМ0).pos = ((Segment)youcangetnoinfoCAZCяОШМ0).limit = 0;
/* 59 */       next = (Segment)youcangetnoinfoCAZCяОШМ0;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\SegmentPool.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */