/*      */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HttpUrl
/*      */ {
/*      */   @Nullable
/*      */   public String scheme;
/*      */   @Nullable
/*      */   public String encodedFragment;
/*      */   public static final String INVALID_HOST = "Invalid URL host";
/*      */   public int port;
/*      */   @Nullable
/*      */   public String host;
/*      */   public String encodedPassword;
/*      */   public String encodedUsername;
/*      */   @Nullable
/*      */   public List<String> encodedQueryNamesAndValues;
/*      */   public final List<String> encodedPathSegments;
/*      */   
/*      */   public HttpUrl() {
/*  978 */     this(); ((HttpUrl)super).encodedUsername = ""; ((HttpUrl)super).encodedPassword = ""; ((HttpUrl)super).port = -1; ((HttpUrl)super).encodedPathSegments = new ArrayList<>();
/*  979 */     ((HttpUrl)super).encodedPathSegments.add("");
/*      */   }
/*      */   
/*      */   public HttpUrl scheme(Object youcangetnoinfoAGXVэЭхб2) {
/*  983 */     if (youcangetnoinfoAGXVэЭхб2 == null)
/*  984 */       throw new NullPointerException("scheme == null"); 
/*  985 */     if (youcangetnoinfoAGXVэЭхб2.equalsIgnoreCase("http")) {
/*  986 */       ((HttpUrl)super).scheme = "http";
/*  987 */     } else if (youcangetnoinfoAGXVэЭхб2.equalsIgnoreCase("https")) {
/*  988 */       ((HttpUrl)super).scheme = "https";
/*      */     } else {
/*  990 */       throw new IllegalArgumentException("unexpected scheme: " + youcangetnoinfoAGXVэЭхб2);
/*      */     } 
/*  992 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl username(Object youcangetnoinfoDCIGу4Ълч) {
/*  996 */     if (youcangetnoinfoDCIGу4Ълч == null) throw new NullPointerException("username == null"); 
/*  997 */     ((HttpUrl)super).encodedUsername = HttpUrl1.canonicalize((String)youcangetnoinfoDCIGу4Ълч, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
/*  998 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl encodedUsername(Object youcangetnoinfoBVDLхЫядЁ) {
/* 1002 */     if (youcangetnoinfoBVDLхЫядЁ == null) throw new NullPointerException("encodedUsername == null"); 
/* 1003 */     ((HttpUrl)super).encodedUsername = HttpUrl1.canonicalize((String)youcangetnoinfoBVDLхЫядЁ, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
/*      */     
/* 1005 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl password(Object youcangetnoinfoBPNZЗХяжЗ) {
/* 1009 */     if (youcangetnoinfoBPNZЗХяжЗ == null) throw new NullPointerException("password == null"); 
/* 1010 */     ((HttpUrl)super).encodedPassword = HttpUrl1.canonicalize((String)youcangetnoinfoBPNZЗХяжЗ, " \"':;<=>@[]^`{}|/\\?#", false, false, false, true);
/* 1011 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl encodedPassword(Object youcangetnoinfoEGSPД3дМл) {
/* 1015 */     if (youcangetnoinfoEGSPД3дМл == null) throw new NullPointerException("encodedPassword == null"); 
/* 1016 */     ((HttpUrl)super).encodedPassword = HttpUrl1.canonicalize((String)youcangetnoinfoEGSPД3дМл, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true);
/*      */     
/* 1018 */     return (HttpUrl)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpUrl host(Object youcangetnoinfoGCDЗЮёф7) {
/* 1026 */     if (youcangetnoinfoGCDЗЮёф7 == null) throw new NullPointerException("host == null"); 
/* 1027 */     Object youcangetnoinfoGCEСКу7й = canonicalizeHost((String)youcangetnoinfoGCDЗЮёф7, 0, youcangetnoinfoGCDЗЮёф7.length());
/* 1028 */     if (youcangetnoinfoGCEСКу7й == null) throw new IllegalArgumentException("unexpected host: " + youcangetnoinfoGCDЗЮёф7); 
/* 1029 */     ((HttpUrl)super).host = (String)youcangetnoinfoGCEСКу7й;
/* 1030 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl port(Object youcangetnoinfoACHXтэСюГ) {
/* 1034 */     if (youcangetnoinfoACHXтэСюГ <= null || youcangetnoinfoACHXтэСюГ > '￿') throw new IllegalArgumentException("unexpected port: " + youcangetnoinfoACHXтэСюГ); 
/* 1035 */     ((HttpUrl)super).port = youcangetnoinfoACHXтэСюГ;
/* 1036 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public int effectivePort() {
/* 1040 */     return (((HttpUrl)super).port != -1) ? ((HttpUrl)super).port : HttpUrl1.defaultPort(((HttpUrl)super).scheme);
/*      */   }
/*      */   
/*      */   public HttpUrl addPathSegment(Object youcangetnoinfoEDVXЭыЮжБ) {
/* 1044 */     if (youcangetnoinfoEDVXЭыЮжБ == null) throw new NullPointerException("pathSegment == null"); 
/* 1045 */     super.push((String)youcangetnoinfoEDVXЭыЮжБ, 0, youcangetnoinfoEDVXЭыЮжБ.length(), false, false);
/* 1046 */     return (HttpUrl)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpUrl addPathSegments(Object youcangetnoinfoENPVАрзКк) {
/* 1054 */     if (youcangetnoinfoENPVАрзКк == null) throw new NullPointerException("pathSegments == null"); 
/* 1055 */     return super.addPathSegments((String)youcangetnoinfoENPVАрзКк, false);
/*      */   }
/*      */   
/*      */   public HttpUrl addEncodedPathSegment(Object youcangetnoinfoAPOEиъп5Ф) {
/* 1059 */     if (youcangetnoinfoAPOEиъп5Ф == null) {
/* 1060 */       throw new NullPointerException("encodedPathSegment == null");
/*      */     }
/* 1062 */     super.push((String)youcangetnoinfoAPOEиъп5Ф, 0, youcangetnoinfoAPOEиъп5Ф.length(), false, true);
/* 1063 */     return (HttpUrl)this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpUrl addEncodedPathSegments(Object youcangetnoinfoDXCEШБМ86) {
/* 1072 */     if (youcangetnoinfoDXCEШБМ86 == null) {
/* 1073 */       throw new NullPointerException("encodedPathSegments == null");
/*      */     }
/* 1075 */     return super.addPathSegments((String)youcangetnoinfoDXCEШБМ86, true);
/*      */   }
/*      */   
/*      */   public HttpUrl addPathSegments(Object youcangetnoinfoCBZXовуДм, Object youcangetnoinfoCBZYМбШтё) {
/* 1079 */     int i = 0;
/*      */     while (true) {
/* 1081 */       int j = Util1.delimiterOffset((String)youcangetnoinfoCBZXовуДм, i, youcangetnoinfoCBZXовуДм.length(), "/\\");
/* 1082 */       boolean bool = (j < youcangetnoinfoCBZXовуДм.length()) ? true : false;
/* 1083 */       super.push((String)youcangetnoinfoCBZXовуДм, i, j, bool, youcangetnoinfoCBZYМбШтё);
/* 1084 */       i = j + 1;
/* 1085 */       if (i > youcangetnoinfoCBZXовуДм.length())
/* 1086 */         return (HttpUrl)this; 
/*      */     } 
/*      */   }
/*      */   public HttpUrl setPathSegment(Object youcangetnoinfoBZBSЯКОпД, Object youcangetnoinfoBZBTВЖээн) {
/* 1090 */     if (youcangetnoinfoBZBTВЖээн == null) throw new NullPointerException("pathSegment == null"); 
/* 1091 */     Object youcangetnoinfoBZBUизЗЗы = HttpUrl1.canonicalize((String)youcangetnoinfoBZBTВЖээн, 0, youcangetnoinfoBZBTВЖээн.length(), " \"<>^`{}|/\\?#", false, false, false, true, null);
/*      */     
/* 1093 */     if (super.isDot((String)youcangetnoinfoBZBUизЗЗы) || super.isDotDot((String)youcangetnoinfoBZBUизЗЗы)) {
/* 1094 */       throw new IllegalArgumentException("unexpected path segment: " + youcangetnoinfoBZBTВЖээн);
/*      */     }
/* 1096 */     ((HttpUrl)super).encodedPathSegments.set(youcangetnoinfoBZBSЯКОпД, youcangetnoinfoBZBUизЗЗы);
/* 1097 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl setEncodedPathSegment(Object youcangetnoinfoAJGIТяДфъ, Object youcangetnoinfoAJGJДрл4э) {
/* 1101 */     if (youcangetnoinfoAJGJДрл4э == null) {
/* 1102 */       throw new NullPointerException("encodedPathSegment == null");
/*      */     }
/* 1104 */     Object youcangetnoinfoAJGKиКУрС = HttpUrl1.canonicalize((String)youcangetnoinfoAJGJДрл4э, 0, youcangetnoinfoAJGJДрл4э.length(), " \"<>^`{}|/\\?#", true, false, false, true, null);
/*      */     
/* 1106 */     ((HttpUrl)super).encodedPathSegments.set(youcangetnoinfoAJGIТяДфъ, youcangetnoinfoAJGKиКУрС);
/* 1107 */     if (super.isDot((String)youcangetnoinfoAJGKиКУрС) || super.isDotDot((String)youcangetnoinfoAJGKиКУрС)) {
/* 1108 */       throw new IllegalArgumentException("unexpected path segment: " + youcangetnoinfoAJGJДрл4э);
/*      */     }
/* 1110 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl removePathSegment(Object youcangetnoinfoARRYНу092) {
/* 1114 */     ((HttpUrl)super).encodedPathSegments.remove(youcangetnoinfoARRYНу092);
/* 1115 */     if (((HttpUrl)super).encodedPathSegments.isEmpty()) {
/* 1116 */       ((HttpUrl)super).encodedPathSegments.add("");
/*      */     }
/* 1118 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl encodedPath(Object youcangetnoinfoBZDHЁьъДш) {
/* 1122 */     if (youcangetnoinfoBZDHЁьъДш == null) throw new NullPointerException("encodedPath == null"); 
/* 1123 */     if (!youcangetnoinfoBZDHЁьъДш.startsWith("/")) {
/* 1124 */       throw new IllegalArgumentException("unexpected encodedPath: " + youcangetnoinfoBZDHЁьъДш);
/*      */     }
/* 1126 */     super.resolvePath((String)youcangetnoinfoBZDHЁьъДш, 0, youcangetnoinfoBZDHЁьъДш.length());
/* 1127 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl query(@Nullable Object youcangetnoinfoEPPJчшФ4Ш) {
/* 1131 */     ((HttpUrl)super)
/*      */ 
/*      */       
/* 1134 */       .encodedQueryNamesAndValues = (youcangetnoinfoEPPJчшФ4Ш != null) ? HttpUrl1.queryStringToNamesAndValues(HttpUrl1.canonicalize((String)youcangetnoinfoEPPJчшФ4Ш, " \"'<>#", false, false, true, true)) : null;
/* 1135 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl encodedQuery(@Nullable Object youcangetnoinfoBVBGьйТЪТ) {
/* 1139 */     ((HttpUrl)super)
/*      */ 
/*      */       
/* 1142 */       .encodedQueryNamesAndValues = (youcangetnoinfoBVBGьйТЪТ != null) ? HttpUrl1.queryStringToNamesAndValues(HttpUrl1.canonicalize((String)youcangetnoinfoBVBGьйТЪТ, " \"'<>#", true, false, true, true)) : null;
/* 1143 */     return (HttpUrl)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpUrl addQueryParameter(Object youcangetnoinfoQMPЮаъен, @Nullable Object youcangetnoinfoQMQНМММГ) {
/* 1148 */     if (youcangetnoinfoQMPЮаъен == null) throw new NullPointerException("name == null"); 
/* 1149 */     if (((HttpUrl)super).encodedQueryNamesAndValues == null) ((HttpUrl)super).encodedQueryNamesAndValues = new ArrayList<>(); 
/* 1150 */     ((HttpUrl)super).encodedQueryNamesAndValues.add(
/* 1151 */         HttpUrl1.canonicalize((String)youcangetnoinfoQMPЮаъен, " !\"#$&'(),/:;<=>?@[]\\^`{|}~", false, false, true, true));
/* 1152 */     ((HttpUrl)super).encodedQueryNamesAndValues.add((youcangetnoinfoQMQНМММГ != null) ? 
/* 1153 */         HttpUrl1.canonicalize((String)youcangetnoinfoQMQНМММГ, " !\"#$&'(),/:;<=>?@[]\\^`{|}~", false, false, true, true) : 
/* 1154 */         null);
/* 1155 */     return (HttpUrl)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public HttpUrl addEncodedQueryParameter(Object youcangetnoinfoXAXвЧБуЦ, @Nullable Object youcangetnoinfoXAYрЬЁМ7) {
/* 1160 */     if (youcangetnoinfoXAXвЧБуЦ == null) throw new NullPointerException("encodedName == null"); 
/* 1161 */     if (((HttpUrl)super).encodedQueryNamesAndValues == null) ((HttpUrl)super).encodedQueryNamesAndValues = new ArrayList<>(); 
/* 1162 */     ((HttpUrl)super).encodedQueryNamesAndValues.add(
/* 1163 */         HttpUrl1.canonicalize((String)youcangetnoinfoXAXвЧБуЦ, " \"'<>#&=", true, false, true, true));
/* 1164 */     ((HttpUrl)super).encodedQueryNamesAndValues.add((youcangetnoinfoXAYрЬЁМ7 != null) ? 
/* 1165 */         HttpUrl1.canonicalize((String)youcangetnoinfoXAYрЬЁМ7, " \"'<>#&=", true, false, true, true) : 
/* 1166 */         null);
/* 1167 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl setQueryParameter(Object youcangetnoinfoDOSVЩТХМв, @Nullable Object youcangetnoinfoDOSW77тяп) {
/* 1171 */     super.removeAllQueryParameters((String)youcangetnoinfoDOSVЩТХМв);
/* 1172 */     super.addQueryParameter((String)youcangetnoinfoDOSVЩТХМв, (String)youcangetnoinfoDOSW77тяп);
/* 1173 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl setEncodedQueryParameter(Object youcangetnoinfoCZS7ПнгО, @Nullable Object youcangetnoinfoCZTЮЭ6юz) {
/* 1177 */     super.removeAllEncodedQueryParameters((String)youcangetnoinfoCZS7ПнгО);
/* 1178 */     super.addEncodedQueryParameter((String)youcangetnoinfoCZS7ПнгО, (String)youcangetnoinfoCZTЮЭ6юz);
/* 1179 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl removeAllQueryParameters(Object youcangetnoinfoARAZДцъФМ) {
/* 1183 */     if (youcangetnoinfoARAZДцъФМ == null) throw new NullPointerException("name == null"); 
/* 1184 */     if (((HttpUrl)super).encodedQueryNamesAndValues == null) return (HttpUrl)this; 
/* 1185 */     Object youcangetnoinfoARBAГжЩЕ3 = HttpUrl1.canonicalize((String)youcangetnoinfoARAZДцъФМ, " !\"#$&'(),/:;<=>?@[]\\^`{|}~", false, false, true, true);
/*      */     
/* 1187 */     super.removeAllCanonicalQueryParameters((String)youcangetnoinfoARBAГжЩЕ3);
/* 1188 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl removeAllEncodedQueryParameters(Object youcangetnoinfoAAQZПЯЗЁд) {
/* 1192 */     if (youcangetnoinfoAAQZПЯЗЁд == null) throw new NullPointerException("encodedName == null"); 
/* 1193 */     if (((HttpUrl)super).encodedQueryNamesAndValues == null) return (HttpUrl)this; 
/* 1194 */     super.removeAllCanonicalQueryParameters(
/* 1195 */         HttpUrl1.canonicalize((String)youcangetnoinfoAAQZПЯЗЁд, " \"'<>#&=", true, false, true, true));
/* 1196 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public void removeAllCanonicalQueryParameters(Object youcangetnoinfoEPUL3ДС8О) {
/* 1200 */     for (int i = ((HttpUrl)super).encodedQueryNamesAndValues.size() - 2; i >= 0; i -= 2) {
/* 1201 */       if (youcangetnoinfoEPUL3ДС8О.equals(((HttpUrl)super).encodedQueryNamesAndValues.get(i))) {
/* 1202 */         ((HttpUrl)super).encodedQueryNamesAndValues.remove(i + 1);
/* 1203 */         ((HttpUrl)super).encodedQueryNamesAndValues.remove(i);
/* 1204 */         if (((HttpUrl)super).encodedQueryNamesAndValues.isEmpty()) {
/* 1205 */           ((HttpUrl)super).encodedQueryNamesAndValues = null;
/*      */           return;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public HttpUrl fragment(@Nullable Object youcangetnoinfoDYFHДвЬДй) {
/* 1213 */     ((HttpUrl)super)
/*      */       
/* 1215 */       .encodedFragment = (youcangetnoinfoDYFHДвЬДй != null) ? HttpUrl1.canonicalize((String)youcangetnoinfoDYFHДвЬДй, "", false, false, false, false) : null;
/* 1216 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl encodedFragment(@Nullable Object youcangetnoinfoAXKKо7ьюБ) {
/* 1220 */     ((HttpUrl)super)
/*      */       
/* 1222 */       .encodedFragment = (youcangetnoinfoAXKKо7ьюБ != null) ? HttpUrl1.canonicalize((String)youcangetnoinfoAXKKо7ьюБ, "", true, false, false, false) : null;
/* 1223 */     return (HttpUrl)this;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpUrl reencodeForUri() {
/*      */     byte b;
/*      */     int i;
/* 1231 */     for (b = 0, i = ((HttpUrl)super).encodedPathSegments.size(); b < i; b++) {
/* 1232 */       Object youcangetnoinfoBAPZЕрЖЪь = ((HttpUrl)super).encodedPathSegments.get(b);
/* 1233 */       ((HttpUrl)super).encodedPathSegments.set(b, 
/* 1234 */           HttpUrl1.canonicalize((String)youcangetnoinfoBAPZЕрЖЪь, "[]", true, true, false, true));
/*      */     } 
/* 1236 */     if (((HttpUrl)super).encodedQueryNamesAndValues != null) {
/* 1237 */       byte b1; int j; for (b1 = 0, j = ((HttpUrl)super).encodedQueryNamesAndValues.size(); b1 < j; b1++) {
/* 1238 */         Object youcangetnoinfoBAQCеz9ЛЛ = ((HttpUrl)super).encodedQueryNamesAndValues.get(b1);
/* 1239 */         if (youcangetnoinfoBAQCеz9ЛЛ != null) {
/* 1240 */           ((HttpUrl)super).encodedQueryNamesAndValues.set(b1, 
/* 1241 */               HttpUrl1.canonicalize((String)youcangetnoinfoBAQCеz9ЛЛ, "\\^`{|}", true, true, true, true));
/*      */         }
/*      */       } 
/*      */     } 
/* 1245 */     if (((HttpUrl)super).encodedFragment != null) {
/* 1246 */       ((HttpUrl)super).encodedFragment = HttpUrl1.canonicalize(((HttpUrl)super).encodedFragment, " \"#<>\\^`{|}", true, true, false, false);
/*      */     }
/*      */     
/* 1249 */     return (HttpUrl)this;
/*      */   }
/*      */   
/*      */   public HttpUrl1 build() {
/* 1253 */     if (((HttpUrl)super).scheme == null) throw new IllegalStateException("scheme == null"); 
/* 1254 */     if (((HttpUrl)super).host == null) throw new IllegalStateException("host == null"); 
/* 1255 */     return new HttpUrl1((HttpUrl)this);
/*      */   }
/*      */   
/*      */   public String toString() {
/* 1259 */     Object youcangetnoinfoCHSUыОБАЮ = new StringBuilder();
/* 1260 */     if (((HttpUrl)super).scheme != null) {
/* 1261 */       youcangetnoinfoCHSUыОБАЮ.append(((HttpUrl)super).scheme);
/* 1262 */       youcangetnoinfoCHSUыОБАЮ.append("://");
/*      */     } else {
/* 1264 */       youcangetnoinfoCHSUыОБАЮ.append("//");
/*      */     } 
/*      */     
/* 1267 */     if (!((HttpUrl)super).encodedUsername.isEmpty() || !((HttpUrl)super).encodedPassword.isEmpty()) {
/* 1268 */       youcangetnoinfoCHSUыОБАЮ.append(((HttpUrl)super).encodedUsername);
/* 1269 */       if (!((HttpUrl)super).encodedPassword.isEmpty()) {
/* 1270 */         youcangetnoinfoCHSUыОБАЮ.append(':');
/* 1271 */         youcangetnoinfoCHSUыОБАЮ.append(((HttpUrl)super).encodedPassword);
/*      */       } 
/* 1273 */       youcangetnoinfoCHSUыОБАЮ.append('@');
/*      */     } 
/*      */     
/* 1276 */     if (((HttpUrl)super).host != null) {
/* 1277 */       if (((HttpUrl)super).host.indexOf(':') != -1) {
/*      */         
/* 1279 */         youcangetnoinfoCHSUыОБАЮ.append('[');
/* 1280 */         youcangetnoinfoCHSUыОБАЮ.append(((HttpUrl)super).host);
/* 1281 */         youcangetnoinfoCHSUыОБАЮ.append(']');
/*      */       } else {
/* 1283 */         youcangetnoinfoCHSUыОБАЮ.append(((HttpUrl)super).host);
/*      */       } 
/*      */     }
/*      */     
/* 1287 */     if (((HttpUrl)super).port != -1 || ((HttpUrl)super).scheme != null) {
/* 1288 */       int i = super.effectivePort();
/* 1289 */       if (((HttpUrl)super).scheme == null || i != HttpUrl1.defaultPort(((HttpUrl)super).scheme)) {
/* 1290 */         youcangetnoinfoCHSUыОБАЮ.append(':');
/* 1291 */         youcangetnoinfoCHSUыОБАЮ.append(i);
/*      */       } 
/*      */     } 
/*      */     
/* 1295 */     HttpUrl1.pathSegmentsToString((StringBuilder)youcangetnoinfoCHSUыОБАЮ, ((HttpUrl)super).encodedPathSegments);
/*      */     
/* 1297 */     if (((HttpUrl)super).encodedQueryNamesAndValues != null) {
/* 1298 */       youcangetnoinfoCHSUыОБАЮ.append('?');
/* 1299 */       HttpUrl1.namesAndValuesToQueryString((StringBuilder)youcangetnoinfoCHSUыОБАЮ, ((HttpUrl)super).encodedQueryNamesAndValues);
/*      */     } 
/*      */     
/* 1302 */     if (((HttpUrl)super).encodedFragment != null) {
/* 1303 */       youcangetnoinfoCHSUыОБАЮ.append('#');
/* 1304 */       youcangetnoinfoCHSUыОБАЮ.append(((HttpUrl)super).encodedFragment);
/*      */     } 
/*      */     
/* 1307 */     return youcangetnoinfoCHSUыОБАЮ.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpUrl parse(@Nullable Object youcangetnoinfoAUMJЛ79КЙ, Object youcangetnoinfoAUMKСХЁис) {
/* 1313 */     int i = Util1.skipLeadingAsciiWhitespace((String)youcangetnoinfoAUMKСХЁис, 0, youcangetnoinfoAUMKСХЁис.length());
/* 1314 */     int j = Util1.skipTrailingAsciiWhitespace((String)youcangetnoinfoAUMKСХЁис, i, youcangetnoinfoAUMKСХЁис.length());
/*      */ 
/*      */     
/* 1317 */     int k = schemeDelimiterOffset((String)youcangetnoinfoAUMKСХЁис, i, j);
/* 1318 */     if (k != -1) {
/* 1319 */       if (youcangetnoinfoAUMKСХЁис.regionMatches(true, i, "https:", 0, 6)) {
/* 1320 */         ((HttpUrl)super).scheme = "https";
/* 1321 */         i += "https:".length();
/* 1322 */       } else if (youcangetnoinfoAUMKСХЁис.regionMatches(true, i, "http:", 0, 5)) {
/* 1323 */         ((HttpUrl)super).scheme = "http";
/* 1324 */         i += "http:".length();
/*      */       } else {
/* 1326 */         throw new IllegalArgumentException("Expected URL scheme 'http' or 'https' but was '" + youcangetnoinfoAUMKСХЁис
/* 1327 */             .substring(0, k) + "'");
/*      */       } 
/* 1329 */     } else if (youcangetnoinfoAUMJЛ79КЙ != null) {
/* 1330 */       ((HttpUrl)super).scheme = ((HttpUrl1)youcangetnoinfoAUMJЛ79КЙ).scheme;
/*      */     } else {
/* 1332 */       throw new IllegalArgumentException("Expected URL scheme 'http' or 'https' but no colon was found");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1337 */     boolean bool1 = false;
/* 1338 */     boolean bool2 = false;
/* 1339 */     int m = slashCount((String)youcangetnoinfoAUMKСХЁис, i, j);
/* 1340 */     if (m >= 2 || youcangetnoinfoAUMJЛ79КЙ == null || !((HttpUrl1)youcangetnoinfoAUMJЛ79КЙ).scheme.equals(((HttpUrl)super).scheme)) {
/*      */       int i1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1350 */       i += m;
/*      */       
/*      */       while (true) {
/* 1353 */         i1 = Util1.delimiterOffset((String)youcangetnoinfoAUMKСХЁис, i, j, "@/\\?#");
/*      */ 
/*      */         
/* 1356 */         boolean bool = (i1 != j) ? youcangetnoinfoAUMKСХЁис.charAt(i1) : true;
/* 1357 */         switch (bool) {
/*      */           
/*      */           case true:
/* 1360 */             if (!bool2) {
/* 1361 */               int i3 = Util1.delimiterOffset((String)youcangetnoinfoAUMKСХЁис, i, i1, ':');
/*      */               
/* 1363 */               Object youcangetnoinfoAUMDч7о2Г = HttpUrl1.canonicalize((String)youcangetnoinfoAUMKСХЁис, i, i3, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
/*      */               
/* 1365 */               ((HttpUrl)super)
/*      */                 
/* 1367 */                 .encodedUsername = bool1 ? (((HttpUrl)super).encodedUsername + "%40" + youcangetnoinfoAUMDч7о2Г) : (String)youcangetnoinfoAUMDч7о2Г;
/* 1368 */               if (i3 != i1) {
/* 1369 */                 bool2 = true;
/* 1370 */                 ((HttpUrl)super).encodedPassword = HttpUrl1.canonicalize((String)youcangetnoinfoAUMKСХЁис, i3 + 1, i1, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
/*      */               } 
/*      */ 
/*      */               
/* 1374 */               bool1 = true;
/*      */             } else {
/* 1376 */               ((HttpUrl)super).encodedPassword += "%40" + HttpUrl1.canonicalize((String)youcangetnoinfoAUMKСХЁис, i, i1, " \"':;<=>@[]^`{}|/\\?#", true, false, false, true, null);
/*      */             } 
/*      */             
/* 1379 */             i = i1 + 1;
/*      */           case true:
/*      */           case true:
/*      */           case true:
/*      */           case true:
/*      */           case true:
/*      */             break;
/*      */         } 
/*      */       } 
/* 1388 */       int i2 = portColonOffset((String)youcangetnoinfoAUMKСХЁис, i, i1);
/* 1389 */       if (i2 + 1 < i1) {
/* 1390 */         ((HttpUrl)super).host = canonicalizeHost((String)youcangetnoinfoAUMKСХЁис, i, i2);
/* 1391 */         ((HttpUrl)super).port = parsePort((String)youcangetnoinfoAUMKСХЁис, i2 + 1, i1);
/* 1392 */         if (((HttpUrl)super).port == -1) {
/* 1393 */           throw new IllegalArgumentException("Invalid URL port: \"" + youcangetnoinfoAUMKСХЁис
/* 1394 */               .substring(i2 + 1, i1) + '"');
/*      */         }
/*      */       } else {
/* 1397 */         ((HttpUrl)super).host = canonicalizeHost((String)youcangetnoinfoAUMKСХЁис, i, i2);
/* 1398 */         ((HttpUrl)super).port = HttpUrl1.defaultPort(((HttpUrl)super).scheme);
/*      */       } 
/* 1400 */       if (((HttpUrl)super).host == null) {
/* 1401 */         throw new IllegalArgumentException("Invalid URL host: \"" + youcangetnoinfoAUMKСХЁис
/* 1402 */             .substring(i, i2) + '"');
/*      */       }
/* 1404 */       i = i1;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1410 */       ((HttpUrl)super).encodedUsername = youcangetnoinfoAUMJЛ79КЙ.encodedUsername();
/* 1411 */       ((HttpUrl)super).encodedPassword = youcangetnoinfoAUMJЛ79КЙ.encodedPassword();
/* 1412 */       ((HttpUrl)super).host = ((HttpUrl1)youcangetnoinfoAUMJЛ79КЙ).host;
/* 1413 */       ((HttpUrl)super).port = ((HttpUrl1)youcangetnoinfoAUMJЛ79КЙ).port;
/* 1414 */       ((HttpUrl)super).encodedPathSegments.clear();
/* 1415 */       ((HttpUrl)super).encodedPathSegments.addAll(youcangetnoinfoAUMJЛ79КЙ.encodedPathSegments());
/* 1416 */       if (i == j || youcangetnoinfoAUMKСХЁис.charAt(i) == '#') {
/* 1417 */         super.encodedQuery(youcangetnoinfoAUMJЛ79КЙ.encodedQuery());
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1422 */     int n = Util1.delimiterOffset((String)youcangetnoinfoAUMKСХЁис, i, j, "?#");
/* 1423 */     super.resolvePath((String)youcangetnoinfoAUMKСХЁис, i, n);
/* 1424 */     i = n;
/*      */ 
/*      */     
/* 1427 */     if (i < j && youcangetnoinfoAUMKСХЁис.charAt(i) == '?') {
/* 1428 */       int i1 = Util1.delimiterOffset((String)youcangetnoinfoAUMKСХЁис, i, j, '#');
/* 1429 */       ((HttpUrl)super).encodedQueryNamesAndValues = HttpUrl1.queryStringToNamesAndValues(HttpUrl1.canonicalize((String)youcangetnoinfoAUMKСХЁис, i + 1, i1, " \"'<>#", true, false, true, true, null));
/*      */       
/* 1431 */       i = i1;
/*      */     } 
/*      */ 
/*      */     
/* 1435 */     if (i < j && youcangetnoinfoAUMKСХЁис.charAt(i) == '#') {
/* 1436 */       ((HttpUrl)super).encodedFragment = HttpUrl1.canonicalize((String)youcangetnoinfoAUMKСХЁис, i + 1, j, "", true, false, false, false, null);
/*      */     }
/*      */ 
/*      */     
/* 1440 */     return (HttpUrl)this;
/*      */   }
/*      */ 
/*      */   
/*      */   public void resolvePath(Object youcangetnoinfoAQJZ97ИВт, Object youcangetnoinfoAQKAЪЕЧНт, Object youcangetnoinfoAQKBП71ио) {
/* 1445 */     if (youcangetnoinfoAQKAЪЕЧНт == youcangetnoinfoAQKBП71ио) {
/*      */       return;
/*      */     }
/*      */     
/* 1449 */     char c = youcangetnoinfoAQJZ97ИВт.charAt(youcangetnoinfoAQKAЪЕЧНт);
/* 1450 */     if (c == '/' || c == '\\') {
/*      */       
/* 1452 */       ((HttpUrl)super).encodedPathSegments.clear();
/* 1453 */       ((HttpUrl)super).encodedPathSegments.add("");
/* 1454 */       youcangetnoinfoAQKAЪЕЧНт++;
/*      */     } else {
/*      */       
/* 1457 */       ((HttpUrl)super).encodedPathSegments.set(((HttpUrl)super).encodedPathSegments.size() - 1, "");
/*      */     } 
/*      */ 
/*      */     
/* 1461 */     for (Object youcangetnoinfoAQJXЦСЩаш = youcangetnoinfoAQKAЪЕЧНт; youcangetnoinfoAQJXЦСЩаш < youcangetnoinfoAQKBП71ио; ) {
/* 1462 */       int j = Util1.delimiterOffset((String)youcangetnoinfoAQJZ97ИВт, youcangetnoinfoAQJXЦСЩаш, youcangetnoinfoAQKBП71ио, "/\\");
/* 1463 */       boolean bool = (j < youcangetnoinfoAQKBП71ио) ? true : false;
/* 1464 */       super.push((String)youcangetnoinfoAQJZ97ИВт, youcangetnoinfoAQJXЦСЩаш, j, bool, true);
/* 1465 */       int i = j;
/* 1466 */       if (bool) i++;
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void push(Object youcangetnoinfoBGGG5Ещзы, Object youcangetnoinfoBGGHН8бШО, Object youcangetnoinfoBGGIыЧГеИ, Object youcangetnoinfoBGGJим4Щц, Object youcangetnoinfoBGGKо00щб) {
/* 1473 */     Object youcangetnoinfoBGGLрхГ8й = HttpUrl1.canonicalize((String)youcangetnoinfoBGGG5Ещзы, youcangetnoinfoBGGHН8бШО, youcangetnoinfoBGGIыЧГеИ, " \"<>^`{}|/\\?#", youcangetnoinfoBGGKо00щб, false, false, true, null);
/*      */     
/* 1475 */     if (super.isDot((String)youcangetnoinfoBGGLрхГ8й)) {
/*      */       return;
/*      */     }
/* 1478 */     if (super.isDotDot((String)youcangetnoinfoBGGLрхГ8й)) {
/* 1479 */       super.pop();
/*      */       return;
/*      */     } 
/* 1482 */     if (((String)((HttpUrl)super).encodedPathSegments.get(((HttpUrl)super).encodedPathSegments.size() - 1)).isEmpty()) {
/* 1483 */       ((HttpUrl)super).encodedPathSegments.set(((HttpUrl)super).encodedPathSegments.size() - 1, youcangetnoinfoBGGLрхГ8й);
/*      */     } else {
/* 1485 */       ((HttpUrl)super).encodedPathSegments.add(youcangetnoinfoBGGLрхГ8й);
/*      */     } 
/* 1487 */     if (youcangetnoinfoBGGJим4Щц != null) {
/* 1488 */       ((HttpUrl)super).encodedPathSegments.add("");
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean isDot(Object youcangetnoinfoCZOXЙвЦй1) {
/* 1493 */     return (youcangetnoinfoCZOXЙвЦй1.equals(".") || youcangetnoinfoCZOXЙвЦй1.equalsIgnoreCase("%2e"));
/*      */   }
/*      */   
/*      */   public boolean isDotDot(Object youcangetnoinfoBZXNЁмжх4) {
/* 1497 */     return (youcangetnoinfoBZXNЁмжх4.equals("..") || youcangetnoinfoBZXNЁмжх4
/* 1498 */       .equalsIgnoreCase("%2e.") || youcangetnoinfoBZXNЁмжх4
/* 1499 */       .equalsIgnoreCase(".%2e") || youcangetnoinfoBZXNЁмжх4
/* 1500 */       .equalsIgnoreCase("%2e%2e"));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pop() {
/* 1514 */     Object youcangetnoinfoCVSOЧсм3Ш = ((HttpUrl)super).encodedPathSegments.remove(((HttpUrl)super).encodedPathSegments.size() - 1);
/*      */ 
/*      */     
/* 1517 */     if (youcangetnoinfoCVSOЧсм3Ш.isEmpty() && !((HttpUrl)super).encodedPathSegments.isEmpty()) {
/* 1518 */       ((HttpUrl)super).encodedPathSegments.set(((HttpUrl)super).encodedPathSegments.size() - 1, "");
/*      */     } else {
/* 1520 */       ((HttpUrl)super).encodedPathSegments.add("");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int schemeDelimiterOffset(Object youcangetnoinfoBNONчявКа, Object youcangetnoinfoBNOOя36zм, Object youcangetnoinfoBNOPъФюЭш) {
/* 1529 */     if (youcangetnoinfoBNOPъФюЭш - youcangetnoinfoBNOOя36zм < 2) return -1;
/*      */     
/* 1531 */     char c = youcangetnoinfoBNONчявКа.charAt(youcangetnoinfoBNOOя36zм);
/* 1532 */     if ((c < 'a' || c > 'z') && (c < 'A' || c > 'Z')) return -1;
/*      */     
/* 1534 */     for (int i = youcangetnoinfoBNOOя36zм + 1; i < youcangetnoinfoBNOPъФюЭш; ) {
/* 1535 */       char c1 = youcangetnoinfoBNONчявКа.charAt(i);
/*      */       
/* 1537 */       if ((c1 >= 'a' && c1 <= 'z') || (c1 >= 'A' && c1 <= 'Z') || (c1 >= '0' && c1 <= '9') || c1 == '+' || c1 == '-' || c1 == '.') {
/*      */         i++;
/*      */ 
/*      */         
/*      */         continue;
/*      */       } 
/*      */       
/* 1544 */       if (c1 == ':') {
/* 1545 */         return i;
/*      */       }
/* 1547 */       return -1;
/*      */     } 
/*      */ 
/*      */     
/* 1551 */     return -1;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int slashCount(Object youcangetnoinfoAVRL4фБпШ, Object youcangetnoinfoAVRMЪЬщЬЬ, Object youcangetnoinfoAVRNёЪ4юц) {
/* 1556 */     byte b = 0;
/* 1557 */     while (youcangetnoinfoAVRMЪЬщЬЬ < youcangetnoinfoAVRNёЪ4юц) {
/* 1558 */       char c = youcangetnoinfoAVRL4фБпШ.charAt(youcangetnoinfoAVRMЪЬщЬЬ);
/* 1559 */       if (c == '\\' || c == '/') {
/* 1560 */         b++;
/* 1561 */         youcangetnoinfoAVRMЪЬщЬЬ++;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1566 */     return b;
/*      */   }
/*      */ 
/*      */   
/*      */   public static int portColonOffset(Object youcangetnoinfoDJUUдЬкм4, Object youcangetnoinfoDJUVАШГо2, Object youcangetnoinfoDJUW2ЕННН) {
/* 1571 */     for (Object youcangetnoinfoDJUTкюЪЬР = youcangetnoinfoDJUVАШГо2; youcangetnoinfoDJUTкюЪЬР < youcangetnoinfoDJUW2ЕННН; youcangetnoinfoDJUTкюЪЬР++) {
/* 1572 */       switch (youcangetnoinfoDJUUдЬкм4.charAt(youcangetnoinfoDJUTкюЪЬР)) { case '[':
/*      */           do {  }
/* 1574 */           while (++youcangetnoinfoDJUTкюЪЬР < youcangetnoinfoDJUW2ЕННН && 
/* 1575 */             youcangetnoinfoDJUUдЬкм4.charAt(youcangetnoinfoDJUTкюЪЬР) != ']');
/*      */           break;
/*      */         
/*      */         case ':':
/* 1579 */           return youcangetnoinfoDJUTкюЪЬР; }
/*      */     
/*      */     } 
/* 1582 */     return youcangetnoinfoDJUW2ЕННН;
/*      */   }
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static String canonicalizeHost(Object youcangetnoinfoAWVXЁШфЙз, Object youcangetnoinfoAWVYщЧИ7й, Object youcangetnoinfoAWVZЕПВвЦ) {
/* 1588 */     Object youcangetnoinfoAWWAБпщкж = HttpUrl1.percentDecode((String)youcangetnoinfoAWVXЁШфЙз, youcangetnoinfoAWVYщЧИ7й, youcangetnoinfoAWVZЕПВвЦ, false);
/* 1589 */     return Util1.canonicalizeHost((String)youcangetnoinfoAWWAБпщкж);
/*      */   }
/*      */ 
/*      */   
/*      */   public static int parsePort(Object youcangetnoinfoWTNвиЁ9ё, Object youcangetnoinfoWTOёдЩ0п, Object youcangetnoinfoWTPъэСДИ) {
/*      */     try {
/* 1595 */       Object youcangetnoinfoWTKр5ьв5 = HttpUrl1.canonicalize((String)youcangetnoinfoWTNвиЁ9ё, youcangetnoinfoWTOёдЩ0п, youcangetnoinfoWTPъэСДИ, "", false, false, false, true, null);
/* 1596 */       int i = Integer.parseInt((String)youcangetnoinfoWTKр5ьв5);
/* 1597 */       if (i > 0 && i <= 65535) return i; 
/* 1598 */       return -1;
/* 1599 */     } catch (NumberFormatException youcangetnoinfoWTMЁЕИу8) {
/* 1600 */       return -1;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\HttpUrl.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */