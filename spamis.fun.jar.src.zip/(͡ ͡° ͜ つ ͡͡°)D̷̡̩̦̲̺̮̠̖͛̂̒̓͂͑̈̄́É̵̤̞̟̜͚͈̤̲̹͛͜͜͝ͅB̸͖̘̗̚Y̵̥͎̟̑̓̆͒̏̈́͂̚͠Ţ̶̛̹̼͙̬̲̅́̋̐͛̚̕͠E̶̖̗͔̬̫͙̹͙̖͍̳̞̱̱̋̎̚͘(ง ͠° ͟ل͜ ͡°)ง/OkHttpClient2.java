/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OkHttpClient2
/*     */   extends Internal
/*     */ {
/*     */   public void addLenient(Object youcangetnoinfoBTVQЁхССФ, Object youcangetnoinfoBTVRи4Ы1Б) {
/* 136 */     youcangetnoinfoBTVQЁхССФ.addLenient((String)youcangetnoinfoBTVRи4Ы1Б);
/*     */   }
/*     */   
/*     */   public void addLenient(Object youcangetnoinfoDWAJЯЗТъЩ, Object youcangetnoinfoDWAKМЧьиА, Object youcangetnoinfoDWALою1жЗ) {
/* 140 */     youcangetnoinfoDWAJЯЗТъЩ.addLenient((String)youcangetnoinfoDWAKМЧьиА, (String)youcangetnoinfoDWALою1жЗ);
/*     */   }
/*     */   
/*     */   public void setCache(Object youcangetnoinfoAUNE61РэН, Object youcangetnoinfoAUNFМо2сх) {
/* 144 */     youcangetnoinfoAUNE61РэН.setInternalCache((InternalCache)youcangetnoinfoAUNFМо2сх);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean connectionBecameIdle(Object youcangetnoinfoANZUйПГЁх, Object youcangetnoinfoANZVСЗ6ф7) {
/* 149 */     return youcangetnoinfoANZUйПГЁх.connectionBecameIdle((RealConnection1)youcangetnoinfoANZVСЗ6ф7);
/*     */   }
/*     */ 
/*     */   
/*     */   public void acquire(Object youcangetnoinfoBOCWЭННЛЬ, Object youcangetnoinfoBOCXи66кБ, Object youcangetnoinfoBOCY8ё13ю, @Nullable Object youcangetnoinfoBOCZЩиэьм) {
/* 154 */     youcangetnoinfoBOCWЭННЛЬ.acquire((Address)youcangetnoinfoBOCXи66кБ, (StreamAllocation1)youcangetnoinfoBOCY8ё13ю, (Route)youcangetnoinfoBOCZЩиэьм);
/*     */   }
/*     */   
/*     */   public boolean equalsNonHost(Object youcangetnoinfoDZUPуzйЯТ, Object youcangetnoinfoDZUQМ25ъЕ) {
/* 158 */     return youcangetnoinfoDZUPуzйЯТ.equalsNonHost((Address)youcangetnoinfoDZUQМ25ъЕ);
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Socket deduplicate(Object youcangetnoinfoBZWUЫя7вл, Object youcangetnoinfoBZWVчХТьФ, Object youcangetnoinfoBZWWёТдЧЫ) {
/* 163 */     return youcangetnoinfoBZWUЫя7вл.deduplicate((Address)youcangetnoinfoBZWVчХТьФ, (StreamAllocation1)youcangetnoinfoBZWWёТдЧЫ);
/*     */   }
/*     */   
/*     */   public void put(Object youcangetnoinfoDJBVСЗГзг, Object youcangetnoinfoDJBWрЮПЖв) {
/* 167 */     youcangetnoinfoDJBVСЗГзг.put((RealConnection1)youcangetnoinfoDJBWрЮПЖв);
/*     */   }
/*     */   
/*     */   public RouteDatabase routeDatabase(Object youcangetnoinfoBUUHщШътн) {
/* 171 */     return ((ConnectionPool)youcangetnoinfoBUUHщШътн).routeDatabase;
/*     */   }
/*     */   
/*     */   public int code(Object youcangetnoinfoBJGUЧаЮиь) {
/* 175 */     return ((Response1)youcangetnoinfoBJGUЧаЮиь).code;
/*     */   }
/*     */ 
/*     */   
/*     */   public void apply(Object youcangetnoinfoCARFвНсКн, Object youcangetnoinfoCARGьсУГ8, Object youcangetnoinfoCARHЗф7АК) {
/* 180 */     youcangetnoinfoCARFвНсКн.apply((SSLSocket)youcangetnoinfoCARGьсУГ8, youcangetnoinfoCARHЗф7АК);
/*     */   }
/*     */   
/*     */   public boolean isInvalidHttpUrlHost(Object youcangetnoinfoDYBEЗужБЙ) {
/* 184 */     return youcangetnoinfoDYBEЗужБЙ.getMessage().startsWith("Invalid URL host");
/*     */   }
/*     */   
/*     */   public StreamAllocation1 streamAllocation(Object youcangetnoinfoCSUCЁгВУь) {
/* 188 */     return ((RealCall2)youcangetnoinfoCSUCЁгВУь).streamAllocation();
/*     */   }
/*     */   @Nullable
/*     */   public IOException timeoutExit(Object youcangetnoinfoCGHVвЪКЕИ, @Nullable Object youcangetnoinfoCGHWзкЗЭр) {
/* 192 */     return ((RealCall2)youcangetnoinfoCGHVвЪКЕИ).timeoutExit((IOException)youcangetnoinfoCGHWзкЗЭр);
/*     */   }
/*     */   
/*     */   public Call newWebSocketCall(Object youcangetnoinfoAVJPБД1жш, Object youcangetnoinfoAVJQ8ьДНр) {
/* 196 */     return RealCall2.newRealCall((OkHttpClient)youcangetnoinfoAVJPБД1жш, (Request)youcangetnoinfoAVJQ8ьДНр, true);
/*     */   }
/*     */   
/*     */   public void initCodec(Object youcangetnoinfoMOKдЛхнС, Object youcangetnoinfoMOLЙ9Н6Ъ) {
/* 200 */     youcangetnoinfoMOKдЛхнС.initCodec((HttpCodec)youcangetnoinfoMOLЙ9Н6Ъ);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\OkHttpClient2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */