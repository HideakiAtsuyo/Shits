/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.util.concurrent.TimeUnit;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class PushableTimeout
/*    */   extends Timeout
/*    */ {
/*    */   public long originalTimeoutNanos;
/*    */   public boolean originalHasDeadline;
/*    */   public long originalDeadlineNanoTime;
/*    */   public Timeout pushed;
/*    */   
/*    */   public void push(Object youcangetnoinfoEIAEикцРЙ) {
/* 33 */     ((PushableTimeout)super).pushed = (Timeout)youcangetnoinfoEIAEикцРЙ;
/* 34 */     ((PushableTimeout)super).originalHasDeadline = youcangetnoinfoEIAEикцРЙ.hasDeadline();
/* 35 */     ((PushableTimeout)super).originalDeadlineNanoTime = ((PushableTimeout)super).originalHasDeadline ? youcangetnoinfoEIAEикцРЙ.deadlineNanoTime() : -1L;
/* 36 */     ((PushableTimeout)super).originalTimeoutNanos = youcangetnoinfoEIAEикцРЙ.timeoutNanos();
/*    */     
/* 38 */     youcangetnoinfoEIAEикцРЙ.timeout(minTimeout(((PushableTimeout)super).originalTimeoutNanos, timeoutNanos()), TimeUnit.NANOSECONDS);
/*    */     
/* 40 */     if (((PushableTimeout)super).originalHasDeadline && hasDeadline()) {
/* 41 */       youcangetnoinfoEIAEикцРЙ.deadlineNanoTime(Math.min(deadlineNanoTime(), ((PushableTimeout)super).originalDeadlineNanoTime));
/* 42 */     } else if (hasDeadline()) {
/* 43 */       youcangetnoinfoEIAEикцРЙ.deadlineNanoTime(deadlineNanoTime());
/*    */     } 
/*    */   }
/*    */   
/*    */   public void pop() {
/* 48 */     ((PushableTimeout)super).pushed.timeout(((PushableTimeout)super).originalTimeoutNanos, TimeUnit.NANOSECONDS);
/*    */     
/* 50 */     if (((PushableTimeout)super).originalHasDeadline) {
/* 51 */       ((PushableTimeout)super).pushed.deadlineNanoTime(((PushableTimeout)super).originalDeadlineNanoTime);
/*    */     } else {
/* 53 */       ((PushableTimeout)super).pushed.clearDeadline();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\PushableTimeout.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */