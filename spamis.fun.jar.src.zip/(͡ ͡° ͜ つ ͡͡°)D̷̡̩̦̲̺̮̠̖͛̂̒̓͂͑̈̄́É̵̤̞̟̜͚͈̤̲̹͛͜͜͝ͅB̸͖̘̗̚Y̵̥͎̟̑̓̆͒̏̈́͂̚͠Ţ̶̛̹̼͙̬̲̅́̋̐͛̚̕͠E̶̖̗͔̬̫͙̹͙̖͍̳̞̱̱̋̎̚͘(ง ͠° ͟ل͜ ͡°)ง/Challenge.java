/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Challenge
/*     */ {
/*     */   public final Map<String, String> authParams;
/*     */   public final String scheme;
/*     */   
/*     */   public Challenge(Object youcangetnoinfoAAOV4ЩЩ8о, Object youcangetnoinfoAAOWшмПщЕ) {
/*  34 */     this();
/*  35 */     if (youcangetnoinfoAAOV4ЩЩ8о == null) throw new NullPointerException("scheme == null"); 
/*  36 */     if (youcangetnoinfoAAOWшмПщЕ == null) throw new NullPointerException("authParams == null"); 
/*  37 */     ((Challenge)super).scheme = (String)youcangetnoinfoAAOV4ЩЩ8о;
/*  38 */     Object<Object, Object> youcangetnoinfoAAOXшпМШо = (Object<Object, Object>)new LinkedHashMap<>();
/*  39 */     for (Object youcangetnoinfoAAOTТЯэ8Й : youcangetnoinfoAAOWшмПщЕ.entrySet()) {
/*  40 */       Object youcangetnoinfoAAOSАФпнл = (youcangetnoinfoAAOTТЯэ8Й.getKey() == null) ? null : ((String)youcangetnoinfoAAOTТЯэ8Й.getKey()).toLowerCase(Locale.US);
/*  41 */       youcangetnoinfoAAOXшпМШо.put(youcangetnoinfoAAOSАФпнл, youcangetnoinfoAAOTТЯэ8Й.getValue());
/*     */     } 
/*  43 */     ((Challenge)super).authParams = Collections.unmodifiableMap((Map<?, ?>)youcangetnoinfoAAOXшпМШо);
/*     */   }
/*     */   public Challenge(Object youcangetnoinfoGGFгАяНч, Object youcangetnoinfoGGGчИя5р) {
/*  46 */     this();
/*  47 */     if (youcangetnoinfoGGFгАяНч == null) throw new NullPointerException("scheme == null"); 
/*  48 */     if (youcangetnoinfoGGGчИя5р == null) throw new NullPointerException("realm == null"); 
/*  49 */     ((Challenge)super).scheme = (String)youcangetnoinfoGGFгАяНч;
/*  50 */     ((Challenge)super).authParams = Collections.singletonMap("realm", youcangetnoinfoGGGчИя5р);
/*     */   }
/*     */ 
/*     */   
/*     */   public Challenge withCharset(Object youcangetnoinfoENOEСЕбзИ) {
/*  55 */     if (youcangetnoinfoENOEСЕбзИ == null) throw new NullPointerException("charset == null"); 
/*  56 */     Object<String, String> youcangetnoinfoENOFЗБНМР = (Object<String, String>)new LinkedHashMap<>(((Challenge)super).authParams);
/*  57 */     youcangetnoinfoENOFЗБНМР.put("charset", youcangetnoinfoENOEСЕбзИ.name());
/*  58 */     return new Challenge(((Challenge)super).scheme, (Map<String, String>)youcangetnoinfoENOFЗБНМР);
/*     */   }
/*     */ 
/*     */   
/*     */   public String scheme() {
/*  63 */     return ((Challenge)super).scheme;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map<String, String> authParams() {
/*  71 */     return ((Challenge)super).authParams;
/*     */   }
/*     */ 
/*     */   
/*     */   public String realm() {
/*  76 */     return ((Challenge)super).authParams.get("realm");
/*     */   }
/*     */ 
/*     */   
/*     */   public Charset charset() {
/*  81 */     Object youcangetnoinfoDLNPдЬ8ЮЖ = ((Challenge)super).authParams.get("charset");
/*  82 */     if (youcangetnoinfoDLNPдЬ8ЮЖ != null) {
/*     */       try {
/*  84 */         return Charset.forName((String)youcangetnoinfoDLNPдЬ8ЮЖ);
/*  85 */       } catch (Exception exception) {}
/*     */     }
/*     */     
/*  88 */     return StandardCharsets.ISO_8859_1;
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object youcangetnoinfoHIRРнЧХП) {
/*  92 */     return (youcangetnoinfoHIRРнЧХП instanceof Challenge && ((Challenge)youcangetnoinfoHIRРнЧХП).scheme
/*  93 */       .equals(((Challenge)super).scheme) && ((Challenge)youcangetnoinfoHIRРнЧХП).authParams
/*  94 */       .equals(((Challenge)super).authParams));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  98 */     int i = 29;
/*  99 */     i = 31 * i + ((Challenge)super).scheme.hashCode();
/* 100 */     i = 31 * i + ((Challenge)super).authParams.hashCode();
/* 101 */     return i;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 105 */     return ((Challenge)super).scheme + " authParams=" + ((Challenge)super).authParams;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Challenge.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */