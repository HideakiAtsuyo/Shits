/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Writer
/*     */   implements Closeable
/*     */ {
/*     */   public boolean closed;
/*     */   public final BufferedSink sink;
/*  47 */   public static final Logger logger = Logger.getLogger(Http2.class.getName());
/*     */   
/*     */   public int maxFrameSize;
/*     */   
/*     */   public final Buffer2 hpackBuffer;
/*     */   
/*     */   public final Hpack2 hpackWriter;
/*     */   public final boolean client;
/*     */   
/*     */   public Http2Writer(Object youcangetnoinfoAZKCмЧкЪы, Object youcangetnoinfoAZKDЮХМВу) {
/*  57 */     this();
/*  58 */     ((Http2Writer)super).sink = (BufferedSink)youcangetnoinfoAZKCмЧкЪы;
/*  59 */     ((Http2Writer)super).client = youcangetnoinfoAZKDЮХМВу;
/*  60 */     ((Http2Writer)super).hpackBuffer = new Buffer2();
/*  61 */     ((Http2Writer)super).hpackWriter = new Hpack2(((Http2Writer)super).hpackBuffer);
/*  62 */     ((Http2Writer)super).maxFrameSize = 16384;
/*     */   }
/*     */   
/*     */   public synchronized void connectionPreface() throws IOException {
/*  66 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/*  67 */     if (!((Http2Writer)super).client)
/*  68 */       return;  if (logger.isLoggable(Level.FINE)) {
/*  69 */       logger.fine(Util1.format(">> CONNECTION %s", new Object[] { Http2.CONNECTION_PREFACE.hex() }));
/*     */     }
/*  71 */     ((Http2Writer)super).sink.write(Http2.CONNECTION_PREFACE.toByteArray());
/*  72 */     ((Http2Writer)super).sink.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void applyAndAckSettings(Object youcangetnoinfoEMGHЧйХМЭ) throws IOException {
/*  77 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/*  78 */     ((Http2Writer)super).maxFrameSize = youcangetnoinfoEMGHЧйХМЭ.getMaxFrameSize(((Http2Writer)super).maxFrameSize);
/*  79 */     if (youcangetnoinfoEMGHЧйХМЭ.getHeaderTableSize() != -1) {
/*  80 */       ((Http2Writer)super).hpackWriter.setHeaderTableSizeSetting(youcangetnoinfoEMGHЧйХМЭ.getHeaderTableSize());
/*     */     }
/*  82 */     boolean bool1 = false;
/*  83 */     byte b = 4;
/*  84 */     boolean bool2 = true;
/*  85 */     boolean bool3 = false;
/*  86 */     super.frameHeader(bool3, bool1, b, bool2);
/*  87 */     ((Http2Writer)super).sink.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void pushPromise(Object youcangetnoinfoAINXлбщшЖ, Object youcangetnoinfoAINYфИ9фё, Object youcangetnoinfoAINZР6ОКю) throws IOException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield closed : Z
/*     */     //   4: ifeq -> 17
/*     */     //   7: new java/io/IOException
/*     */     //   10: dup
/*     */     //   11: ldc 'closed'
/*     */     //   13: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   16: athrow
/*     */     //   17: aload_0
/*     */     //   18: getfield hpackWriter : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Hpack2;
/*     */     //   21: aload_3
/*     */     //   22: invokevirtual writeHeaders : (Ljava/util/List;)V
/*     */     //   25: aload_0
/*     */     //   26: getfield hpackBuffer : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   29: invokevirtual size : ()J
/*     */     //   32: lstore #4
/*     */     //   34: aload_0
/*     */     //   35: getfield maxFrameSize : I
/*     */     //   38: iconst_4
/*     */     //   39: isub
/*     */     //   40: i2l
/*     */     //   41: lload #4
/*     */     //   43: invokestatic min : (JJ)J
/*     */     //   46: l2i
/*     */     //   47: istore #6
/*     */     //   49: iconst_5
/*     */     //   50: istore #7
/*     */     //   52: lload #4
/*     */     //   54: iload #6
/*     */     //   56: i2l
/*     */     //   57: lcmp
/*     */     //   58: ifne -> 65
/*     */     //   61: iconst_4
/*     */     //   62: goto -> 66
/*     */     //   65: iconst_0
/*     */     //   66: istore #8
/*     */     //   68: aload_0
/*     */     //   69: iload_1
/*     */     //   70: iload #6
/*     */     //   72: iconst_4
/*     */     //   73: iadd
/*     */     //   74: iload #7
/*     */     //   76: iload #8
/*     */     //   78: invokevirtual frameHeader : (IIBB)V
/*     */     //   81: aload_0
/*     */     //   82: getfield sink : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   85: iload_2
/*     */     //   86: ldc 2147483647
/*     */     //   88: iand
/*     */     //   89: invokeinterface writeInt : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   94: pop
/*     */     //   95: aload_0
/*     */     //   96: getfield sink : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   99: aload_0
/*     */     //   100: getfield hpackBuffer : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   103: iload #6
/*     */     //   105: i2l
/*     */     //   106: invokeinterface write : (L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;J)V
/*     */     //   111: lload #4
/*     */     //   113: iload #6
/*     */     //   115: i2l
/*     */     //   116: lcmp
/*     */     //   117: ifle -> 131
/*     */     //   120: aload_0
/*     */     //   121: iload_1
/*     */     //   122: lload #4
/*     */     //   124: iload #6
/*     */     //   126: i2l
/*     */     //   127: lsub
/*     */     //   128: invokespecial writeContinuationFrames : (IJ)V
/*     */     //   131: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #105	-> 0
/*     */     //   #106	-> 17
/*     */     //   #108	-> 25
/*     */     //   #109	-> 34
/*     */     //   #110	-> 49
/*     */     //   #111	-> 52
/*     */     //   #112	-> 68
/*     */     //   #113	-> 81
/*     */     //   #114	-> 95
/*     */     //   #116	-> 111
/*     */     //   #117	-> 131
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   49	83	6	youcangetnoinfoAIOBь9БЖФ	Ljava/lang/Object;
/*     */     //   34	98	4	youcangetnoinfoAIOAьЦйЮб	Ljava/lang/Object;
/*     */     //   0	132	1	youcangetnoinfoAINXлбщшЖ	Ljava/lang/Object;
/*     */     //   0	132	2	youcangetnoinfoAINYфИ9фё	Ljava/lang/Object;
/*     */     //   68	64	8	youcangetnoinfoAIODтчЁ73	Ljava/lang/Object;
/*     */     //   0	132	0	youcangetnoinfoAINWЬ6сЩГ	Ljava/lang/Object;
/*     */     //   52	80	7	youcangetnoinfoAIOCбсЛлЛ	Ljava/lang/Object;
/*     */     //   0	132	3	youcangetnoinfoAINZР6ОКю	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void flush() throws IOException {
/* 120 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/* 121 */     ((Http2Writer)super).sink.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void rstStream(Object youcangetnoinfoAGZZСКкРЦ, Object youcangetnoinfoAHAAё7юэЧ) throws IOException {
/* 126 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/* 127 */     if (((ErrorCode)youcangetnoinfoAHAAё7юэЧ).httpCode == -1) throw new IllegalArgumentException();
/*     */     
/* 129 */     byte b1 = 4;
/* 130 */     byte b2 = 3;
/* 131 */     boolean bool = false;
/* 132 */     super.frameHeader(youcangetnoinfoAGZZСКкРЦ, b1, b2, bool);
/* 133 */     ((Http2Writer)super).sink.writeInt(((ErrorCode)youcangetnoinfoAHAAё7юэЧ).httpCode);
/* 134 */     ((Http2Writer)super).sink.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public int maxDataLength() {
/* 139 */     return ((Http2Writer)super).maxFrameSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void data(Object youcangetnoinfoEFDVф8Ы9й, Object youcangetnoinfoEFDWРЮп0б, Object youcangetnoinfoEFDX3ьм0Э, Object youcangetnoinfoEFDY4Хъш9) throws IOException {
/* 152 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/* 153 */     byte b = 0;
/* 154 */     if (youcangetnoinfoEFDVф8Ы9й != null) b = (byte)(b | 0x1); 
/* 155 */     super.dataFrame(youcangetnoinfoEFDWРЮп0б, b, (Buffer2)youcangetnoinfoEFDX3ьм0Э, youcangetnoinfoEFDY4Хъш9);
/*     */   }
/*     */   
/*     */   public void dataFrame(Object youcangetnoinfoBHPUР7ббё, Object youcangetnoinfoBHPVЮЖсТП, Object youcangetnoinfoBHPWМД88ц, Object youcangetnoinfoBHPX8Атуо) throws IOException {
/* 159 */     boolean bool = false;
/* 160 */     super.frameHeader(youcangetnoinfoBHPUР7ббё, youcangetnoinfoBHPX8Атуо, bool, youcangetnoinfoBHPVЮЖсТП);
/* 161 */     if (youcangetnoinfoBHPX8Атуо > null) {
/* 162 */       ((Http2Writer)super).sink.write((Buffer2)youcangetnoinfoBHPWМД88ц, youcangetnoinfoBHPX8Атуо);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void settings(Object youcangetnoinfoAZKUхЭМдр) throws IOException {
/* 168 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/* 169 */     int i = youcangetnoinfoAZKUхЭМдр.size() * 6;
/* 170 */     byte b1 = 4;
/* 171 */     boolean bool1 = false;
/* 172 */     boolean bool2 = false;
/* 173 */     super.frameHeader(bool2, i, b1, bool1);
/* 174 */     for (byte b2 = 0; b2 < 10; b2++) {
/* 175 */       if (youcangetnoinfoAZKUхЭМдр.isSet(b2)) {
/* 176 */         byte b = b2;
/* 177 */         if (b == 4) {
/* 178 */           b = 3;
/* 179 */         } else if (b == 7) {
/* 180 */           b = 4;
/*     */         } 
/* 182 */         ((Http2Writer)super).sink.writeShort(b);
/* 183 */         ((Http2Writer)super).sink.writeInt(youcangetnoinfoAZKUхЭМдр.get(b2));
/*     */       } 
/* 185 */     }  ((Http2Writer)super).sink.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void ping(Object youcangetnoinfoAHYKвнЩЖК, Object youcangetnoinfoAHYLиМйз1, Object youcangetnoinfoAHYM1Хбхъ) throws IOException {
/* 193 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/* 194 */     byte b1 = 8;
/* 195 */     byte b2 = 6;
/* 196 */     boolean bool1 = (youcangetnoinfoAHYKвнЩЖК != null) ? true : false;
/* 197 */     boolean bool2 = false;
/* 198 */     super.frameHeader(bool2, b1, b2, bool1);
/* 199 */     ((Http2Writer)super).sink.writeInt(youcangetnoinfoAHYLиМйз1);
/* 200 */     ((Http2Writer)super).sink.writeInt(youcangetnoinfoAHYM1Хбхъ);
/* 201 */     ((Http2Writer)super).sink.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void goAway(Object youcangetnoinfoBPKMЧтшЙв, Object youcangetnoinfoBPKNЭЧЩче, Object youcangetnoinfoBPKOёчкШО) throws IOException {
/* 214 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/* 215 */     if (((ErrorCode)youcangetnoinfoBPKNЭЧЩче).httpCode == -1) throw Http2.illegalArgument("errorCode.httpCode == -1", new Object[0]); 
/* 216 */     int i = 8 + youcangetnoinfoBPKOёчкШО.length;
/* 217 */     byte b = 7;
/* 218 */     boolean bool1 = false;
/* 219 */     boolean bool2 = false;
/* 220 */     super.frameHeader(bool2, i, b, bool1);
/* 221 */     ((Http2Writer)super).sink.writeInt(youcangetnoinfoBPKMЧтшЙв);
/* 222 */     ((Http2Writer)super).sink.writeInt(((ErrorCode)youcangetnoinfoBPKNЭЧЩче).httpCode);
/* 223 */     if (youcangetnoinfoBPKOёчкШО.length > 0) {
/* 224 */       ((Http2Writer)super).sink.write((byte[])youcangetnoinfoBPKOёчкШО);
/*     */     }
/* 226 */     ((Http2Writer)super).sink.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void windowUpdate(Object youcangetnoinfoVLTКобфХ, Object youcangetnoinfoVLU8Втдо) throws IOException {
/* 234 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/* 235 */     if (youcangetnoinfoVLU8Втдо == 0L || youcangetnoinfoVLU8Втдо > 2147483647L)
/* 236 */       throw Http2.illegalArgument("windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: %s", new Object[] {
/* 237 */             Long.valueOf(youcangetnoinfoVLU8Втдо)
/*     */           }); 
/* 239 */     byte b1 = 4;
/* 240 */     byte b2 = 8;
/* 241 */     boolean bool = false;
/* 242 */     super.frameHeader(youcangetnoinfoVLTКобфХ, b1, b2, bool);
/* 243 */     ((Http2Writer)super).sink.writeInt((int)youcangetnoinfoVLU8Втдо);
/* 244 */     ((Http2Writer)super).sink.flush();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void frameHeader(Object youcangetnoinfoADJDчшЮуМ, Object youcangetnoinfoADJEЖРкЛЮ, Object youcangetnoinfoADJFМСллЭ, Object youcangetnoinfoADJG4СЗёЗ) throws IOException {
/*     */     // Byte code:
/*     */     //   0: getstatic (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Http2Writer.logger : Ljava/util/logging/Logger;
/*     */     //   3: getstatic java/util/logging/Level.FINE : Ljava/util/logging/Level;
/*     */     //   6: invokevirtual isLoggable : (Ljava/util/logging/Level;)Z
/*     */     //   9: ifeq -> 27
/*     */     //   12: getstatic (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Http2Writer.logger : Ljava/util/logging/Logger;
/*     */     //   15: iconst_0
/*     */     //   16: iload_1
/*     */     //   17: iload_2
/*     */     //   18: iload_3
/*     */     //   19: iload #4
/*     */     //   21: invokestatic frameLog : (ZIIBB)Ljava/lang/String;
/*     */     //   24: invokevirtual fine : (Ljava/lang/String;)V
/*     */     //   27: iload_2
/*     */     //   28: aload_0
/*     */     //   29: getfield maxFrameSize : I
/*     */     //   32: if_icmple -> 62
/*     */     //   35: ldc 'FRAME_SIZE_ERROR length > %d: %d'
/*     */     //   37: iconst_2
/*     */     //   38: anewarray java/lang/Object
/*     */     //   41: dup
/*     */     //   42: iconst_0
/*     */     //   43: aload_0
/*     */     //   44: getfield maxFrameSize : I
/*     */     //   47: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   50: aastore
/*     */     //   51: dup
/*     */     //   52: iconst_1
/*     */     //   53: iload_2
/*     */     //   54: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   57: aastore
/*     */     //   58: invokestatic illegalArgument : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;
/*     */     //   61: athrow
/*     */     //   62: iload_1
/*     */     //   63: ldc -2147483648
/*     */     //   65: iand
/*     */     //   66: ifeq -> 86
/*     */     //   69: ldc 'reserved bit set: %s'
/*     */     //   71: iconst_1
/*     */     //   72: anewarray java/lang/Object
/*     */     //   75: dup
/*     */     //   76: iconst_0
/*     */     //   77: iload_1
/*     */     //   78: invokestatic valueOf : (I)Ljava/lang/Integer;
/*     */     //   81: aastore
/*     */     //   82: invokestatic illegalArgument : (Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/IllegalArgumentException;
/*     */     //   85: athrow
/*     */     //   86: aload_0
/*     */     //   87: getfield sink : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   90: iload_2
/*     */     //   91: invokestatic writeMedium : (L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;I)V
/*     */     //   94: aload_0
/*     */     //   95: getfield sink : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   98: iload_3
/*     */     //   99: sipush #255
/*     */     //   102: iand
/*     */     //   103: invokeinterface writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   108: pop
/*     */     //   109: aload_0
/*     */     //   110: getfield sink : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   113: iload #4
/*     */     //   115: sipush #255
/*     */     //   118: iand
/*     */     //   119: invokeinterface writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   124: pop
/*     */     //   125: aload_0
/*     */     //   126: getfield sink : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   129: iload_1
/*     */     //   130: ldc 2147483647
/*     */     //   132: iand
/*     */     //   133: invokeinterface writeInt : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   138: pop
/*     */     //   139: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #248	-> 0
/*     */     //   #249	-> 27
/*     */     //   #250	-> 35
/*     */     //   #252	-> 62
/*     */     //   #253	-> 86
/*     */     //   #254	-> 94
/*     */     //   #255	-> 109
/*     */     //   #256	-> 125
/*     */     //   #257	-> 139
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	140	1	youcangetnoinfoADJDчшЮуМ	Ljava/lang/Object;
/*     */     //   0	140	2	youcangetnoinfoADJEЖРкЛЮ	Ljava/lang/Object;
/*     */     //   0	140	0	youcangetnoinfoADJCяzРжЧ	Ljava/lang/Object;
/*     */     //   0	140	3	youcangetnoinfoADJFМСллЭ	Ljava/lang/Object;
/*     */     //   0	140	4	youcangetnoinfoADJG4СЗёЗ	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() throws IOException {
/* 260 */     ((Http2Writer)super).closed = true;
/* 261 */     ((Http2Writer)super).sink.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void writeMedium(Object youcangetnoinfoDHOPЙр7КФ, Object youcangetnoinfoDHOQХжЕюЙ) throws IOException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: iload_1
/*     */     //   2: bipush #16
/*     */     //   4: iushr
/*     */     //   5: sipush #255
/*     */     //   8: iand
/*     */     //   9: invokeinterface writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   14: pop
/*     */     //   15: aload_0
/*     */     //   16: iload_1
/*     */     //   17: bipush #8
/*     */     //   19: iushr
/*     */     //   20: sipush #255
/*     */     //   23: iand
/*     */     //   24: invokeinterface writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   29: pop
/*     */     //   30: aload_0
/*     */     //   31: iload_1
/*     */     //   32: sipush #255
/*     */     //   35: iand
/*     */     //   36: invokeinterface writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/BufferedSink;
/*     */     //   41: pop
/*     */     //   42: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #265	-> 0
/*     */     //   #266	-> 15
/*     */     //   #267	-> 30
/*     */     //   #268	-> 42
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	43	1	youcangetnoinfoDHOQХжЕюЙ	Ljava/lang/Object;
/*     */     //   0	43	0	youcangetnoinfoDHOPЙр7КФ	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeContinuationFrames(Object youcangetnoinfoAXHУАК9К, Object youcangetnoinfoAXIьЦВОи) throws IOException {
/* 271 */     while (youcangetnoinfoAXIьЦВОи > 0L) {
/* 272 */       int i = (int)Math.min(((Http2Writer)super).maxFrameSize, youcangetnoinfoAXIьЦВОи);
/* 273 */       long l = youcangetnoinfoAXIьЦВОи - i;
/* 274 */       super.frameHeader(youcangetnoinfoAXHУАК9К, i, (byte)9, (l == 0L) ? 4 : 0);
/* 275 */       ((Http2Writer)super).sink.write(((Http2Writer)super).hpackBuffer, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void headers(Object youcangetnoinfoCTMYнБёШн, Object youcangetnoinfoCTMZХЮсЭч, Object youcangetnoinfoCTNAНХхсА) throws IOException {
/* 281 */     if (((Http2Writer)super).closed) throw new IOException("closed"); 
/* 282 */     ((Http2Writer)super).hpackWriter.writeHeaders((List)youcangetnoinfoCTNAНХхсА);
/*     */     
/* 284 */     long l = ((Http2Writer)super).hpackBuffer.size();
/* 285 */     int i = (int)Math.min(((Http2Writer)super).maxFrameSize, l);
/* 286 */     boolean bool = true;
/* 287 */     byte b = (l == i) ? 4 : 0;
/* 288 */     if (youcangetnoinfoCTMYнБёШн != null) b = (byte)(b | 0x1); 
/* 289 */     super.frameHeader(youcangetnoinfoCTMZХЮсЭч, i, bool, b);
/* 290 */     ((Http2Writer)super).sink.write(((Http2Writer)super).hpackBuffer, i);
/*     */     
/* 292 */     if (l > i) super.writeContinuationFrames(youcangetnoinfoCTMZХЮсЭч, l - i); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http2Writer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */