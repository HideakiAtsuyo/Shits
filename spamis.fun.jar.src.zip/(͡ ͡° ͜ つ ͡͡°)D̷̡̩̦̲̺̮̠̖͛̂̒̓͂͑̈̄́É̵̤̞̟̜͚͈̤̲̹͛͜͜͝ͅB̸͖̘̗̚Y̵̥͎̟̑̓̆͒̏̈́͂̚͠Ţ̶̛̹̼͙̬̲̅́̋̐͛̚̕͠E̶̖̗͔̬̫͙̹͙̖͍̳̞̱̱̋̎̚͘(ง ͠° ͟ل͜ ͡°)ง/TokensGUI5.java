/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import fun.spamis.spammer.SpamIsFun;
/*    */ import java.awt.event.ActionListener;
/*    */ import java.io.IOException;
/*    */ import java.nio.charset.Charset;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Paths;
/*    */ import javax.swing.table.DefaultTableModel;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TokensGUI5
/*    */   implements ActionListener
/*    */ {
/*    */   public final TokensGUI1 this$0;
/*    */   public final DefaultTableModel val$tokenModel;
/*    */   
/*    */   public TokensGUI5() {
/* 81 */     this();
/*    */   }
/*    */   public void actionPerformed(Object youcangetnoinfoCMPJгмроЬ) {
/*    */     try {
/* 85 */       int i = SpamIsFun.tokens.size();
/* 86 */       Object youcangetnoinfoCMPHщФхбШ = FileUtils.loadTextFile();
/* 87 */       for (String youcangetnoinfoCMPFИЁяфз : Files.readAllLines(Paths.get(youcangetnoinfoCMPHщФхбШ.toString(), new String[0]), 
/* 88 */           Charset.defaultCharset())) {
/* 89 */         i++;
/* 90 */         Object youcangetnoinfoCMPEыёуЗю = youcangetnoinfoCMPFИЁяфз.split(";");
/* 91 */         SpamIsFun.tokens.put(Integer.valueOf(i), youcangetnoinfoCMPEыёуЗю[0]);
/* 92 */         tokenModel.addRow(new Object[] { Integer.valueOf(i), youcangetnoinfoCMPEыёуЗю[0] });
/*    */       } 
/* 94 */       FileUtils.writeFile(SpamIsFun.homeDir + "tokens.spamisfun", youcangetnoinfoCMPHщФхбШ.getAbsolutePath());
/* 95 */     } catch (IOException iOException) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\TokensGUI5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */