/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ServerSpammer5
/*     */   extends JPanel
/*     */ {
/*     */   public static boolean enabled = false;
/*     */   public static final long serialVersionUID = 5863841638739212758L;
/*     */   public static JButton serverSpamStartBtn;
/*     */   public static JButton serverSpamStopBtn;
/*     */   
/*     */   public ServerSpammer5() {
/*  33 */     super.initialize();
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  37 */     setLayout((LayoutManager)null);
/*     */     
/*  39 */     Object youcangetnoinfoBZDOЗУжЦГ = new JLabel("Channel id");
/*  40 */     youcangetnoinfoBZDOЗУжЦГ.setBounds(28, 12, 249, 15);
/*  41 */     add((Component)youcangetnoinfoBZDOЗУжЦГ);
/*     */     
/*  43 */     Object youcangetnoinfoBZDPачЦдВ = new JTextField();
/*  44 */     youcangetnoinfoBZDPачЦдВ.setColumns(10);
/*  45 */     youcangetnoinfoBZDPачЦдВ.setBounds(28, 27, 341, 32);
/*  46 */     add((Component)youcangetnoinfoBZDPачЦдВ);
/*     */     
/*  48 */     Object youcangetnoinfoBZDQКЛАсЭ = new JLabel("Text (Live)");
/*  49 */     youcangetnoinfoBZDQКЛАсЭ.setBounds(28, 71, 249, 15);
/*  50 */     add((Component)youcangetnoinfoBZDQКЛАсЭ);
/*     */     
/*  52 */     Object youcangetnoinfoBZDRуХ8зА = new JTextArea();
/*  53 */     Object youcangetnoinfoBZDSжЫЬТБ = new JScrollPane((Component)youcangetnoinfoBZDRуХ8зА, 22, 30);
/*     */     
/*  55 */     youcangetnoinfoBZDSжЫЬТБ.setBounds(28, 86, 341, 115);
/*  56 */     add((Component)youcangetnoinfoBZDSжЫЬТБ);
/*     */     
/*  58 */     Object youcangetnoinfoBZDTЪ3Вж4 = new JLabel("Delay: 100ms");
/*  59 */     youcangetnoinfoBZDTЪ3Вж4.setBounds(38, 214, 293, 15);
/*  60 */     add((Component)youcangetnoinfoBZDTЪ3Вж4);
/*     */     
/*  62 */     Object youcangetnoinfoBZDUЯЯбнц = new JSlider();
/*  63 */     youcangetnoinfoBZDUЯЯбнц.setValue(100);
/*  64 */     youcangetnoinfoBZDUЯЯбнц.setMinimum(50);
/*  65 */     youcangetnoinfoBZDUЯЯбнц.setMaximum(3000);
/*  66 */     youcangetnoinfoBZDUЯЯбнц.setBounds(38, 230, 331, 32);
/*  67 */     youcangetnoinfoBZDUЯЯбнц.addChangeListener(new ServerSpammer3((ServerSpammer5)this, (JLabel)youcangetnoinfoBZDTЪ3Вж4, (JSlider)youcangetnoinfoBZDUЯЯбнц));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  73 */     add((Component)youcangetnoinfoBZDUЯЯбнц);
/*     */     
/*  75 */     Object youcangetnoinfoBZDV46ЦНй = new JCheckBox("Text to speech (/tts)");
/*  76 */     youcangetnoinfoBZDV46ЦНй.setBounds(38, 264, 307, 23);
/*  77 */     add((Component)youcangetnoinfoBZDV46ЦНй);
/*     */     
/*  79 */     serverSpamStartBtn = new JButton("Start");
/*  80 */     serverSpamStartBtn.setIcon(new ImageIcon(getClass().getResource("/ui/start.png")));
/*  81 */     serverSpamStartBtn.setBounds(28, 310, 157, 32);
/*  82 */     serverSpamStartBtn.addActionListener(new ServerSpammer1((ServerSpammer5)this, (JTextField)youcangetnoinfoBZDPачЦдВ, (JTextArea)youcangetnoinfoBZDRуХ8зА, (JCheckBox)youcangetnoinfoBZDV46ЦНй, (JSlider)youcangetnoinfoBZDUЯЯбнц));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     add(serverSpamStartBtn);
/*     */     
/* 126 */     serverSpamStopBtn = new JButton("Stop");
/* 127 */     serverSpamStopBtn.setIcon(new ImageIcon(getClass().getResource("/ui/stop.png")));
/* 128 */     serverSpamStopBtn.setEnabled(false);
/* 129 */     serverSpamStopBtn.setBounds(212, 310, 157, 32);
/* 130 */     serverSpamStopBtn.addActionListener(new ServerSpammer((ServerSpammer5)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 138 */     add(serverSpamStopBtn);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ServerSpammer5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */