/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.FileReader;
/*    */ import java.io.IOException;
/*    */ import java.nio.file.Files;
/*    */ import java.nio.file.Paths;
/*    */ import java.util.Random;
/*    */ import java.util.Scanner;
/*    */ import javax.swing.JFileChooser;
/*    */ 
/*    */ public class FileUtils {
/*    */   public FileUtils() {
/* 15 */     this();
/*    */   }
/*    */   public static File loadTextFile() throws FileNotFoundException {
/* 18 */     Object youcangetnoinfoCZNQЗАцов = new JFileChooser();
/* 19 */     youcangetnoinfoCZNQЗАцов.setCurrentDirectory(new File(System.getProperty("user.home")));
/* 20 */     int i = youcangetnoinfoCZNQЗАцов.showOpenDialog(null);
/* 21 */     Object youcangetnoinfoCZNSёчРХ0 = null;
/* 22 */     if (i == 0) {
/* 23 */       youcangetnoinfoCZNSёчРХ0 = youcangetnoinfoCZNQЗАцов.getSelectedFile();
/*    */     }
/* 25 */     return (File)youcangetnoinfoCZNSёчРХ0;
/*    */   }
/*    */   
/*    */   public static File saveTextFile() throws FileNotFoundException {
/* 29 */     Object youcangetnoinfoDSNHЬивФс = new JFileChooser();
/* 30 */     youcangetnoinfoDSNHЬивФс.setCurrentDirectory(new File(System.getProperty("user.home")));
/* 31 */     int i = youcangetnoinfoDSNHЬивФс.showSaveDialog(null);
/* 32 */     Object youcangetnoinfoDSNJОЖЫ8И = null;
/* 33 */     if (i == 0) {
/* 34 */       youcangetnoinfoDSNJОЖЫ8И = youcangetnoinfoDSNHЬивФс.getSelectedFile();
/*    */     }
/* 36 */     return (File)youcangetnoinfoDSNJОЖЫ8И;
/*    */   }
/*    */   
/*    */   public static String readTextFile(Object youcangetnoinfoBOTЯЧРЩж) throws FileNotFoundException {
/* 40 */     Object youcangetnoinfoBOUЕЖ0фа = null;
/* 41 */     Object youcangetnoinfoBOVрёБЗЮ = new Random();
/* 42 */     byte b = 0;
/* 43 */     for (Object youcangetnoinfoBOSёЯЛЗЧ = new Scanner((String)youcangetnoinfoBOTЯЧРЩж); youcangetnoinfoBOSёЯЛЗЧ.hasNext(); ) {
/* 44 */       b++;
/* 45 */       Object youcangetnoinfoBORЦЭгаи = youcangetnoinfoBOSёЯЛЗЧ.nextLine();
/* 46 */       if (youcangetnoinfoBOVрёБЗЮ.nextInt(b) == 0) {
/* 47 */         youcangetnoinfoBOUЕЖ0фа = youcangetnoinfoBORЦЭгаи;
/*    */       }
/*    */     } 
/* 50 */     return (String)youcangetnoinfoBOUЕЖ0фа;
/*    */   }
/*    */   
/*    */   public static String readFile(Object youcangetnoinfoAMVBОш7чЕ) throws IOException {
/* 54 */     Object youcangetnoinfoAMVCвеz7ч = null;
/* 55 */     Object youcangetnoinfoAMVD3zцл1 = new File((String)youcangetnoinfoAMVBОш7чЕ);
/* 56 */     Object youcangetnoinfoAMVEсДь37 = null;
/*    */     try {
/* 58 */       youcangetnoinfoAMVEсДь37 = new FileReader((File)youcangetnoinfoAMVD3zцл1);
/* 59 */       Object youcangetnoinfoAMUZяЕКЭ8 = new char[(int)youcangetnoinfoAMVD3zцл1.length()];
/* 60 */       youcangetnoinfoAMVEсДь37.read((char[])youcangetnoinfoAMUZяЕКЭ8);
/* 61 */       youcangetnoinfoAMVCвеz7ч = new String((char[])youcangetnoinfoAMUZяЕКЭ8);
/* 62 */       youcangetnoinfoAMVEсДь37.close();
/* 63 */     } catch (IOException youcangetnoinfoAMVAЧТи3Е) {
/* 64 */       youcangetnoinfoAMVAЧТи3Е.printStackTrace();
/*    */     } finally {
/* 66 */       if (youcangetnoinfoAMVEсДь37 != null) {
/* 67 */         youcangetnoinfoAMVEсДь37.close();
/*    */       }
/*    */     } 
/* 70 */     return (String)youcangetnoinfoAMVCвеz7ч;
/*    */   }
/*    */   
/*    */   public static void writeFile(Object youcangetnoinfoEGAPЖМнНТ, Object youcangetnoinfoEGAQТжЧЁр) {
/*    */     try {
/* 75 */       Files.write(Paths.get((String)youcangetnoinfoEGAPЖМнНТ, new String[0]), youcangetnoinfoEGAQТжЧЁр.getBytes(), new java.nio.file.OpenOption[0]);
/* 76 */     } catch (IOException youcangetnoinfoEGAOеЮпйц) {
/* 77 */       youcangetnoinfoEGAOеЮпйц.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\FileUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */