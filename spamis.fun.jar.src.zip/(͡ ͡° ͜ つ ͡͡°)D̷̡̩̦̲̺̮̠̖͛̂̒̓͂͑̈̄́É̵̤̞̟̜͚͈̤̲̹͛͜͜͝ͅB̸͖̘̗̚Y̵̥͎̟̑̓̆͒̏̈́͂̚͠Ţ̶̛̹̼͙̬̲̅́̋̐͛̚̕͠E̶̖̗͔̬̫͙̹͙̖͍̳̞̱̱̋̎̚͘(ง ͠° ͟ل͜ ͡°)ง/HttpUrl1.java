/*      */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*      */ 
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.nio.charset.Charset;
/*      */ import java.nio.charset.StandardCharsets;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.LinkedHashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import javax.annotation.Nullable;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class HttpUrl1
/*      */ {
/*      */   public final String password;
/*      */   public static final String FRAGMENT_ENCODE_SET_URI = " \"#<>\\^`{|}";
/*      */   public static final String PATH_SEGMENT_ENCODE_SET = " \"<>^`{}|/\\?#";
/*      */   public static final String QUERY_COMPONENT_ENCODE_SET_URI = "\\^`{|}";
/*      */   public final String url;
/*      */   @Nullable
/*      */   public final List<String> queryNamesAndValues;
/*      */   public static final String QUERY_COMPONENT_REENCODE_SET = " \"'<>#&=";
/*      */   public static final String FRAGMENT_ENCODE_SET = "";
/*      */   public final List<String> pathSegments;
/*      */   public final String username;
/*      */   public final int port;
/*      */   @Nullable
/*      */   public final String fragment;
/*  290 */   public static final char[] HEX_DIGITS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String host;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String PASSWORD_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String USERNAME_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final String scheme;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String PATH_SEGMENT_ENCODE_SET_URI = "[]";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String QUERY_ENCODE_SET = " \"'<>#";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String FORM_ENCODE_SET = " \"':;<=>@[]^`{}|/\\?#&!$(),~";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final String QUERY_COMPONENT_ENCODE_SET = " !\"#$&'(),/:;<=>?@[]\\^`{|}~";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HttpUrl1(Object youcangetnoinfoAAEJтЦ8Ща) {
/*  339 */     this();
/*  340 */     ((HttpUrl1)super).scheme = ((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).scheme;
/*  341 */     ((HttpUrl1)super).username = percentDecode(((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).encodedUsername, false);
/*  342 */     ((HttpUrl1)super).password = percentDecode(((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).encodedPassword, false);
/*  343 */     ((HttpUrl1)super).host = ((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).host;
/*  344 */     ((HttpUrl1)super).port = youcangetnoinfoAAEJтЦ8Ща.effectivePort();
/*  345 */     ((HttpUrl1)super).pathSegments = super.percentDecode(((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).encodedPathSegments, false);
/*  346 */     ((HttpUrl1)super)
/*      */       
/*  348 */       .queryNamesAndValues = (((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).encodedQueryNamesAndValues != null) ? super.percentDecode(((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).encodedQueryNamesAndValues, true) : null;
/*  349 */     ((HttpUrl1)super)
/*      */       
/*  351 */       .fragment = (((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).encodedFragment != null) ? percentDecode(((HttpUrl)youcangetnoinfoAAEJтЦ8Ща).encodedFragment, false) : null;
/*  352 */     ((HttpUrl1)super).url = youcangetnoinfoAAEJтЦ8Ща.toString();
/*      */   }
/*      */ 
/*      */   
/*      */   public URL url() {
/*      */     try {
/*  358 */       return new URL(((HttpUrl1)super).url);
/*  359 */     } catch (MalformedURLException youcangetnoinfoCHQJХбда3) {
/*  360 */       throw new RuntimeException(youcangetnoinfoCHQJХбда3);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URI uri() {
/*  378 */     Object youcangetnoinfoGBFБУЫЕ8 = super.newBuilder().reencodeForUri().toString();
/*      */     try {
/*  380 */       return new URI((String)youcangetnoinfoGBFБУЫЕ8);
/*  381 */     } catch (URISyntaxException youcangetnoinfoGBDЕЪАЬч) {
/*      */       
/*      */       try {
/*  384 */         Object youcangetnoinfoGBBзБЫ3щ = youcangetnoinfoGBFБУЫЕ8.replaceAll("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]", "");
/*  385 */         return URI.create((String)youcangetnoinfoGBBзБЫ3щ);
/*  386 */       } catch (Exception youcangetnoinfoGBC5Кzвч) {
/*  387 */         throw new RuntimeException(youcangetnoinfoGBDЕЪАЬч);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String scheme() {
/*  394 */     return ((HttpUrl1)super).scheme;
/*      */   }
/*      */   
/*      */   public boolean isHttps() {
/*  398 */     return ((HttpUrl1)super).scheme.equals("https");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodedUsername() {
/*  413 */     if (((HttpUrl1)super).username.isEmpty()) return ""; 
/*  414 */     int i = ((HttpUrl1)super).scheme.length() + 3;
/*  415 */     int j = Util1.delimiterOffset(((HttpUrl1)super).url, i, ((HttpUrl1)super).url.length(), ":@");
/*  416 */     return ((HttpUrl1)super).url.substring(i, j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String username() {
/*  431 */     return ((HttpUrl1)super).username;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodedPassword() {
/*  446 */     if (((HttpUrl1)super).password.isEmpty()) return ""; 
/*  447 */     int i = ((HttpUrl1)super).url.indexOf(':', ((HttpUrl1)super).scheme.length() + 3) + 1;
/*  448 */     int j = ((HttpUrl1)super).url.indexOf('@');
/*  449 */     return ((HttpUrl1)super).url.substring(i, j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String password() {
/*  464 */     return ((HttpUrl1)super).password;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String host() {
/*  487 */     return ((HttpUrl1)super).host;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int port() {
/*  503 */     return ((HttpUrl1)super).port;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int defaultPort(Object youcangetnoinfoDGTIд7Црь) {
/*  511 */     if (youcangetnoinfoDGTIд7Црь.equals("http"))
/*  512 */       return 80; 
/*  513 */     if (youcangetnoinfoDGTIд7Црь.equals("https")) {
/*  514 */       return 443;
/*      */     }
/*  516 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int pathSize() {
/*  532 */     return ((HttpUrl1)super).pathSegments.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String encodedPath() {
/*  547 */     int i = ((HttpUrl1)super).url.indexOf('/', ((HttpUrl1)super).scheme.length() + 3);
/*  548 */     int j = Util1.delimiterOffset(((HttpUrl1)super).url, i, ((HttpUrl1)super).url.length(), "?#");
/*  549 */     return ((HttpUrl1)super).url.substring(i, j);
/*      */   } public static void pathSegmentsToString(Object youcangetnoinfoALYEюхф5ш, Object youcangetnoinfoALYFЭЬыЗц) {
/*      */     byte b;
/*      */     int i;
/*  553 */     for (b = 0, i = youcangetnoinfoALYFЭЬыЗц.size(); b < i; b++) {
/*  554 */       youcangetnoinfoALYEюхф5ш.append('/');
/*  555 */       youcangetnoinfoALYEюхф5ш.append(youcangetnoinfoALYFЭЬыЗц.get(b));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> encodedPathSegments() {
/*  571 */     int i = ((HttpUrl1)super).url.indexOf('/', ((HttpUrl1)super).scheme.length() + 3);
/*  572 */     int j = Util1.delimiterOffset(((HttpUrl1)super).url, i, ((HttpUrl1)super).url.length(), "?#");
/*  573 */     Object youcangetnoinfoCRUGЬЪцек = new ArrayList(); int k;
/*  574 */     for (k = i; k < j; ) {
/*  575 */       k++;
/*  576 */       int m = Util1.delimiterOffset(((HttpUrl1)super).url, k, j, '/');
/*  577 */       youcangetnoinfoCRUGЬЪцек.add(((HttpUrl1)super).url.substring(k, m));
/*  578 */       k = m;
/*      */     } 
/*  580 */     return (List<String>)youcangetnoinfoCRUGЬЪцек;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> pathSegments() {
/*  595 */     return ((HttpUrl1)super).pathSegments;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String encodedQuery() {
/*  614 */     if (((HttpUrl1)super).queryNamesAndValues == null) return null; 
/*  615 */     int i = ((HttpUrl1)super).url.indexOf('?') + 1;
/*  616 */     int j = Util1.delimiterOffset(((HttpUrl1)super).url, i, ((HttpUrl1)super).url.length(), '#');
/*  617 */     return ((HttpUrl1)super).url.substring(i, j);
/*      */   } public static void namesAndValuesToQueryString(Object youcangetnoinfoARVLИояы3, Object youcangetnoinfoARVMдОМйЖ) {
/*      */     byte b;
/*      */     int i;
/*  621 */     for (b = 0, i = youcangetnoinfoARVMдОМйЖ.size(); b < i; b += 2) {
/*  622 */       Object youcangetnoinfoARVHШаЭо8 = youcangetnoinfoARVMдОМйЖ.get(b);
/*  623 */       Object youcangetnoinfoARVIЗщкфЙ = youcangetnoinfoARVMдОМйЖ.get(b + 1);
/*  624 */       if (b > 0) youcangetnoinfoARVLИояы3.append('&'); 
/*  625 */       youcangetnoinfoARVLИояы3.append((String)youcangetnoinfoARVHШаЭо8);
/*  626 */       if (youcangetnoinfoARVIЗщкфЙ != null) {
/*  627 */         youcangetnoinfoARVLИояы3.append('=');
/*  628 */         youcangetnoinfoARVLИояы3.append((String)youcangetnoinfoARVIЗщкфЙ);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static List<String> queryStringToNamesAndValues(Object youcangetnoinfoEFXM7ниТг) {
/*  640 */     Object youcangetnoinfoEFXNтгЁьЛ = new ArrayList();
/*  641 */     for (int i = 0; i <= youcangetnoinfoEFXM7ниТг.length(); ) {
/*  642 */       int j = youcangetnoinfoEFXM7ниТг.indexOf('&', i);
/*  643 */       if (j == -1) j = youcangetnoinfoEFXM7ниТг.length();
/*      */       
/*  645 */       int k = youcangetnoinfoEFXM7ниТг.indexOf('=', i);
/*  646 */       if (k == -1 || k > j) {
/*  647 */         youcangetnoinfoEFXNтгЁьЛ.add(youcangetnoinfoEFXM7ниТг.substring(i, j));
/*  648 */         youcangetnoinfoEFXNтгЁьЛ.add(null);
/*      */       } else {
/*  650 */         youcangetnoinfoEFXNтгЁьЛ.add(youcangetnoinfoEFXM7ниТг.substring(i, k));
/*  651 */         youcangetnoinfoEFXNтгЁьЛ.add(youcangetnoinfoEFXM7ниТг.substring(k + 1, j));
/*      */       } 
/*  653 */       i = j + 1;
/*      */     } 
/*  655 */     return (List<String>)youcangetnoinfoEFXNтгЁьЛ;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String query() {
/*  674 */     if (((HttpUrl1)super).queryNamesAndValues == null) return null; 
/*  675 */     Object youcangetnoinfoDRAFКС3ЦС = new StringBuilder();
/*  676 */     namesAndValuesToQueryString((StringBuilder)youcangetnoinfoDRAFКС3ЦС, ((HttpUrl1)super).queryNamesAndValues);
/*  677 */     return youcangetnoinfoDRAFКС3ЦС.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int querySize() {
/*  695 */     return (((HttpUrl1)super).queryNamesAndValues != null) ? (((HttpUrl1)super).queryNamesAndValues.size() / 2) : 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String queryParameter(Object youcangetnoinfoLXBЛ1ДГх) {
/*  712 */     if (((HttpUrl1)super).queryNamesAndValues == null) return null;  byte b; int i;
/*  713 */     for (b = 0, i = ((HttpUrl1)super).queryNamesAndValues.size(); b < i; b += 2) {
/*  714 */       if (youcangetnoinfoLXBЛ1ДГх.equals(((HttpUrl1)super).queryNamesAndValues.get(b))) {
/*  715 */         return ((HttpUrl1)super).queryNamesAndValues.get(b + 1);
/*      */       }
/*      */     } 
/*  718 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Set<String> queryParameterNames() {
/*  735 */     if (((HttpUrl1)super).queryNamesAndValues == null) return Collections.emptySet(); 
/*  736 */     Object youcangetnoinfoCJZMмхЪГ1 = new LinkedHashSet(); byte b; int i;
/*  737 */     for (b = 0, i = ((HttpUrl1)super).queryNamesAndValues.size(); b < i; b += 2) {
/*  738 */       youcangetnoinfoCJZMмхЪГ1.add(((HttpUrl1)super).queryNamesAndValues.get(b));
/*      */     }
/*  740 */     return Collections.unmodifiableSet((Set<? extends String>)youcangetnoinfoCJZMмхЪГ1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public List<String> queryParameterValues(Object youcangetnoinfoAXGH1АГДй) {
/*  762 */     if (((HttpUrl1)super).queryNamesAndValues == null) return Collections.emptyList(); 
/*  763 */     Object youcangetnoinfoAXGIчзэуш = new ArrayList(); byte b; int i;
/*  764 */     for (b = 0, i = ((HttpUrl1)super).queryNamesAndValues.size(); b < i; b += 2) {
/*  765 */       if (youcangetnoinfoAXGH1АГДй.equals(((HttpUrl1)super).queryNamesAndValues.get(b))) {
/*  766 */         youcangetnoinfoAXGIчзэуш.add(((HttpUrl1)super).queryNamesAndValues.get(b + 1));
/*      */       }
/*      */     } 
/*  769 */     return Collections.unmodifiableList((List<? extends String>)youcangetnoinfoAXGIчзэуш);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String queryParameterName(Object youcangetnoinfoBDMAЛЦнОz) {
/*  790 */     if (((HttpUrl1)super).queryNamesAndValues == null) throw new IndexOutOfBoundsException(); 
/*  791 */     return ((HttpUrl1)super).queryNamesAndValues.get(youcangetnoinfoBDMAЛЦнОz * 2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String queryParameterValue(Object youcangetnoinfoDAXW3НКйф) {
/*  812 */     if (((HttpUrl1)super).queryNamesAndValues == null) throw new IndexOutOfBoundsException(); 
/*  813 */     return ((HttpUrl1)super).queryNamesAndValues.get(youcangetnoinfoDAXW3НКйф * 2 + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String encodedFragment() {
/*  829 */     if (((HttpUrl1)super).fragment == null) return null; 
/*  830 */     int i = ((HttpUrl1)super).url.indexOf('#') + 1;
/*  831 */     return ((HttpUrl1)super).url.substring(i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String fragment() {
/*  847 */     return ((HttpUrl1)super).fragment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String redact() {
/*  856 */     return super.newBuilder("/...")
/*  857 */       .username("")
/*  858 */       .password("")
/*  859 */       .build()
/*  860 */       .toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public HttpUrl1 resolve(Object youcangetnoinfoIUWу0орА) {
/*  868 */     Object youcangetnoinfoIUX1zмыл = super.newBuilder((String)youcangetnoinfoIUWу0орА);
/*  869 */     return (youcangetnoinfoIUX1zмыл != null) ? youcangetnoinfoIUX1zмыл.build() : null;
/*      */   }
/*      */   
/*      */   public HttpUrl newBuilder() {
/*  873 */     Object youcangetnoinfoVAA8цСхЪ = new HttpUrl();
/*  874 */     ((HttpUrl)youcangetnoinfoVAA8цСхЪ).scheme = ((HttpUrl1)super).scheme;
/*  875 */     ((HttpUrl)youcangetnoinfoVAA8цСхЪ).encodedUsername = super.encodedUsername();
/*  876 */     ((HttpUrl)youcangetnoinfoVAA8цСхЪ).encodedPassword = super.encodedPassword();
/*  877 */     ((HttpUrl)youcangetnoinfoVAA8цСхЪ).host = ((HttpUrl1)super).host;
/*      */     
/*  879 */     ((HttpUrl)youcangetnoinfoVAA8цСхЪ).port = (((HttpUrl1)super).port != defaultPort(((HttpUrl1)super).scheme)) ? ((HttpUrl1)super).port : -1;
/*  880 */     ((HttpUrl)youcangetnoinfoVAA8цСхЪ).encodedPathSegments.clear();
/*  881 */     ((HttpUrl)youcangetnoinfoVAA8цСхЪ).encodedPathSegments.addAll(super.encodedPathSegments());
/*  882 */     youcangetnoinfoVAA8цСхЪ.encodedQuery(super.encodedQuery());
/*  883 */     ((HttpUrl)youcangetnoinfoVAA8цСхЪ).encodedFragment = super.encodedFragment();
/*  884 */     return (HttpUrl)youcangetnoinfoVAA8цСхЪ;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public HttpUrl newBuilder(Object youcangetnoinfoCKCFШтЁПХ) {
/*      */     try {
/*  893 */       return (new HttpUrl()).parse((HttpUrl1)this, (String)youcangetnoinfoCKCFШтЁПХ);
/*  894 */     } catch (IllegalArgumentException youcangetnoinfoCKCDаыСюЫ) {
/*  895 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static HttpUrl1 parse(Object youcangetnoinfoBUSYЭчпЦя) {
/*      */     try {
/*  905 */       return get((String)youcangetnoinfoBUSYЭчпЦя);
/*  906 */     } catch (IllegalArgumentException youcangetnoinfoBUSXзьлЕЖ) {
/*  907 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static HttpUrl1 get(Object youcangetnoinfoEGQFЖММГЪ) {
/*  917 */     return (new HttpUrl()).parse(null, (String)youcangetnoinfoEGQFЖММГЪ).build();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public static HttpUrl1 get(Object youcangetnoinfoABZZцхТТп) {
/*  925 */     return parse(youcangetnoinfoABZZцхТТп.toString());
/*      */   }
/*      */   @Nullable
/*      */   public static HttpUrl1 get(Object youcangetnoinfoZWLЭпуйЦ) {
/*  929 */     return parse(youcangetnoinfoZWLЭпуйЦ.toString());
/*      */   }
/*      */   
/*      */   public boolean equals(@Nullable Object youcangetnoinfoAFIMФщЮдЮ) {
/*  933 */     return (youcangetnoinfoAFIMФщЮдЮ instanceof HttpUrl1 && ((HttpUrl1)youcangetnoinfoAFIMФщЮдЮ).url.equals(((HttpUrl1)super).url));
/*      */   }
/*      */   
/*      */   public int hashCode() {
/*  937 */     return ((HttpUrl1)super).url.hashCode();
/*      */   }
/*      */   
/*      */   public String toString() {
/*  941 */     return ((HttpUrl1)super).url;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   @Nullable
/*      */   public String topPrivateDomain() {
/*  964 */     if (Util1.verifyAsIpAddress(((HttpUrl1)super).host)) return null; 
/*  965 */     return PublicSuffixDatabase.get().getEffectiveTldPlusOne(((HttpUrl1)super).host);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String percentDecode(Object youcangetnoinfoPONХЮМ2с, Object youcangetnoinfoPOOййЙЭй) {
/* 1606 */     return percentDecode((String)youcangetnoinfoPONХЮМ2с, 0, youcangetnoinfoPONХЮМ2с.length(), youcangetnoinfoPOOййЙЭй);
/*      */   }
/*      */   
/*      */   public List<String> percentDecode(Object youcangetnoinfoCEKBгБыВъ, Object youcangetnoinfoCEKCюз9УЁ) {
/* 1610 */     int i = youcangetnoinfoCEKBгБыВъ.size();
/* 1611 */     Object youcangetnoinfoCEKEЩКД3з = new ArrayList(i);
/* 1612 */     for (byte b = 0; b < i; b++) {
/* 1613 */       Object youcangetnoinfoCEJYНгТьЮ = youcangetnoinfoCEKBгБыВъ.get(b);
/* 1614 */       youcangetnoinfoCEKEЩКД3з.add((youcangetnoinfoCEJYНгТьЮ != null) ? percentDecode((String)youcangetnoinfoCEJYНгТьЮ, youcangetnoinfoCEKCюз9УЁ) : null);
/*      */     } 
/* 1616 */     return Collections.unmodifiableList((List<? extends String>)youcangetnoinfoCEKEЩКД3з);
/*      */   }
/*      */   
/*      */   public static String percentDecode(Object youcangetnoinfoEBIYтшиТа, Object youcangetnoinfoEBIZИпГЯш, Object youcangetnoinfoEBJAНЙэщЩ, Object youcangetnoinfoEBJBАЭХаФ) {
/* 1620 */     for (Object youcangetnoinfoEBIXЭЩд1А = youcangetnoinfoEBIZИпГЯш; youcangetnoinfoEBIXЭЩд1А < youcangetnoinfoEBJAНЙэщЩ; youcangetnoinfoEBIXЭЩд1А++) {
/* 1621 */       char c = youcangetnoinfoEBIYтшиТа.charAt(youcangetnoinfoEBIXЭЩд1А);
/* 1622 */       if (c == '%' || (c == '+' && youcangetnoinfoEBJBАЭХаФ != null)) {
/*      */         
/* 1624 */         Object youcangetnoinfoEBIVЩлжМш = new Buffer2();
/* 1625 */         youcangetnoinfoEBIVЩлжМш.writeUtf8((String)youcangetnoinfoEBIYтшиТа, youcangetnoinfoEBIZИпГЯш, youcangetnoinfoEBIXЭЩд1А);
/* 1626 */         percentDecode((Buffer2)youcangetnoinfoEBIVЩлжМш, (String)youcangetnoinfoEBIYтшиТа, youcangetnoinfoEBIXЭЩд1А, youcangetnoinfoEBJAНЙэщЩ, youcangetnoinfoEBJBАЭХаФ);
/* 1627 */         return youcangetnoinfoEBIVЩлжМш.readUtf8();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1632 */     return youcangetnoinfoEBIYтшиТа.substring(youcangetnoinfoEBIZИпГЯш, youcangetnoinfoEBJAНЙэщЩ);
/*      */   }
/*      */   
/*      */   public static void percentDecode(Object youcangetnoinfoAGTWЭzРжЭ, Object youcangetnoinfoAGTX1ЭнЗз, Object youcangetnoinfoAGTYы7П0Р, Object youcangetnoinfoAGTZ3зюэ8, Object youcangetnoinfoAGUAУпАлА) {
/*      */     int i;
/* 1637 */     for (Object youcangetnoinfoAGTV7пЕЖ6 = youcangetnoinfoAGTYы7П0Р; i < youcangetnoinfoAGTZ3зюэ8; i = youcangetnoinfoAGTV7пЕЖ6 + Character.charCount(SYNTHETIC_LOCAL_VARIABLE_5)) {
/* 1638 */       int j = youcangetnoinfoAGTX1ЭнЗз.codePointAt(i);
/* 1639 */       if (j == 37 && i + 2 < youcangetnoinfoAGTZ3зюэ8) {
/* 1640 */         int k = Util1.decodeHexDigit(youcangetnoinfoAGTX1ЭнЗз.charAt(i + 1));
/* 1641 */         int m = Util1.decodeHexDigit(youcangetnoinfoAGTX1ЭнЗз.charAt(i + 2));
/* 1642 */         if (k != -1 && m != -1) {
/* 1643 */           youcangetnoinfoAGTWЭzРжЭ.writeByte((k << 4) + m);
/* 1644 */           i += 2;
/*      */           continue;
/*      */         } 
/* 1647 */       } else if (j == 43 && youcangetnoinfoAGUAУпАлА != null) {
/* 1648 */         youcangetnoinfoAGTWЭzРжЭ.writeByte(32);
/*      */         continue;
/*      */       } 
/* 1651 */       youcangetnoinfoAGTWЭzРжЭ.writeUtf8CodePoint(j);
/*      */       continue;
/*      */     } 
/*      */   }
/*      */   public static boolean percentEncoded(Object youcangetnoinfoAHHEчвШУс, Object youcangetnoinfoAHHFи9Изщ, Object youcangetnoinfoAHHG9ял9с) {
/* 1656 */     return (youcangetnoinfoAHHFи9Изщ + 2 < youcangetnoinfoAHHG9ял9с && youcangetnoinfoAHHEчвШУс
/* 1657 */       .charAt(youcangetnoinfoAHHFи9Изщ) == '%' && 
/* 1658 */       Util1.decodeHexDigit(youcangetnoinfoAHHEчвШУс.charAt(youcangetnoinfoAHHFи9Изщ + 1)) != -1 && 
/* 1659 */       Util1.decodeHexDigit(youcangetnoinfoAHHEчвШУс.charAt(youcangetnoinfoAHHFи9Изщ + 2)) != -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String canonicalize(Object youcangetnoinfoRHUААЫве, Object youcangetnoinfoRHVшн01э, Object youcangetnoinfoRHWЙоеzЁ, Object youcangetnoinfoRHXиПГzъ, Object youcangetnoinfoRHYбё5Хе, Object youcangetnoinfoRHZ7мчЦИ, Object youcangetnoinfoRIAДЮЬСа, Object youcangetnoinfoRIBдО1Е6, @Nullable Object youcangetnoinfoRICйЧТГъ) {
/* 1683 */     for (Object youcangetnoinfoRHTъ28ЕФ = youcangetnoinfoRHVшн01э; youcangetnoinfoRHTъ28ЕФ < youcangetnoinfoRHWЙоеzЁ; j = youcangetnoinfoRHTъ28ЕФ + Character.charCount(i)) {
/* 1684 */       int j, i = youcangetnoinfoRHUААЫве.codePointAt(youcangetnoinfoRHTъ28ЕФ);
/* 1685 */       if (i < 32 || i == 127 || (i >= 128 && youcangetnoinfoRIBдО1Е6 != null) || youcangetnoinfoRHXиПГzъ
/*      */ 
/*      */         
/* 1688 */         .indexOf(i) != -1 || (i == 37 && (youcangetnoinfoRHYбё5Хе == null || (youcangetnoinfoRHZ7мчЦИ != null && 
/* 1689 */         !percentEncoded((String)youcangetnoinfoRHUААЫве, youcangetnoinfoRHTъ28ЕФ, youcangetnoinfoRHWЙоеzЁ)))) || (i == 43 && youcangetnoinfoRIAДЮЬСа != null)) {
/*      */ 
/*      */         
/* 1692 */         Object youcangetnoinfoRHR3zРФц = new Buffer2();
/* 1693 */         youcangetnoinfoRHR3zРФц.writeUtf8((String)youcangetnoinfoRHUААЫве, youcangetnoinfoRHVшн01э, youcangetnoinfoRHTъ28ЕФ);
/* 1694 */         canonicalize((Buffer2)youcangetnoinfoRHR3zРФц, (String)youcangetnoinfoRHUААЫве, youcangetnoinfoRHTъ28ЕФ, youcangetnoinfoRHWЙоеzЁ, (String)youcangetnoinfoRHXиПГzъ, youcangetnoinfoRHYбё5Хе, youcangetnoinfoRHZ7мчЦИ, youcangetnoinfoRIAДЮЬСа, youcangetnoinfoRIBдО1Е6, (Charset)youcangetnoinfoRICйЧТГъ);
/*      */         
/* 1696 */         return youcangetnoinfoRHR3zРФц.readUtf8();
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1701 */     return youcangetnoinfoRHUААЫве.substring(youcangetnoinfoRHVшн01э, youcangetnoinfoRHWЙоеzЁ);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static void canonicalize(Object youcangetnoinfoZTUйЙzсЛ, Object youcangetnoinfoZTVянчк0, Object youcangetnoinfoZTWоРК3х, Object youcangetnoinfoZTXКЮЖьр, Object youcangetnoinfoZTYбгдЧ2, Object youcangetnoinfoZTZ1рИ0н, Object youcangetnoinfoZUAъЫдир, Object youcangetnoinfoZUBЛйЯЪа, Object youcangetnoinfoZUCэв3ЕЖ, @Nullable Object youcangetnoinfoZUDфсьЯ5) {
/* 1707 */     Object youcangetnoinfoZUEО2z9ю = null;
/*      */     
/* 1709 */     for (Object youcangetnoinfoZTTрЕ3жя = youcangetnoinfoZTWоРК3х; youcangetnoinfoZTTрЕ3жя < youcangetnoinfoZTXКЮЖьр; j = youcangetnoinfoZTTрЕ3жя + Character.charCount(i)) {
/* 1710 */       int j, i = youcangetnoinfoZTVянчк0.codePointAt(youcangetnoinfoZTTрЕ3жя);
/* 1711 */       if (youcangetnoinfoZTZ1рИ0н == null || (i != 9 && i != 10 && i != 12 && i != 13))
/*      */       {
/*      */         
/* 1714 */         if (i == 43 && youcangetnoinfoZUBЛйЯЪа != null) {
/*      */           
/* 1716 */           youcangetnoinfoZTUйЙzсЛ.writeUtf8((youcangetnoinfoZTZ1рИ0н != null) ? "+" : "%2B");
/* 1717 */         } else if (i < 32 || i == 127 || (i >= 128 && youcangetnoinfoZUCэв3ЕЖ != null) || youcangetnoinfoZTYбгдЧ2
/*      */ 
/*      */           
/* 1720 */           .indexOf(i) != -1 || (i == 37 && (youcangetnoinfoZTZ1рИ0н == null || (youcangetnoinfoZUAъЫдир != null && 
/* 1721 */           !percentEncoded((String)youcangetnoinfoZTVянчк0, youcangetnoinfoZTTрЕ3жя, youcangetnoinfoZTXКЮЖьр))))) {
/*      */           
/* 1723 */           if (youcangetnoinfoZUEО2z9ю == null) {
/* 1724 */             youcangetnoinfoZUEО2z9ю = new Buffer2();
/*      */           }
/*      */           
/* 1727 */           if (youcangetnoinfoZUDфсьЯ5 == null || youcangetnoinfoZUDфсьЯ5.equals(StandardCharsets.UTF_8)) {
/* 1728 */             youcangetnoinfoZUEО2z9ю.writeUtf8CodePoint(i);
/*      */           } else {
/* 1730 */             youcangetnoinfoZUEО2z9ю.writeString((String)youcangetnoinfoZTVянчк0, youcangetnoinfoZTTрЕ3жя, youcangetnoinfoZTTрЕ3жя + Character.charCount(i), (Charset)youcangetnoinfoZUDфсьЯ5);
/*      */           } 
/*      */           
/* 1733 */           while (!youcangetnoinfoZUEО2z9ю.exhausted()) {
/* 1734 */             int k = youcangetnoinfoZUEО2z9ю.readByte() & 0xFF;
/* 1735 */             youcangetnoinfoZTUйЙzсЛ.writeByte(37);
/* 1736 */             youcangetnoinfoZTUйЙzсЛ.writeByte(HEX_DIGITS[k >> 4 & 0xF]);
/* 1737 */             youcangetnoinfoZTUйЙzсЛ.writeByte(HEX_DIGITS[k & 0xF]);
/*      */           } 
/*      */         } else {
/*      */           
/* 1741 */           youcangetnoinfoZTUйЙzсЛ.writeUtf8CodePoint(i);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static String canonicalize(Object youcangetnoinfoELHYзруыЪ, Object youcangetnoinfoELHZжыЦвю, Object youcangetnoinfoELIAув0бГ, Object youcangetnoinfoELIBВцфдТ, Object youcangetnoinfoELICРЫЖ6Й, Object youcangetnoinfoELIDФЁа6д, @Nullable Object youcangetnoinfoELIEвёЩсШ) {
/* 1748 */     return canonicalize((String)youcangetnoinfoELHYзруыЪ, 0, youcangetnoinfoELHYзруыЪ.length(), (String)youcangetnoinfoELHZжыЦвю, youcangetnoinfoELIAув0бГ, youcangetnoinfoELIBВцфдТ, youcangetnoinfoELICРЫЖ6Й, youcangetnoinfoELIDФЁа6д, (Charset)youcangetnoinfoELIEвёЩсШ);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static String canonicalize(Object youcangetnoinfoCIUUВжХУс, Object youcangetnoinfoCIUVЛДУг0, Object youcangetnoinfoCIUWъ2йХы, Object youcangetnoinfoCIUXщ3цкм, Object youcangetnoinfoCIUYглЛОО, Object youcangetnoinfoCIUZФобшК) {
/* 1754 */     return canonicalize((String)youcangetnoinfoCIUUВжХУс, 0, youcangetnoinfoCIUUВжХУс
/* 1755 */         .length(), (String)youcangetnoinfoCIUVЛДУг0, youcangetnoinfoCIUWъ2йХы, youcangetnoinfoCIUXщ3цкм, youcangetnoinfoCIUYглЛОО, youcangetnoinfoCIUZФобшК, null);
/*      */   }
/*      */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\HttpUrl1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */