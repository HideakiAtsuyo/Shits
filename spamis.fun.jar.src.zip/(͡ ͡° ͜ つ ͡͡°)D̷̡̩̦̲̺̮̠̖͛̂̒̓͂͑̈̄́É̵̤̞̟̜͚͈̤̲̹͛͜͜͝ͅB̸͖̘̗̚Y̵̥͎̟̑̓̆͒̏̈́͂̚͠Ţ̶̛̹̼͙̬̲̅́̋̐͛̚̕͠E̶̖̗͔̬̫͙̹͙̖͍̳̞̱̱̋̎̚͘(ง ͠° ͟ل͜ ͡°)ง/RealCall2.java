/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RealCall2
/*     */   implements Call
/*     */ {
/*     */   @Nullable
/*     */   public EventListener1 eventListener;
/*     */   public final RetryAndFollowUpInterceptor retryAndFollowUpInterceptor;
/*     */   public final Request originalRequest;
/*     */   public boolean executed;
/*     */   public final AsyncTimeout1 timeout;
/*     */   public final boolean forWebSocket;
/*     */   public final OkHttpClient client;
/*     */   
/*     */   public Object clone() throws CloneNotSupportedException {
/*  41 */     return super.clone(); } public Call clone() { return super.clone(); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public RealCall2(Object youcangetnoinfoBLEUчМ9ею, Object youcangetnoinfoBLEVТэёюz, Object youcangetnoinfoBLEWёКали) {
/*  59 */     this();
/*  60 */     ((RealCall2)super).client = (OkHttpClient)youcangetnoinfoBLEUчМ9ею;
/*  61 */     ((RealCall2)super).originalRequest = (Request)youcangetnoinfoBLEVТэёюz;
/*  62 */     ((RealCall2)super).forWebSocket = youcangetnoinfoBLEWёКали;
/*  63 */     ((RealCall2)super).retryAndFollowUpInterceptor = new RetryAndFollowUpInterceptor((OkHttpClient)youcangetnoinfoBLEUчМ9ею);
/*  64 */     ((RealCall2)super).timeout = new RealCall1((RealCall2)this);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  69 */     ((RealCall2)super).timeout.timeout(youcangetnoinfoBLEUчМ9ею.callTimeoutMillis(), TimeUnit.MILLISECONDS);
/*     */   }
/*     */ 
/*     */   
/*     */   public static RealCall2 newRealCall(Object youcangetnoinfoCVYX7ЛzмР, Object youcangetnoinfoCVYYэеУzу, Object youcangetnoinfoCVYZЕВбуъ) {
/*  74 */     Object youcangetnoinfoCVZAЛВ0ОМ = new RealCall2((OkHttpClient)youcangetnoinfoCVYX7ЛzмР, (Request)youcangetnoinfoCVYYэеУzу, youcangetnoinfoCVYZЕВбуъ);
/*  75 */     ((RealCall2)youcangetnoinfoCVZAЛВ0ОМ).eventListener = youcangetnoinfoCVYX7ЛzмР.eventListenerFactory().create((Call)youcangetnoinfoCVZAЛВ0ОМ);
/*  76 */     return (RealCall2)youcangetnoinfoCVZAЛВ0ОМ;
/*     */   }
/*     */   
/*     */   public Request request() {
/*  80 */     return ((RealCall2)super).originalRequest;
/*     */   }
/*     */   
/*     */   public Response execute() throws IOException {
/*  84 */     synchronized (this) {
/*  85 */       if (((RealCall2)super).executed) throw new IllegalStateException("Already Executed"); 
/*  86 */       ((RealCall2)super).executed = true;
/*     */     } 
/*  88 */     super.captureCallStackTrace();
/*  89 */     ((RealCall2)super).timeout.enter();
/*  90 */     ((RealCall2)super).eventListener.callStart((Call)this);
/*     */     try {
/*  92 */       ((RealCall2)super).client.dispatcher().executed((RealCall2)this);
/*  93 */       Object youcangetnoinfoIUFбНАтЪ = super.getResponseWithInterceptorChain();
/*  94 */       if (youcangetnoinfoIUFбНАтЪ == null) throw new IOException("Canceled"); 
/*  95 */       return (Response)youcangetnoinfoIUFбНАтЪ;
/*  96 */     } catch (IOException youcangetnoinfoIUGцтьоп) {
/*  97 */       youcangetnoinfoIUGцтьоп = super.timeoutExit((IOException)youcangetnoinfoIUGцтьоп);
/*  98 */       ((RealCall2)super).eventListener.callFailed((Call)this, (IOException)youcangetnoinfoIUGцтьоп);
/*  99 */       throw youcangetnoinfoIUGцтьоп;
/*     */     } finally {
/* 101 */       ((RealCall2)super).client.dispatcher().finished((RealCall2)this);
/*     */     } 
/*     */   }
/*     */   @Nullable
/*     */   public IOException timeoutExit(@Nullable Object youcangetnoinfoEHRHУГаАТ) {
/* 106 */     if (!((RealCall2)super).timeout.exit()) return (IOException)youcangetnoinfoEHRHУГаАТ;
/*     */     
/* 108 */     Object youcangetnoinfoEHRI9z29ь = new InterruptedIOException("timeout");
/* 109 */     if (youcangetnoinfoEHRHУГаАТ != null) {
/* 110 */       youcangetnoinfoEHRI9z29ь.initCause((Throwable)youcangetnoinfoEHRHУГаАТ);
/*     */     }
/* 112 */     return (IOException)youcangetnoinfoEHRI9z29ь;
/*     */   }
/*     */   
/*     */   public void captureCallStackTrace() {
/* 116 */     Object youcangetnoinfoAYLGзЬж36 = Platform.get().getStackTraceForCloseable("response.body().close()");
/* 117 */     ((RealCall2)super).retryAndFollowUpInterceptor.setCallStackTrace(youcangetnoinfoAYLGзЬж36);
/*     */   }
/*     */   
/*     */   public void enqueue(Object youcangetnoinfoBLMZК7сЧу) {
/* 121 */     synchronized (this) {
/* 122 */       if (((RealCall2)super).executed) throw new IllegalStateException("Already Executed"); 
/* 123 */       ((RealCall2)super).executed = true;
/*     */     } 
/* 125 */     super.captureCallStackTrace();
/* 126 */     ((RealCall2)super).eventListener.callStart((Call)this);
/* 127 */     ((RealCall2)super).client.dispatcher().enqueue(new RealCall((RealCall2)this, (Callback)youcangetnoinfoBLMZК7сЧу));
/*     */   }
/*     */   
/*     */   public void cancel() {
/* 131 */     ((RealCall2)super).retryAndFollowUpInterceptor.cancel();
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 135 */     return ((RealCall2)super).timeout;
/*     */   }
/*     */   
/*     */   public synchronized boolean isExecuted() {
/* 139 */     return ((RealCall2)super).executed;
/*     */   }
/*     */   
/*     */   public boolean isCanceled() {
/* 143 */     return ((RealCall2)super).retryAndFollowUpInterceptor.isCanceled();
/*     */   }
/*     */ 
/*     */   
/*     */   public RealCall2 clone() {
/* 148 */     return newRealCall(((RealCall2)super).client, ((RealCall2)super).originalRequest, ((RealCall2)super).forWebSocket);
/*     */   }
/*     */   
/*     */   public StreamAllocation1 streamAllocation() {
/* 152 */     return ((RealCall2)super).retryAndFollowUpInterceptor.streamAllocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toLoggableString() {
/* 238 */     return (super.isCanceled() ? "canceled " : "") + (
/* 239 */       ((RealCall2)super).forWebSocket ? "web socket" : "call") + " to " + super
/* 240 */       .redactedUrl();
/*     */   }
/*     */   
/*     */   public String redactedUrl() {
/* 244 */     return ((RealCall2)super).originalRequest.url().redact();
/*     */   }
/*     */ 
/*     */   
/*     */   public Response getResponseWithInterceptorChain() throws IOException {
/* 249 */     Object youcangetnoinfoBFUOАшеЮ0 = new ArrayList();
/* 250 */     youcangetnoinfoBFUOАшеЮ0.addAll(((RealCall2)super).client.interceptors());
/* 251 */     youcangetnoinfoBFUOАшеЮ0.add(((RealCall2)super).retryAndFollowUpInterceptor);
/* 252 */     youcangetnoinfoBFUOАшеЮ0.add(new BridgeInterceptor(((RealCall2)super).client.cookieJar()));
/* 253 */     youcangetnoinfoBFUOАшеЮ0.add(new CacheInterceptor(((RealCall2)super).client.internalCache()));
/* 254 */     youcangetnoinfoBFUOАшеЮ0.add(new ConnectInterceptor(((RealCall2)super).client));
/* 255 */     if (!((RealCall2)super).forWebSocket) {
/* 256 */       youcangetnoinfoBFUOАшеЮ0.addAll(((RealCall2)super).client.networkInterceptors());
/*     */     }
/* 258 */     youcangetnoinfoBFUOАшеЮ0.add(new CallServerInterceptor(((RealCall2)super).forWebSocket));
/*     */ 
/*     */ 
/*     */     
/* 262 */     Object youcangetnoinfoBFUPЯы5яЮ = new RealInterceptorChain((List)youcangetnoinfoBFUOАшеЮ0, null, null, null, 0, ((RealCall2)super).originalRequest, (Call)this, ((RealCall2)super).eventListener, ((RealCall2)super).client.connectTimeoutMillis(), ((RealCall2)super).client.readTimeoutMillis(), ((RealCall2)super).client.writeTimeoutMillis());
/*     */     
/* 264 */     return youcangetnoinfoBFUPЯы5яЮ.proceed(((RealCall2)super).originalRequest);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RealCall2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */