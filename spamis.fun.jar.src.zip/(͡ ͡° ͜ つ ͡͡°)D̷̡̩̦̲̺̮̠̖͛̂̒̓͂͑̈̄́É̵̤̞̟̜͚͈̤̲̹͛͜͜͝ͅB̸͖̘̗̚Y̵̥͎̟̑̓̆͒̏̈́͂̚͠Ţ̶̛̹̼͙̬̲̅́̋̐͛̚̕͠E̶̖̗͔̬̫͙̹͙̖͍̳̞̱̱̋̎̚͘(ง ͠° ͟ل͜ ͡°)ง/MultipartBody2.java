/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MultipartBody2
/*     */ {
/*     */   @Nullable
/*     */   public final Headers headers;
/*     */   public final RequestBody body;
/*     */   
/*     */   public static MultipartBody2 create(Object youcangetnoinfoCXVSЫвЁХй) {
/* 226 */     return create(null, (RequestBody)youcangetnoinfoCXVSЫвЁХй);
/*     */   }
/*     */   
/*     */   public static MultipartBody2 create(@Nullable Object youcangetnoinfoEAMLУщ2Э9, Object youcangetnoinfoEAMM83Сюю) {
/* 230 */     if (youcangetnoinfoEAMM83Сюю == null) {
/* 231 */       throw new NullPointerException("body == null");
/*     */     }
/* 233 */     if (youcangetnoinfoEAMLУщ2Э9 != null && youcangetnoinfoEAMLУщ2Э9.get("Content-Type") != null) {
/* 234 */       throw new IllegalArgumentException("Unexpected header: Content-Type");
/*     */     }
/* 236 */     if (youcangetnoinfoEAMLУщ2Э9 != null && youcangetnoinfoEAMLУщ2Э9.get("Content-Length") != null) {
/* 237 */       throw new IllegalArgumentException("Unexpected header: Content-Length");
/*     */     }
/* 239 */     return new MultipartBody2((Headers)youcangetnoinfoEAMLУщ2Э9, (RequestBody)youcangetnoinfoEAMM83Сюю);
/*     */   }
/*     */   
/*     */   public static MultipartBody2 createFormData(Object youcangetnoinfoAIFRЪЬхл4, Object youcangetnoinfoAIFSОПюЭУ) {
/* 243 */     return createFormData((String)youcangetnoinfoAIFRЪЬхл4, null, RequestBody.create((MediaType)null, (String)youcangetnoinfoAIFSОПюЭУ));
/*     */   }
/*     */   
/*     */   public static MultipartBody2 createFormData(Object youcangetnoinfoBZKK4ДЁХС, @Nullable Object youcangetnoinfoBZKLЩzхУЁ, Object youcangetnoinfoBZKMЕоУИА) {
/* 247 */     if (youcangetnoinfoBZKK4ДЁХС == null) {
/* 248 */       throw new NullPointerException("name == null");
/*     */     }
/* 250 */     Object youcangetnoinfoBZKNЯшЮ3э = new StringBuilder("form-data; name=");
/* 251 */     MultipartBody.appendQuotedString((StringBuilder)youcangetnoinfoBZKNЯшЮ3э, (String)youcangetnoinfoBZKK4ДЁХС);
/*     */     
/* 253 */     if (youcangetnoinfoBZKLЩzхУЁ != null) {
/* 254 */       youcangetnoinfoBZKNЯшЮ3э.append("; filename=");
/* 255 */       MultipartBody.appendQuotedString((StringBuilder)youcangetnoinfoBZKNЯшЮ3э, (String)youcangetnoinfoBZKLЩzхУЁ);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 260 */     Object youcangetnoinfoBZKOк3ЪмВ = (new Headers1()).addUnsafeNonAscii("Content-Disposition", youcangetnoinfoBZKNЯшЮ3э.toString()).build();
/*     */     
/* 262 */     return create((Headers)youcangetnoinfoBZKOк3ЪмВ, (RequestBody)youcangetnoinfoBZKMЕоУИА);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartBody2(@Nullable Object youcangetnoinfoDIZOй1Ю2й, Object youcangetnoinfoDIZPСпунЯ) {
/* 268 */     this();
/* 269 */     ((MultipartBody2)super).headers = (Headers)youcangetnoinfoDIZOй1Ю2й;
/* 270 */     ((MultipartBody2)super).body = (RequestBody)youcangetnoinfoDIZPСпунЯ;
/*     */   }
/*     */   @Nullable
/*     */   public Headers headers() {
/* 274 */     return ((MultipartBody2)super).headers;
/*     */   }
/*     */   
/*     */   public RequestBody body() {
/* 278 */     return ((MultipartBody2)super).body;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\MultipartBody2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */