/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import fun.spamis.spammer.SpamIsFun;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.security.InvalidKeyException;
/*    */ import java.security.Key;
/*    */ import java.security.MessageDigest;
/*    */ import java.security.NoSuchAlgorithmException;
/*    */ import java.util.Arrays;
/*    */ import java.util.Base64;
/*    */ import java.util.UUID;
/*    */ import javax.crypto.BadPaddingException;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.IllegalBlockSizeException;
/*    */ import javax.crypto.NoSuchPaddingException;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SecurityUtils
/*    */ {
/*    */   public SecurityUtils() {
/* 25 */     this();
/*    */   }
/* 27 */   public static String password = "HsO3uRNzGpTmFu8h7nAKO9vGwU0GGqqM";
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String convertToMD5(Object youcangetnoinfoPRTётУдш) {
/*    */     // Byte code:
/*    */     //   0: ldc 'MD5'
/*    */     //   2: invokestatic getInstance : (Ljava/lang/String;)Ljava/security/MessageDigest;
/*    */     //   5: astore_1
/*    */     //   6: aload_1
/*    */     //   7: aload_0
/*    */     //   8: invokevirtual getBytes : ()[B
/*    */     //   11: invokevirtual digest : ([B)[B
/*    */     //   14: astore_2
/*    */     //   15: new java/lang/StringBuffer
/*    */     //   18: dup
/*    */     //   19: invokespecial <init> : ()V
/*    */     //   22: astore_3
/*    */     //   23: iconst_0
/*    */     //   24: istore #4
/*    */     //   26: iload #4
/*    */     //   28: aload_2
/*    */     //   29: arraylength
/*    */     //   30: if_icmpge -> 64
/*    */     //   33: aload_3
/*    */     //   34: aload_2
/*    */     //   35: iload #4
/*    */     //   37: baload
/*    */     //   38: sipush #255
/*    */     //   41: iand
/*    */     //   42: sipush #256
/*    */     //   45: ior
/*    */     //   46: invokestatic toHexString : (I)Ljava/lang/String;
/*    */     //   49: iconst_1
/*    */     //   50: iconst_3
/*    */     //   51: invokevirtual substring : (II)Ljava/lang/String;
/*    */     //   54: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuffer;
/*    */     //   57: pop
/*    */     //   58: iinc #4, 1
/*    */     //   61: goto -> 26
/*    */     //   64: aload_3
/*    */     //   65: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   68: areturn
/*    */     //   69: astore_1
/*    */     //   70: aconst_null
/*    */     //   71: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #32	-> 0
/*    */     //   #33	-> 6
/*    */     //   #34	-> 15
/*    */     //   #35	-> 23
/*    */     //   #36	-> 33
/*    */     //   #35	-> 58
/*    */     //   #38	-> 64
/*    */     //   #39	-> 69
/*    */     //   #41	-> 70
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   6	63	1	youcangetnoinfoPRQжЁ9эЁ	Ljava/lang/Object;
/*    */     //   0	72	0	youcangetnoinfoPRTётУдш	Ljava/lang/Object;
/*    */     //   23	46	3	youcangetnoinfoPRSЭЪ95Ы	Ljava/lang/Object;
/*    */     //   15	54	2	youcangetnoinfoPRRахЙРz	Ljava/lang/Object;
/*    */     //   26	38	4	youcangetnoinfoPRPгИШ1Ф	Ljava/lang/Object;
/*    */     // Exception table:
/*    */     //   from	to	target	type
/*    */     //   0	68	69	java/security/NoSuchAlgorithmException
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String AESencoder(Object youcangetnoinfoCMMFРяВФл) throws InvalidKeyException, BadPaddingException, IllegalBlockSizeException, UnsupportedEncodingException, NoSuchPaddingException, NoSuchAlgorithmException {
/* 47 */     Object youcangetnoinfoCMMGщвъуш = password.getBytes("UTF-8");
/* 48 */     Object youcangetnoinfoCMMHЪz7Дё = MessageDigest.getInstance("SHA-256");
/* 49 */     youcangetnoinfoCMMGщвъуш = youcangetnoinfoCMMHЪz7Дё.digest((byte[])youcangetnoinfoCMMGщвъуш);
/* 50 */     youcangetnoinfoCMMGщвъуш = Arrays.copyOf((byte[])youcangetnoinfoCMMGщвъуш, 16);
/* 51 */     Object youcangetnoinfoCMMIСж33У = new SecretKeySpec((byte[])youcangetnoinfoCMMGщвъуш, "AES");
/* 52 */     Object youcangetnoinfoCMMJЬЫ5пХ = Cipher.getInstance("AES");
/* 53 */     youcangetnoinfoCMMJЬЫ5пХ.init(1, (Key)youcangetnoinfoCMMIСж33У);
/* 54 */     Object youcangetnoinfoCMMKйоЕЦэ = youcangetnoinfoCMMJЬЫ5пХ.doFinal(youcangetnoinfoCMMFРяВФл.getBytes());
/* 55 */     Object youcangetnoinfoCMMLФДч5ц = Base64.getEncoder().encodeToString((byte[])youcangetnoinfoCMMKйоЕЦэ);
/* 56 */     return (String)youcangetnoinfoCMMLФДч5ц;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static String AESdecoder(Object youcangetnoinfoCISQЧаБЗи) throws IllegalBlockSizeException, InvalidKeyException, IOException, NoSuchAlgorithmException, BadPaddingException, NoSuchPaddingException {
/* 62 */     Object youcangetnoinfoCISRОЙЛёс = Base64.getDecoder().decode((String)youcangetnoinfoCISQЧаБЗи);
/* 63 */     Object youcangetnoinfoCISSюнд84 = password.getBytes("UTF-8");
/* 64 */     Object youcangetnoinfoCISTРя0ьШ = MessageDigest.getInstance("SHA-256");
/* 65 */     youcangetnoinfoCISSюнд84 = youcangetnoinfoCISTРя0ьШ.digest((byte[])youcangetnoinfoCISSюнд84);
/* 66 */     youcangetnoinfoCISSюнд84 = Arrays.copyOf((byte[])youcangetnoinfoCISSюнд84, 16);
/* 67 */     Object youcangetnoinfoCISUЪкбКг = new SecretKeySpec((byte[])youcangetnoinfoCISSюнд84, "AES");
/* 68 */     Object youcangetnoinfoCISVШДтЕм = Cipher.getInstance("AES");
/* 69 */     youcangetnoinfoCISVШДтЕм.init(2, (Key)youcangetnoinfoCISUЪкбКг);
/* 70 */     Object youcangetnoinfoCISWс8йЙЕ = youcangetnoinfoCISVШДтЕм.doFinal((byte[])youcangetnoinfoCISRОЙЛёс);
/* 71 */     Object youcangetnoinfoCISXцяЮтЮ = new String((byte[])youcangetnoinfoCISWс8йЙЕ);
/* 72 */     return (String)youcangetnoinfoCISXцяЮтЮ;
/*    */   }
/*    */   
/*    */   public static String getHWID2() throws IOException {
/* 76 */     Object youcangetnoinfoDOIX9чБфИ = null;
/* 77 */     if ((new File(SpamIsFun.homeDir + "h")).exists()) {
/* 78 */       youcangetnoinfoDOIX9чБфИ = FileUtils.readFile(SpamIsFun.homeDir + "h");
/*    */     } else {
/* 80 */       youcangetnoinfoDOIX9чБфИ = convertToMD5(UUID.randomUUID().toString());
/* 81 */       FileUtils.writeFile(SpamIsFun.homeDir + "h", (String)youcangetnoinfoDOIX9чБфИ);
/*    */     } 
/*    */     
/* 84 */     return (String)youcangetnoinfoDOIX9чБфИ;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\SecurityUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */