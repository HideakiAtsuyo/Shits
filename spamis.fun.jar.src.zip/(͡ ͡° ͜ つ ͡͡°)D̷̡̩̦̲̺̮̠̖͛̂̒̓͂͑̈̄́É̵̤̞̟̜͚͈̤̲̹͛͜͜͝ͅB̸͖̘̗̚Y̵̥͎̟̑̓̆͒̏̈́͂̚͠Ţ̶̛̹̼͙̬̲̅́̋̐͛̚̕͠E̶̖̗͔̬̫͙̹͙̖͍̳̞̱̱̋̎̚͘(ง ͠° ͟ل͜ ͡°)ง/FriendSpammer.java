/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FriendSpammer
/*     */   extends Thread
/*     */ {
/*     */   public final FriendSpammer1 this$2;
/*     */   public final Map.Entry val$token;
/*     */   
/*     */   public void run() {
/* 116 */     boolean bool = true;
/* 117 */     while (bool) {
/*     */       try {
/* 119 */         Object youcangetnoinfoGXUВНг3z = SpamUtils.getRandomProxy();
/* 120 */         Object youcangetnoinfoGXVв1zzР = SpamUtils.deleteFriend(userIdTxt.getText(), token
/* 121 */             .getValue().toString(), (String)youcangetnoinfoGXUВНг3z);
/* 122 */         if (youcangetnoinfoGXVв1zzР == null) {
/* 123 */           ConsoleGUI.log(youcangetnoinfoGXUВНг3z + "-> Token(" + token
/* 124 */               .getKey() + ")-> Friend removed");
/* 125 */           bool = false; continue;
/* 126 */         }  if (youcangetnoinfoGXVв1zzР.startsWith("<")) {
/* 127 */           ConsoleGUI.log(youcangetnoinfoGXUВНг3z + "-> Token(" + token.getKey() + ")-> Proxy failed. Retrying");
/*     */           continue;
/*     */         } 
/* 130 */         ConsoleGUI.log(youcangetnoinfoGXUВНг3z + "-> Token(" + token.getKey() + ")-> Unknown error: " + youcangetnoinfoGXVв1zzР);
/*     */         
/* 132 */         bool = false;
/*     */       }
/* 134 */       catch (IOException youcangetnoinfoGXWвыРшЕ) {
/* 135 */         youcangetnoinfoGXWвыРшЕ.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\FriendSpammer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */