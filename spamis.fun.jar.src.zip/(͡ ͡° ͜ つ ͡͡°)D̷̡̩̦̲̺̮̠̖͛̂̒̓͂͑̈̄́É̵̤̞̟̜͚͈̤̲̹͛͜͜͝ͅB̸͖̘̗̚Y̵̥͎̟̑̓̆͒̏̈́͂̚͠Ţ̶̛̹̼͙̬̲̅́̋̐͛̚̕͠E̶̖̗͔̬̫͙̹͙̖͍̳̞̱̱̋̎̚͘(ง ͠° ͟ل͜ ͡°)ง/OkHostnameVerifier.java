/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.security.cert.CertificateParsingException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class OkHostnameVerifier
/*     */   implements HostnameVerifier
/*     */ {
/*     */   public static final int ALT_IPA_NAME = 7;
/*  37 */   public static final OkHostnameVerifier INSTANCE = new OkHostnameVerifier();
/*     */   
/*     */   public static final int ALT_DNS_NAME = 2;
/*     */   
/*     */   public OkHostnameVerifier() {
/*  42 */     this();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean verify(Object youcangetnoinfoDOWRл98фМ, Object youcangetnoinfoDOWS81Иёz) {
/*     */     try {
/*  48 */       Object youcangetnoinfoDOWOйаюёС = youcangetnoinfoDOWS81Иёz.getPeerCertificates();
/*  49 */       return super.verify((String)youcangetnoinfoDOWRл98фМ, (X509Certificate)youcangetnoinfoDOWOйаюёС[0]);
/*  50 */     } catch (SSLException youcangetnoinfoDOWP590ж2) {
/*  51 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean verify(Object youcangetnoinfoDDJEУ2Дтъ, Object youcangetnoinfoDDJFчъбЁу) {
/*  56 */     return Util1.verifyAsIpAddress((String)youcangetnoinfoDDJEУ2Дтъ) ? 
/*  57 */       super.verifyIpAddress((String)youcangetnoinfoDDJEУ2Дтъ, (X509Certificate)youcangetnoinfoDDJFчъбЁу) : 
/*  58 */       super.verifyHostname((String)youcangetnoinfoDDJEУ2Дтъ, (X509Certificate)youcangetnoinfoDDJFчъбЁу);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean verifyIpAddress(Object youcangetnoinfoAVVNШСуГГ, Object youcangetnoinfoAVVOёОюкБ) {
/*  63 */     Object<String> youcangetnoinfoAVVPЩсаХЯ = (Object<String>)getSubjectAltNames((X509Certificate)youcangetnoinfoAVVOёОюкБ, 7); byte b; int i;
/*  64 */     for (b = 0, i = youcangetnoinfoAVVPЩсаХЯ.size(); b < i; b++) {
/*  65 */       if (youcangetnoinfoAVVNШСуГГ.equalsIgnoreCase(youcangetnoinfoAVVPЩсаХЯ.get(b))) {
/*  66 */         return true;
/*     */       }
/*     */     } 
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean verifyHostname(Object youcangetnoinfoBEAKкьюЦЙ, Object youcangetnoinfoBEALЬфЯЛЯ) {
/*  74 */     youcangetnoinfoBEAKкьюЦЙ = youcangetnoinfoBEAKкьюЦЙ.toLowerCase(Locale.US);
/*  75 */     Object<String> youcangetnoinfoBEAMМдОФэ = (Object<String>)getSubjectAltNames((X509Certificate)youcangetnoinfoBEALЬфЯЛЯ, 2);
/*  76 */     for (String youcangetnoinfoBEAIщУкЗШ : youcangetnoinfoBEAMМдОФэ) {
/*  77 */       if (super.verifyHostname((String)youcangetnoinfoBEAKкьюЦЙ, youcangetnoinfoBEAIщУкЗШ)) {
/*  78 */         return true;
/*     */       }
/*     */     } 
/*  81 */     return false;
/*     */   }
/*     */   
/*     */   public static List<String> allSubjectAltNames(Object youcangetnoinfoBPRTДФИЛШ) {
/*  85 */     Object<String> youcangetnoinfoBPRUЙНзЭф = (Object<String>)getSubjectAltNames((X509Certificate)youcangetnoinfoBPRTДФИЛШ, 7);
/*  86 */     Object<String> youcangetnoinfoBPRVуАНдЯ = (Object<String>)getSubjectAltNames((X509Certificate)youcangetnoinfoBPRTДФИЛШ, 2);
/*  87 */     Object youcangetnoinfoBPRWтГУмz = new ArrayList(youcangetnoinfoBPRUЙНзЭф.size() + youcangetnoinfoBPRVуАНдЯ.size());
/*  88 */     youcangetnoinfoBPRWтГУмz.addAll((Collection<? extends String>)youcangetnoinfoBPRUЙНзЭф);
/*  89 */     youcangetnoinfoBPRWтГУмz.addAll((Collection<? extends String>)youcangetnoinfoBPRVуАНдЯ);
/*  90 */     return (List<String>)youcangetnoinfoBPRWтГУмz;
/*     */   }
/*     */   
/*     */   public static List<String> getSubjectAltNames(Object youcangetnoinfoDCMQёЧювх, Object youcangetnoinfoDCMRЁЫг3Т) {
/*  94 */     Object youcangetnoinfoDCMSийМяе = new ArrayList();
/*     */     try {
/*  96 */       Object<List<?>> youcangetnoinfoDCMOйаБкд = (Object<List<?>>)youcangetnoinfoDCMQёЧювх.getSubjectAlternativeNames();
/*  97 */       if (youcangetnoinfoDCMOйаБкд == null) {
/*  98 */         return Collections.emptyList();
/*     */       }
/* 100 */       for (Object<?> youcangetnoinfoDCMNжzхzш : youcangetnoinfoDCMOйаБкд) {
/* 101 */         Object youcangetnoinfoDCMLО6пъё = youcangetnoinfoDCMNжzхzш;
/* 102 */         if (youcangetnoinfoDCMLО6пъё == null || youcangetnoinfoDCMLО6пъё.size() < 2) {
/*     */           continue;
/*     */         }
/* 105 */         Object youcangetnoinfoDCMM730Къ = youcangetnoinfoDCMLО6пъё.get(0);
/* 106 */         if (youcangetnoinfoDCMM730Къ == null) {
/*     */           continue;
/*     */         }
/* 109 */         if (youcangetnoinfoDCMM730Къ.intValue() == youcangetnoinfoDCMRЁЫг3Т) {
/* 110 */           Object youcangetnoinfoDCMKнzМоэ = youcangetnoinfoDCMLО6пъё.get(1);
/* 111 */           if (youcangetnoinfoDCMKнzМоэ != null) {
/* 112 */             youcangetnoinfoDCMSийМяе.add(youcangetnoinfoDCMKнzМоэ);
/*     */           }
/*     */         } 
/*     */       } 
/* 116 */       return (List<String>)youcangetnoinfoDCMSийМяе;
/* 117 */     } catch (CertificateParsingException youcangetnoinfoDCMPщЪшЖХ) {
/* 118 */       return Collections.emptyList();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean verifyHostname(Object youcangetnoinfoAVPMУРЖбР, Object youcangetnoinfoAVPNбщэйИ) {
/* 132 */     if (youcangetnoinfoAVPMУРЖбР == null || youcangetnoinfoAVPMУРЖбР.length() == 0 || youcangetnoinfoAVPMУРЖбР.startsWith(".") || youcangetnoinfoAVPMУРЖбР
/* 133 */       .endsWith(".."))
/*     */     {
/* 135 */       return false;
/*     */     }
/* 137 */     if (youcangetnoinfoAVPNбщэйИ == null || youcangetnoinfoAVPNбщэйИ.length() == 0 || youcangetnoinfoAVPNбщэйИ.startsWith(".") || youcangetnoinfoAVPNбщэйИ
/* 138 */       .endsWith(".."))
/*     */     {
/* 140 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     if (!youcangetnoinfoAVPMУРЖбР.endsWith(".")) {
/* 153 */       youcangetnoinfoAVPMУРЖбР = youcangetnoinfoAVPMУРЖбР + '.';
/*     */     }
/* 155 */     if (!youcangetnoinfoAVPNбщэйИ.endsWith(".")) {
/* 156 */       youcangetnoinfoAVPNбщэйИ = youcangetnoinfoAVPNбщэйИ + '.';
/*     */     }
/*     */ 
/*     */     
/* 160 */     youcangetnoinfoAVPNбщэйИ = youcangetnoinfoAVPNбщэйИ.toLowerCase(Locale.US);
/*     */ 
/*     */     
/* 163 */     if (!youcangetnoinfoAVPNбщэйИ.contains("*"))
/*     */     {
/* 165 */       return youcangetnoinfoAVPMУРЖбР.equals(youcangetnoinfoAVPNбщэйИ);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     if (!youcangetnoinfoAVPNбщэйИ.startsWith("*.") || youcangetnoinfoAVPNбщэйИ.indexOf('*', 1) != -1)
/*     */     {
/*     */       
/* 182 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     if (youcangetnoinfoAVPMУРЖбР.length() < youcangetnoinfoAVPNбщэйИ.length())
/*     */     {
/* 190 */       return false;
/*     */     }
/*     */     
/* 193 */     if ("*.".equals(youcangetnoinfoAVPNбщэйИ))
/*     */     {
/* 195 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 199 */     Object youcangetnoinfoAVPOВЭСЯт = youcangetnoinfoAVPNбщэйИ.substring(1);
/* 200 */     if (!youcangetnoinfoAVPMУРЖбР.endsWith((String)youcangetnoinfoAVPOВЭСЯт))
/*     */     {
/* 202 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 206 */     int i = youcangetnoinfoAVPMУРЖбР.length() - youcangetnoinfoAVPOВЭСЯт.length();
/* 207 */     if (i > 0 && youcangetnoinfoAVPMУРЖбР
/* 208 */       .lastIndexOf('.', i - 1) != -1)
/*     */     {
/* 210 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 214 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\OkHostnameVerifier.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */