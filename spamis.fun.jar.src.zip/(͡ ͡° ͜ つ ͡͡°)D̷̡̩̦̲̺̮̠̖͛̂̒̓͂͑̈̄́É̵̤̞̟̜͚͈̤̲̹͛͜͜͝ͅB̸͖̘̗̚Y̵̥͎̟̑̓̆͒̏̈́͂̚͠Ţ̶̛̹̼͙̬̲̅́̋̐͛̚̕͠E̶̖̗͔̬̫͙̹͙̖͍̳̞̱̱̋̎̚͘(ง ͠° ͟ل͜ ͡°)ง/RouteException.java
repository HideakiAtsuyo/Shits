/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RouteException
/*    */   extends RuntimeException
/*    */ {
/*    */   public IOException lastException;
/*    */   public IOException firstException;
/*    */   
/*    */   public RouteException(Object youcangetnoinfoBDDGхяшУЧ) {
/* 31 */     super((Throwable)youcangetnoinfoBDDGхяшУЧ);
/* 32 */     ((RouteException)super).firstException = (IOException)youcangetnoinfoBDDGхяшУЧ;
/* 33 */     ((RouteException)super).lastException = (IOException)youcangetnoinfoBDDGхяшУЧ;
/*    */   }
/*    */   
/*    */   public IOException getFirstConnectException() {
/* 37 */     return ((RouteException)super).firstException;
/*    */   }
/*    */   
/*    */   public IOException getLastConnectException() {
/* 41 */     return ((RouteException)super).lastException;
/*    */   }
/*    */   
/*    */   public void addConnectException(Object youcangetnoinfoCCKZИПьсЭ) {
/* 45 */     Util1.addSuppressedIfPossible(((RouteException)super).firstException, (Throwable)youcangetnoinfoCCKZИПьсЭ);
/* 46 */     ((RouteException)super).lastException = (IOException)youcangetnoinfoCCKZИПьсЭ;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RouteException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */