/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Proxy;
/*     */ import java.net.SocketException;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RouteSelector1
/*     */ {
/*     */   public final EventListener1 eventListener;
/*     */   public final RouteDatabase routeDatabase;
/*     */   public List<Proxy> proxies;
/*     */   public final List postponedRoutes;
/*     */   public int nextProxyIndex;
/*     */   public final Address address;
/*     */   public final Call call;
/*     */   public List<InetSocketAddress> inetSocketAddresses;
/*     */   
/*     */   public RouteSelector1(Object youcangetnoinfoEDHZъКсзи, Object youcangetnoinfoEDIAМЭОнх, Object youcangetnoinfoEDIBЗХЁОл, Object youcangetnoinfoEDICиЩСвЕ) {
/*  57 */     this(); ((RouteSelector1)super).proxies = Collections.emptyList(); ((RouteSelector1)super).inetSocketAddresses = Collections.emptyList(); ((RouteSelector1)super).postponedRoutes = new ArrayList();
/*  58 */     ((RouteSelector1)super).address = (Address)youcangetnoinfoEDHZъКсзи;
/*  59 */     ((RouteSelector1)super).routeDatabase = (RouteDatabase)youcangetnoinfoEDIAМЭОнх;
/*  60 */     ((RouteSelector1)super).call = (Call)youcangetnoinfoEDIBЗХЁОл;
/*  61 */     ((RouteSelector1)super).eventListener = (EventListener1)youcangetnoinfoEDICиЩСвЕ;
/*     */     
/*  63 */     super.resetNextProxy(youcangetnoinfoEDHZъКсзи.url(), youcangetnoinfoEDHZъКсзи.proxy());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasNext() {
/*  70 */     return (super.hasNextProxy() || !((RouteSelector1)super).postponedRoutes.isEmpty());
/*     */   }
/*     */   
/*     */   public RouteSelector next() throws IOException {
/*  74 */     if (!super.hasNext()) {
/*  75 */       throw new NoSuchElementException();
/*     */     }
/*     */ 
/*     */     
/*  79 */     Object youcangetnoinfoAZVIШ2ьВв = new ArrayList();
/*  80 */     while (super.hasNextProxy()) {
/*     */ 
/*     */ 
/*     */       
/*  84 */       Object youcangetnoinfoAZVGх6Щжь = super.nextProxy(); byte b; int i;
/*  85 */       for (b = 0, i = ((RouteSelector1)super).inetSocketAddresses.size(); b < i; b++) {
/*  86 */         Object youcangetnoinfoAZVDёzРЙ6 = new Route(((RouteSelector1)super).address, (Proxy)youcangetnoinfoAZVGх6Щжь, ((RouteSelector1)super).inetSocketAddresses.get(b));
/*  87 */         if (((RouteSelector1)super).routeDatabase.shouldPostpone((Route)youcangetnoinfoAZVDёzРЙ6)) {
/*  88 */           ((RouteSelector1)super).postponedRoutes.add(youcangetnoinfoAZVDёzРЙ6);
/*     */         } else {
/*  90 */           youcangetnoinfoAZVIШ2ьВв.add(youcangetnoinfoAZVDёzРЙ6);
/*     */         } 
/*     */       } 
/*     */       
/*  94 */       if (!youcangetnoinfoAZVIШ2ьВв.isEmpty()) {
/*     */         break;
/*     */       }
/*     */     } 
/*     */     
/*  99 */     if (youcangetnoinfoAZVIШ2ьВв.isEmpty()) {
/*     */       
/* 101 */       youcangetnoinfoAZVIШ2ьВв.addAll(((RouteSelector1)super).postponedRoutes);
/* 102 */       ((RouteSelector1)super).postponedRoutes.clear();
/*     */     } 
/*     */     
/* 105 */     return new RouteSelector((List)youcangetnoinfoAZVIШ2ьВв);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectFailed(Object youcangetnoinfoCJFTыЩйлЬ, Object youcangetnoinfoCJFUёэИоц) {
/* 113 */     if (youcangetnoinfoCJFTыЩйлЬ.proxy().type() != Proxy.Type.DIRECT && ((RouteSelector1)super).address.proxySelector() != null)
/*     */     {
/* 115 */       ((RouteSelector1)super).address.proxySelector().connectFailed(((RouteSelector1)super).address
/* 116 */           .url().uri(), youcangetnoinfoCJFTыЩйлЬ.proxy().address(), (IOException)youcangetnoinfoCJFUёэИоц);
/*     */     }
/*     */     
/* 119 */     ((RouteSelector1)super).routeDatabase.failed((Route)youcangetnoinfoCJFTыЩйлЬ);
/*     */   }
/*     */ 
/*     */   
/*     */   public void resetNextProxy(Object youcangetnoinfoQMJхз09ы, Object youcangetnoinfoQMKЕД987) {
/* 124 */     if (youcangetnoinfoQMKЕД987 != null) {
/*     */       
/* 126 */       ((RouteSelector1)super).proxies = Collections.singletonList(youcangetnoinfoQMKЕД987);
/*     */     } else {
/*     */       
/* 129 */       Object<Proxy> youcangetnoinfoQMHВ4фР3 = (Object<Proxy>)((RouteSelector1)super).address.proxySelector().select(youcangetnoinfoQMJхз09ы.uri());
/* 130 */       ((RouteSelector1)super)
/*     */         
/* 132 */         .proxies = (youcangetnoinfoQMHВ4фР3 != null && !youcangetnoinfoQMHВ4фР3.isEmpty()) ? Util1.<Proxy>immutableList((List<Proxy>)youcangetnoinfoQMHВ4фР3) : Util1.<Proxy>immutableList(new Proxy[] { Proxy.NO_PROXY });
/*     */     } 
/* 134 */     ((RouteSelector1)super).nextProxyIndex = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean hasNextProxy() {
/* 139 */     return (((RouteSelector1)super).nextProxyIndex < ((RouteSelector1)super).proxies.size());
/*     */   }
/*     */ 
/*     */   
/*     */   public Proxy nextProxy() throws IOException {
/* 144 */     if (!super.hasNextProxy()) {
/* 145 */       throw new SocketException("No route to " + super.address.url().host() + "; exhausted proxy configurations: " + super.proxies);
/*     */     }
/*     */     
/* 148 */     Object youcangetnoinfoASUNЁzЕиз = ((RouteSelector1)super).proxies.get(((RouteSelector1)super).nextProxyIndex++);
/* 149 */     super.resetNextInetSocketAddress((Proxy)youcangetnoinfoASUNЁzЕиз);
/* 150 */     return (Proxy)youcangetnoinfoASUNЁzЕиз;
/*     */   }
/*     */   
/*     */   public void resetNextInetSocketAddress(Object youcangetnoinfoCRLьшРём) throws IOException {
/*     */     Object youcangetnoinfoCRMЙнмЪч;
/*     */     int i;
/* 156 */     ((RouteSelector1)super).inetSocketAddresses = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (youcangetnoinfoCRLьшРём.type() == Proxy.Type.DIRECT || youcangetnoinfoCRLьшРём.type() == Proxy.Type.SOCKS) {
/* 161 */       Object youcangetnoinfoCRCэцТЬ0 = ((RouteSelector1)super).address.url().host();
/* 162 */       i = ((RouteSelector1)super).address.url().port();
/*     */     } else {
/* 164 */       Object youcangetnoinfoCREЗЁлёД = youcangetnoinfoCRLьшРём.address();
/* 165 */       if (!(youcangetnoinfoCREЗЁлёД instanceof InetSocketAddress)) {
/* 166 */         throw new IllegalArgumentException("Proxy.address() is not an InetSocketAddress: " + youcangetnoinfoCREЗЁлёД
/* 167 */             .getClass());
/*     */       }
/* 169 */       Object youcangetnoinfoCRFёэтиВ = youcangetnoinfoCREЗЁлёД;
/* 170 */       youcangetnoinfoCRMЙнмЪч = getHostString((InetSocketAddress)youcangetnoinfoCRFёэтиВ);
/* 171 */       i = youcangetnoinfoCRFёэтиВ.getPort();
/*     */     } 
/*     */     
/* 174 */     if (i < 1 || i > 65535) {
/* 175 */       throw new SocketException("No route to " + youcangetnoinfoCRMЙнмЪч + ":" + i + "; port is out of range");
/*     */     }
/*     */ 
/*     */     
/* 179 */     if (youcangetnoinfoCRLьшРём.type() == Proxy.Type.SOCKS) {
/* 180 */       ((RouteSelector1)super).inetSocketAddresses.add(InetSocketAddress.createUnresolved((String)youcangetnoinfoCRMЙнмЪч, i));
/*     */     } else {
/* 182 */       ((RouteSelector1)super).eventListener.dnsStart(((RouteSelector1)super).call, (String)youcangetnoinfoCRMЙнмЪч);
/*     */ 
/*     */       
/* 185 */       Object<InetAddress> youcangetnoinfoCRJКТвгщ = (Object<InetAddress>)((RouteSelector1)super).address.dns().lookup((String)youcangetnoinfoCRMЙнмЪч);
/* 186 */       if (youcangetnoinfoCRJКТвгщ.isEmpty()) {
/* 187 */         throw new UnknownHostException(super.address.dns() + " returned no addresses for " + youcangetnoinfoCRMЙнмЪч);
/*     */       }
/*     */       
/* 190 */       ((RouteSelector1)super).eventListener.dnsEnd(((RouteSelector1)super).call, (String)youcangetnoinfoCRMЙнмЪч, (List)youcangetnoinfoCRJКТвгщ); byte b;
/*     */       int j;
/* 192 */       for (b = 0, j = youcangetnoinfoCRJКТвгщ.size(); b < j; b++) {
/* 193 */         Object youcangetnoinfoCRG0Ш7ЕБ = youcangetnoinfoCRJКТвгщ.get(b);
/* 194 */         ((RouteSelector1)super).inetSocketAddresses.add(new InetSocketAddress((InetAddress)youcangetnoinfoCRG0Ш7ЕБ, i));
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getHostString(Object youcangetnoinfoCRDA4лмА6) {
/* 205 */     Object youcangetnoinfoCRDBыййтд = youcangetnoinfoCRDA4лмА6.getAddress();
/* 206 */     if (youcangetnoinfoCRDBыййтд == null)
/*     */     {
/*     */ 
/*     */       
/* 210 */       return youcangetnoinfoCRDA4лмА6.getHostName();
/*     */     }
/*     */ 
/*     */     
/* 214 */     return youcangetnoinfoCRDBыййтд.getHostAddress();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RouteSelector1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */