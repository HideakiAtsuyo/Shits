package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;

import java.io.IOException;
import java.util.List;

public interface Http2Reader1 {
  void priority(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean);
  
  void headers(boolean paramBoolean, int paramInt1, int paramInt2, List paramList);
  
  void rstStream(int paramInt, ErrorCode paramErrorCode);
  
  void goAway(int paramInt, ErrorCode paramErrorCode, ByteString paramByteString);
  
  void data(boolean paramBoolean, int paramInt1, BufferedSource paramBufferedSource, int paramInt2) throws IOException;
  
  void settings(boolean paramBoolean, Settings paramSettings);
  
  void windowUpdate(int paramInt, long paramLong);
  
  void alternateService(int paramInt1, String paramString1, ByteString paramByteString, String paramString2, int paramInt2, long paramLong);
  
  void ping(boolean paramBoolean, int paramInt1, int paramInt2);
  
  void ackSettings();
  
  void pushPromise(int paramInt1, int paramInt2, List paramList) throws IOException;
}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http2Reader1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */