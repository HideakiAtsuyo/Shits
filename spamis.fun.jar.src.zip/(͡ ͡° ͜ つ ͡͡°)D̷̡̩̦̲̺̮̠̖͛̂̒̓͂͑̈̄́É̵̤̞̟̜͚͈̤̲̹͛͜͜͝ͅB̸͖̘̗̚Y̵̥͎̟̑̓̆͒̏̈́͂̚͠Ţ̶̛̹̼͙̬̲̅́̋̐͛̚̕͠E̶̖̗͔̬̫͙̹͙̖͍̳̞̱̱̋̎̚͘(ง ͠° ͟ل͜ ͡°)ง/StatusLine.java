/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class StatusLine
/*     */ {
/*     */   public static final int HTTP_CONTINUE = 100;
/*     */   public static final int HTTP_TEMP_REDIRECT = 307;
/*     */   public final String message;
/*     */   public final Protocol protocol;
/*     */   public final int code;
/*     */   public static final int HTTP_PERM_REDIRECT = 308;
/*     */   
/*     */   public StatusLine(Object youcangetnoinfoDZZFщёкАz, Object youcangetnoinfoDZZGё0ПЧ1, Object youcangetnoinfoDZZHщГйвж) {
/*  34 */     this();
/*  35 */     ((StatusLine)super).protocol = (Protocol)youcangetnoinfoDZZFщёкАz;
/*  36 */     ((StatusLine)super).code = youcangetnoinfoDZZGё0ПЧ1;
/*  37 */     ((StatusLine)super).message = (String)youcangetnoinfoDZZHщГйвж;
/*     */   }
/*     */   
/*     */   public static StatusLine get(Object youcangetnoinfoCGNQъЮпШ3) {
/*  41 */     return new StatusLine(youcangetnoinfoCGNQъЮпШ3.protocol(), youcangetnoinfoCGNQъЮпШ3.code(), youcangetnoinfoCGNQъЮпШ3.message());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static StatusLine parse(Object youcangetnoinfoAISRеёЛХь) throws IOException {
/*     */     byte b;
/*     */     Object youcangetnoinfoAISOеъЗХ7;
/*     */     int i;
/*  51 */     if (youcangetnoinfoAISRеёЛХь.startsWith("HTTP/1.")) {
/*  52 */       if (youcangetnoinfoAISRеёЛХь.length() < 9 || youcangetnoinfoAISRеёЛХь.charAt(8) != ' ') {
/*  53 */         throw new ProtocolException("Unexpected status line: " + youcangetnoinfoAISRеёЛХь);
/*     */       }
/*  55 */       i = youcangetnoinfoAISRеёЛХь.charAt(7) - 48;
/*  56 */       b = 9;
/*  57 */       if (i == 0) {
/*  58 */         Object youcangetnoinfoAISI4о1ДИ = Protocol.HTTP_1_0;
/*  59 */       } else if (i == 1) {
/*  60 */         Object youcangetnoinfoAISJТх1Еь = Protocol.HTTP_1_1;
/*     */       } else {
/*  62 */         throw new ProtocolException("Unexpected status line: " + youcangetnoinfoAISRеёЛХь);
/*     */       } 
/*  64 */     } else if (youcangetnoinfoAISRеёЛХь.startsWith("ICY ")) {
/*     */       
/*  66 */       youcangetnoinfoAISOеъЗХ7 = Protocol.HTTP_1_0;
/*  67 */       b = 4;
/*     */     } else {
/*  69 */       throw new ProtocolException("Unexpected status line: " + youcangetnoinfoAISRеёЛХь);
/*     */     } 
/*     */ 
/*     */     
/*  73 */     if (youcangetnoinfoAISRеёЛХь.length() < b + 3) {
/*  74 */       throw new ProtocolException("Unexpected status line: " + youcangetnoinfoAISRеёЛХь);
/*     */     }
/*     */     
/*     */     try {
/*  78 */       i = Integer.parseInt(youcangetnoinfoAISRеёЛХь.substring(b, b + 3));
/*  79 */     } catch (NumberFormatException youcangetnoinfoAISQЙzКМБ) {
/*  80 */       throw new ProtocolException("Unexpected status line: " + youcangetnoinfoAISRеёЛХь);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  85 */     Object youcangetnoinfoAISVшооГБ = "";
/*  86 */     if (youcangetnoinfoAISRеёЛХь.length() > b + 3) {
/*  87 */       if (youcangetnoinfoAISRеёЛХь.charAt(b + 3) != ' ') {
/*  88 */         throw new ProtocolException("Unexpected status line: " + youcangetnoinfoAISRеёЛХь);
/*     */       }
/*  90 */       youcangetnoinfoAISVшооГБ = youcangetnoinfoAISRеёЛХь.substring(b + 4);
/*     */     } 
/*     */     
/*  93 */     return new StatusLine((Protocol)youcangetnoinfoAISOеъЗХ7, i, (String)youcangetnoinfoAISVшооГБ);
/*     */   }
/*     */   
/*     */   public String toString() {
/*  97 */     Object youcangetnoinfoBLWNзВа0ш = new StringBuilder();
/*  98 */     youcangetnoinfoBLWNзВа0ш.append((((StatusLine)super).protocol == Protocol.HTTP_1_0) ? "HTTP/1.0" : "HTTP/1.1");
/*  99 */     youcangetnoinfoBLWNзВа0ш.append(' ').append(((StatusLine)super).code);
/* 100 */     if (((StatusLine)super).message != null) {
/* 101 */       youcangetnoinfoBLWNзВа0ш.append(' ').append(((StatusLine)super).message);
/*     */     }
/* 103 */     return youcangetnoinfoBLWNзВа0ш.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\StatusLine.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */