/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class WebSocketReader
/*     */ {
/*     */   public int opcode;
/*     */   public final Buffer2 controlFrameBuffer;
/*     */   public boolean isFinalFrame;
/*     */   public final boolean isClient;
/*     */   public final WebSocketReader1 frameCallback;
/*     */   public final Buffer2 messageFrameBuffer;
/*     */   public boolean closed;
/*     */   public final BufferedSource source;
/*     */   public boolean isControlFrame;
/*     */   public final byte[] maskKey;
/*     */   public long frameLength;
/*     */   public final Buffer1 maskCursor;
/*     */   
/*     */   public WebSocketReader(Object youcangetnoinfoSWZхАцфЯ, Object youcangetnoinfoSXAЁщхАц, Object youcangetnoinfoSXBХМРФ6) {
/*  78 */     this(); ((WebSocketReader)super).controlFrameBuffer = new Buffer2(); ((WebSocketReader)super).messageFrameBuffer = new Buffer2();
/*  79 */     if (youcangetnoinfoSXAЁщхАц == null) throw new NullPointerException("source == null"); 
/*  80 */     if (youcangetnoinfoSXBХМРФ6 == null) throw new NullPointerException("frameCallback == null"); 
/*  81 */     ((WebSocketReader)super).isClient = youcangetnoinfoSWZхАцфЯ;
/*  82 */     ((WebSocketReader)super).source = (BufferedSource)youcangetnoinfoSXAЁщхАц;
/*  83 */     ((WebSocketReader)super).frameCallback = (WebSocketReader1)youcangetnoinfoSXBХМРФ6;
/*     */ 
/*     */     
/*  86 */     ((WebSocketReader)super).maskKey = (youcangetnoinfoSWZхАцфЯ != null) ? null : new byte[4];
/*  87 */     ((WebSocketReader)super).maskCursor = (youcangetnoinfoSWZхАцфЯ != null) ? null : new Buffer1();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void processNextFrame() throws IOException {
/* 101 */     super.readHeader();
/* 102 */     if (((WebSocketReader)super).isControlFrame) {
/* 103 */       super.readControlFrame();
/*     */     } else {
/* 105 */       super.readMessageFrame();
/*     */     } 
/*     */   }
/*     */   public void readHeader() throws IOException {
/*     */     int i;
/* 110 */     if (((WebSocketReader)super).closed) throw new IOException("closed");
/*     */ 
/*     */ 
/*     */     
/* 114 */     long l = ((WebSocketReader)super).source.timeout().timeoutNanos();
/* 115 */     ((WebSocketReader)super).source.timeout().clearTimeout();
/*     */     try {
/* 117 */       i = ((WebSocketReader)super).source.readByte() & 0xFF;
/*     */     } finally {
/* 119 */       ((WebSocketReader)super).source.timeout().timeout(l, TimeUnit.NANOSECONDS);
/*     */     } 
/*     */     
/* 122 */     ((WebSocketReader)super).opcode = i & 0xF;
/* 123 */     ((WebSocketReader)super).isFinalFrame = ((i & 0x80) != 0);
/* 124 */     ((WebSocketReader)super).isControlFrame = ((i & 0x8) != 0);
/*     */ 
/*     */     
/* 127 */     if (((WebSocketReader)super).isControlFrame && !((WebSocketReader)super).isFinalFrame) {
/* 128 */       throw new ProtocolException("Control frames must be final.");
/*     */     }
/*     */     
/* 131 */     boolean bool1 = ((i & 0x40) != 0) ? true : false;
/* 132 */     boolean bool2 = ((i & 0x20) != 0) ? true : false;
/* 133 */     boolean bool3 = ((i & 0x10) != 0) ? true : false;
/* 134 */     if (bool1 || bool2 || bool3)
/*     */     {
/* 136 */       throw new ProtocolException("Reserved flags are unsupported.");
/*     */     }
/*     */     
/* 139 */     int j = ((WebSocketReader)super).source.readByte() & 0xFF;
/*     */     
/* 141 */     boolean bool = ((j & 0x80) != 0);
/* 142 */     if (bool == ((WebSocketReader)super).isClient)
/*     */     {
/* 144 */       throw new ProtocolException(super.isClient ? 
/* 145 */           "Server-sent frames must not be masked." : 
/* 146 */           "Client-sent frames must be masked.");
/*     */     }
/*     */ 
/*     */     
/* 150 */     ((WebSocketReader)super).frameLength = (j & 0x7F);
/* 151 */     if (((WebSocketReader)super).frameLength == 126L) {
/* 152 */       ((WebSocketReader)super).frameLength = ((WebSocketReader)super).source.readShort() & 0xFFFFL;
/* 153 */     } else if (((WebSocketReader)super).frameLength == 127L) {
/* 154 */       ((WebSocketReader)super).frameLength = ((WebSocketReader)super).source.readLong();
/* 155 */       if (((WebSocketReader)super).frameLength < 0L) {
/* 156 */         throw new ProtocolException("Frame length 0x" + 
/* 157 */             Long.toHexString(super.frameLength) + " > 0x7FFFFFFFFFFFFFFF");
/*     */       }
/*     */     } 
/*     */     
/* 161 */     if (((WebSocketReader)super).isControlFrame && ((WebSocketReader)super).frameLength > 125L) {
/* 162 */       throw new ProtocolException("Control frame must be less than 125B.");
/*     */     }
/*     */     
/* 165 */     if (bool)
/*     */     {
/* 167 */       ((WebSocketReader)super).source.readFully(((WebSocketReader)super).maskKey); } 
/*     */   } public void readControlFrame() throws IOException {
/*     */     short s;
/*     */     Object youcangetnoinfoDTLFХСчтВ;
/*     */     long l;
/* 172 */     if (((WebSocketReader)super).frameLength > 0L) {
/* 173 */       ((WebSocketReader)super).source.readFully(((WebSocketReader)super).controlFrameBuffer, ((WebSocketReader)super).frameLength);
/*     */       
/* 175 */       if (!((WebSocketReader)super).isClient) {
/* 176 */         ((WebSocketReader)super).controlFrameBuffer.readAndWriteUnsafe(((WebSocketReader)super).maskCursor);
/* 177 */         ((WebSocketReader)super).maskCursor.seek(0L);
/* 178 */         WebSocketProtocol.toggleMask(((WebSocketReader)super).maskCursor, ((WebSocketReader)super).maskKey);
/* 179 */         ((WebSocketReader)super).maskCursor.close();
/*     */       } 
/*     */     } 
/*     */     
/* 183 */     switch (((WebSocketReader)super).opcode) {
/*     */       case 9:
/* 185 */         ((WebSocketReader)super).frameCallback.onReadPing(((WebSocketReader)super).controlFrameBuffer.readByteString());
/*     */         return;
/*     */       case 10:
/* 188 */         ((WebSocketReader)super).frameCallback.onReadPong(((WebSocketReader)super).controlFrameBuffer.readByteString());
/*     */         return;
/*     */       case 8:
/* 191 */         s = 1005;
/* 192 */         youcangetnoinfoDTLFХСчтВ = "";
/* 193 */         l = ((WebSocketReader)super).controlFrameBuffer.size();
/* 194 */         if (l == 1L)
/* 195 */           throw new ProtocolException("Malformed close payload length of 1."); 
/* 196 */         if (l != 0L) {
/* 197 */           s = ((WebSocketReader)super).controlFrameBuffer.readShort();
/* 198 */           youcangetnoinfoDTLFХСчтВ = ((WebSocketReader)super).controlFrameBuffer.readUtf8();
/* 199 */           Object youcangetnoinfoDTLDезЩ2н = WebSocketProtocol.closeCodeExceptionMessage(s);
/* 200 */           if (youcangetnoinfoDTLDезЩ2н != null) throw new ProtocolException(youcangetnoinfoDTLDезЩ2н); 
/*     */         } 
/* 202 */         ((WebSocketReader)super).frameCallback.onReadClose(s, (String)youcangetnoinfoDTLFХСчтВ);
/* 203 */         ((WebSocketReader)super).closed = true;
/*     */         return;
/*     */     } 
/* 206 */     throw new ProtocolException("Unknown control opcode: " + Integer.toHexString(super.opcode));
/*     */   }
/*     */ 
/*     */   
/*     */   public void readMessageFrame() throws IOException {
/* 211 */     int i = ((WebSocketReader)super).opcode;
/* 212 */     if (i != 1 && i != 2) {
/* 213 */       throw new ProtocolException("Unknown opcode: " + Integer.toHexString(i));
/*     */     }
/*     */     
/* 216 */     super.readMessage();
/*     */     
/* 218 */     if (i == 1) {
/* 219 */       ((WebSocketReader)super).frameCallback.onReadMessage(((WebSocketReader)super).messageFrameBuffer.readUtf8());
/*     */     } else {
/* 221 */       ((WebSocketReader)super).frameCallback.onReadMessage(((WebSocketReader)super).messageFrameBuffer.readByteString());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void readUntilNonControlFrame() throws IOException {
/* 227 */     while (!((WebSocketReader)super).closed) {
/* 228 */       super.readHeader();
/* 229 */       if (!((WebSocketReader)super).isControlFrame) {
/*     */         break;
/*     */       }
/* 232 */       super.readControlFrame();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void readMessage() throws IOException {
/*     */     while (true) {
/* 243 */       if (((WebSocketReader)super).closed) throw new IOException("closed");
/*     */       
/* 245 */       if (((WebSocketReader)super).frameLength > 0L) {
/* 246 */         ((WebSocketReader)super).source.readFully(((WebSocketReader)super).messageFrameBuffer, ((WebSocketReader)super).frameLength);
/*     */         
/* 248 */         if (!((WebSocketReader)super).isClient) {
/* 249 */           ((WebSocketReader)super).messageFrameBuffer.readAndWriteUnsafe(((WebSocketReader)super).maskCursor);
/* 250 */           ((WebSocketReader)super).maskCursor.seek(((WebSocketReader)super).messageFrameBuffer.size() - ((WebSocketReader)super).frameLength);
/* 251 */           WebSocketProtocol.toggleMask(((WebSocketReader)super).maskCursor, ((WebSocketReader)super).maskKey);
/* 252 */           ((WebSocketReader)super).maskCursor.close();
/*     */         } 
/*     */       } 
/*     */       
/* 256 */       if (((WebSocketReader)super).isFinalFrame)
/*     */         break; 
/* 258 */       super.readUntilNonControlFrame();
/* 259 */       if (((WebSocketReader)super).opcode != 0)
/* 260 */         throw new ProtocolException("Expected continuation opcode. Got: " + Integer.toHexString(super.opcode)); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\WebSocketReader.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */