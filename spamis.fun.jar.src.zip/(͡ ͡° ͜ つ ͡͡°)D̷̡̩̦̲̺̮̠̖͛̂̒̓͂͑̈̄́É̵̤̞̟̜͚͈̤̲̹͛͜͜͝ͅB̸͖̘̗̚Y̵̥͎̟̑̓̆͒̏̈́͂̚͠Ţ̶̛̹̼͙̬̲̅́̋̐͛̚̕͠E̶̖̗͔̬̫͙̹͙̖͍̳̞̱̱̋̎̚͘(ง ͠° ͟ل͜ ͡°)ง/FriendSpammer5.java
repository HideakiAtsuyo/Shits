/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FriendSpammer5
/*    */   extends Thread
/*    */ {
/*    */   public final Map.Entry val$token;
/*    */   public final FriendSpammer2 this$2;
/*    */   
/*    */   public void run() {
/* 61 */     boolean bool = true;
/* 62 */     while (bool) {
/*    */       try {
/* 64 */         Object youcangetnoinfoACDYБшЬтЙ = SpamUtils.getRandomProxy();
/* 65 */         Object youcangetnoinfoACDZчЖпГо = SpamUtils.addFriend(userIdTxt.getText(), token
/* 66 */             .getValue().toString(), (String)youcangetnoinfoACDYБшЬтЙ);
/* 67 */         if (youcangetnoinfoACDZчЖпГо == null) {
/*    */           
/* 69 */           ConsoleGUI.log(youcangetnoinfoACDYБшЬтЙ + "-> Token(" + token.getKey() + ")-> Friend added");
/* 70 */           bool = false; continue;
/* 71 */         }  if (youcangetnoinfoACDZчЖпГо.startsWith("<")) {
/* 72 */           ConsoleGUI.log(youcangetnoinfoACDYБшЬтЙ + "-> Token(" + token.getKey() + ")-> Proxy failed. Retrying");
/*    */           continue;
/*    */         } 
/* 75 */         ConsoleGUI.log(youcangetnoinfoACDYБшЬтЙ + "-> Token(" + token.getKey() + ")-> Unknown error: " + youcangetnoinfoACDZчЖпГо);
/*    */         
/* 77 */         bool = false;
/*    */       }
/* 79 */       catch (IOException youcangetnoinfoACEAЧЛЫЦЛ) {
/* 80 */         youcangetnoinfoACEAЧЛЫЦЛ.printStackTrace();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\FriendSpammer5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */