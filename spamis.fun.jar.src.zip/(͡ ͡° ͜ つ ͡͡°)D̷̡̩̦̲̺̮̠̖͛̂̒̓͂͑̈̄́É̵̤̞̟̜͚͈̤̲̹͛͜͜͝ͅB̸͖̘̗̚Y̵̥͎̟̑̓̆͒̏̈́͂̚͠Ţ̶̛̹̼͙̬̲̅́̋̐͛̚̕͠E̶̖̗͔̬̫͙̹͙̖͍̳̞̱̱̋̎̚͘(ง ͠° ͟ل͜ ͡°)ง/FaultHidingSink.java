/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FaultHidingSink
/*    */   extends ForwardingSink
/*    */ {
/*    */   public boolean hasErrors;
/*    */   
/*    */   public FaultHidingSink(Object youcangetnoinfoEDKCЮСйШФ) {
/* 28 */     super((Sink)youcangetnoinfoEDKCЮСйШФ);
/*    */   }
/*    */   
/*    */   public void write(Object youcangetnoinfoCEZRжиПМт, Object youcangetnoinfoCEZSкЛбЪЁ) throws IOException {
/* 32 */     if (((FaultHidingSink)super).hasErrors) {
/* 33 */       youcangetnoinfoCEZRжиПМт.skip(youcangetnoinfoCEZSкЛбЪЁ);
/*    */       return;
/*    */     } 
/*    */     try {
/* 37 */       super.write((Buffer2)youcangetnoinfoCEZRжиПМт, youcangetnoinfoCEZSкЛбЪЁ);
/* 38 */     } catch (IOException youcangetnoinfoCEZPАТШЭ8) {
/* 39 */       ((FaultHidingSink)super).hasErrors = true;
/* 40 */       super.onException((IOException)youcangetnoinfoCEZPАТШЭ8);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void flush() throws IOException {
/* 45 */     if (((FaultHidingSink)super).hasErrors)
/*    */       return;  try {
/* 47 */       super.flush();
/* 48 */     } catch (IOException youcangetnoinfoSJDщъ2НС) {
/* 49 */       ((FaultHidingSink)super).hasErrors = true;
/* 50 */       super.onException((IOException)youcangetnoinfoSJDщъ2НС);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 55 */     if (((FaultHidingSink)super).hasErrors)
/*    */       return;  try {
/* 57 */       super.close();
/* 58 */     } catch (IOException youcangetnoinfoEDPAТ7Йлъ) {
/* 59 */       ((FaultHidingSink)super).hasErrors = true;
/* 60 */       super.onException((IOException)youcangetnoinfoEDPAТ7Йлъ);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void onException(Object youcangetnoinfoEALTаЩПву) {}
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\FaultHidingSink.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */