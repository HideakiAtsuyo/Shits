/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Response1
/*     */ {
/*     */   @Nullable
/*     */   public Response networkResponse;
/*     */   public long sentRequestAtMillis;
/*     */   @Nullable
/*     */   public Protocol protocol;
/*     */   @Nullable
/*     */   public ResponseBody body;
/*     */   @Nullable
/*     */   public Response priorResponse;
/*     */   public long receivedResponseAtMillis;
/*     */   public Headers1 headers;
/*     */   public int code;
/*     */   @Nullable
/*     */   public HttpCodec httpCodec;
/*     */   @Nullable
/*     */   public Request request;
/*     */   public String message;
/*     */   @Nullable
/*     */   public Handshake handshake;
/*     */   @Nullable
/*     */   public Response cacheResponse;
/*     */   
/*     */   public Response1() {
/* 319 */     this(); ((Response1)super).code = -1;
/* 320 */     ((Response1)super).headers = new Headers1();
/*     */   }
/*     */   public Response1(Object youcangetnoinfoBYEAяюуШш) {
/* 323 */     this(); ((Response1)super).code = -1;
/* 324 */     ((Response1)super).request = ((Response)youcangetnoinfoBYEAяюуШш).request;
/* 325 */     ((Response1)super).protocol = ((Response)youcangetnoinfoBYEAяюуШш).protocol;
/* 326 */     ((Response1)super).code = ((Response)youcangetnoinfoBYEAяюуШш).code;
/* 327 */     ((Response1)super).message = ((Response)youcangetnoinfoBYEAяюуШш).message;
/* 328 */     ((Response1)super).handshake = ((Response)youcangetnoinfoBYEAяюуШш).handshake;
/* 329 */     ((Response1)super).headers = ((Response)youcangetnoinfoBYEAяюуШш).headers.newBuilder();
/* 330 */     ((Response1)super).body = ((Response)youcangetnoinfoBYEAяюуШш).body;
/* 331 */     ((Response1)super).networkResponse = ((Response)youcangetnoinfoBYEAяюуШш).networkResponse;
/* 332 */     ((Response1)super).cacheResponse = ((Response)youcangetnoinfoBYEAяюуШш).cacheResponse;
/* 333 */     ((Response1)super).priorResponse = ((Response)youcangetnoinfoBYEAяюуШш).priorResponse;
/* 334 */     ((Response1)super).sentRequestAtMillis = ((Response)youcangetnoinfoBYEAяюуШш).sentRequestAtMillis;
/* 335 */     ((Response1)super).receivedResponseAtMillis = ((Response)youcangetnoinfoBYEAяюуШш).receivedResponseAtMillis;
/* 336 */     ((Response1)super).httpCodec = ((Response)youcangetnoinfoBYEAяюуШш).httpCodec;
/*     */   }
/*     */   
/*     */   public Response1 request(Object youcangetnoinfoECWUдкЫОЗ) {
/* 340 */     ((Response1)super).request = (Request)youcangetnoinfoECWUдкЫОЗ;
/* 341 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 protocol(Object youcangetnoinfoBUUFюЙ87В) {
/* 345 */     ((Response1)super).protocol = (Protocol)youcangetnoinfoBUUFюЙ87В;
/* 346 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 code(Object youcangetnoinfoAIZDВЧштЗ) {
/* 350 */     ((Response1)super).code = youcangetnoinfoAIZDВЧштЗ;
/* 351 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 message(Object youcangetnoinfoBRAJВьЛХА) {
/* 355 */     ((Response1)super).message = (String)youcangetnoinfoBRAJВьЛХА;
/* 356 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 handshake(@Nullable Object youcangetnoinfoBZDYьВ964) {
/* 360 */     ((Response1)super).handshake = (Handshake)youcangetnoinfoBZDYьВ964;
/* 361 */     return (Response1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response1 header(Object youcangetnoinfoEFZOцЮасУ, Object youcangetnoinfoEFZPтАлЧд) {
/* 369 */     ((Response1)super).headers.set((String)youcangetnoinfoEFZOцЮасУ, (String)youcangetnoinfoEFZPтАлЧд);
/* 370 */     return (Response1)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Response1 addHeader(Object youcangetnoinfoBAIOврЮГ3, Object youcangetnoinfoBAIPпЦИЦ0) {
/* 378 */     ((Response1)super).headers.add((String)youcangetnoinfoBAIOврЮГ3, (String)youcangetnoinfoBAIPпЦИЦ0);
/* 379 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 removeHeader(Object youcangetnoinfoLNYЛдни6) {
/* 383 */     ((Response1)super).headers.removeAll((String)youcangetnoinfoLNYЛдни6);
/* 384 */     return (Response1)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public Response1 headers(Object youcangetnoinfoDWARБЧОоб) {
/* 389 */     ((Response1)super).headers = youcangetnoinfoDWARБЧОоб.newBuilder();
/* 390 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 body(@Nullable Object youcangetnoinfoCTTKачЮю2) {
/* 394 */     ((Response1)super).body = (ResponseBody)youcangetnoinfoCTTKачЮю2;
/* 395 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 networkResponse(@Nullable Object youcangetnoinfoDSCOЬЛЦу3) {
/* 399 */     if (youcangetnoinfoDSCOЬЛЦу3 != null) super.checkSupportResponse("networkResponse", (Response)youcangetnoinfoDSCOЬЛЦу3); 
/* 400 */     ((Response1)super).networkResponse = (Response)youcangetnoinfoDSCOЬЛЦу3;
/* 401 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 cacheResponse(@Nullable Object youcangetnoinfoCMKIОч2ь3) {
/* 405 */     if (youcangetnoinfoCMKIОч2ь3 != null) super.checkSupportResponse("cacheResponse", (Response)youcangetnoinfoCMKIОч2ь3); 
/* 406 */     ((Response1)super).cacheResponse = (Response)youcangetnoinfoCMKIОч2ь3;
/* 407 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public void checkSupportResponse(Object youcangetnoinfoMNJкилчЦ, Object youcangetnoinfoMNKТпДЯс) {
/* 411 */     if (((Response)youcangetnoinfoMNKТпДЯс).body != null)
/* 412 */       throw new IllegalArgumentException(youcangetnoinfoMNJкилчЦ + ".body != null"); 
/* 413 */     if (((Response)youcangetnoinfoMNKТпДЯс).networkResponse != null)
/* 414 */       throw new IllegalArgumentException(youcangetnoinfoMNJкилчЦ + ".networkResponse != null"); 
/* 415 */     if (((Response)youcangetnoinfoMNKТпДЯс).cacheResponse != null)
/* 416 */       throw new IllegalArgumentException(youcangetnoinfoMNJкилчЦ + ".cacheResponse != null"); 
/* 417 */     if (((Response)youcangetnoinfoMNKТпДЯс).priorResponse != null) {
/* 418 */       throw new IllegalArgumentException(youcangetnoinfoMNJкилчЦ + ".priorResponse != null");
/*     */     }
/*     */   }
/*     */   
/*     */   public Response1 priorResponse(@Nullable Object youcangetnoinfoCCNDМудБъ) {
/* 423 */     if (youcangetnoinfoCCNDМудБъ != null) super.checkPriorResponse((Response)youcangetnoinfoCCNDМудБъ); 
/* 424 */     ((Response1)super).priorResponse = (Response)youcangetnoinfoCCNDМудБъ;
/* 425 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public void checkPriorResponse(Object youcangetnoinfoCRFBЙБХЖБ) {
/* 429 */     if (((Response)youcangetnoinfoCRFBЙБХЖБ).body != null) {
/* 430 */       throw new IllegalArgumentException("priorResponse.body != null");
/*     */     }
/*     */   }
/*     */   
/*     */   public Response1 sentRequestAtMillis(Object youcangetnoinfoAXTQпХЮшу) {
/* 435 */     ((Response1)super).sentRequestAtMillis = youcangetnoinfoAXTQпХЮшу;
/* 436 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public Response1 receivedResponseAtMillis(Object youcangetnoinfoBTZEЪьбьб) {
/* 440 */     ((Response1)super).receivedResponseAtMillis = youcangetnoinfoBTZEЪьбьб;
/* 441 */     return (Response1)this;
/*     */   }
/*     */   
/*     */   public void initCodec(Object youcangetnoinfoDPURУБмЦч) {
/* 445 */     ((Response1)super).httpCodec = (HttpCodec)youcangetnoinfoDPURУБмЦч;
/*     */   }
/*     */   
/*     */   public Response build() {
/* 449 */     if (((Response1)super).request == null) throw new IllegalStateException("request == null"); 
/* 450 */     if (((Response1)super).protocol == null) throw new IllegalStateException("protocol == null"); 
/* 451 */     if (((Response1)super).code < 0) throw new IllegalStateException("code < 0: " + super.code); 
/* 452 */     if (((Response1)super).message == null) throw new IllegalStateException("message == null"); 
/* 453 */     return new Response((Response1)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Response1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */