/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.net.Socket;
/*    */ import javax.annotation.Nullable;
/*    */ import javax.net.ssl.SSLSocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Internal
/*    */ {
/*    */   public static Internal instance;
/*    */   
/*    */   public abstract void put(ConnectionPool paramConnectionPool, RealConnection1 paramRealConnection1);
/*    */   
/*    */   public abstract void addLenient(Headers1 paramHeaders1, String paramString1, String paramString2);
/*    */   
/*    */   public abstract void addLenient(Headers1 paramHeaders1, String paramString);
/*    */   
/*    */   public abstract void apply(ConnectionSpec paramConnectionSpec, SSLSocket paramSSLSocket, boolean paramBoolean);
/*    */   
/*    */   public abstract boolean connectionBecameIdle(ConnectionPool paramConnectionPool, RealConnection1 paramRealConnection1);
/*    */   
/*    */   public Internal() {
/* 41 */     this();
/*    */   }
/*    */   
/*    */   public static void initializeInstanceForTests() {
/* 45 */     new OkHttpClient();
/*    */   }
/*    */   
/*    */   public abstract boolean isInvalidHttpUrlHost(IllegalArgumentException paramIllegalArgumentException);
/*    */   
/*    */   public abstract void initCodec(Response1 paramResponse1, HttpCodec paramHttpCodec);
/*    */   
/*    */   @Nullable
/*    */   public abstract IOException timeoutExit(Call paramCall, @Nullable IOException paramIOException);
/*    */   
/*    */   public abstract boolean equalsNonHost(Address paramAddress1, Address paramAddress2);
/*    */   
/*    */   public abstract void setCache(OkHttpClient1 paramOkHttpClient1, InternalCache paramInternalCache);
/*    */   
/*    */   public abstract int code(Response1 paramResponse1);
/*    */   
/*    */   public abstract StreamAllocation1 streamAllocation(Call paramCall);
/*    */   
/*    */   @Nullable
/*    */   public abstract Socket deduplicate(ConnectionPool paramConnectionPool, Address paramAddress, StreamAllocation1 paramStreamAllocation1);
/*    */   
/*    */   public abstract RouteDatabase routeDatabase(ConnectionPool paramConnectionPool);
/*    */   
/*    */   public abstract void acquire(ConnectionPool paramConnectionPool, Address paramAddress, StreamAllocation1 paramStreamAllocation1, @Nullable Route paramRoute);
/*    */   
/*    */   public abstract Call newWebSocketCall(OkHttpClient paramOkHttpClient, Request paramRequest);
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Internal.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */