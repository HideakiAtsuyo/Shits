/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class FormBody1
/*     */ {
/*     */   public final List<String> values;
/*     */   @Nullable
/*     */   public final Charset charset;
/*     */   public final List<String> names;
/*     */   
/*     */   public FormBody1() {
/* 111 */     super(null);
/*     */   }
/*     */   public FormBody1(@Nullable Object youcangetnoinfoARTP9яЪМЗ) {
/* 114 */     this(); ((FormBody1)super).names = new ArrayList<>(); ((FormBody1)super).values = new ArrayList<>();
/* 115 */     ((FormBody1)super).charset = (Charset)youcangetnoinfoARTP9яЪМЗ;
/*     */   }
/*     */   
/*     */   public FormBody1 add(Object youcangetnoinfoTSAЕШгЦж, Object youcangetnoinfoTSBШЁхд5) {
/* 119 */     if (youcangetnoinfoTSAЕШгЦж == null) throw new NullPointerException("name == null"); 
/* 120 */     if (youcangetnoinfoTSBШЁхд5 == null) throw new NullPointerException("value == null");
/*     */     
/* 122 */     ((FormBody1)super).names.add(HttpUrl1.canonicalize((String)youcangetnoinfoTSAЕШгЦж, " \"':;<=>@[]^`{}|/\\?#&!$(),~", false, false, true, true, ((FormBody1)super).charset));
/* 123 */     ((FormBody1)super).values.add(HttpUrl1.canonicalize((String)youcangetnoinfoTSBШЁхд5, " \"':;<=>@[]^`{}|/\\?#&!$(),~", false, false, true, true, ((FormBody1)super).charset));
/* 124 */     return (FormBody1)this;
/*     */   }
/*     */   
/*     */   public FormBody1 addEncoded(Object youcangetnoinfoDOMUжтпфХ, Object youcangetnoinfoDOMVД6дзд) {
/* 128 */     if (youcangetnoinfoDOMUжтпфХ == null) throw new NullPointerException("name == null"); 
/* 129 */     if (youcangetnoinfoDOMVД6дзд == null) throw new NullPointerException("value == null");
/*     */     
/* 131 */     ((FormBody1)super).names.add(HttpUrl1.canonicalize((String)youcangetnoinfoDOMUжтпфХ, " \"':;<=>@[]^`{}|/\\?#&!$(),~", true, false, true, true, ((FormBody1)super).charset));
/* 132 */     ((FormBody1)super).values.add(HttpUrl1.canonicalize((String)youcangetnoinfoDOMVД6дзд, " \"':;<=>@[]^`{}|/\\?#&!$(),~", true, false, true, true, ((FormBody1)super).charset));
/* 133 */     return (FormBody1)this;
/*     */   }
/*     */   
/*     */   public FormBody build() {
/* 137 */     return new FormBody(((FormBody1)super).names, ((FormBody1)super).values);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\FormBody1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */