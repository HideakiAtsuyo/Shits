package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.Charset;

public interface BufferedSink extends Sink, WritableByteChannel {
  BufferedSink emit() throws IOException;
  
  BufferedSink writeByte(int paramInt) throws IOException;
  
  BufferedSink write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException;
  
  BufferedSink writeDecimalLong(long paramLong) throws IOException;
  
  BufferedSink writeString(String paramString, Charset paramCharset) throws IOException;
  
  BufferedSink writeIntLe(int paramInt) throws IOException;
  
  BufferedSink writeInt(int paramInt) throws IOException;
  
  BufferedSink writeHexadecimalUnsignedLong(long paramLong) throws IOException;
  
  OutputStream outputStream();
  
  BufferedSink writeShort(int paramInt) throws IOException;
  
  BufferedSink write(byte[] paramArrayOfbyte) throws IOException;
  
  Buffer2 buffer();
  
  BufferedSink writeUtf8(String paramString, int paramInt1, int paramInt2) throws IOException;
  
  BufferedSink write(ByteString paramByteString) throws IOException;
  
  BufferedSink writeShortLe(int paramInt) throws IOException;
  
  BufferedSink writeString(String paramString, int paramInt1, int paramInt2, Charset paramCharset) throws IOException;
  
  BufferedSink write(Source paramSource, long paramLong) throws IOException;
  
  BufferedSink writeUtf8(String paramString) throws IOException;
  
  BufferedSink writeLongLe(long paramLong) throws IOException;
  
  BufferedSink writeUtf8CodePoint(int paramInt) throws IOException;
  
  BufferedSink writeLong(long paramLong) throws IOException;
  
  long writeAll(Source paramSource) throws IOException;
  
  void flush() throws IOException;
  
  BufferedSink emitCompleteSegments() throws IOException;
}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\BufferedSink.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */