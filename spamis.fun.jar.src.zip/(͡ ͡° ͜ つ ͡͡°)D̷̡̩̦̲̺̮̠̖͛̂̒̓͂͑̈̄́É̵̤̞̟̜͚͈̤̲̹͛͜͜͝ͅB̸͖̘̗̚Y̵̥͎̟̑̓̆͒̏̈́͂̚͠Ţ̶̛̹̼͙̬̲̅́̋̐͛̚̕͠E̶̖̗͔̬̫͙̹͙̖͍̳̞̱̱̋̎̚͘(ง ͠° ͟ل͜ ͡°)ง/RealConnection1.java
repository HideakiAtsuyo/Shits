/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ConnectException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.Proxy;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.net.UnknownServiceException;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ import javax.net.ssl.SSLSession;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RealConnection1
/*     */   extends Http2Connection13
/*     */   implements Connection
/*     */ {
/*     */   public final Route route;
/*     */   public Http2Connection5 http2Connection;
/*     */   public final ConnectionPool connectionPool;
/*     */   public int successCount;
/*     */   public static final int MAX_TUNNEL_ATTEMPTS = 21;
/*     */   public Socket socket;
/*     */   public final List allocations;
/*     */   public int allocationLimit;
/*     */   public boolean noNewStreams;
/*     */   public BufferedSource source;
/*     */   public BufferedSink sink;
/*     */   public Socket rawSocket;
/*     */   public static final String NPE_THROW_WITH_NULL = "throw with null exception";
/*     */   public Handshake handshake;
/*     */   public long idleAtNanos;
/*     */   public Protocol protocol;
/*     */   
/*     */   public RealConnection1(Object youcangetnoinfoAXBCаиёМП, Object youcangetnoinfoAXBDУьЦСС) {
/* 111 */     ((RealConnection1)super).allocationLimit = 1;
/*     */ 
/*     */     
/* 114 */     ((RealConnection1)super).allocations = new ArrayList();
/*     */ 
/*     */     
/* 117 */     ((RealConnection1)super).idleAtNanos = Long.MAX_VALUE;
/*     */ 
/*     */     
/* 120 */     ((RealConnection1)super).connectionPool = (ConnectionPool)youcangetnoinfoAXBCаиёМП;
/* 121 */     ((RealConnection1)super).route = (Route)youcangetnoinfoAXBDУьЦСС;
/*     */   }
/*     */ 
/*     */   
/*     */   public static RealConnection1 testConnection(Object youcangetnoinfoDGZXулЩЩЮ, Object youcangetnoinfoDGZYыЖёЫА, Object youcangetnoinfoDGZZЧ5дБн, Object youcangetnoinfoDHAAбЕпЕН) {
/* 126 */     Object youcangetnoinfoDHABз774б = new RealConnection1((ConnectionPool)youcangetnoinfoDGZXулЩЩЮ, (Route)youcangetnoinfoDGZYыЖёЫА);
/* 127 */     ((RealConnection1)youcangetnoinfoDHABз774б).socket = (Socket)youcangetnoinfoDGZZЧ5дБн;
/* 128 */     ((RealConnection1)youcangetnoinfoDHABз774б).idleAtNanos = youcangetnoinfoDHAAбЕпЕН;
/* 129 */     return (RealConnection1)youcangetnoinfoDHABз774б;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(Object youcangetnoinfoCTEBШДЪС8, Object youcangetnoinfoCTECЭлпаэ, Object youcangetnoinfoCTEDЫёшИТ, Object youcangetnoinfoCTEEЩВШХп, Object youcangetnoinfoCTEFЕЁ6кП, Object youcangetnoinfoCTEGД6Вф9, Object youcangetnoinfoCTEHЁЗдЫИ) {
/* 135 */     if (((RealConnection1)super).protocol != null) throw new IllegalStateException("already connected");
/*     */     
/* 137 */     Object youcangetnoinfoCTEI2НшъГ = null;
/* 138 */     Object youcangetnoinfoCTEJъzаеД = ((RealConnection1)super).route.address().connectionSpecs();
/* 139 */     Object youcangetnoinfoCTEKфдъГЛ = new ConnectionSpecSelector((List)youcangetnoinfoCTEJъzаеД);
/*     */     
/* 141 */     if (((RealConnection1)super).route.address().sslSocketFactory() == null) {
/* 142 */       if (!youcangetnoinfoCTEJъzаеД.contains(ConnectionSpec.CLEARTEXT)) {
/* 143 */         throw new RouteException(new UnknownServiceException("CLEARTEXT communication not enabled for client"));
/*     */       }
/*     */       
/* 146 */       Object youcangetnoinfoCTDXБфтч0 = ((RealConnection1)super).route.address().url().host();
/* 147 */       if (!Platform.get().isCleartextTrafficPermitted((String)youcangetnoinfoCTDXБфтч0)) {
/* 148 */         throw new RouteException(new UnknownServiceException("CLEARTEXT communication to " + youcangetnoinfoCTDXБфтч0 + " not permitted by network security policy"));
/*     */       
/*     */       }
/*     */     }
/* 152 */     else if (((RealConnection1)super).route.address().protocols().contains(Protocol.H2_PRIOR_KNOWLEDGE)) {
/* 153 */       throw new RouteException(new UnknownServiceException("H2_PRIOR_KNOWLEDGE cannot be used with HTTPS"));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/*     */       try {
/* 160 */         if (((RealConnection1)super).route.requiresTunnel()) {
/* 161 */           super.connectTunnel(youcangetnoinfoCTEBШДЪС8, youcangetnoinfoCTECЭлпаэ, youcangetnoinfoCTEDЫёшИТ, (Call)youcangetnoinfoCTEGД6Вф9, (EventListener1)youcangetnoinfoCTEHЁЗдЫИ);
/* 162 */           if (((RealConnection1)super).rawSocket == null) {
/*     */             break;
/*     */           }
/*     */         } else {
/*     */           
/* 167 */           super.connectSocket(youcangetnoinfoCTEBШДЪС8, youcangetnoinfoCTECЭлпаэ, (Call)youcangetnoinfoCTEGД6Вф9, (EventListener1)youcangetnoinfoCTEHЁЗдЫИ);
/*     */         } 
/* 169 */         super.establishProtocol((ConnectionSpecSelector)youcangetnoinfoCTEKфдъГЛ, youcangetnoinfoCTEEЩВШХп, (Call)youcangetnoinfoCTEGД6Вф9, (EventListener1)youcangetnoinfoCTEHЁЗдЫИ);
/* 170 */         youcangetnoinfoCTEHЁЗдЫИ.connectEnd((Call)youcangetnoinfoCTEGД6Вф9, ((RealConnection1)super).route.socketAddress(), ((RealConnection1)super).route.proxy(), ((RealConnection1)super).protocol);
/*     */         break;
/* 172 */       } catch (IOException youcangetnoinfoCTDY9РщОУ) {
/* 173 */         Util1.closeQuietly(((RealConnection1)super).socket);
/* 174 */         Util1.closeQuietly(((RealConnection1)super).rawSocket);
/* 175 */         ((RealConnection1)super).socket = null;
/* 176 */         ((RealConnection1)super).rawSocket = null;
/* 177 */         ((RealConnection1)super).source = null;
/* 178 */         ((RealConnection1)super).sink = null;
/* 179 */         ((RealConnection1)super).handshake = null;
/* 180 */         ((RealConnection1)super).protocol = null;
/* 181 */         ((RealConnection1)super).http2Connection = null;
/*     */         
/* 183 */         youcangetnoinfoCTEHЁЗдЫИ.connectFailed((Call)youcangetnoinfoCTEGД6Вф9, ((RealConnection1)super).route.socketAddress(), ((RealConnection1)super).route.proxy(), null, (IOException)youcangetnoinfoCTDY9РщОУ);
/*     */         
/* 185 */         if (youcangetnoinfoCTEI2НшъГ == null) {
/* 186 */           youcangetnoinfoCTEI2НшъГ = new RouteException((IOException)youcangetnoinfoCTDY9РщОУ);
/*     */         } else {
/* 188 */           youcangetnoinfoCTEI2НшъГ.addConnectException((IOException)youcangetnoinfoCTDY9РщОУ);
/*     */         } 
/*     */         
/* 191 */         if (youcangetnoinfoCTEFЕЁ6кП == null || !youcangetnoinfoCTEKфдъГЛ.connectionFailed((IOException)youcangetnoinfoCTDY9РщОУ)) {
/* 192 */           throw youcangetnoinfoCTEI2НшъГ;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 197 */     if (((RealConnection1)super).route.requiresTunnel() && ((RealConnection1)super).rawSocket == null) {
/* 198 */       Object youcangetnoinfoCTDZЧщРШр = new ProtocolException("Too many tunnel connections attempted: 21");
/*     */       
/* 200 */       throw new RouteException(youcangetnoinfoCTDZЧщРШр);
/*     */     } 
/*     */     
/* 203 */     if (((RealConnection1)super).http2Connection != null) {
/* 204 */       synchronized (((RealConnection1)super).connectionPool) {
/* 205 */         ((RealConnection1)super).allocationLimit = ((RealConnection1)super).http2Connection.maxConcurrentStreams();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectTunnel(Object youcangetnoinfoEJGFЗ4Вгб, Object youcangetnoinfoEJGGДэП5Й, Object youcangetnoinfoEJGH8нгр9, Object youcangetnoinfoEJGI8Ны26, Object youcangetnoinfoEJGJЖЫхСй) throws IOException {
/* 216 */     Object youcangetnoinfoEJGKйТЛёО = super.createTunnelRequest();
/* 217 */     Object youcangetnoinfoEJGLАч2СС = youcangetnoinfoEJGKйТЛёО.url();
/* 218 */     for (byte b = 0; b < 21; b++) {
/* 219 */       super.connectSocket(youcangetnoinfoEJGFЗ4Вгб, youcangetnoinfoEJGGДэП5Й, (Call)youcangetnoinfoEJGI8Ны26, (EventListener1)youcangetnoinfoEJGJЖЫхСй);
/* 220 */       youcangetnoinfoEJGKйТЛёО = super.createTunnel(youcangetnoinfoEJGGДэП5Й, youcangetnoinfoEJGH8нгр9, (Request)youcangetnoinfoEJGKйТЛёО, (HttpUrl1)youcangetnoinfoEJGLАч2СС);
/*     */       
/* 222 */       if (youcangetnoinfoEJGKйТЛёО == null) {
/*     */         break;
/*     */       }
/*     */       
/* 226 */       Util1.closeQuietly(((RealConnection1)super).rawSocket);
/* 227 */       ((RealConnection1)super).rawSocket = null;
/* 228 */       ((RealConnection1)super).sink = null;
/* 229 */       ((RealConnection1)super).source = null;
/* 230 */       youcangetnoinfoEJGJЖЫхСй.connectEnd((Call)youcangetnoinfoEJGI8Ны26, ((RealConnection1)super).route.socketAddress(), ((RealConnection1)super).route.proxy(), null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectSocket(Object youcangetnoinfoCKQKщzкюб, Object youcangetnoinfoCKQLЙядлк, Object youcangetnoinfoCKQMХ7мке, Object youcangetnoinfoCKQNк94ЫД) throws IOException {
/* 237 */     Object youcangetnoinfoCKQO0ШОюр = ((RealConnection1)super).route.proxy();
/* 238 */     Object youcangetnoinfoCKQPЦУмЛР = ((RealConnection1)super).route.address();
/*     */     
/* 240 */     ((RealConnection1)super)
/*     */       
/* 242 */       .rawSocket = (youcangetnoinfoCKQO0ШОюр.type() == Proxy.Type.DIRECT || youcangetnoinfoCKQO0ШОюр.type() == Proxy.Type.HTTP) ? youcangetnoinfoCKQPЦУмЛР.socketFactory().createSocket() : new Socket((Proxy)youcangetnoinfoCKQO0ШОюр);
/*     */     
/* 244 */     youcangetnoinfoCKQNк94ЫД.connectStart((Call)youcangetnoinfoCKQMХ7мке, ((RealConnection1)super).route.socketAddress(), (Proxy)youcangetnoinfoCKQO0ШОюр);
/* 245 */     ((RealConnection1)super).rawSocket.setSoTimeout(youcangetnoinfoCKQLЙядлк);
/*     */     try {
/* 247 */       Platform.get().connectSocket(((RealConnection1)super).rawSocket, ((RealConnection1)super).route.socketAddress(), youcangetnoinfoCKQKщzкюб);
/* 248 */     } catch (ConnectException youcangetnoinfoCKQHЙЦЧ0ф) {
/* 249 */       Object youcangetnoinfoCKQGЖ84Уе = new ConnectException("Failed to connect to " + ((RealConnection1)super).route.socketAddress());
/* 250 */       youcangetnoinfoCKQGЖ84Уе.initCause((Throwable)youcangetnoinfoCKQHЙЦЧ0ф);
/* 251 */       throw youcangetnoinfoCKQGЖ84Уе;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 259 */       ((RealConnection1)super).source = Okio1.buffer(Okio1.source(((RealConnection1)super).rawSocket));
/* 260 */       ((RealConnection1)super).sink = Okio1.buffer(Okio1.sink(((RealConnection1)super).rawSocket));
/* 261 */     } catch (NullPointerException youcangetnoinfoCKQIТТпГВ) {
/* 262 */       if ("throw with null exception".equals(youcangetnoinfoCKQIТТпГВ.getMessage())) {
/* 263 */         throw new IOException(youcangetnoinfoCKQIТТпГВ);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void establishProtocol(Object youcangetnoinfoBMHVЖятФ5, Object youcangetnoinfoBMHWЮщзНВ, Object youcangetnoinfoBMHXтЪоПЛ, Object youcangetnoinfoBMHYЙЕФРП) throws IOException {
/* 270 */     if (((RealConnection1)super).route.address().sslSocketFactory() == null) {
/* 271 */       if (((RealConnection1)super).route.address().protocols().contains(Protocol.H2_PRIOR_KNOWLEDGE)) {
/* 272 */         ((RealConnection1)super).socket = ((RealConnection1)super).rawSocket;
/* 273 */         ((RealConnection1)super).protocol = Protocol.H2_PRIOR_KNOWLEDGE;
/* 274 */         super.startHttp2(youcangetnoinfoBMHWЮщзНВ);
/*     */         
/*     */         return;
/*     */       } 
/* 278 */       ((RealConnection1)super).socket = ((RealConnection1)super).rawSocket;
/* 279 */       ((RealConnection1)super).protocol = Protocol.HTTP_1_1;
/*     */       
/*     */       return;
/*     */     } 
/* 283 */     youcangetnoinfoBMHYЙЕФРП.secureConnectStart((Call)youcangetnoinfoBMHXтЪоПЛ);
/* 284 */     super.connectTls((ConnectionSpecSelector)youcangetnoinfoBMHVЖятФ5);
/* 285 */     youcangetnoinfoBMHYЙЕФРП.secureConnectEnd((Call)youcangetnoinfoBMHXтЪоПЛ, ((RealConnection1)super).handshake);
/*     */     
/* 287 */     if (((RealConnection1)super).protocol == Protocol.HTTP_2) {
/* 288 */       super.startHttp2(youcangetnoinfoBMHWЮщзНВ);
/*     */     }
/*     */   }
/*     */   
/*     */   public void startHttp2(Object youcangetnoinfoDRZDАлёрц) throws IOException {
/* 293 */     ((RealConnection1)super).socket.setSoTimeout(0);
/* 294 */     ((RealConnection1)super)
/*     */ 
/*     */ 
/*     */       
/* 298 */       .http2Connection = (new Http2Connection12(true)).socket(((RealConnection1)super).socket, ((RealConnection1)super).route.address().url().host(), ((RealConnection1)super).source, ((RealConnection1)super).sink).listener((Http2Connection13)this).pingIntervalMillis(youcangetnoinfoDRZDАлёрц).build();
/* 299 */     ((RealConnection1)super).http2Connection.start();
/*     */   }
/*     */   
/*     */   public void connectTls(Object youcangetnoinfoCNYPшйюсО) throws IOException {
/* 303 */     Object youcangetnoinfoCNYQъяОфЫ = ((RealConnection1)super).route.address();
/* 304 */     Object youcangetnoinfoCNYRичсЦС = youcangetnoinfoCNYQъяОфЫ.sslSocketFactory();
/* 305 */     boolean bool = false;
/* 306 */     Object youcangetnoinfoCNYTzГЭчь = null;
/*     */     
/*     */     try {
/* 309 */       youcangetnoinfoCNYTzГЭчь = youcangetnoinfoCNYRичсЦС.createSocket(((RealConnection1)super).rawSocket, youcangetnoinfoCNYQъяОфЫ
/* 310 */           .url().host(), youcangetnoinfoCNYQъяОфЫ.url().port(), true);
/*     */ 
/*     */       
/* 313 */       Object youcangetnoinfoCNYJИЦМБД = youcangetnoinfoCNYPшйюсО.configureSecureSocket((SSLSocket)youcangetnoinfoCNYTzГЭчь);
/* 314 */       if (youcangetnoinfoCNYJИЦМБД.supportsTlsExtensions()) {
/* 315 */         Platform.get().configureTlsExtensions((SSLSocket)youcangetnoinfoCNYTzГЭчь, youcangetnoinfoCNYQъяОфЫ
/* 316 */             .url().host(), youcangetnoinfoCNYQъяОфЫ.protocols());
/*     */       }
/*     */ 
/*     */       
/* 320 */       youcangetnoinfoCNYTzГЭчь.startHandshake();
/*     */       
/* 322 */       Object youcangetnoinfoCNYK8УЧлЮ = youcangetnoinfoCNYTzГЭчь.getSession();
/* 323 */       Object youcangetnoinfoCNYL7фХЩ5 = Handshake.get((SSLSession)youcangetnoinfoCNYK8УЧлЮ);
/*     */ 
/*     */       
/* 326 */       if (!youcangetnoinfoCNYQъяОфЫ.hostnameVerifier().verify(youcangetnoinfoCNYQъяОфЫ.url().host(), (SSLSession)youcangetnoinfoCNYK8УЧлЮ)) {
/* 327 */         Object<Certificate> youcangetnoinfoCNYIzЯоЖй = (Object<Certificate>)youcangetnoinfoCNYL7фХЩ5.peerCertificates();
/* 328 */         if (!youcangetnoinfoCNYIzЯоЖй.isEmpty()) {
/* 329 */           Object youcangetnoinfoCNYHлФък2 = youcangetnoinfoCNYIzЯоЖй.get(0);
/* 330 */           throw new SSLPeerUnverifiedException("Hostname " + youcangetnoinfoCNYQъяОфЫ
/* 331 */               .url().host() + " not verified:\n    certificate: " + 
/* 332 */               CertificatePinner1.pin(youcangetnoinfoCNYHлФък2) + "\n    DN: " + youcangetnoinfoCNYHлФък2
/* 333 */               .getSubjectDN().getName() + "\n    subjectAltNames: " + 
/* 334 */               OkHostnameVerifier.allSubjectAltNames(youcangetnoinfoCNYHлФък2));
/*     */         } 
/* 336 */         throw new SSLPeerUnverifiedException("Hostname " + youcangetnoinfoCNYQъяОфЫ
/* 337 */             .url().host() + " not verified (no certificates)");
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 342 */       youcangetnoinfoCNYQъяОфЫ.certificatePinner().check(youcangetnoinfoCNYQъяОфЫ.url().host(), youcangetnoinfoCNYL7фХЩ5
/* 343 */           .peerCertificates());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 348 */       Object youcangetnoinfoCNYMВ6ъна = youcangetnoinfoCNYJИЦМБД.supportsTlsExtensions() ? Platform.get().getSelectedProtocol((SSLSocket)youcangetnoinfoCNYTzГЭчь) : null;
/* 349 */       ((RealConnection1)super).socket = (Socket)youcangetnoinfoCNYTzГЭчь;
/* 350 */       ((RealConnection1)super).source = Okio1.buffer(Okio1.source(((RealConnection1)super).socket));
/* 351 */       ((RealConnection1)super).sink = Okio1.buffer(Okio1.sink(((RealConnection1)super).socket));
/* 352 */       ((RealConnection1)super).handshake = (Handshake)youcangetnoinfoCNYL7фХЩ5;
/* 353 */       ((RealConnection1)super)
/*     */         
/* 355 */         .protocol = (youcangetnoinfoCNYMВ6ъна != null) ? Protocol.get((String)youcangetnoinfoCNYMВ6ъна) : Protocol.HTTP_1_1;
/* 356 */       bool = true;
/* 357 */     } catch (AssertionError youcangetnoinfoCNYNфкНзЯ) {
/* 358 */       if (Util1.isAndroidGetsocknameError((AssertionError)youcangetnoinfoCNYNфкНзЯ)) throw new IOException(youcangetnoinfoCNYNфкНзЯ); 
/* 359 */       throw youcangetnoinfoCNYNфкНзЯ;
/*     */     } finally {
/* 361 */       if (youcangetnoinfoCNYTzГЭчь != null) {
/* 362 */         Platform.get().afterHandshake((SSLSocket)youcangetnoinfoCNYTzГЭчь);
/*     */       }
/* 364 */       if (!bool) {
/* 365 */         Util1.closeQuietly((Socket)youcangetnoinfoCNYTzГЭчь);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request createTunnel(Object youcangetnoinfoCHSNшЕ1щЫ, Object youcangetnoinfoCHSOсхПГЕ, Object youcangetnoinfoCHSPЩАФэЧ, Object youcangetnoinfoCHSQдЮьЮЪ) throws IOException {
/* 377 */     Object youcangetnoinfoCHSJЦйшГз, youcangetnoinfoCHSRнцабф = "CONNECT " + Util1.hostHeader((HttpUrl1)youcangetnoinfoCHSQдЮьЮЪ, true) + " HTTP/1.1";
/*     */     while (true) {
/* 379 */       Object youcangetnoinfoCHSI1ЖХХз = new Http1Codec7(null, null, ((RealConnection1)super).source, ((RealConnection1)super).sink);
/* 380 */       ((RealConnection1)super).source.timeout().timeout(youcangetnoinfoCHSNшЕ1щЫ, TimeUnit.MILLISECONDS);
/* 381 */       ((RealConnection1)super).sink.timeout().timeout(youcangetnoinfoCHSOсхПГЕ, TimeUnit.MILLISECONDS);
/* 382 */       youcangetnoinfoCHSI1ЖХХз.writeRequest(youcangetnoinfoCHSPЩАФэЧ.headers(), (String)youcangetnoinfoCHSRнцабф);
/* 383 */       youcangetnoinfoCHSI1ЖХХз.finishRequest();
/*     */ 
/*     */       
/* 386 */       youcangetnoinfoCHSJЦйшГз = youcangetnoinfoCHSI1ЖХХз.readResponseHeaders(false).request((Request)youcangetnoinfoCHSPЩАФэЧ).build();
/*     */ 
/*     */       
/* 389 */       long l = HttpHeaders.contentLength((Response)youcangetnoinfoCHSJЦйшГз);
/* 390 */       if (l == -1L) {
/* 391 */         l = 0L;
/*     */       }
/* 393 */       Object youcangetnoinfoCHSLЮ9БТо = youcangetnoinfoCHSI1ЖХХз.newFixedLengthSource(l);
/* 394 */       Util1.skipAll((Source)youcangetnoinfoCHSLЮ9БТо, 2147483647, TimeUnit.MILLISECONDS);
/* 395 */       youcangetnoinfoCHSLЮ9БТо.close();
/*     */       
/* 397 */       switch (youcangetnoinfoCHSJЦйшГз.code()) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 200:
/* 403 */           if (!((RealConnection1)super).source.getBuffer().exhausted() || !((RealConnection1)super).sink.buffer().exhausted()) {
/* 404 */             throw new IOException("TLS tunnel buffered too many bytes!");
/*     */           }
/* 406 */           return null;
/*     */         
/*     */         case 407:
/* 409 */           youcangetnoinfoCHSPЩАФэЧ = ((RealConnection1)super).route.address().proxyAuthenticator().authenticate(((RealConnection1)super).route, (Response)youcangetnoinfoCHSJЦйшГз);
/* 410 */           if (youcangetnoinfoCHSPЩАФэЧ == null) throw new IOException("Failed to authenticate with proxy");
/*     */           
/* 412 */           if ("close".equalsIgnoreCase(youcangetnoinfoCHSJЦйшГз.header("Connection")))
/* 413 */             return (Request)youcangetnoinfoCHSPЩАФэЧ; 
/*     */           continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 418 */     throw new IOException("Unexpected response code for CONNECT: " + youcangetnoinfoCHSJЦйшГз
/* 419 */         .code());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request createTunnelRequest() throws IOException {
/* 440 */     Object youcangetnoinfoPCKпПиЗЭ = (new Request1()).url(((RealConnection1)super).route.address().url()).method("CONNECT", null).header("Host", Util1.hostHeader(((RealConnection1)super).route.address().url(), true)).header("Proxy-Connection", "Keep-Alive").header("User-Agent", Version.userAgent()).build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 451 */     Object youcangetnoinfoPCLОЕЬМб = (new Response1()).request((Request)youcangetnoinfoPCKпПиЗЭ).protocol(Protocol.HTTP_1_1).code(407).message("Preemptive Authenticate").body(Util1.EMPTY_RESPONSE).sentRequestAtMillis(-1L).receivedResponseAtMillis(-1L).header("Proxy-Authenticate", "OkHttp-Preemptive").build();
/*     */ 
/*     */     
/* 454 */     Object youcangetnoinfoPCMСусеД = ((RealConnection1)super).route.address().proxyAuthenticator().authenticate(((RealConnection1)super).route, (Response)youcangetnoinfoPCLОЕЬМб);
/*     */     
/* 456 */     return (youcangetnoinfoPCMСусеД != null) ? 
/* 457 */       (Request)youcangetnoinfoPCMСусеД : 
/* 458 */       (Request)youcangetnoinfoPCKпПиЗЭ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEligible(Object youcangetnoinfoAWHVзч3ФП, @Nullable Object youcangetnoinfoAWHWеешфё) {
/* 467 */     if (((RealConnection1)super).allocations.size() >= ((RealConnection1)super).allocationLimit || ((RealConnection1)super).noNewStreams) return false;
/*     */ 
/*     */     
/* 470 */     if (!Internal.instance.equalsNonHost(((RealConnection1)super).route.address(), (Address)youcangetnoinfoAWHVзч3ФП)) return false;
/*     */ 
/*     */     
/* 473 */     if (youcangetnoinfoAWHVзч3ФП.url().host().equals(super.route().address().url().host())) {
/* 474 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 483 */     if (((RealConnection1)super).http2Connection == null) return false;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 488 */     if (youcangetnoinfoAWHWеешфё == null) return false; 
/* 489 */     if (youcangetnoinfoAWHWеешфё.proxy().type() != Proxy.Type.DIRECT) return false; 
/* 490 */     if (((RealConnection1)super).route.proxy().type() != Proxy.Type.DIRECT) return false; 
/* 491 */     if (!((RealConnection1)super).route.socketAddress().equals(youcangetnoinfoAWHWеешфё.socketAddress())) return false;
/*     */ 
/*     */     
/* 494 */     if (youcangetnoinfoAWHWеешфё.address().hostnameVerifier() != OkHostnameVerifier.INSTANCE) return false; 
/* 495 */     if (!super.supportsUrl(youcangetnoinfoAWHVзч3ФП.url())) return false;
/*     */ 
/*     */     
/*     */     try {
/* 499 */       youcangetnoinfoAWHVзч3ФП.certificatePinner().check(youcangetnoinfoAWHVзч3ФП.url().host(), super.handshake().peerCertificates());
/* 500 */     } catch (SSLPeerUnverifiedException youcangetnoinfoAWHTИюбэя) {
/* 501 */       return false;
/*     */     } 
/*     */     
/* 504 */     return true;
/*     */   }
/*     */   
/*     */   public boolean supportsUrl(Object youcangetnoinfoDILHПЭЩzц) {
/* 508 */     if (youcangetnoinfoDILHПЭЩzц.port() != ((RealConnection1)super).route.address().url().port()) {
/* 509 */       return false;
/*     */     }
/*     */     
/* 512 */     if (!youcangetnoinfoDILHПЭЩzц.host().equals(((RealConnection1)super).route.address().url().host()))
/*     */     {
/* 514 */       return (((RealConnection1)super).handshake != null && OkHostnameVerifier.INSTANCE.verify(youcangetnoinfoDILHПЭЩzц
/* 515 */           .host(), (X509Certificate)((RealConnection1)super).handshake.peerCertificates().get(0)));
/*     */     }
/*     */     
/* 518 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public HttpCodec newCodec(Object youcangetnoinfoCZAS0ижСЖ, Object youcangetnoinfoCZATцРНв3, Object youcangetnoinfoCZAUк1ННТ) throws SocketException {
/* 523 */     if (((RealConnection1)super).http2Connection != null) {
/* 524 */       return new Http2Codec1((OkHttpClient)youcangetnoinfoCZAS0ижСЖ, (Interceptor1)youcangetnoinfoCZATцРНв3, (StreamAllocation1)youcangetnoinfoCZAUк1ННТ, ((RealConnection1)super).http2Connection);
/*     */     }
/* 526 */     ((RealConnection1)super).socket.setSoTimeout(youcangetnoinfoCZATцРНв3.readTimeoutMillis());
/* 527 */     ((RealConnection1)super).source.timeout().timeout(youcangetnoinfoCZATцРНв3.readTimeoutMillis(), TimeUnit.MILLISECONDS);
/* 528 */     ((RealConnection1)super).sink.timeout().timeout(youcangetnoinfoCZATцРНв3.writeTimeoutMillis(), TimeUnit.MILLISECONDS);
/* 529 */     return new Http1Codec7((OkHttpClient)youcangetnoinfoCZAS0ижСЖ, (StreamAllocation1)youcangetnoinfoCZAUк1ННТ, ((RealConnection1)super).source, ((RealConnection1)super).sink);
/*     */   }
/*     */ 
/*     */   
/*     */   public RealWebSocket3 newWebSocketStreams(Object youcangetnoinfoDSSC0втЮП) {
/* 534 */     return new RealConnection((RealConnection1)this, true, ((RealConnection1)super).source, ((RealConnection1)super).sink, (StreamAllocation1)youcangetnoinfoDSSC0втЮП);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Route route() {
/* 542 */     return ((RealConnection1)super).route;
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 547 */     Util1.closeQuietly(((RealConnection1)super).rawSocket);
/*     */   }
/*     */   
/*     */   public Socket socket() {
/* 551 */     return ((RealConnection1)super).socket;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isHealthy(Object youcangetnoinfoATNEНРоюЪ) {
/* 556 */     if (((RealConnection1)super).socket.isClosed() || ((RealConnection1)super).socket.isInputShutdown() || ((RealConnection1)super).socket.isOutputShutdown()) {
/* 557 */       return false;
/*     */     }
/*     */     
/* 560 */     if (((RealConnection1)super).http2Connection != null) {
/* 561 */       return !((RealConnection1)super).http2Connection.isShutdown();
/*     */     }
/*     */     
/* 564 */     if (youcangetnoinfoATNEНРоюЪ != null) {
/*     */       try {
/* 566 */         int i = ((RealConnection1)super).socket.getSoTimeout();
/*     */         try {
/* 568 */           ((RealConnection1)super).socket.setSoTimeout(1);
/* 569 */           if (((RealConnection1)super).source.exhausted()) {
/* 570 */             return false;
/*     */           }
/* 572 */           return true;
/*     */         } finally {
/* 574 */           ((RealConnection1)super).socket.setSoTimeout(i);
/*     */         } 
/* 576 */       } catch (SocketTimeoutException socketTimeoutException) {
/*     */       
/* 578 */       } catch (IOException youcangetnoinfoATNCЗц9ЭО) {
/* 579 */         return false;
/*     */       } 
/*     */     }
/*     */     
/* 583 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onStream(Object youcangetnoinfoCWMы5хНв) throws IOException {
/* 588 */     youcangetnoinfoCWMы5хНв.close(ErrorCode.REFUSED_STREAM);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onSettings(Object youcangetnoinfoAOHVМЧджл) {
/* 593 */     synchronized (((RealConnection1)super).connectionPool) {
/* 594 */       ((RealConnection1)super).allocationLimit = youcangetnoinfoAOHVМЧджл.maxConcurrentStreams();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Handshake handshake() {
/* 599 */     return ((RealConnection1)super).handshake;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isMultiplexed() {
/* 607 */     return (((RealConnection1)super).http2Connection != null);
/*     */   }
/*     */   
/*     */   public Protocol protocol() {
/* 611 */     return ((RealConnection1)super).protocol;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 615 */     return "Connection{" + ((RealConnection1)super).route
/* 616 */       .address().url().host() + ":" + ((RealConnection1)super).route.address().url().port() + ", proxy=" + ((RealConnection1)super).route
/*     */       
/* 618 */       .proxy() + " hostAddress=" + ((RealConnection1)super).route
/*     */       
/* 620 */       .socketAddress() + " cipherSuite=" + (
/*     */       
/* 622 */       (((RealConnection1)super).handshake != null) ? (String)((RealConnection1)super).handshake.cipherSuite() : "none") + " protocol=" + ((RealConnection1)super).protocol + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RealConnection1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */