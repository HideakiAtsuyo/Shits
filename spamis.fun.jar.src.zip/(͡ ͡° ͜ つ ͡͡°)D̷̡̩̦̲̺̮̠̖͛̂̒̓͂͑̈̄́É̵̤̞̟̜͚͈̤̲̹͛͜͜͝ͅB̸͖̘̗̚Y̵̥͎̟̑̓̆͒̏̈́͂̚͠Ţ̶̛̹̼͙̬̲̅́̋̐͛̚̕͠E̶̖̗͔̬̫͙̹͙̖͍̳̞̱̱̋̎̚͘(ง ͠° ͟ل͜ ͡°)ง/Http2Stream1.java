/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Stream1
/*     */   implements Sink
/*     */ {
/*     */   public final Http2Stream2 this$0;
/*     */   public boolean closed;
/*     */   public boolean finished;
/*     */   public static final boolean $assertionsDisabled;
/*     */   public Headers trailers;
/*     */   public static final long EMIT_BUFFER_SIZE = 16384L;
/*     */   public final Buffer2 sendBuffer;
/*     */   
/*     */   public Http2Stream1() {
/* 510 */     this();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 517 */     ((Http2Stream1)super).sendBuffer = new Buffer2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(Object youcangetnoinfoCIDJФ8АЛА, Object youcangetnoinfoCIDKДПщдz) throws IOException {
/* 530 */     assert !Thread.holdsLock(((Http2Stream1)super).this$0);
/* 531 */     ((Http2Stream1)super).sendBuffer.write((Buffer2)youcangetnoinfoCIDJФ8АЛА, youcangetnoinfoCIDKДПщдz);
/* 532 */     while (((Http2Stream1)super).sendBuffer.size() >= 16384L) {
/* 533 */       super.emitFrame(false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void emitFrame(Object youcangetnoinfoEAZEОыЪ0ж) throws IOException {
/*     */     long l;
/* 543 */     synchronized (((Http2Stream1)super).this$0) {
/* 544 */       ((Http2Stream1)super).this$0.writeTimeout.enter();
/*     */       try {
/* 546 */         while (((Http2Stream1)super).this$0.bytesLeftInWriteWindow <= 0L && !((Http2Stream1)super).finished && !((Http2Stream1)super).closed && ((Http2Stream1)super).this$0.errorCode == null) {
/* 547 */           ((Http2Stream1)super).this$0.waitForIo();
/*     */         }
/*     */       } finally {
/* 550 */         ((Http2Stream1)super).this$0.writeTimeout.exitAndThrowIfTimedOut();
/*     */       } 
/*     */       
/* 553 */       ((Http2Stream1)super).this$0.checkOutNotClosed();
/* 554 */       l = Math.min(((Http2Stream1)super).this$0.bytesLeftInWriteWindow, ((Http2Stream1)super).sendBuffer.size());
/* 555 */       ((Http2Stream1)super).this$0.bytesLeftInWriteWindow -= l;
/*     */     } 
/*     */     
/* 558 */     ((Http2Stream1)super).this$0.writeTimeout.enter();
/*     */     try {
/* 560 */       boolean bool = (youcangetnoinfoEAZEОыЪ0ж != null && l == ((Http2Stream1)super).sendBuffer.size()) ? true : false;
/* 561 */       ((Http2Stream1)super).this$0.connection.writeData(((Http2Stream1)super).this$0.id, bool, ((Http2Stream1)super).sendBuffer, l);
/*     */     } finally {
/* 563 */       ((Http2Stream1)super).this$0.writeTimeout.exitAndThrowIfTimedOut();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/* 568 */     assert !Thread.holdsLock(((Http2Stream1)super).this$0);
/* 569 */     synchronized (((Http2Stream1)super).this$0) {
/* 570 */       ((Http2Stream1)super).this$0.checkOutNotClosed();
/*     */     } 
/* 572 */     while (((Http2Stream1)super).sendBuffer.size() > 0L) {
/* 573 */       super.emitFrame(false);
/* 574 */       ((Http2Stream1)super).this$0.connection.flush();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 579 */     return ((Http2Stream1)super).this$0.writeTimeout;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 583 */     assert !Thread.holdsLock(((Http2Stream1)super).this$0);
/* 584 */     synchronized (((Http2Stream1)super).this$0) {
/* 585 */       if (((Http2Stream1)super).closed)
/*     */         return; 
/* 587 */     }  if (!((Http2Stream1)super).this$0.sink.finished) {
/*     */ 
/*     */ 
/*     */       
/* 591 */       boolean bool1 = (((Http2Stream1)super).sendBuffer.size() > 0L) ? true : false;
/* 592 */       boolean bool2 = (((Http2Stream1)super).trailers != null) ? true : false;
/* 593 */       if (bool2) {
/* 594 */         while (((Http2Stream1)super).sendBuffer.size() > 0L) {
/* 595 */           super.emitFrame(false);
/*     */         }
/* 597 */         ((Http2Stream1)super).this$0.connection.writeHeaders(((Http2Stream1)super).this$0.id, true, Util1.toHeaderBlock(((Http2Stream1)super).trailers));
/* 598 */       } else if (bool1) {
/* 599 */         while (((Http2Stream1)super).sendBuffer.size() > 0L) {
/* 600 */           super.emitFrame(true);
/*     */         }
/*     */       } else {
/* 603 */         ((Http2Stream1)super).this$0.connection.writeData(((Http2Stream1)super).this$0.id, true, null, 0L);
/*     */       } 
/*     */     } 
/* 606 */     synchronized (((Http2Stream1)super).this$0) {
/* 607 */       ((Http2Stream1)super).closed = true;
/*     */     } 
/* 609 */     ((Http2Stream1)super).this$0.connection.flush();
/* 610 */     ((Http2Stream1)super).this$0.cancelStreamIfNecessary();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http2Stream1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */