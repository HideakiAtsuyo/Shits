/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import com.formdev.flatlaf.IntelliJTheme;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SpamIsFun
/*    */   implements Runnable
/*    */ {
/*    */   public SpamIsFun() {
/* 65 */     this();
/*    */   }
/*    */   public void run() {
/* 68 */     if ((new File(fun.spamis.spammer.SpamIsFun.homeDir + "theme.spamisfun")).exists()) {
/*    */       try {
/* 70 */         Object youcangetnoinfoBESHЦмпцЛ = FileUtils.readFile(fun.spamis.spammer.SpamIsFun.homeDir + "theme.spamisfun");
/* 71 */         switch (youcangetnoinfoBESHЦмпцЛ) {
/*    */           case "lightblue":
/* 73 */             IntelliJTheme.install(fun.spamis.spammer.SpamIsFun.class.getResourceAsStream("/ui/Light.theme.json"));
/*    */             break;
/*    */           case "lightrange":
/* 76 */             IntelliJTheme.install(fun.spamis.spammer.SpamIsFun.class.getResourceAsStream("/ui/arc-theme-orange.theme.json"));
/*    */             break;
/*    */           case "darkblue":
/* 79 */             IntelliJTheme.install(fun.spamis.spammer.SpamIsFun.class.getResourceAsStream("/ui/Atom One Dark Contrast.theme.json"));
/*    */             break;
/*    */           case "darkpurple":
/* 82 */             IntelliJTheme.install(fun.spamis.spammer.SpamIsFun.class.getResourceAsStream("/ui/Material Palenight Contrast.theme.json"));
/*    */             break;
/*    */           default:
/* 85 */             IntelliJTheme.install(fun.spamis.spammer.SpamIsFun.class.getResourceAsStream("/ui/Light.theme.json")); break;
/*    */         } 
/* 87 */       } catch (IOException youcangetnoinfoBESIоРтё4) {
/* 88 */         youcangetnoinfoBESIоРтё4.printStackTrace();
/*    */       } 
/*    */     } else {
/* 91 */       IntelliJTheme.install(fun.spamis.spammer.SpamIsFun.class.getResourceAsStream("/ui/Light.theme.json"));
/*    */     } 
/*    */     
/*    */     try {
/* 95 */       Object youcangetnoinfoBESJЁ7чшК = new LoginGUI1();
/* 96 */       youcangetnoinfoBESJЁ7чшК.setVisible(true);
/* 97 */     } catch (Exception youcangetnoinfoBESKЛБсШ8) {
/* 98 */       youcangetnoinfoBESKЛБсШ8.printStackTrace();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\SpamIsFun.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */