/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HashingSink
/*     */   extends ForwardingSink
/*     */ {
/*     */   @Nullable
/*     */   public final Mac mac;
/*     */   @Nullable
/*     */   public final MessageDigest messageDigest;
/*     */   
/*     */   public static HashingSink md5(Object youcangetnoinfoBCFZпмъа9) {
/*  50 */     return new HashingSink((Sink)youcangetnoinfoBCFZпмъа9, "MD5");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSink sha1(Object youcangetnoinfoDVFGЛ5эеП) {
/*  55 */     return new HashingSink((Sink)youcangetnoinfoDVFGЛ5эеП, "SHA-1");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSink sha256(Object youcangetnoinfoEIXFывЁбК) {
/*  60 */     return new HashingSink((Sink)youcangetnoinfoEIXFывЁбК, "SHA-256");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSink sha512(Object youcangetnoinfoBCPJ0ЖЧл3) {
/*  65 */     return new HashingSink((Sink)youcangetnoinfoBCPJ0ЖЧл3, "SHA-512");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSink hmacSha1(Object youcangetnoinfoAAVFЯёщ5ш, Object youcangetnoinfoAAVGяЩЮьо) {
/*  70 */     return new HashingSink((Sink)youcangetnoinfoAAVFЯёщ5ш, (ByteString)youcangetnoinfoAAVGяЩЮьо, "HmacSHA1");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSink hmacSha256(Object youcangetnoinfoCAXDЬ0ы7э, Object youcangetnoinfoCAXEцРдпТ) {
/*  75 */     return new HashingSink((Sink)youcangetnoinfoCAXDЬ0ы7э, (ByteString)youcangetnoinfoCAXEцРдпТ, "HmacSHA256");
/*     */   }
/*     */ 
/*     */   
/*     */   public static HashingSink hmacSha512(Object youcangetnoinfoCQNKдЙАшЪ, Object youcangetnoinfoCQNLолфш5) {
/*  80 */     return new HashingSink((Sink)youcangetnoinfoCQNKдЙАшЪ, (ByteString)youcangetnoinfoCQNLолфш5, "HmacSHA512");
/*     */   }
/*     */   
/*     */   public HashingSink(Object youcangetnoinfoGTYРДШЦИ, Object youcangetnoinfoGTZМ3фЖУ) {
/*  84 */     super((Sink)youcangetnoinfoGTYРДШЦИ);
/*     */     try {
/*  86 */       ((HashingSink)super).messageDigest = MessageDigest.getInstance((String)youcangetnoinfoGTZМ3фЖУ);
/*  87 */       ((HashingSink)super).mac = null;
/*  88 */     } catch (NoSuchAlgorithmException youcangetnoinfoGTWВб7МЫ) {
/*  89 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */   
/*     */   public HashingSink(Object youcangetnoinfoALPCЮш1вЪ, Object youcangetnoinfoALPDПРххЗ, Object youcangetnoinfoALPEЁфшкЛ) {
/*  94 */     super((Sink)youcangetnoinfoALPCЮш1вЪ);
/*     */     try {
/*  96 */       ((HashingSink)super).mac = Mac.getInstance((String)youcangetnoinfoALPEЁфшкЛ);
/*  97 */       ((HashingSink)super).mac.init(new SecretKeySpec(youcangetnoinfoALPDПРххЗ.toByteArray(), (String)youcangetnoinfoALPEЁфшкЛ));
/*  98 */       ((HashingSink)super).messageDigest = null;
/*  99 */     } catch (NoSuchAlgorithmException youcangetnoinfoALOZШ97Гл) {
/* 100 */       throw new AssertionError();
/* 101 */     } catch (InvalidKeyException youcangetnoinfoALPAКНЕЛк) {
/* 102 */       throw new IllegalArgumentException(youcangetnoinfoALPAКНЕЛк);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write(Object youcangetnoinfoDLPIЖщндс, Object youcangetnoinfoDLPJ7уНЁД) throws IOException {
/* 107 */     Util.checkOffsetAndCount(((Buffer2)youcangetnoinfoDLPIЖщндс).size, 0L, youcangetnoinfoDLPJ7уНЁД);
/*     */ 
/*     */     
/* 110 */     long l = 0L;
/* 111 */     for (Object youcangetnoinfoDLPGУ700В = ((Buffer2)youcangetnoinfoDLPIЖщндс).head; l < youcangetnoinfoDLPJ7уНЁД; youcangetnoinfoDLPGУ700В = ((Segment)youcangetnoinfoDLPGУ700В).next) {
/* 112 */       int i = (int)Math.min(youcangetnoinfoDLPJ7уНЁД - l, (((Segment)youcangetnoinfoDLPGУ700В).limit - ((Segment)youcangetnoinfoDLPGУ700В).pos));
/* 113 */       if (((HashingSink)super).messageDigest != null) {
/* 114 */         ((HashingSink)super).messageDigest.update(((Segment)youcangetnoinfoDLPGУ700В).data, ((Segment)youcangetnoinfoDLPGУ700В).pos, i);
/*     */       } else {
/* 116 */         ((HashingSink)super).mac.update(((Segment)youcangetnoinfoDLPGУ700В).data, ((Segment)youcangetnoinfoDLPGУ700В).pos, i);
/*     */       } 
/* 118 */       l += i;
/*     */     } 
/*     */ 
/*     */     
/* 122 */     super.write((Buffer2)youcangetnoinfoDLPIЖщндс, youcangetnoinfoDLPJ7уНЁД);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final ByteString hash() {
/* 132 */     Object youcangetnoinfoDMCJЗцЪжё = (((HashingSink)super).messageDigest != null) ? ((HashingSink)super).messageDigest.digest() : ((HashingSink)super).mac.doFinal();
/* 133 */     return ByteString.of((byte[])youcangetnoinfoDMCJЗцЪжё);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\HashingSink.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */