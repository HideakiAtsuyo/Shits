/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypingSpammer2
/*     */   extends JPanel
/*     */ {
/*     */   public JButton typingStopBtn;
/*     */   public static final long serialVersionUID = 8135869397405727400L;
/*     */   public JButton typingStartBtn;
/*     */   public boolean typing;
/*     */   
/*     */   public TypingSpammer2() {
/*  24 */     ((TypingSpammer2)super).typing = false;
/*     */ 
/*     */     
/*  27 */     super.initialize();
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  31 */     setLayout((LayoutManager)null);
/*     */     
/*  33 */     Object youcangetnoinfoDXONжЦоГч = new JLabel("Channel id");
/*  34 */     youcangetnoinfoDXONжЦоГч.setBounds(28, 12, 293, 15);
/*  35 */     add((Component)youcangetnoinfoDXONжЦоГч);
/*     */     
/*  37 */     Object youcangetnoinfoDXOOТчыЪО = new JTextField();
/*  38 */     youcangetnoinfoDXOOТчыЪО.setColumns(10);
/*  39 */     youcangetnoinfoDXOOТчыЪО.setBounds(28, 27, 341, 32);
/*  40 */     add((Component)youcangetnoinfoDXOOТчыЪО);
/*     */     
/*  42 */     ((TypingSpammer2)super).typingStartBtn = new JButton("Start");
/*  43 */     ((TypingSpammer2)super).typingStartBtn.setIcon(new ImageIcon(getClass().getResource("/ui/start.png")));
/*  44 */     ((TypingSpammer2)super).typingStartBtn.addActionListener(new TypingSpammer3((TypingSpammer2)this, (JTextField)youcangetnoinfoDXOOТчыЪО));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     ((TypingSpammer2)super).typingStartBtn.setBounds(28, 71, 157, 32);
/*  99 */     add(((TypingSpammer2)super).typingStartBtn);
/*     */     
/* 101 */     ((TypingSpammer2)super).typingStopBtn = new JButton("Stop");
/* 102 */     ((TypingSpammer2)super).typingStopBtn.setIcon(new ImageIcon(getClass().getResource("/ui/stop.png")));
/* 103 */     ((TypingSpammer2)super).typingStopBtn.addActionListener(new TypingSpammer((TypingSpammer2)this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 110 */     ((TypingSpammer2)super).typingStopBtn.setEnabled(false);
/* 111 */     ((TypingSpammer2)super).typingStopBtn.setBounds(212, 71, 157, 32);
/* 112 */     add(((TypingSpammer2)super).typingStopBtn);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\TypingSpammer2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */