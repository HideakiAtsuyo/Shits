/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpDate
/*     */ {
/*     */   public static final DateFormat[] BROWSER_COMPATIBLE_DATE_FORMATS;
/*     */   public static final String[] BROWSER_COMPATIBLE_DATE_FORMAT_STRINGS;
/*     */   public static final long MAX_DATE = 253402300799999L;
/*  37 */   public static final ThreadLocal<DateFormat> STANDARD_DATE_FORMAT = new HttpDate1();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/*  49 */     BROWSER_COMPATIBLE_DATE_FORMAT_STRINGS = new String[] { "EEE, dd MMM yyyy HH:mm:ss zzz", "EEEE, dd-MMM-yy HH:mm:ss zzz", "EEE MMM d HH:mm:ss yyyy", "EEE, dd-MMM-yyyy HH:mm:ss z", "EEE, dd-MMM-yyyy HH-mm-ss z", "EEE, dd MMM yy HH:mm:ss z", "EEE dd-MMM-yyyy HH:mm:ss z", "EEE dd MMM yyyy HH:mm:ss z", "EEE dd-MMM-yyyy HH-mm-ss z", "EEE dd-MMM-yy HH:mm:ss z", "EEE dd MMM yy HH:mm:ss z", "EEE,dd-MMM-yy HH:mm:ss z", "EEE,dd-MMM-yyyy HH:mm:ss z", "EEE, dd-MM-yyyy HH:mm:ss z", "EEE MMM d yyyy HH:mm:ss z" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     BROWSER_COMPATIBLE_DATE_FORMATS = new DateFormat[BROWSER_COMPATIBLE_DATE_FORMAT_STRINGS.length];
/*     */   }
/*     */ 
/*     */   
/*     */   public static Date parse(Object youcangetnoinfoAFJWш8аяЪ) {
/*  76 */     if (youcangetnoinfoAFJWш8аяЪ.length() == 0) {
/*  77 */       return null;
/*     */     }
/*     */     
/*  80 */     Object youcangetnoinfoAFJXлЦйЛй = new ParsePosition(0);
/*  81 */     Object youcangetnoinfoAFJYгСДуц = ((DateFormat)STANDARD_DATE_FORMAT.get()).parse((String)youcangetnoinfoAFJWш8аяЪ, (ParsePosition)youcangetnoinfoAFJXлЦйЛй);
/*  82 */     if (youcangetnoinfoAFJXлЦйЛй.getIndex() == youcangetnoinfoAFJWш8аяЪ.length())
/*     */     {
/*     */       
/*  85 */       return (Date)youcangetnoinfoAFJYгСДуц;
/*     */     }
/*  87 */     synchronized (BROWSER_COMPATIBLE_DATE_FORMAT_STRINGS) {
/*  88 */       byte b; int i; for (b = 0, i = BROWSER_COMPATIBLE_DATE_FORMAT_STRINGS.length; b < i; b++) {
/*  89 */         Object youcangetnoinfoAFJTьфнщ7 = BROWSER_COMPATIBLE_DATE_FORMATS[b];
/*  90 */         if (youcangetnoinfoAFJTьфнщ7 == null) {
/*  91 */           youcangetnoinfoAFJTьфнщ7 = new SimpleDateFormat(BROWSER_COMPATIBLE_DATE_FORMAT_STRINGS[b], Locale.US);
/*     */ 
/*     */           
/*  94 */           youcangetnoinfoAFJTьфнщ7.setTimeZone(Util1.UTC);
/*  95 */           BROWSER_COMPATIBLE_DATE_FORMATS[b] = (DateFormat)youcangetnoinfoAFJTьфнщ7;
/*     */         } 
/*  97 */         youcangetnoinfoAFJXлЦйЛй.setIndex(0);
/*  98 */         youcangetnoinfoAFJYгСДуц = youcangetnoinfoAFJTьфнщ7.parse((String)youcangetnoinfoAFJWш8аяЪ, (ParsePosition)youcangetnoinfoAFJXлЦйЛй);
/*  99 */         if (youcangetnoinfoAFJXлЦйЛй.getIndex() != 0)
/*     */         {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 105 */           return (Date)youcangetnoinfoAFJYгСДуц;
/*     */         }
/*     */       } 
/*     */     } 
/* 109 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String format(Object youcangetnoinfoAKCH94ычф) {
/* 114 */     return ((DateFormat)STANDARD_DATE_FORMAT.get()).format((Date)youcangetnoinfoAKCH94ычф);
/*     */   }
/*     */   public HttpDate() {
/* 117 */     this();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\HttpDate.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */