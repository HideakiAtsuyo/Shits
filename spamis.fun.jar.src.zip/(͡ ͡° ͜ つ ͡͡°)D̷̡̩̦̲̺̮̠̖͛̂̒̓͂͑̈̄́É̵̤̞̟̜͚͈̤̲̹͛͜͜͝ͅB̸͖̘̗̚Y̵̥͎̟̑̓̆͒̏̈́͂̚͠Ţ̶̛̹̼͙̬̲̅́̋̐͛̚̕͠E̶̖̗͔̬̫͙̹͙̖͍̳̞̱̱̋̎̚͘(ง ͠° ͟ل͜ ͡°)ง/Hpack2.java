/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Arrays;
/*     */ import java.util.Objects;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Hpack2
/*     */ {
/*     */   public final Buffer2 out;
/*     */   public boolean emitDynamicTableSizeUpdate;
/*     */   public int smallestHeaderTableSizeSetting;
/*     */   public int headerCount;
/*     */   public int maxDynamicTableByteCount;
/*     */   public int dynamicTableByteCount;
/*     */   public final boolean useCompression;
/*     */   public static final int SETTINGS_HEADER_TABLE_SIZE = 4096;
/*     */   public int headerTableSizeSetting;
/*     */   public Header[] dynamicTable;
/*     */   public int nextHeaderIndex;
/*     */   public static final int SETTINGS_HEADER_TABLE_SIZE_LIMIT = 16384;
/*     */   
/*     */   public Hpack2(Object youcangetnoinfoEMQGГКЛВё) {
/* 397 */     super(4096, true, (Buffer2)youcangetnoinfoEMQGГКЛВё);
/*     */   }
/*     */   public Hpack2(Object youcangetnoinfoBEGPЫЬепж, Object youcangetnoinfoBEGQу48иФ, Object youcangetnoinfoBEGR0ЛПДЦ) {
/* 400 */     this(); ((Hpack2)super).smallestHeaderTableSizeSetting = Integer.MAX_VALUE; ((Hpack2)super).dynamicTable = new Header[8]; ((Hpack2)super).nextHeaderIndex = ((Hpack2)super).dynamicTable.length - 1; ((Hpack2)super).headerCount = 0; ((Hpack2)super).dynamicTableByteCount = 0;
/* 401 */     ((Hpack2)super).headerTableSizeSetting = youcangetnoinfoBEGPЫЬепж;
/* 402 */     ((Hpack2)super).maxDynamicTableByteCount = youcangetnoinfoBEGPЫЬепж;
/* 403 */     ((Hpack2)super).useCompression = youcangetnoinfoBEGQу48иФ;
/* 404 */     ((Hpack2)super).out = (Buffer2)youcangetnoinfoBEGR0ЛПДЦ;
/*     */   }
/*     */   
/*     */   public void clearDynamicTable() {
/* 408 */     Arrays.fill((Object[])((Hpack2)super).dynamicTable, (Object)null);
/* 409 */     ((Hpack2)super).nextHeaderIndex = ((Hpack2)super).dynamicTable.length - 1;
/* 410 */     ((Hpack2)super).headerCount = 0;
/* 411 */     ((Hpack2)super).dynamicTableByteCount = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int evictToRecoverBytes(Object youcangetnoinfoENHJмЧЬzё) {
/* 416 */     byte b = 0;
/* 417 */     if (youcangetnoinfoENHJмЧЬzё > null) {
/*     */       
/* 419 */       for (int i = ((Hpack2)super).dynamicTable.length - 1; i >= ((Hpack2)super).nextHeaderIndex && youcangetnoinfoENHJмЧЬzё > null; i--) {
/* 420 */         int j = youcangetnoinfoENHJмЧЬzё - (((Hpack2)super).dynamicTable[i]).hpackSize;
/* 421 */         ((Hpack2)super).dynamicTableByteCount -= (((Hpack2)super).dynamicTable[i]).hpackSize;
/* 422 */         ((Hpack2)super).headerCount--;
/* 423 */         b++;
/*     */       } 
/* 425 */       System.arraycopy(((Hpack2)super).dynamicTable, ((Hpack2)super).nextHeaderIndex + 1, ((Hpack2)super).dynamicTable, ((Hpack2)super).nextHeaderIndex + 1 + b, ((Hpack2)super).headerCount);
/*     */       
/* 427 */       Arrays.fill((Object[])((Hpack2)super).dynamicTable, ((Hpack2)super).nextHeaderIndex + 1, ((Hpack2)super).nextHeaderIndex + 1 + b, (Object)null);
/* 428 */       ((Hpack2)super).nextHeaderIndex += b;
/*     */     } 
/* 430 */     return b;
/*     */   }
/*     */   
/*     */   public void insertIntoDynamicTable(Object youcangetnoinfoAWAVИсёэЮ) {
/* 434 */     int i = ((Header)youcangetnoinfoAWAVИсёэЮ).hpackSize;
/*     */ 
/*     */     
/* 437 */     if (i > ((Hpack2)super).maxDynamicTableByteCount) {
/* 438 */       super.clearDynamicTable();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 443 */     int j = ((Hpack2)super).dynamicTableByteCount + i - ((Hpack2)super).maxDynamicTableByteCount;
/* 444 */     super.evictToRecoverBytes(j);
/*     */     
/* 446 */     if (((Hpack2)super).headerCount + 1 > ((Hpack2)super).dynamicTable.length) {
/* 447 */       Object youcangetnoinfoAWATщ3гыъ = new Header[((Hpack2)super).dynamicTable.length * 2];
/* 448 */       System.arraycopy(((Hpack2)super).dynamicTable, 0, youcangetnoinfoAWATщ3гыъ, ((Hpack2)super).dynamicTable.length, ((Hpack2)super).dynamicTable.length);
/* 449 */       ((Hpack2)super).nextHeaderIndex = ((Hpack2)super).dynamicTable.length - 1;
/* 450 */       ((Hpack2)super).dynamicTable = (Header[])youcangetnoinfoAWATщ3гыъ;
/*     */     } 
/* 452 */     int k = ((Hpack2)super).nextHeaderIndex--;
/* 453 */     ((Hpack2)super).dynamicTable[k] = (Header)youcangetnoinfoAWAVИсёэЮ;
/* 454 */     ((Hpack2)super).headerCount++;
/* 455 */     ((Hpack2)super).dynamicTableByteCount += i;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeHeaders(Object youcangetnoinfoATEQфр0д4) throws IOException {
/* 461 */     if (((Hpack2)super).emitDynamicTableSizeUpdate) {
/* 462 */       if (((Hpack2)super).smallestHeaderTableSizeSetting < ((Hpack2)super).maxDynamicTableByteCount)
/*     */       {
/* 464 */         super.writeInt(((Hpack2)super).smallestHeaderTableSizeSetting, 31, 32);
/*     */       }
/* 466 */       ((Hpack2)super).emitDynamicTableSizeUpdate = false;
/* 467 */       ((Hpack2)super).smallestHeaderTableSizeSetting = Integer.MAX_VALUE;
/* 468 */       super.writeInt(((Hpack2)super).maxDynamicTableByteCount, 31, 32);
/*     */     }  byte b;
/*     */     int i;
/* 471 */     for (b = 0, i = youcangetnoinfoATEQфр0д4.size(); b < i; b++) {
/* 472 */       Object youcangetnoinfoATEHщюнцё = youcangetnoinfoATEQфр0д4.get(b);
/* 473 */       Object youcangetnoinfoATEIтШдЦ7 = ((Header)youcangetnoinfoATEHщюнцё).name.toAsciiLowercase();
/* 474 */       Object youcangetnoinfoATEJрпИГХ = ((Header)youcangetnoinfoATEHщюнцё).value;
/* 475 */       int j = -1;
/* 476 */       int k = -1;
/*     */       
/* 478 */       Object youcangetnoinfoATEM2ЯфПь = Hpack1.NAME_TO_FIRST_INDEX.get(youcangetnoinfoATEIтШдЦ7);
/* 479 */       if (youcangetnoinfoATEM2ЯфПь != null) {
/* 480 */         k = youcangetnoinfoATEM2ЯфПь.intValue() + 1;
/* 481 */         if (k > 1 && k < 8)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 486 */           if (Objects.equals((Hpack1.STATIC_HEADER_TABLE[k - 1]).value, youcangetnoinfoATEJрпИГХ)) {
/* 487 */             j = k;
/* 488 */           } else if (Objects.equals((Hpack1.STATIC_HEADER_TABLE[k]).value, youcangetnoinfoATEJрпИГХ)) {
/* 489 */             j = k + 1;
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 494 */       if (j == -1) {
/* 495 */         for (int m = ((Hpack2)super).nextHeaderIndex + 1, n = ((Hpack2)super).dynamicTable.length; m < n; m++) {
/* 496 */           if (Objects.equals((((Hpack2)super).dynamicTable[m]).name, youcangetnoinfoATEIтШдЦ7)) {
/* 497 */             if (Objects.equals((((Hpack2)super).dynamicTable[m]).value, youcangetnoinfoATEJрпИГХ)) {
/* 498 */               j = m - ((Hpack2)super).nextHeaderIndex + Hpack1.STATIC_HEADER_TABLE.length; break;
/*     */             } 
/* 500 */             if (k == -1) {
/* 501 */               k = m - ((Hpack2)super).nextHeaderIndex + Hpack1.STATIC_HEADER_TABLE.length;
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */       
/* 507 */       if (j != -1) {
/*     */         
/* 509 */         super.writeInt(j, 127, 128);
/* 510 */       } else if (k == -1) {
/*     */         
/* 512 */         ((Hpack2)super).out.writeByte(64);
/* 513 */         super.writeByteString((ByteString)youcangetnoinfoATEIтШдЦ7);
/* 514 */         super.writeByteString((ByteString)youcangetnoinfoATEJрпИГХ);
/* 515 */         super.insertIntoDynamicTable((Header)youcangetnoinfoATEHщюнцё);
/* 516 */       } else if (youcangetnoinfoATEIтШдЦ7.startsWith(Header.PSEUDO_PREFIX) && !Header.TARGET_AUTHORITY.equals(youcangetnoinfoATEIтШдЦ7)) {
/*     */ 
/*     */         
/* 519 */         super.writeInt(k, 15, 0);
/* 520 */         super.writeByteString((ByteString)youcangetnoinfoATEJрпИГХ);
/*     */       } else {
/*     */         
/* 523 */         super.writeInt(k, 63, 64);
/* 524 */         super.writeByteString((ByteString)youcangetnoinfoATEJрпИГХ);
/* 525 */         super.insertIntoDynamicTable((Header)youcangetnoinfoATEHщюнцё);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeInt(Object youcangetnoinfoBINLНпИz6, Object youcangetnoinfoBINMНЁиАш, Object youcangetnoinfoBINNЮЫтвЬ) {
/*     */     // Byte code:
/*     */     //   0: iload_1
/*     */     //   1: iload_2
/*     */     //   2: if_icmpge -> 17
/*     */     //   5: aload_0
/*     */     //   6: getfield out : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   9: iload_3
/*     */     //   10: iload_1
/*     */     //   11: ior
/*     */     //   12: invokevirtual writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   15: pop
/*     */     //   16: return
/*     */     //   17: aload_0
/*     */     //   18: getfield out : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   21: iload_3
/*     */     //   22: iload_2
/*     */     //   23: ior
/*     */     //   24: invokevirtual writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   27: pop
/*     */     //   28: iload_1
/*     */     //   29: iload_2
/*     */     //   30: isub
/*     */     //   31: istore_1
/*     */     //   32: iload_1
/*     */     //   33: sipush #128
/*     */     //   36: if_icmplt -> 67
/*     */     //   39: iload_1
/*     */     //   40: bipush #127
/*     */     //   42: iand
/*     */     //   43: istore #4
/*     */     //   45: aload_0
/*     */     //   46: getfield out : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   49: iload #4
/*     */     //   51: sipush #128
/*     */     //   54: ior
/*     */     //   55: invokevirtual writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   58: pop
/*     */     //   59: iload_1
/*     */     //   60: bipush #7
/*     */     //   62: iushr
/*     */     //   63: istore_1
/*     */     //   64: goto -> 32
/*     */     //   67: aload_0
/*     */     //   68: getfield out : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   71: iload_1
/*     */     //   72: invokevirtual writeByte : (I)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Buffer2;
/*     */     //   75: pop
/*     */     //   76: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #533	-> 0
/*     */     //   #534	-> 5
/*     */     //   #535	-> 16
/*     */     //   #539	-> 17
/*     */     //   #540	-> 28
/*     */     //   #543	-> 32
/*     */     //   #544	-> 39
/*     */     //   #545	-> 45
/*     */     //   #546	-> 59
/*     */     //   #547	-> 64
/*     */     //   #548	-> 67
/*     */     //   #549	-> 76
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	77	0	youcangetnoinfoBINKг68Ру	Ljava/lang/Object;
/*     */     //   0	77	1	youcangetnoinfoBINLНпИz6	Ljava/lang/Object;
/*     */     //   0	77	2	youcangetnoinfoBINMНЁиАш	Ljava/lang/Object;
/*     */     //   0	77	3	youcangetnoinfoBINNЮЫтвЬ	Ljava/lang/Object;
/*     */     //   45	19	4	youcangetnoinfoBINJХ1Зьк	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeByteString(Object youcangetnoinfoCISMПУДхТ) throws IOException {
/* 552 */     if (((Hpack2)super).useCompression && Huffman.get().encodedLength((ByteString)youcangetnoinfoCISMПУДхТ) < youcangetnoinfoCISMПУДхТ.size()) {
/* 553 */       Object youcangetnoinfoCISJъР8де = new Buffer2();
/* 554 */       Huffman.get().encode((ByteString)youcangetnoinfoCISMПУДхТ, (BufferedSink)youcangetnoinfoCISJъР8де);
/* 555 */       Object youcangetnoinfoCISKнЖЩЭУ = youcangetnoinfoCISJъР8де.readByteString();
/* 556 */       super.writeInt(youcangetnoinfoCISKнЖЩЭУ.size(), 127, 128);
/* 557 */       ((Hpack2)super).out.write((ByteString)youcangetnoinfoCISKнЖЩЭУ);
/*     */     } else {
/* 559 */       super.writeInt(youcangetnoinfoCISMПУДхТ.size(), 127, 0);
/* 560 */       ((Hpack2)super).out.write((ByteString)youcangetnoinfoCISMПУДхТ);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setHeaderTableSizeSetting(Object youcangetnoinfoAULPьДузъ) {
/* 565 */     ((Hpack2)super).headerTableSizeSetting = youcangetnoinfoAULPьДузъ;
/* 566 */     int i = Math.min(youcangetnoinfoAULPьДузъ, 16384);
/*     */ 
/*     */     
/* 569 */     if (((Hpack2)super).maxDynamicTableByteCount == i)
/*     */       return; 
/* 571 */     if (i < ((Hpack2)super).maxDynamicTableByteCount) {
/* 572 */       ((Hpack2)super).smallestHeaderTableSizeSetting = Math.min(((Hpack2)super).smallestHeaderTableSizeSetting, i);
/*     */     }
/*     */     
/* 575 */     ((Hpack2)super).emitDynamicTableSizeUpdate = true;
/* 576 */     ((Hpack2)super).maxDynamicTableByteCount = i;
/* 577 */     super.adjustDynamicTableByteCount();
/*     */   }
/*     */   
/*     */   public void adjustDynamicTableByteCount() {
/* 581 */     if (((Hpack2)super).maxDynamicTableByteCount < ((Hpack2)super).dynamicTableByteCount)
/* 582 */       if (((Hpack2)super).maxDynamicTableByteCount == 0) {
/* 583 */         super.clearDynamicTable();
/*     */       } else {
/* 585 */         super.evictToRecoverBytes(((Hpack2)super).dynamicTableByteCount - ((Hpack2)super).maxDynamicTableByteCount);
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Hpack2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */