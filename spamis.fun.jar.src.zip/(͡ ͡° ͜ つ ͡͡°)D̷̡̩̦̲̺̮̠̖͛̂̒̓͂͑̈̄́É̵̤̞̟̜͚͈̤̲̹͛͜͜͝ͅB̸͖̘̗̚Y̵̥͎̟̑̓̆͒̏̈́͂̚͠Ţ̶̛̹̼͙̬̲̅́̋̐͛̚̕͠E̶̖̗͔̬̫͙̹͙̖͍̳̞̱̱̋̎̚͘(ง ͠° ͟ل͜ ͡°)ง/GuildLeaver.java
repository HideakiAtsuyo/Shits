/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildLeaver
/*    */   extends Thread
/*    */ {
/*    */   public final Map.Entry val$token;
/*    */   public final GuildLeaver1 this$1;
/*    */   
/*    */   public void run() {
/* 58 */     boolean bool = true;
/* 59 */     while (bool) {
/*    */       try {
/* 61 */         Object youcangetnoinfoDMTMЦ7ХвЙ = SpamUtils.getRandomProxy();
/* 62 */         Object youcangetnoinfoDMTN1бМНй = SpamUtils.leave(leaveGuildTxt.getText(), token
/* 63 */             .getValue().toString(), (String)youcangetnoinfoDMTMЦ7ХвЙ);
/* 64 */         if (youcangetnoinfoDMTN1бМНй == null) {
/* 65 */           ConsoleGUI.log(youcangetnoinfoDMTMЦ7ХвЙ + "-> Token(" + token.getKey() + ")-> Leaved " + leaveGuildTxt
/* 66 */               .getText());
/* 67 */           bool = false; continue;
/* 68 */         }  if (youcangetnoinfoDMTN1бМНй.startsWith("<")) {
/* 69 */           ConsoleGUI.log(youcangetnoinfoDMTMЦ7ХвЙ + "-> Token(" + token
/* 70 */               .getKey() + ")-> Proxy failed. Retrying"); continue;
/*    */         } 
/* 72 */         ConsoleGUI.log(youcangetnoinfoDMTMЦ7ХвЙ + "-> Token(" + token.getKey() + ")-> Unknown error: " + youcangetnoinfoDMTN1бМНй);
/*    */         
/* 74 */         bool = false;
/*    */       }
/* 76 */       catch (IOException youcangetnoinfoDMTOйкИ5л) {
/* 77 */         youcangetnoinfoDMTOйкИ5л.printStackTrace();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\GuildLeaver.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */