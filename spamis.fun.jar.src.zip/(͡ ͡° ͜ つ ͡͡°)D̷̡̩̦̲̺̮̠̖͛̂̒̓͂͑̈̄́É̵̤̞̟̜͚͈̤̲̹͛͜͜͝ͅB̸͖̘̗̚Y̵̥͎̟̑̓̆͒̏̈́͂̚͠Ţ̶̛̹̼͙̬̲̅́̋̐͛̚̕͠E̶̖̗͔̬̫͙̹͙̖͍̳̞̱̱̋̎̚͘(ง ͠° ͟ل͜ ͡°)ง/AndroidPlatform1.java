/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.security.cert.Certificate;
/*     */ import java.util.List;
/*     */ import javax.net.ssl.SSLPeerUnverifiedException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class AndroidPlatform1
/*     */   extends CertificateChainCleaner
/*     */ {
/*     */   public final Object x509TrustManagerExtensions;
/*     */   public final Method checkServerTrusted;
/*     */   
/*     */   public AndroidPlatform1(Object youcangetnoinfoXTLшгЧФЗ, Object youcangetnoinfoXTMбеДшЪ) {
/* 241 */     ((AndroidPlatform1)super).x509TrustManagerExtensions = youcangetnoinfoXTLшгЧФЗ;
/* 242 */     ((AndroidPlatform1)super).checkServerTrusted = (Method)youcangetnoinfoXTMбеДшЪ;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List<Certificate> clean(Object youcangetnoinfoCKKHэФГ1А, Object youcangetnoinfoCKKIЙХУеП) throws SSLPeerUnverifiedException {
/*     */     try {
/* 249 */       Object youcangetnoinfoCKKCФТЪды = youcangetnoinfoCKKHэФГ1А.toArray((Object[])new java.security.cert.X509Certificate[youcangetnoinfoCKKHэФГ1А.size()]);
/* 250 */       return (List<Certificate>)((AndroidPlatform1)super).checkServerTrusted.invoke(((AndroidPlatform1)super).x509TrustManagerExtensions, new Object[] { youcangetnoinfoCKKCФТЪды, "RSA", youcangetnoinfoCKKIЙХУеП });
/*     */     }
/* 252 */     catch (InvocationTargetException youcangetnoinfoCKKEБНцаz) {
/* 253 */       Object youcangetnoinfoCKKDЭ2ЁвЩ = new SSLPeerUnverifiedException(youcangetnoinfoCKKEБНцаz.getMessage());
/* 254 */       youcangetnoinfoCKKDЭ2ЁвЩ.initCause((Throwable)youcangetnoinfoCKKEБНцаz);
/* 255 */       throw youcangetnoinfoCKKDЭ2ЁвЩ;
/* 256 */     } catch (IllegalAccessException youcangetnoinfoCKKFрОг1Х) {
/* 257 */       throw new AssertionError(youcangetnoinfoCKKFрОг1Х);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean equals(Object youcangetnoinfoADTWЭлЭеш) {
/* 262 */     return youcangetnoinfoADTWЭлЭеш instanceof AndroidPlatform1;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 266 */     return 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\AndroidPlatform1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */