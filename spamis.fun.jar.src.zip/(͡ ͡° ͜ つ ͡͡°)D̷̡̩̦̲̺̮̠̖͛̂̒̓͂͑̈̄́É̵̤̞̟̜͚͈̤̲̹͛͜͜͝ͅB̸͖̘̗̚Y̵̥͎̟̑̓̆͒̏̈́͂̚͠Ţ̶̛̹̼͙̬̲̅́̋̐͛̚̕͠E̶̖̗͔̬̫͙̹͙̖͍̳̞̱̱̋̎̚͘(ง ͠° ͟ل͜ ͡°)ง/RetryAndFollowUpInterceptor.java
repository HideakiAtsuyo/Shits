/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.HttpRetryException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.Proxy;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RetryAndFollowUpInterceptor
/*     */   implements Interceptor
/*     */ {
/*     */   public static final int MAX_FOLLOW_UPS = 20;
/*     */   public Object callStackTrace;
/*     */   public final OkHttpClient client;
/*     */   public boolean canceled;
/*     */   public StreamAllocation1 streamAllocation;
/*     */   
/*     */   public RetryAndFollowUpInterceptor(Object youcangetnoinfoDCKTМЩрЗ5) {
/*  73 */     this();
/*  74 */     ((RetryAndFollowUpInterceptor)super).client = (OkHttpClient)youcangetnoinfoDCKTМЩрЗ5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancel() {
/*  87 */     ((RetryAndFollowUpInterceptor)super).canceled = true;
/*  88 */     Object youcangetnoinfoDCZCуоШЯс = ((RetryAndFollowUpInterceptor)super).streamAllocation;
/*  89 */     if (youcangetnoinfoDCZCуоШЯс != null) youcangetnoinfoDCZCуоШЯс.cancel(); 
/*     */   }
/*     */   
/*     */   public boolean isCanceled() {
/*  93 */     return ((RetryAndFollowUpInterceptor)super).canceled;
/*     */   }
/*     */   
/*     */   public void setCallStackTrace(Object youcangetnoinfoCGDYБхюЬ9) {
/*  97 */     ((RetryAndFollowUpInterceptor)super).callStackTrace = youcangetnoinfoCGDYБхюЬ9;
/*     */   }
/*     */   
/*     */   public StreamAllocation1 streamAllocation() {
/* 101 */     return ((RetryAndFollowUpInterceptor)super).streamAllocation;
/*     */   }
/*     */   
/*     */   public Response intercept(Object youcangetnoinfoCMCюяЦыь) throws IOException {
/* 105 */     Object youcangetnoinfoCMDФРЧЖЪ = youcangetnoinfoCMCюяЦыь.request();
/* 106 */     Object youcangetnoinfoCMEнйЦАЯ = youcangetnoinfoCMCюяЦыь;
/* 107 */     Object youcangetnoinfoCMFыЧмцщ = youcangetnoinfoCMEнйЦАЯ.call();
/* 108 */     Object youcangetnoinfoCMGЭГПЧы = youcangetnoinfoCMEнйЦАЯ.eventListener();
/*     */ 
/*     */     
/* 111 */     Object youcangetnoinfoCMHчЩШШ2 = new StreamAllocation1(((RetryAndFollowUpInterceptor)super).client.connectionPool(), super.createAddress(youcangetnoinfoCMDФРЧЖЪ.url()), (Call)youcangetnoinfoCMFыЧмцщ, (EventListener1)youcangetnoinfoCMGЭГПЧы, ((RetryAndFollowUpInterceptor)super).callStackTrace);
/* 112 */     ((RetryAndFollowUpInterceptor)super).streamAllocation = (StreamAllocation1)youcangetnoinfoCMHчЩШШ2;
/*     */     
/* 114 */     byte b = 0;
/* 115 */     Object youcangetnoinfoCMJДщчЙЭ = null; while (true) {
/*     */       Object youcangetnoinfoCLSф1уыЫ, youcangetnoinfoCLYЁь9У9, youcangetnoinfoCLWВАзБщ;
/* 117 */       if (((RetryAndFollowUpInterceptor)super).canceled) {
/* 118 */         youcangetnoinfoCMHчЩШШ2.release(true);
/* 119 */         throw new IOException("Canceled");
/*     */       } 
/*     */ 
/*     */       
/* 123 */       boolean bool = true;
/*     */       try {
/* 125 */         youcangetnoinfoCLSф1уыЫ = youcangetnoinfoCMEнйЦАЯ.proceed((Request)youcangetnoinfoCMDФРЧЖЪ, (StreamAllocation1)youcangetnoinfoCMHчЩШШ2, null, null);
/* 126 */         bool = false;
/* 127 */       } catch (RouteException youcangetnoinfoCLTжГУВн) {
/*     */         
/* 129 */         if (!super.recover(youcangetnoinfoCLTжГУВн.getLastConnectException(), (StreamAllocation1)youcangetnoinfoCMHчЩШШ2, false, (Request)youcangetnoinfoCMDФРЧЖЪ)) {
/* 130 */           throw youcangetnoinfoCLTжГУВн.getFirstConnectException();
/*     */         }
/* 132 */         bool = false;
/*     */         continue;
/* 134 */       } catch (IOException youcangetnoinfoCLVыюВыД) {
/*     */         
/* 136 */         boolean bool1 = !(youcangetnoinfoCLVыюВыД instanceof ConnectionShutdownException) ? true : false;
/* 137 */         if (!super.recover((IOException)youcangetnoinfoCLVыюВыД, (StreamAllocation1)youcangetnoinfoCMHчЩШШ2, bool1, (Request)youcangetnoinfoCMDФРЧЖЪ)) throw youcangetnoinfoCLVыюВыД; 
/* 138 */         bool = false;
/*     */         
/*     */         continue;
/*     */       } finally {
/* 142 */         if (bool) {
/* 143 */           youcangetnoinfoCMHчЩШШ2.streamFailed(null);
/* 144 */           youcangetnoinfoCMHчЩШШ2.release(true);
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 149 */       if (youcangetnoinfoCMJДщчЙЭ != null)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 154 */         youcangetnoinfoCLYЁь9У9 = youcangetnoinfoCLSф1уыЫ.newBuilder().priorResponse(youcangetnoinfoCMJДщчЙЭ.newBuilder().body(null).build()).build();
/*     */       }
/*     */ 
/*     */       
/*     */       try {
/* 159 */         youcangetnoinfoCLWВАзБщ = super.followUpRequest((Response)youcangetnoinfoCLYЁь9У9, youcangetnoinfoCMHчЩШШ2.route());
/* 160 */       } catch (IOException youcangetnoinfoCLXЫЪЙс7) {
/* 161 */         youcangetnoinfoCMHчЩШШ2.release(true);
/* 162 */         throw youcangetnoinfoCLXЫЪЙс7;
/*     */       } 
/*     */       
/* 165 */       if (youcangetnoinfoCLWВАзБщ == null) {
/* 166 */         youcangetnoinfoCMHчЩШШ2.release(true);
/* 167 */         return (Response)youcangetnoinfoCLYЁь9У9;
/*     */       } 
/*     */       
/* 170 */       Util1.closeQuietly(youcangetnoinfoCLYЁь9У9.body());
/*     */       
/* 172 */       if (++b > 20) {
/* 173 */         youcangetnoinfoCMHчЩШШ2.release(true);
/* 174 */         throw new ProtocolException("Too many follow-up requests: " + b);
/*     */       } 
/*     */       
/* 177 */       if (youcangetnoinfoCLWВАзБщ.body() instanceof UnrepeatableRequestBody) {
/* 178 */         youcangetnoinfoCMHчЩШШ2.release(true);
/* 179 */         throw new HttpRetryException("Cannot retry streamed HTTP body", youcangetnoinfoCLYЁь9У9.code());
/*     */       } 
/*     */       
/* 182 */       if (!super.sameConnection((Response)youcangetnoinfoCLYЁь9У9, youcangetnoinfoCLWВАзБщ.url())) {
/* 183 */         youcangetnoinfoCMHчЩШШ2.release(false);
/*     */         
/* 185 */         youcangetnoinfoCMHчЩШШ2 = new StreamAllocation1(((RetryAndFollowUpInterceptor)super).client.connectionPool(), super.createAddress(youcangetnoinfoCLWВАзБщ.url()), (Call)youcangetnoinfoCMFыЧмцщ, (EventListener1)youcangetnoinfoCMGЭГПЧы, ((RetryAndFollowUpInterceptor)super).callStackTrace);
/* 186 */         ((RetryAndFollowUpInterceptor)super).streamAllocation = (StreamAllocation1)youcangetnoinfoCMHчЩШШ2;
/* 187 */       } else if (youcangetnoinfoCMHчЩШШ2.codec() != null) {
/* 188 */         throw new IllegalStateException("Closing the body of " + youcangetnoinfoCLYЁь9У9 + " didn't close its backing stream. Bad interceptor?");
/*     */       } 
/*     */ 
/*     */       
/* 192 */       youcangetnoinfoCMDФРЧЖЪ = youcangetnoinfoCLWВАзБщ;
/* 193 */       youcangetnoinfoCMJДщчЙЭ = youcangetnoinfoCLYЁь9У9;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Address createAddress(Object youcangetnoinfoGOWСщиМЕ) {
/* 198 */     Object youcangetnoinfoGOXИхщщё = null;
/* 199 */     Object youcangetnoinfoGOYбЭянЩ = null;
/* 200 */     Object youcangetnoinfoGOZцНфЁБ = null;
/* 201 */     if (youcangetnoinfoGOWСщиМЕ.isHttps()) {
/* 202 */       youcangetnoinfoGOXИхщщё = ((RetryAndFollowUpInterceptor)super).client.sslSocketFactory();
/* 203 */       youcangetnoinfoGOYбЭянЩ = ((RetryAndFollowUpInterceptor)super).client.hostnameVerifier();
/* 204 */       youcangetnoinfoGOZцНфЁБ = ((RetryAndFollowUpInterceptor)super).client.certificatePinner();
/*     */     } 
/*     */     
/* 207 */     return new Address(youcangetnoinfoGOWСщиМЕ.host(), youcangetnoinfoGOWСщиМЕ.port(), ((RetryAndFollowUpInterceptor)super).client.dns(), ((RetryAndFollowUpInterceptor)super).client.socketFactory(), (SSLSocketFactory)youcangetnoinfoGOXИхщщё, (HostnameVerifier)youcangetnoinfoGOYбЭянЩ, (CertificatePinner1)youcangetnoinfoGOZцНфЁБ, ((RetryAndFollowUpInterceptor)super).client
/* 208 */         .proxyAuthenticator(), ((RetryAndFollowUpInterceptor)super).client
/* 209 */         .proxy(), ((RetryAndFollowUpInterceptor)super).client.protocols(), ((RetryAndFollowUpInterceptor)super).client.connectionSpecs(), ((RetryAndFollowUpInterceptor)super).client.proxySelector());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean recover(Object youcangetnoinfoDJMSкбГэН, Object youcangetnoinfoDJMT6Пмхе, Object youcangetnoinfoDJMUщЯБы8, Object youcangetnoinfoDJMVцМ1тУ) {
/* 220 */     youcangetnoinfoDJMT6Пмхе.streamFailed((IOException)youcangetnoinfoDJMSкбГэН);
/*     */ 
/*     */     
/* 223 */     if (!((RetryAndFollowUpInterceptor)super).client.retryOnConnectionFailure()) return false;
/*     */ 
/*     */     
/* 226 */     if (youcangetnoinfoDJMUщЯБы8 != null && super.requestIsUnrepeatable((IOException)youcangetnoinfoDJMSкбГэН, (Request)youcangetnoinfoDJMVцМ1тУ)) return false;
/*     */ 
/*     */     
/* 229 */     if (!super.isRecoverable((IOException)youcangetnoinfoDJMSкбГэН, youcangetnoinfoDJMUщЯБы8)) return false;
/*     */ 
/*     */     
/* 232 */     if (!youcangetnoinfoDJMT6Пмхе.hasMoreRoutes()) return false;
/*     */ 
/*     */     
/* 235 */     return true;
/*     */   }
/*     */   
/*     */   public boolean requestIsUnrepeatable(Object youcangetnoinfoCHJYюЮЕЯХ, Object youcangetnoinfoCHJZНКнГ4) {
/* 239 */     return (youcangetnoinfoCHJZНКнГ4.body() instanceof UnrepeatableRequestBody || youcangetnoinfoCHJYюЮЕЯХ instanceof java.io.FileNotFoundException);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isRecoverable(Object youcangetnoinfoCIYYи7янМ, Object youcangetnoinfoCIYZНфЛХВ) {
/* 245 */     if (youcangetnoinfoCIYYи7янМ instanceof ProtocolException) {
/* 246 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 251 */     if (youcangetnoinfoCIYYи7янМ instanceof java.io.InterruptedIOException) {
/* 252 */       return (youcangetnoinfoCIYYи7янМ instanceof java.net.SocketTimeoutException && youcangetnoinfoCIYZНфЛХВ == null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 257 */     if (youcangetnoinfoCIYYи7янМ instanceof javax.net.ssl.SSLHandshakeException)
/*     */     {
/*     */       
/* 260 */       if (youcangetnoinfoCIYYи7янМ.getCause() instanceof java.security.cert.CertificateException) {
/* 261 */         return false;
/*     */       }
/*     */     }
/* 264 */     if (youcangetnoinfoCIYYи7янМ instanceof javax.net.ssl.SSLPeerUnverifiedException)
/*     */     {
/* 266 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 272 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Request followUpRequest(Object youcangetnoinfoCPCDпАйПр, Object youcangetnoinfoCPCEбигцИ) throws IOException {
/*     */     Object youcangetnoinfoCPBVкЖйТя, youcangetnoinfoCPBYВуННй, youcangetnoinfoCPBZэДМшЁ;
/*     */     boolean bool;
/*     */     Object youcangetnoinfoCPCBzЯВУz;
/* 281 */     if (youcangetnoinfoCPCDпАйПр == null) throw new IllegalStateException(); 
/* 282 */     int i = youcangetnoinfoCPCDпАйПр.code();
/*     */     
/* 284 */     Object youcangetnoinfoCPCGхиЧЯы = youcangetnoinfoCPCDпАйПр.request().method();
/* 285 */     switch (i) {
/*     */ 
/*     */       
/*     */       case 407:
/* 289 */         youcangetnoinfoCPBVкЖйТя = (youcangetnoinfoCPCEбигцИ != null) ? youcangetnoinfoCPCEбигцИ.proxy() : ((RetryAndFollowUpInterceptor)super).client.proxy();
/* 290 */         if (youcangetnoinfoCPBVкЖйТя.type() != Proxy.Type.HTTP) {
/* 291 */           throw new ProtocolException("Received HTTP_PROXY_AUTH (407) code while not using proxy");
/*     */         }
/* 293 */         return ((RetryAndFollowUpInterceptor)super).client.proxyAuthenticator().authenticate((Route)youcangetnoinfoCPCEбигцИ, (Response)youcangetnoinfoCPCDпАйПр);
/*     */       
/*     */       case 401:
/* 296 */         return ((RetryAndFollowUpInterceptor)super).client.authenticator().authenticate((Route)youcangetnoinfoCPCEбигцИ, (Response)youcangetnoinfoCPCDпАйПр);
/*     */ 
/*     */ 
/*     */       
/*     */       case 307:
/*     */       case 308:
/* 302 */         if (!youcangetnoinfoCPCGхиЧЯы.equals("GET") && !youcangetnoinfoCPCGхиЧЯы.equals("HEAD")) {
/* 303 */           return null;
/*     */         }
/*     */ 
/*     */       
/*     */       case 300:
/*     */       case 301:
/*     */       case 302:
/*     */       case 303:
/* 311 */         if (!((RetryAndFollowUpInterceptor)super).client.followRedirects()) return null;
/*     */         
/* 313 */         youcangetnoinfoCPBYВуННй = youcangetnoinfoCPCDпАйПр.header("Location");
/* 314 */         if (youcangetnoinfoCPBYВуННй == null) return null; 
/* 315 */         youcangetnoinfoCPBZэДМшЁ = youcangetnoinfoCPCDпАйПр.request().url().resolve((String)youcangetnoinfoCPBYВуННй);
/*     */ 
/*     */         
/* 318 */         if (youcangetnoinfoCPBZэДМшЁ == null) return null;
/*     */ 
/*     */         
/* 321 */         bool = youcangetnoinfoCPBZэДМшЁ.scheme().equals(youcangetnoinfoCPCDпАйПр.request().url().scheme());
/* 322 */         if (!bool && !((RetryAndFollowUpInterceptor)super).client.followSslRedirects()) return null;
/*     */ 
/*     */         
/* 325 */         youcangetnoinfoCPCBzЯВУz = youcangetnoinfoCPCDпАйПр.request().newBuilder();
/* 326 */         if (HttpMethod.permitsRequestBody((String)youcangetnoinfoCPCGхиЧЯы)) {
/* 327 */           boolean bool1 = HttpMethod.redirectsWithBody((String)youcangetnoinfoCPCGхиЧЯы);
/* 328 */           if (HttpMethod.redirectsToGet((String)youcangetnoinfoCPCGхиЧЯы)) {
/* 329 */             youcangetnoinfoCPCBzЯВУz.method("GET", null);
/*     */           } else {
/* 331 */             Object youcangetnoinfoCPBWЪрАЖ4 = bool1 ? youcangetnoinfoCPCDпАйПр.request().body() : null;
/* 332 */             youcangetnoinfoCPCBzЯВУz.method((String)youcangetnoinfoCPCGхиЧЯы, (RequestBody)youcangetnoinfoCPBWЪрАЖ4);
/*     */           } 
/* 334 */           if (!bool1) {
/* 335 */             youcangetnoinfoCPCBzЯВУz.removeHeader("Transfer-Encoding");
/* 336 */             youcangetnoinfoCPCBzЯВУz.removeHeader("Content-Length");
/* 337 */             youcangetnoinfoCPCBzЯВУz.removeHeader("Content-Type");
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 344 */         if (!super.sameConnection((Response)youcangetnoinfoCPCDпАйПр, (HttpUrl1)youcangetnoinfoCPBZэДМшЁ)) {
/* 345 */           youcangetnoinfoCPCBzЯВУz.removeHeader("Authorization");
/*     */         }
/*     */         
/* 348 */         return youcangetnoinfoCPCBzЯВУz.url((HttpUrl1)youcangetnoinfoCPBZэДМшЁ).build();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 408:
/* 354 */         if (!((RetryAndFollowUpInterceptor)super).client.retryOnConnectionFailure())
/*     */         {
/* 356 */           return null;
/*     */         }
/*     */         
/* 359 */         if (youcangetnoinfoCPCDпАйПр.request().body() instanceof UnrepeatableRequestBody) {
/* 360 */           return null;
/*     */         }
/*     */         
/* 363 */         if (youcangetnoinfoCPCDпАйПр.priorResponse() != null && youcangetnoinfoCPCDпАйПр
/* 364 */           .priorResponse().code() == 408)
/*     */         {
/* 366 */           return null;
/*     */         }
/*     */         
/* 369 */         if (super.retryAfter((Response)youcangetnoinfoCPCDпАйПр, 0) > 0) {
/* 370 */           return null;
/*     */         }
/*     */         
/* 373 */         return youcangetnoinfoCPCDпАйПр.request();
/*     */       
/*     */       case 503:
/* 376 */         if (youcangetnoinfoCPCDпАйПр.priorResponse() != null && youcangetnoinfoCPCDпАйПр
/* 377 */           .priorResponse().code() == 503)
/*     */         {
/* 379 */           return null;
/*     */         }
/*     */         
/* 382 */         if (super.retryAfter((Response)youcangetnoinfoCPCDпАйПр, 2147483647) == 0)
/*     */         {
/* 384 */           return youcangetnoinfoCPCDпАйПр.request();
/*     */         }
/*     */         
/* 387 */         return null;
/*     */     } 
/*     */     
/* 390 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int retryAfter(Object youcangetnoinfoCHHKзюД7о, Object youcangetnoinfoCHHLдВЕЫ8) {
/* 395 */     Object youcangetnoinfoCHHMЯЮЁей = youcangetnoinfoCHHKзюД7о.header("Retry-After");
/*     */     
/* 397 */     if (youcangetnoinfoCHHMЯЮЁей == null) {
/* 398 */       return youcangetnoinfoCHHLдВЕЫ8;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 403 */     if (youcangetnoinfoCHHMЯЮЁей.matches("\\d+")) {
/* 404 */       return Integer.valueOf((String)youcangetnoinfoCHHMЯЮЁей).intValue();
/*     */     }
/*     */     
/* 407 */     return Integer.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean sameConnection(Object youcangetnoinfoECCXуБу0Ч, Object youcangetnoinfoECCYАцдЭ9) {
/* 415 */     Object youcangetnoinfoECCZюЬЗФ5 = youcangetnoinfoECCXуБу0Ч.request().url();
/* 416 */     return (youcangetnoinfoECCZюЬЗФ5.host().equals(youcangetnoinfoECCYАцдЭ9.host()) && youcangetnoinfoECCZюЬЗФ5
/* 417 */       .port() == youcangetnoinfoECCYАцдЭ9.port() && youcangetnoinfoECCZюЬЗФ5
/* 418 */       .scheme().equals(youcangetnoinfoECCYАцдЭ9.scheme()));
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RetryAndFollowUpInterceptor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */