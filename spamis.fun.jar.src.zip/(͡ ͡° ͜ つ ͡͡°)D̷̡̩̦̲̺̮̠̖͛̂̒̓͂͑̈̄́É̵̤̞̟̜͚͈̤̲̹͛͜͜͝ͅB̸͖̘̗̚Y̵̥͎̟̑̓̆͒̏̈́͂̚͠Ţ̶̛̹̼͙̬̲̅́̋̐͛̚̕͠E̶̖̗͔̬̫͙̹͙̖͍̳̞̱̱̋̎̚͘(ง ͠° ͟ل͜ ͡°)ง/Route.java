/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.net.InetSocketAddress;
/*    */ import java.net.Proxy;
/*    */ import javax.annotation.Nullable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Route
/*    */ {
/*    */   public final Proxy proxy;
/*    */   public final Address address;
/*    */   public final InetSocketAddress inetSocketAddress;
/*    */   
/*    */   public Route(Object youcangetnoinfoPIBГЁУкЙ, Object youcangetnoinfoPIC9ШУКА, Object youcangetnoinfoPIDя7Щч2) {
/* 42 */     this();
/* 43 */     if (youcangetnoinfoPIBГЁУкЙ == null) {
/* 44 */       throw new NullPointerException("address == null");
/*    */     }
/* 46 */     if (youcangetnoinfoPIC9ШУКА == null) {
/* 47 */       throw new NullPointerException("proxy == null");
/*    */     }
/* 49 */     if (youcangetnoinfoPIDя7Щч2 == null) {
/* 50 */       throw new NullPointerException("inetSocketAddress == null");
/*    */     }
/* 52 */     ((Route)super).address = (Address)youcangetnoinfoPIBГЁУкЙ;
/* 53 */     ((Route)super).proxy = (Proxy)youcangetnoinfoPIC9ШУКА;
/* 54 */     ((Route)super).inetSocketAddress = (InetSocketAddress)youcangetnoinfoPIDя7Щч2;
/*    */   }
/*    */   
/*    */   public Address address() {
/* 58 */     return ((Route)super).address;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Proxy proxy() {
/* 68 */     return ((Route)super).proxy;
/*    */   }
/*    */   
/*    */   public InetSocketAddress socketAddress() {
/* 72 */     return ((Route)super).inetSocketAddress;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean requiresTunnel() {
/* 80 */     return (((Route)super).address.sslSocketFactory != null && ((Route)super).proxy.type() == Proxy.Type.HTTP);
/*    */   }
/*    */   
/*    */   public boolean equals(@Nullable Object youcangetnoinfoQQFШпЫиН) {
/* 84 */     return (youcangetnoinfoQQFШпЫиН instanceof Route && ((Route)youcangetnoinfoQQFШпЫиН).address
/* 85 */       .equals(((Route)super).address) && ((Route)youcangetnoinfoQQFШпЫиН).proxy
/* 86 */       .equals(((Route)super).proxy) && ((Route)youcangetnoinfoQQFШпЫиН).inetSocketAddress
/* 87 */       .equals(((Route)super).inetSocketAddress));
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 91 */     int i = 17;
/* 92 */     i = 31 * i + ((Route)super).address.hashCode();
/* 93 */     i = 31 * i + ((Route)super).proxy.hashCode();
/* 94 */     i = 31 * i + ((Route)super).inetSocketAddress.hashCode();
/* 95 */     return i;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 99 */     return "Route{" + ((Route)super).inetSocketAddress + "}";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Route.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */