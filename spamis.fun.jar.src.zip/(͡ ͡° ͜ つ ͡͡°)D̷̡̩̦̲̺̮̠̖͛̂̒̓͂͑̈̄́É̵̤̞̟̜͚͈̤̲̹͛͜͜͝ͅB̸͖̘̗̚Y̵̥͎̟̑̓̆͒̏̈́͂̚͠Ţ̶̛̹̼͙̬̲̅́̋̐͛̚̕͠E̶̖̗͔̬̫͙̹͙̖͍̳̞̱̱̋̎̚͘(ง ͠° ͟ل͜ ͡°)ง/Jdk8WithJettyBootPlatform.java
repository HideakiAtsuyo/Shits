/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Jdk8WithJettyBootPlatform
/*     */   implements InvocationHandler
/*     */ {
/*     */   public final List<String> protocols;
/*     */   public String selected;
/*     */   public boolean unsupported;
/*     */   
/*     */   public Jdk8WithJettyBootPlatform(Object youcangetnoinfoAQBXЫz1ки) {
/* 112 */     this();
/* 113 */     ((Jdk8WithJettyBootPlatform)super).protocols = (List<String>)youcangetnoinfoAQBXЫz1ки;
/*     */   }
/*     */   
/*     */   public Object invoke(Object youcangetnoinfoADIXв9вОй, Object youcangetnoinfoADIYМфЩ4Ъ, Object youcangetnoinfoADIZЩНдзр) throws Throwable {
/* 117 */     Object youcangetnoinfoADJAшДШиФ = youcangetnoinfoADIYМфЩ4Ъ.getName();
/* 118 */     Object<?> youcangetnoinfoADJBТаК14 = (Object<?>)youcangetnoinfoADIYМфЩ4Ъ.getReturnType();
/* 119 */     if (youcangetnoinfoADIZЩНдзр == null) {
/* 120 */       youcangetnoinfoADIZЩНдзр = Util1.EMPTY_STRING_ARRAY;
/*     */     }
/* 122 */     if (youcangetnoinfoADJAшДШиФ.equals("supports") && boolean.class == youcangetnoinfoADJBТаК14)
/* 123 */       return Boolean.valueOf(true); 
/* 124 */     if (youcangetnoinfoADJAшДШиФ.equals("unsupported") && void.class == youcangetnoinfoADJBТаК14) {
/* 125 */       ((Jdk8WithJettyBootPlatform)super).unsupported = true;
/* 126 */       return null;
/* 127 */     }  if (youcangetnoinfoADJAшДШиФ.equals("protocols") && youcangetnoinfoADIZЩНдзр.length == 0)
/* 128 */       return ((Jdk8WithJettyBootPlatform)super).protocols; 
/* 129 */     if ((youcangetnoinfoADJAшДШиФ.equals("selectProtocol") || youcangetnoinfoADJAшДШиФ.equals("select")) && String.class == youcangetnoinfoADJBТаК14 && youcangetnoinfoADIZЩНдзр.length == 1 && youcangetnoinfoADIZЩНдзр[0] instanceof List) {
/*     */       
/* 131 */       Object youcangetnoinfoADIVШюЬСЫ = youcangetnoinfoADIZЩНдзр[0]; byte b;
/*     */       int i;
/* 133 */       for (b = 0, i = youcangetnoinfoADIVШюЬСЫ.size(); b < i; b++) {
/* 134 */         Object youcangetnoinfoADISвЙшСч = youcangetnoinfoADIVШюЬСЫ.get(b);
/* 135 */         if (((Jdk8WithJettyBootPlatform)super).protocols.contains(youcangetnoinfoADISвЙшСч)) {
/* 136 */           return ((Jdk8WithJettyBootPlatform)super).selected = (String)youcangetnoinfoADISвЙшСч;
/*     */         }
/*     */       } 
/* 139 */       return ((Jdk8WithJettyBootPlatform)super).selected = ((Jdk8WithJettyBootPlatform)super).protocols.get(0);
/* 140 */     }  if ((youcangetnoinfoADJAшДШиФ.equals("protocolSelected") || youcangetnoinfoADJAшДШиФ.equals("selected")) && youcangetnoinfoADIZЩНдзр.length == 1) {
/*     */       
/* 142 */       ((Jdk8WithJettyBootPlatform)super).selected = (String)youcangetnoinfoADIZЩНдзр[0];
/* 143 */       return null;
/*     */     } 
/* 145 */     return youcangetnoinfoADIYМфЩ4Ъ.invoke(this, (Object[])youcangetnoinfoADIZЩНдзр);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Jdk8WithJettyBootPlatform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */