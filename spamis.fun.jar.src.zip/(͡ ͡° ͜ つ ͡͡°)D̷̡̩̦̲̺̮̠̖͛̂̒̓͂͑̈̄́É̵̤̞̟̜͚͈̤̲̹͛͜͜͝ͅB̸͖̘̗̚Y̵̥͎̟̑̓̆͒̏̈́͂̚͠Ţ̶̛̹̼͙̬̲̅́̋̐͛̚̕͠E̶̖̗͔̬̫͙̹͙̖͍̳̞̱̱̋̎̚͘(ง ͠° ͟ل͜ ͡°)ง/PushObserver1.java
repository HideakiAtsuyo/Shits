/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PushObserver1
/*    */   implements PushObserver
/*    */ {
/*    */   public PushObserver1() {
/* 76 */     this();
/*    */   }
/*    */   public boolean onRequest(Object youcangetnoinfoACQCКутАЗ, Object youcangetnoinfoACQDлЛлдш) {
/* 79 */     return true;
/*    */   }
/*    */   
/*    */   public boolean onHeaders(Object youcangetnoinfoBPHFёыешв, Object youcangetnoinfoBPHGЁ49Эе, Object youcangetnoinfoBPHH1СТэЛ) {
/* 83 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean onData(Object youcangetnoinfoCPOOz3эъЩ, Object youcangetnoinfoCPOPкрАе5, Object youcangetnoinfoCPOQй4ЦРР, Object youcangetnoinfoCPORЙЪкьэ) throws IOException {
/* 88 */     youcangetnoinfoCPOPкрАе5.skip(youcangetnoinfoCPOQй4ЦРР);
/* 89 */     return true;
/*    */   }
/*    */   
/*    */   public void onReset(Object youcangetnoinfoHE5ф1Аю, Object youcangetnoinfoHFЁ2дЪГ) {}
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\PushObserver1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */