/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Deque;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Stream2
/*     */ {
/*     */   public final Http2Stream3 readTimeout;
/*     */   public static final boolean $assertionsDisabled;
/*     */   public long unacknowledgedBytesRead;
/*     */   public boolean hasResponseHeaders;
/*     */   public long bytesLeftInWriteWindow;
/*     */   public ErrorCode errorCode;
/*     */   public final Http2Stream source;
/*     */   public final int id;
/*     */   public final Deque headersQueue;
/*     */   public final Http2Stream1 sink;
/*     */   public final Http2Stream3 writeTimeout;
/*     */   public final Http2Connection5 connection;
/*     */   
/*     */   public Http2Stream2(Object youcangetnoinfoBAXSЪ2еоН, Object youcangetnoinfoBAXTЧСОмМ, Object youcangetnoinfoBAXUяэиЛА, Object youcangetnoinfoBAXVЯё9РС, @Nullable Object youcangetnoinfoBAXW6НЫzЪ) {
/*  80 */     this(); ((Http2Stream2)super).unacknowledgedBytesRead = 0L; ((Http2Stream2)super).headersQueue = new ArrayDeque(); ((Http2Stream2)super).readTimeout = new Http2Stream3((Http2Stream2)this); ((Http2Stream2)super).writeTimeout = new Http2Stream3((Http2Stream2)this); ((Http2Stream2)super).errorCode = null;
/*  81 */     if (youcangetnoinfoBAXTЧСОмМ == null) throw new NullPointerException("connection == null");
/*     */     
/*  83 */     ((Http2Stream2)super).id = youcangetnoinfoBAXSЪ2еоН;
/*  84 */     ((Http2Stream2)super).connection = (Http2Connection5)youcangetnoinfoBAXTЧСОмМ;
/*  85 */     ((Http2Stream2)super)
/*  86 */       .bytesLeftInWriteWindow = ((Http2Connection5)youcangetnoinfoBAXTЧСОмМ).peerSettings.getInitialWindowSize();
/*  87 */     ((Http2Stream2)super).source = new Http2Stream((Http2Stream2)this, ((Http2Connection5)youcangetnoinfoBAXTЧСОмМ).okHttpSettings.getInitialWindowSize());
/*  88 */     ((Http2Stream2)super).sink = new Http2Stream1((Http2Stream2)this);
/*  89 */     ((Http2Stream2)super).source.finished = youcangetnoinfoBAXVЯё9РС;
/*  90 */     ((Http2Stream2)super).sink.finished = youcangetnoinfoBAXUяэиЛА;
/*  91 */     if (youcangetnoinfoBAXW6НЫzЪ != null) {
/*  92 */       ((Http2Stream2)super).headersQueue.add(youcangetnoinfoBAXW6НЫzЪ);
/*     */     }
/*     */     
/*  95 */     if (super.isLocallyInitiated() && youcangetnoinfoBAXW6НЫzЪ != null)
/*  96 */       throw new IllegalStateException("locally-initiated streams shouldn't have headers yet"); 
/*  97 */     if (!super.isLocallyInitiated() && youcangetnoinfoBAXW6НЫzЪ == null) {
/*  98 */       throw new IllegalStateException("remotely-initiated streams should have headers");
/*     */     }
/*     */   }
/*     */   
/*     */   public int getId() {
/* 103 */     return ((Http2Stream2)super).id;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean isOpen() {
/* 118 */     if (((Http2Stream2)super).errorCode != null) {
/* 119 */       return false;
/*     */     }
/* 121 */     if ((((Http2Stream2)super).source.finished || ((Http2Stream2)super).source.closed) && (((Http2Stream2)super).sink.finished || ((Http2Stream2)super).sink.closed) && ((Http2Stream2)super).hasResponseHeaders)
/*     */     {
/*     */       
/* 124 */       return false;
/*     */     }
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLocallyInitiated() {
/* 131 */     boolean bool = ((((Http2Stream2)super).id & 0x1) == 1);
/* 132 */     return (((Http2Stream2)super).connection.client == bool);
/*     */   }
/*     */   
/*     */   public Http2Connection5 getConnection() {
/* 136 */     return ((Http2Stream2)super).connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Headers takeHeaders() throws IOException {
/* 145 */     ((Http2Stream2)super).readTimeout.enter();
/*     */     try {
/* 147 */       while (((Http2Stream2)super).headersQueue.isEmpty() && ((Http2Stream2)super).errorCode == null) {
/* 148 */         super.waitForIo();
/*     */       }
/*     */     } finally {
/* 151 */       ((Http2Stream2)super).readTimeout.exitAndThrowIfTimedOut();
/*     */     } 
/* 153 */     if (!((Http2Stream2)super).headersQueue.isEmpty()) {
/* 154 */       return ((Http2Stream2)super).headersQueue.removeFirst();
/*     */     }
/* 156 */     throw new StreamResetException(super.errorCode);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Headers trailers() throws IOException {
/* 164 */     if (((Http2Stream2)super).errorCode != null) {
/* 165 */       throw new StreamResetException(super.errorCode);
/*     */     }
/* 167 */     if (!((Http2Stream2)super).source.finished || !Http2Stream.access$000(((Http2Stream2)super).source).exhausted() || !Http2Stream.access$100(((Http2Stream2)super).source).exhausted()) {
/* 168 */       throw new IllegalStateException("too early; can't read the trailers yet");
/*     */     }
/* 170 */     return (Http2Stream.access$200(((Http2Stream2)super).source) != null) ? Http2Stream.access$200(((Http2Stream2)super).source) : Util1.EMPTY_HEADERS;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized ErrorCode getErrorCode() {
/* 178 */     return ((Http2Stream2)super).errorCode;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeHeaders(Object youcangetnoinfoAIMZыЩВЕс, Object youcangetnoinfoAINAЕлюнЦ, Object youcangetnoinfoAINBмВ4МЁ) throws IOException {
/*     */     boolean bool;
/* 191 */     assert !Thread.holdsLock(this);
/* 192 */     if (youcangetnoinfoAIMZыЩВЕс == null) {
/* 193 */       throw new NullPointerException("headers == null");
/*     */     }
/* 195 */     synchronized (this) {
/* 196 */       ((Http2Stream2)super).hasResponseHeaders = true;
/* 197 */       if (youcangetnoinfoAINAЕлюнЦ != null) {
/* 198 */         ((Http2Stream2)super).sink.finished = true;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 204 */     if (youcangetnoinfoAINBмВ4МЁ == null) {
/* 205 */       synchronized (((Http2Stream2)super).connection) {
/* 206 */         bool = (((Http2Stream2)super).connection.bytesLeftInWriteWindow == 0L) ? true : false;
/*     */       } 
/*     */     }
/*     */     
/* 210 */     ((Http2Stream2)super).connection.writeHeaders(((Http2Stream2)super).id, youcangetnoinfoAINAЕлюнЦ, (List)youcangetnoinfoAIMZыЩВЕс);
/*     */     
/* 212 */     if (bool) {
/* 213 */       ((Http2Stream2)super).connection.flush();
/*     */     }
/*     */   }
/*     */   
/*     */   public void enqueueTrailers(Object youcangetnoinfoDFDW4ггГЧ) {
/* 218 */     synchronized (this) {
/* 219 */       if (((Http2Stream2)super).sink.finished) throw new IllegalStateException("already finished"); 
/* 220 */       if (youcangetnoinfoDFDW4ггГЧ.size() == 0) throw new IllegalArgumentException("trailers.size() == 0"); 
/* 221 */       Http2Stream1.access$302(((Http2Stream2)super).sink, (Headers)youcangetnoinfoDFDW4ггГЧ);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Timeout readTimeout() {
/* 226 */     return ((Http2Stream2)super).readTimeout;
/*     */   }
/*     */   
/*     */   public Timeout writeTimeout() {
/* 230 */     return ((Http2Stream2)super).writeTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public Source getSource() {
/* 235 */     return ((Http2Stream2)super).source;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Sink getSink() {
/* 245 */     synchronized (this) {
/* 246 */       if (!((Http2Stream2)super).hasResponseHeaders && !super.isLocallyInitiated()) {
/* 247 */         throw new IllegalStateException("reply before requesting the sink");
/*     */       }
/*     */     } 
/* 250 */     return ((Http2Stream2)super).sink;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close(Object youcangetnoinfoHJNожмЭЗ) throws IOException {
/* 258 */     if (!super.closeInternal((ErrorCode)youcangetnoinfoHJNожмЭЗ)) {
/*     */       return;
/*     */     }
/* 261 */     ((Http2Stream2)super).connection.writeSynReset(((Http2Stream2)super).id, (ErrorCode)youcangetnoinfoHJNожмЭЗ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeLater(Object youcangetnoinfoDBACа5сдж) {
/* 269 */     if (!super.closeInternal((ErrorCode)youcangetnoinfoDBACа5сдж)) {
/*     */       return;
/*     */     }
/* 272 */     ((Http2Stream2)super).connection.writeSynResetLater(((Http2Stream2)super).id, (ErrorCode)youcangetnoinfoDBACа5сдж);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean closeInternal(Object youcangetnoinfoAICTощВгЫ) {
/* 277 */     assert !Thread.holdsLock(this);
/* 278 */     synchronized (this) {
/* 279 */       if (((Http2Stream2)super).errorCode != null) {
/* 280 */         return false;
/*     */       }
/* 282 */       if (((Http2Stream2)super).source.finished && ((Http2Stream2)super).sink.finished) {
/* 283 */         return false;
/*     */       }
/* 285 */       ((Http2Stream2)super).errorCode = (ErrorCode)youcangetnoinfoAICTощВгЫ;
/* 286 */       notifyAll();
/*     */     } 
/* 288 */     ((Http2Stream2)super).connection.removeStream(((Http2Stream2)super).id);
/* 289 */     return true;
/*     */   }
/*     */   
/*     */   public void receiveData(Object youcangetnoinfoBUQAГяБг8, Object youcangetnoinfoBUQBЧГЗяз) throws IOException {
/* 293 */     assert !Thread.holdsLock(this);
/* 294 */     ((Http2Stream2)super).source.receive((BufferedSource)youcangetnoinfoBUQAГяБг8, youcangetnoinfoBUQBЧГЗяз);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void receiveHeaders(Object youcangetnoinfoBYGKШбКС3, Object youcangetnoinfoBYGLз1НЫб) {
/*     */     boolean bool;
/* 302 */     assert !Thread.holdsLock(this);
/*     */     
/* 304 */     synchronized (this) {
/* 305 */       if (!((Http2Stream2)super).hasResponseHeaders || youcangetnoinfoBYGLз1НЫб == null) {
/* 306 */         ((Http2Stream2)super).hasResponseHeaders = true;
/* 307 */         ((Http2Stream2)super).headersQueue.add(youcangetnoinfoBYGKШбКС3);
/*     */       } else {
/* 309 */         Http2Stream.access$202(((Http2Stream2)super).source, (Headers)youcangetnoinfoBYGKШбКС3);
/*     */       } 
/* 311 */       if (youcangetnoinfoBYGLз1НЫб != null) {
/* 312 */         ((Http2Stream2)super).source.finished = true;
/*     */       }
/* 314 */       bool = super.isOpen();
/* 315 */       notifyAll();
/*     */     } 
/* 317 */     if (!bool) {
/* 318 */       ((Http2Stream2)super).connection.removeStream(((Http2Stream2)super).id);
/*     */     }
/*     */   }
/*     */   
/*     */   public synchronized void receiveRstStream(Object youcangetnoinfoCTMK6июпщ) {
/* 323 */     if (((Http2Stream2)super).errorCode == null) {
/* 324 */       ((Http2Stream2)super).errorCode = (ErrorCode)youcangetnoinfoCTMK6июпщ;
/* 325 */       notifyAll();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancelStreamIfNecessary() throws IOException {
/*     */     boolean bool;
/*     */     boolean bool1;
/* 491 */     assert !Thread.holdsLock(this);
/*     */ 
/*     */     
/* 494 */     synchronized (this) {
/* 495 */       bool1 = (!((Http2Stream2)super).source.finished && ((Http2Stream2)super).source.closed && (((Http2Stream2)super).sink.finished || ((Http2Stream2)super).sink.closed)) ? true : false;
/* 496 */       bool = super.isOpen();
/*     */     } 
/* 498 */     if (bool1) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 503 */       super.close(ErrorCode.CANCEL);
/* 504 */     } else if (!bool) {
/* 505 */       ((Http2Stream2)super).connection.removeStream(((Http2Stream2)super).id);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addBytesToWriteWindow(Object youcangetnoinfoDMRYд4Ц2А) {
/* 618 */     ((Http2Stream2)super).bytesLeftInWriteWindow += youcangetnoinfoDMRYд4Ц2А;
/* 619 */     if (youcangetnoinfoDMRYд4Ц2А > 0L) notifyAll(); 
/*     */   }
/*     */   
/*     */   public void checkOutNotClosed() throws IOException {
/* 623 */     if (((Http2Stream2)super).sink.closed)
/* 624 */       throw new IOException("stream closed"); 
/* 625 */     if (((Http2Stream2)super).sink.finished)
/* 626 */       throw new IOException("stream finished"); 
/* 627 */     if (((Http2Stream2)super).errorCode != null) {
/* 628 */       throw new StreamResetException(super.errorCode);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void waitForIo() throws InterruptedIOException {
/*     */     try {
/* 638 */       wait();
/* 639 */     } catch (InterruptedException youcangetnoinfoCXADтВЕАВ) {
/* 640 */       Thread.currentThread().interrupt();
/* 641 */       throw new InterruptedIOException();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http2Stream2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */