/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.net.SocketTimeoutException;
/*     */ import java.util.ArrayDeque;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledFuture;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RealWebSocket5
/*     */   implements WebSocketReader1, WebSocket1
/*     */ {
/*     */   public boolean failed;
/*     */   public final ArrayDeque<Object> messageAndCloseQueue;
/*  57 */   public static final List ONLY_HTTP1 = Collections.singletonList(Protocol.HTTP_1_1);
/*     */ 
/*     */ 
/*     */   
/*     */   public String receivedCloseReason;
/*     */ 
/*     */ 
/*     */   
/*     */   public final Runnable writerRunnable;
/*     */ 
/*     */ 
/*     */   
/*     */   public static final long CANCEL_AFTER_CLOSE_MILLIS = 60000L;
/*     */ 
/*     */ 
/*     */   
/*     */   public ScheduledFuture<?> cancelFuture;
/*     */ 
/*     */ 
/*     */   
/*     */   public Call call;
/*     */ 
/*     */ 
/*     */   
/*     */   public int receivedPingCount;
/*     */ 
/*     */ 
/*     */   
/*     */   public final Random random;
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSocketReader reader;
/*     */ 
/*     */ 
/*     */   
/*     */   public RealWebSocket3 streams;
/*     */ 
/*     */   
/*     */   public final String key;
/*     */ 
/*     */   
/*     */   public static final boolean $assertionsDisabled;
/*     */ 
/*     */   
/*     */   public final long pingIntervalMillis;
/*     */ 
/*     */   
/*     */   public WebSocketWriter writer;
/*     */ 
/*     */   
/*     */   public int receivedPongCount;
/*     */ 
/*     */   
/*     */   public static final long MAX_QUEUE_SIZE = 16777216L;
/*     */ 
/*     */   
/*     */   public final ArrayDeque pongQueue;
/*     */ 
/*     */   
/*     */   public int receivedCloseCode;
/*     */ 
/*     */   
/*     */   public boolean awaitingPong;
/*     */ 
/*     */   
/*     */   public int sentPingCount;
/*     */ 
/*     */   
/*     */   public final WebSocketListener listener;
/*     */ 
/*     */   
/*     */   public final Request originalRequest;
/*     */ 
/*     */   
/*     */   public boolean enqueuedClose;
/*     */ 
/*     */   
/*     */   public long queueSize;
/*     */ 
/*     */   
/*     */   public ScheduledExecutorService executor;
/*     */ 
/*     */ 
/*     */   
/*     */   public RealWebSocket5(Object youcangetnoinfoANXKЫЕИБС, Object youcangetnoinfoANXL6ЯсФ6, Object youcangetnoinfoANXMйщССт, Object youcangetnoinfoANXNМЬИкм) {
/* 143 */     this(); ((RealWebSocket5)super).pongQueue = new ArrayDeque(); ((RealWebSocket5)super).messageAndCloseQueue = new ArrayDeque(); ((RealWebSocket5)super).receivedCloseCode = -1;
/* 144 */     if (!"GET".equals(youcangetnoinfoANXKЫЕИБС.method())) {
/* 145 */       throw new IllegalArgumentException("Request must be GET: " + youcangetnoinfoANXKЫЕИБС.method());
/*     */     }
/* 147 */     ((RealWebSocket5)super).originalRequest = (Request)youcangetnoinfoANXKЫЕИБС;
/* 148 */     ((RealWebSocket5)super).listener = (WebSocketListener)youcangetnoinfoANXL6ЯсФ6;
/* 149 */     ((RealWebSocket5)super).random = (Random)youcangetnoinfoANXMйщССт;
/* 150 */     ((RealWebSocket5)super).pingIntervalMillis = youcangetnoinfoANXNМЬИкм;
/*     */     
/* 152 */     Object youcangetnoinfoANXOйтщ4Ч = new byte[16];
/* 153 */     youcangetnoinfoANXMйщССт.nextBytes((byte[])youcangetnoinfoANXOйтщ4Ч);
/* 154 */     ((RealWebSocket5)super).key = ByteString.of((byte[])youcangetnoinfoANXOйтщ4Ч).base64();
/*     */     
/* 156 */     ((RealWebSocket5)super).writerRunnable = this::lambda$new$0; } public void lambda$new$0() {
/*     */     try {
/* 158 */       while (super.writeOneFrame());
/*     */     }
/* 160 */     catch (IOException youcangetnoinfoBPVC3тзпе) {
/* 161 */       super.failWebSocket((Exception)youcangetnoinfoBPVC3тзпе, null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Request request() {
/* 167 */     return ((RealWebSocket5)super).originalRequest;
/*     */   }
/*     */   
/*     */   public synchronized long queueSize() {
/* 171 */     return ((RealWebSocket5)super).queueSize;
/*     */   }
/*     */   
/*     */   public void cancel() {
/* 175 */     ((RealWebSocket5)super).call.cancel();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connect(Object youcangetnoinfoBEJYИгАЯЙ) {
/* 182 */     youcangetnoinfoBEJYИгАЯЙ = youcangetnoinfoBEJYИгАЯЙ.newBuilder().eventListener(EventListener1.NONE).protocols(ONLY_HTTP1).build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 188 */     Object youcangetnoinfoBEJZдК4ЯЮ = ((RealWebSocket5)super).originalRequest.newBuilder().header("Upgrade", "websocket").header("Connection", "Upgrade").header("Sec-WebSocket-Key", ((RealWebSocket5)super).key).header("Sec-WebSocket-Version", "13").build();
/* 189 */     ((RealWebSocket5)super).call = Internal.instance.newWebSocketCall((OkHttpClient)youcangetnoinfoBEJYИгАЯЙ, (Request)youcangetnoinfoBEJZдК4ЯЮ);
/* 190 */     ((RealWebSocket5)super).call.timeout().clearTimeout();
/* 191 */     ((RealWebSocket5)super).call.enqueue(new RealWebSocket2((RealWebSocket5)this, (Request)youcangetnoinfoBEJZдК4ЯЮ));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void checkResponse(Object youcangetnoinfoCNRBкДЖо8) throws ProtocolException {
/* 227 */     if (youcangetnoinfoCNRBкДЖо8.code() != 101) {
/* 228 */       throw new ProtocolException("Expected HTTP 101 response but was '" + youcangetnoinfoCNRBкДЖо8
/* 229 */           .code() + " " + youcangetnoinfoCNRBкДЖо8.message() + "'");
/*     */     }
/*     */     
/* 232 */     Object youcangetnoinfoCNRCМыА5п = youcangetnoinfoCNRBкДЖо8.header("Connection");
/* 233 */     if (!"Upgrade".equalsIgnoreCase((String)youcangetnoinfoCNRCМыА5п)) {
/* 234 */       throw new ProtocolException("Expected 'Connection' header value 'Upgrade' but was '" + youcangetnoinfoCNRCМыА5п + "'");
/*     */     }
/*     */ 
/*     */     
/* 238 */     Object youcangetnoinfoCNRD6ШЪщф = youcangetnoinfoCNRBкДЖо8.header("Upgrade");
/* 239 */     if (!"websocket".equalsIgnoreCase((String)youcangetnoinfoCNRD6ШЪщф)) {
/* 240 */       throw new ProtocolException("Expected 'Upgrade' header value 'websocket' but was '" + youcangetnoinfoCNRD6ШЪщф + "'");
/*     */     }
/*     */ 
/*     */     
/* 244 */     Object youcangetnoinfoCNREшьйб7 = youcangetnoinfoCNRBкДЖо8.header("Sec-WebSocket-Accept");
/*     */     
/* 246 */     Object youcangetnoinfoCNRFЕЫыРР = ByteString.encodeUtf8(((RealWebSocket5)super).key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").sha1().base64();
/* 247 */     if (!youcangetnoinfoCNRFЕЫыРР.equals(youcangetnoinfoCNREшьйб7)) {
/* 248 */       throw new ProtocolException("Expected 'Sec-WebSocket-Accept' header value '" + youcangetnoinfoCNRFЕЫыРР + "' but was '" + youcangetnoinfoCNREшьйб7 + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void initReaderAndWriter(Object youcangetnoinfoBOTWЬщ79ш, Object youcangetnoinfoBOTXеГбХД) throws IOException {
/* 254 */     synchronized (this) {
/* 255 */       ((RealWebSocket5)super).streams = (RealWebSocket3)youcangetnoinfoBOTXеГбХД;
/* 256 */       ((RealWebSocket5)super).writer = new WebSocketWriter(((RealWebSocket3)youcangetnoinfoBOTXеГбХД).client, ((RealWebSocket3)youcangetnoinfoBOTXеГбХД).sink, ((RealWebSocket5)super).random);
/* 257 */       ((RealWebSocket5)super).executor = new ScheduledThreadPoolExecutor(1, Util1.threadFactory((String)youcangetnoinfoBOTWЬщ79ш, false));
/* 258 */       if (((RealWebSocket5)super).pingIntervalMillis != 0L) {
/* 259 */         ((RealWebSocket5)super).executor.scheduleAtFixedRate(new RealWebSocket((RealWebSocket5)this), ((RealWebSocket5)super).pingIntervalMillis, ((RealWebSocket5)super).pingIntervalMillis, TimeUnit.MILLISECONDS);
/*     */       }
/*     */       
/* 262 */       if (!((RealWebSocket5)super).messageAndCloseQueue.isEmpty()) {
/* 263 */         super.runWriter();
/*     */       }
/*     */     } 
/*     */     
/* 267 */     ((RealWebSocket5)super).reader = new WebSocketReader(((RealWebSocket3)youcangetnoinfoBOTXеГбХД).client, ((RealWebSocket3)youcangetnoinfoBOTXеГбХД).source, (WebSocketReader1)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public void loopReader() throws IOException {
/* 272 */     while (((RealWebSocket5)super).receivedCloseCode == -1)
/*     */     {
/* 274 */       ((RealWebSocket5)super).reader.processNextFrame();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean processNextFrame() throws IOException {
/*     */     try {
/* 284 */       ((RealWebSocket5)super).reader.processNextFrame();
/* 285 */       return (((RealWebSocket5)super).receivedCloseCode == -1);
/* 286 */     } catch (Exception youcangetnoinfoBFSYЬяИшЮ) {
/* 287 */       super.failWebSocket((Exception)youcangetnoinfoBFSYЬяИшЮ, null);
/* 288 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void awaitTermination(Object youcangetnoinfoDWZOИЮЫэФ, Object youcangetnoinfoDWZPФ4ИБо) throws InterruptedException {
/* 296 */     ((RealWebSocket5)super).executor.awaitTermination(youcangetnoinfoDWZOИЮЫэФ, (TimeUnit)youcangetnoinfoDWZPФ4ИБо);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void tearDown() throws InterruptedException {
/* 303 */     if (((RealWebSocket5)super).cancelFuture != null) {
/* 304 */       ((RealWebSocket5)super).cancelFuture.cancel(false);
/*     */     }
/* 306 */     ((RealWebSocket5)super).executor.shutdown();
/* 307 */     ((RealWebSocket5)super).executor.awaitTermination(10L, TimeUnit.SECONDS);
/*     */   }
/*     */   
/*     */   public synchronized int sentPingCount() {
/* 311 */     return ((RealWebSocket5)super).sentPingCount;
/*     */   }
/*     */   
/*     */   public synchronized int receivedPingCount() {
/* 315 */     return ((RealWebSocket5)super).receivedPingCount;
/*     */   }
/*     */   
/*     */   public synchronized int receivedPongCount() {
/* 319 */     return ((RealWebSocket5)super).receivedPongCount;
/*     */   }
/*     */   
/*     */   public void onReadMessage(Object youcangetnoinfoDIMKЛщЩас) throws IOException {
/* 323 */     ((RealWebSocket5)super).listener.onMessage((WebSocket1)this, (String)youcangetnoinfoDIMKЛщЩас);
/*     */   }
/*     */   
/*     */   public void onReadMessage(Object youcangetnoinfoCVZUР48ЮО) throws IOException {
/* 327 */     ((RealWebSocket5)super).listener.onMessage((WebSocket1)this, (ByteString)youcangetnoinfoCVZUР48ЮО);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void onReadPing(Object youcangetnoinfoPAH7мФнЩ) {
/* 332 */     if (((RealWebSocket5)super).failed || (((RealWebSocket5)super).enqueuedClose && ((RealWebSocket5)super).messageAndCloseQueue.isEmpty()))
/*     */       return; 
/* 334 */     ((RealWebSocket5)super).pongQueue.add(youcangetnoinfoPAH7мФнЩ);
/* 335 */     super.runWriter();
/* 336 */     ((RealWebSocket5)super).receivedPingCount++;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void onReadPong(Object youcangetnoinfoAGZXиТПнр) {
/* 341 */     ((RealWebSocket5)super).receivedPongCount++;
/* 342 */     ((RealWebSocket5)super).awaitingPong = false;
/*     */   }
/*     */   
/*     */   public void onReadClose(Object youcangetnoinfoCZKPжЕаъд, Object youcangetnoinfoCZKQхДю4Ё) {
/* 346 */     if (youcangetnoinfoCZKPжЕаъд == -1) throw new IllegalArgumentException();
/*     */     
/* 348 */     Object youcangetnoinfoCZKRъЗЬОВ = null;
/* 349 */     synchronized (this) {
/* 350 */       if (((RealWebSocket5)super).receivedCloseCode != -1) throw new IllegalStateException("already closed"); 
/* 351 */       ((RealWebSocket5)super).receivedCloseCode = youcangetnoinfoCZKPжЕаъд;
/* 352 */       ((RealWebSocket5)super).receivedCloseReason = (String)youcangetnoinfoCZKQхДю4Ё;
/* 353 */       if (((RealWebSocket5)super).enqueuedClose && ((RealWebSocket5)super).messageAndCloseQueue.isEmpty()) {
/* 354 */         youcangetnoinfoCZKRъЗЬОВ = ((RealWebSocket5)super).streams;
/* 355 */         ((RealWebSocket5)super).streams = null;
/* 356 */         if (((RealWebSocket5)super).cancelFuture != null) ((RealWebSocket5)super).cancelFuture.cancel(false); 
/* 357 */         ((RealWebSocket5)super).executor.shutdown();
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 362 */       ((RealWebSocket5)super).listener.onClosing((WebSocket1)this, youcangetnoinfoCZKPжЕаъд, (String)youcangetnoinfoCZKQхДю4Ё);
/*     */       
/* 364 */       if (youcangetnoinfoCZKRъЗЬОВ != null) {
/* 365 */         ((RealWebSocket5)super).listener.onClosed((WebSocket1)this, youcangetnoinfoCZKPжЕаъд, (String)youcangetnoinfoCZKQхДю4Ё);
/*     */       }
/*     */     } finally {
/* 368 */       Util1.closeQuietly((Closeable)youcangetnoinfoCZKRъЗЬОВ);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean send(Object youcangetnoinfoCPJWщэХцф) {
/* 375 */     if (youcangetnoinfoCPJWщэХцф == null) throw new NullPointerException("text == null"); 
/* 376 */     return super.send(ByteString.encodeUtf8((String)youcangetnoinfoCPJWщэХцф), 1);
/*     */   }
/*     */   
/*     */   public boolean send(Object youcangetnoinfoBZOAДФ2Тц) {
/* 380 */     if (youcangetnoinfoBZOAДФ2Тц == null) throw new NullPointerException("bytes == null"); 
/* 381 */     return super.send((ByteString)youcangetnoinfoBZOAДФ2Тц, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean send(Object youcangetnoinfoMPRЪиыЪк, Object youcangetnoinfoMPSЕркЪж) {
/* 386 */     if (((RealWebSocket5)super).failed || ((RealWebSocket5)super).enqueuedClose) return false;
/*     */ 
/*     */     
/* 389 */     if (((RealWebSocket5)super).queueSize + youcangetnoinfoMPRЪиыЪк.size() > 16777216L) {
/* 390 */       super.close(1001, null);
/* 391 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 395 */     ((RealWebSocket5)super).queueSize += youcangetnoinfoMPRЪиыЪк.size();
/* 396 */     ((RealWebSocket5)super).messageAndCloseQueue.add(new RealWebSocket1(youcangetnoinfoMPSЕркЪж, (ByteString)youcangetnoinfoMPRЪиыЪк));
/* 397 */     super.runWriter();
/* 398 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized boolean pong(Object youcangetnoinfoCQFLкбрЧф) {
/* 403 */     if (((RealWebSocket5)super).failed || (((RealWebSocket5)super).enqueuedClose && ((RealWebSocket5)super).messageAndCloseQueue.isEmpty())) return false;
/*     */     
/* 405 */     ((RealWebSocket5)super).pongQueue.add(youcangetnoinfoCQFLкбрЧф);
/* 406 */     super.runWriter();
/* 407 */     return true;
/*     */   }
/*     */   
/*     */   public boolean close(Object youcangetnoinfoBPPAТёЯдБ, Object youcangetnoinfoBPPBНяzощ) {
/* 411 */     return super.close(youcangetnoinfoBPPAТёЯдБ, (String)youcangetnoinfoBPPBНяzощ, 60000L);
/*     */   }
/*     */   
/*     */   public synchronized boolean close(Object youcangetnoinfoAKELЯхЮх3, Object youcangetnoinfoAKEMГикНФ, Object youcangetnoinfoAKENВ4уСС) {
/* 415 */     WebSocketProtocol.validateCloseCode(youcangetnoinfoAKELЯхЮх3);
/*     */     
/* 417 */     Object youcangetnoinfoAKEOЭ9ВФИ = null;
/* 418 */     if (youcangetnoinfoAKEMГикНФ != null) {
/* 419 */       youcangetnoinfoAKEOЭ9ВФИ = ByteString.encodeUtf8((String)youcangetnoinfoAKEMГикНФ);
/* 420 */       if (youcangetnoinfoAKEOЭ9ВФИ.size() > 123L) {
/* 421 */         throw new IllegalArgumentException("reason.size() > 123: " + youcangetnoinfoAKEMГикНФ);
/*     */       }
/*     */     } 
/*     */     
/* 425 */     if (((RealWebSocket5)super).failed || ((RealWebSocket5)super).enqueuedClose) return false;
/*     */ 
/*     */     
/* 428 */     ((RealWebSocket5)super).enqueuedClose = true;
/*     */ 
/*     */     
/* 431 */     ((RealWebSocket5)super).messageAndCloseQueue.add(new RealWebSocket6(youcangetnoinfoAKELЯхЮх3, (ByteString)youcangetnoinfoAKEOЭ9ВФИ, youcangetnoinfoAKENВ4уСС));
/* 432 */     super.runWriter();
/* 433 */     return true;
/*     */   }
/*     */   
/*     */   public void runWriter() {
/* 437 */     assert Thread.holdsLock(this);
/*     */     
/* 439 */     if (((RealWebSocket5)super).executor != null) {
/* 440 */       ((RealWebSocket5)super).executor.execute(((RealWebSocket5)super).writerRunnable);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean writeOneFrame() throws IOException {
/* 460 */     Object youcangetnoinfoALJNГЪьУа, youcangetnoinfoALJOдлЫЫМ, youcangetnoinfoALJVвдЭмз = null;
/* 461 */     int i = -1;
/* 462 */     Object youcangetnoinfoALJXнчгАЗ = null;
/* 463 */     Object youcangetnoinfoALJYСЮнАм = null;
/*     */     
/* 465 */     synchronized (this) {
/* 466 */       if (((RealWebSocket5)super).failed) {
/* 467 */         return false;
/*     */       }
/*     */       
/* 470 */       youcangetnoinfoALJNГЪьУа = ((RealWebSocket5)super).writer;
/* 471 */       youcangetnoinfoALJOдлЫЫМ = ((RealWebSocket5)super).pongQueue.poll();
/* 472 */       if (youcangetnoinfoALJOдлЫЫМ == null) {
/* 473 */         youcangetnoinfoALJVвдЭмз = ((RealWebSocket5)super).messageAndCloseQueue.poll();
/* 474 */         if (youcangetnoinfoALJVвдЭмз instanceof RealWebSocket6) {
/* 475 */           i = ((RealWebSocket5)super).receivedCloseCode;
/* 476 */           youcangetnoinfoALJXнчгАЗ = ((RealWebSocket5)super).receivedCloseReason;
/* 477 */           if (i != -1) {
/* 478 */             youcangetnoinfoALJYСЮнАм = ((RealWebSocket5)super).streams;
/* 479 */             ((RealWebSocket5)super).streams = null;
/* 480 */             ((RealWebSocket5)super).executor.shutdown();
/*     */           } else {
/*     */             
/* 483 */             ((RealWebSocket5)super).cancelFuture = ((RealWebSocket5)super).executor.schedule(new RealWebSocket4((RealWebSocket5)this), ((RealWebSocket6)youcangetnoinfoALJVвдЭмз).cancelAfterCloseMillis, TimeUnit.MILLISECONDS);
/*     */           }
/*     */         
/* 486 */         } else if (youcangetnoinfoALJVвдЭмз == null) {
/* 487 */           return false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*     */     try {
/* 493 */       if (youcangetnoinfoALJOдлЫЫМ != null) {
/* 494 */         youcangetnoinfoALJNГЪьУа.writePong((ByteString)youcangetnoinfoALJOдлЫЫМ);
/*     */       }
/* 496 */       else if (youcangetnoinfoALJVвдЭмз instanceof RealWebSocket1) {
/* 497 */         Object youcangetnoinfoALJPzИ89я = ((RealWebSocket1)youcangetnoinfoALJVвдЭмз).data;
/* 498 */         Object youcangetnoinfoALJQСЖВ35 = Okio1.buffer(youcangetnoinfoALJNГЪьУа.newMessageSink(((RealWebSocket1)youcangetnoinfoALJVвдЭмз).formatOpcode, youcangetnoinfoALJPzИ89я
/* 499 */               .size()));
/* 500 */         youcangetnoinfoALJQСЖВ35.write((ByteString)youcangetnoinfoALJPzИ89я);
/* 501 */         youcangetnoinfoALJQСЖВ35.close();
/* 502 */         synchronized (this) {
/* 503 */           ((RealWebSocket5)super).queueSize -= youcangetnoinfoALJPzИ89я.size();
/*     */         }
/*     */       
/* 506 */       } else if (youcangetnoinfoALJVвдЭмз instanceof RealWebSocket6) {
/* 507 */         Object youcangetnoinfoALJRНоЮъП = youcangetnoinfoALJVвдЭмз;
/* 508 */         youcangetnoinfoALJNГЪьУа.writeClose(((RealWebSocket6)youcangetnoinfoALJRНоЮъП).code, ((RealWebSocket6)youcangetnoinfoALJRНоЮъП).reason);
/*     */ 
/*     */         
/* 511 */         if (youcangetnoinfoALJYСЮнАм != null) {
/* 512 */           ((RealWebSocket5)super).listener.onClosed((WebSocket1)this, i, (String)youcangetnoinfoALJXнчгАЗ);
/*     */         }
/*     */       } else {
/*     */         
/* 516 */         throw new AssertionError();
/*     */       } 
/*     */       
/* 519 */       return true;
/*     */     } finally {
/* 521 */       Util1.closeQuietly((Closeable)youcangetnoinfoALJYСЮнАм);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writePingFrame() {
/*     */     Object youcangetnoinfoRXFпНе5Щ;
/*     */     byte b;
/* 537 */     synchronized (this) {
/* 538 */       if (((RealWebSocket5)super).failed)
/* 539 */         return;  youcangetnoinfoRXFпНе5Щ = ((RealWebSocket5)super).writer;
/* 540 */       b = ((RealWebSocket5)super).awaitingPong ? ((RealWebSocket5)super).sentPingCount : -1;
/* 541 */       ((RealWebSocket5)super).sentPingCount++;
/* 542 */       ((RealWebSocket5)super).awaitingPong = true;
/*     */     } 
/*     */     
/* 545 */     if (b != -1) {
/* 546 */       super.failWebSocket(new SocketTimeoutException("sent ping but didn't receive pong within " + ((RealWebSocket5)super).pingIntervalMillis + "ms (after " + (b - 1) + " successful ping/pongs)"), null);
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*     */     try {
/* 553 */       youcangetnoinfoRXFпНе5Щ.writePing(ByteString.EMPTY);
/* 554 */     } catch (IOException youcangetnoinfoRXHлЙУБХ) {
/* 555 */       super.failWebSocket((Exception)youcangetnoinfoRXHлЙУБХ, null);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void failWebSocket(Object youcangetnoinfoDXEIЁ0ДДю, @Nullable Object youcangetnoinfoDXEJЬ68ФЛ) {
/*     */     Object youcangetnoinfoDXEGщыУэД;
/* 561 */     synchronized (this) {
/* 562 */       if (((RealWebSocket5)super).failed)
/* 563 */         return;  ((RealWebSocket5)super).failed = true;
/* 564 */       youcangetnoinfoDXEGщыУэД = ((RealWebSocket5)super).streams;
/* 565 */       ((RealWebSocket5)super).streams = null;
/* 566 */       if (((RealWebSocket5)super).cancelFuture != null) ((RealWebSocket5)super).cancelFuture.cancel(false); 
/* 567 */       if (((RealWebSocket5)super).executor != null) ((RealWebSocket5)super).executor.shutdown();
/*     */     
/*     */     } 
/*     */     try {
/* 571 */       ((RealWebSocket5)super).listener.onFailure((WebSocket1)this, (Throwable)youcangetnoinfoDXEIЁ0ДДю, (Response)youcangetnoinfoDXEJЬ68ФЛ);
/*     */     } finally {
/* 573 */       Util1.closeQuietly((Closeable)youcangetnoinfoDXEGщыУэД);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RealWebSocket5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */