/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Header
/*    */ {
/*    */   public static final String TARGET_METHOD_UTF8 = ":method";
/*    */   public static final ByteString RESPONSE_STATUS;
/*    */   public final ByteString value;
/*    */   public final ByteString name;
/*    */   public static final String TARGET_PATH_UTF8 = ":path";
/*    */   public static final String RESPONSE_STATUS_UTF8 = ":status";
/*    */   public static final String TARGET_AUTHORITY_UTF8 = ":authority";
/* 24 */   public static final ByteString PSEUDO_PREFIX = ByteString.encodeUtf8(":");
/*    */   
/*    */   public static final ByteString TARGET_PATH;
/*    */   
/*    */   public static final ByteString TARGET_AUTHORITY;
/*    */   public static final ByteString TARGET_METHOD;
/*    */   
/*    */   static {
/* 32 */     RESPONSE_STATUS = ByteString.encodeUtf8(":status");
/* 33 */     TARGET_METHOD = ByteString.encodeUtf8(":method");
/* 34 */     TARGET_PATH = ByteString.encodeUtf8(":path");
/* 35 */     TARGET_SCHEME = ByteString.encodeUtf8(":scheme");
/* 36 */     TARGET_AUTHORITY = ByteString.encodeUtf8(":authority");
/*    */   }
/*    */ 
/*    */   
/*    */   public final int hpackSize;
/*    */   
/*    */   public static final ByteString TARGET_SCHEME;
/*    */   
/*    */   public static final String TARGET_SCHEME_UTF8 = ":scheme";
/*    */   
/*    */   public Header(Object youcangetnoinfoAKVD3СкЫГ, Object youcangetnoinfoAKVEЫЭьЖИ) {
/* 47 */     super(ByteString.encodeUtf8((String)youcangetnoinfoAKVD3СкЫГ), ByteString.encodeUtf8((String)youcangetnoinfoAKVEЫЭьЖИ));
/*    */   }
/*    */   
/*    */   public Header(Object youcangetnoinfoDHDQР6Зжш, Object youcangetnoinfoDHDRмХД5в) {
/* 51 */     super((ByteString)youcangetnoinfoDHDQР6Зжш, ByteString.encodeUtf8((String)youcangetnoinfoDHDRмХД5в));
/*    */   }
/*    */   public Header(Object youcangetnoinfoAWFD61ЛмЦ, Object youcangetnoinfoAWFEъЦШэщ) {
/* 54 */     this();
/* 55 */     ((Header)super).name = (ByteString)youcangetnoinfoAWFD61ЛмЦ;
/* 56 */     ((Header)super).value = (ByteString)youcangetnoinfoAWFEъЦШэщ;
/* 57 */     ((Header)super).hpackSize = 32 + youcangetnoinfoAWFD61ЛмЦ.size() + youcangetnoinfoAWFEъЦШэщ.size();
/*    */   }
/*    */   
/*    */   public boolean equals(Object youcangetnoinfoELRK9вмБщ) {
/* 61 */     if (youcangetnoinfoELRK9вмБщ instanceof Header) {
/* 62 */       Object youcangetnoinfoELRIрсВЦм = youcangetnoinfoELRK9вмБщ;
/* 63 */       return (((Header)super).name.equals(((Header)youcangetnoinfoELRIрсВЦм).name) && ((Header)super).value
/* 64 */         .equals(((Header)youcangetnoinfoELRIрсВЦм).value));
/*    */     } 
/* 66 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 70 */     int i = 17;
/* 71 */     i = 31 * i + ((Header)super).name.hashCode();
/* 72 */     i = 31 * i + ((Header)super).value.hashCode();
/* 73 */     return i;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 77 */     return Util1.format("%s: %s", new Object[] { ((Header)super).name.utf8(), ((Header)super).value.utf8() });
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Header.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */