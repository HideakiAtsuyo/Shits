/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Segment
/*     */ {
/*     */   public Segment next;
/*     */   public int limit;
/*     */   public final byte[] data;
/*     */   public static final int SHARE_MINIMUM = 1024;
/*     */   public Segment prev;
/*     */   public boolean owner;
/*     */   public static final int SIZE = 8192;
/*     */   public boolean shared;
/*     */   public int pos;
/*     */   
/*     */   public Segment() {
/*  62 */     this();
/*  63 */     ((Segment)super).data = new byte[8192];
/*  64 */     ((Segment)super).owner = true;
/*  65 */     ((Segment)super).shared = false;
/*     */   }
/*     */   public Segment(Object youcangetnoinfoAUYSугйтЁ, Object youcangetnoinfoAUYTшю2zБ, Object youcangetnoinfoAUYUх3иих, Object youcangetnoinfoAUYVЖНфЭЙ, Object youcangetnoinfoAUYWЩzЭЬТ) {
/*  68 */     this();
/*  69 */     ((Segment)super).data = (byte[])youcangetnoinfoAUYSугйтЁ;
/*  70 */     ((Segment)super).pos = youcangetnoinfoAUYTшю2zБ;
/*  71 */     ((Segment)super).limit = youcangetnoinfoAUYUх3иих;
/*  72 */     ((Segment)super).shared = youcangetnoinfoAUYVЖНфЭЙ;
/*  73 */     ((Segment)super).owner = youcangetnoinfoAUYWЩzЭЬТ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Segment sharedCopy() {
/*  82 */     ((Segment)super).shared = true;
/*  83 */     return new Segment(((Segment)super).data, ((Segment)super).pos, ((Segment)super).limit, true, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public final Segment unsharedCopy() {
/*  88 */     return new Segment((byte[])((Segment)super).data.clone(), ((Segment)super).pos, ((Segment)super).limit, false, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final Segment pop() {
/*  96 */     Object youcangetnoinfoCBLMцшЕ57 = (((Segment)super).next != this) ? ((Segment)super).next : null;
/*  97 */     ((Segment)super).prev.next = ((Segment)super).next;
/*  98 */     ((Segment)super).next.prev = ((Segment)super).prev;
/*  99 */     ((Segment)super).next = null;
/* 100 */     ((Segment)super).prev = null;
/* 101 */     return (Segment)youcangetnoinfoCBLMцшЕ57;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Segment push(Object youcangetnoinfoBFNOzЕГТъ) {
/* 109 */     ((Segment)youcangetnoinfoBFNOzЕГТъ).prev = (Segment)this;
/* 110 */     ((Segment)youcangetnoinfoBFNOzЕГТъ).next = ((Segment)super).next;
/* 111 */     ((Segment)super).next.prev = (Segment)youcangetnoinfoBFNOzЕГТъ;
/* 112 */     ((Segment)super).next = (Segment)youcangetnoinfoBFNOzЕГТъ;
/* 113 */     return (Segment)youcangetnoinfoBFNOzЕГТъ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Segment split(Object youcangetnoinfoAKXIмю5ЛЧ) {
/*     */     Object youcangetnoinfoAKXJуУЛЬ6;
/* 125 */     if (youcangetnoinfoAKXIмю5ЛЧ <= null || youcangetnoinfoAKXIмю5ЛЧ > ((Segment)super).limit - ((Segment)super).pos) throw new IllegalArgumentException();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 133 */     if (youcangetnoinfoAKXIмю5ЛЧ >= 'Ѐ') {
/* 134 */       Object youcangetnoinfoAKXGЖВЪпо = super.sharedCopy();
/*     */     } else {
/* 136 */       youcangetnoinfoAKXJуУЛЬ6 = SegmentPool.take();
/* 137 */       System.arraycopy(((Segment)super).data, ((Segment)super).pos, ((Segment)youcangetnoinfoAKXJуУЛЬ6).data, 0, youcangetnoinfoAKXIмю5ЛЧ);
/*     */     } 
/*     */     
/* 140 */     ((Segment)youcangetnoinfoAKXJуУЛЬ6).limit = ((Segment)youcangetnoinfoAKXJуУЛЬ6).pos + youcangetnoinfoAKXIмю5ЛЧ;
/* 141 */     ((Segment)super).pos += youcangetnoinfoAKXIмю5ЛЧ;
/* 142 */     ((Segment)super).prev.push((Segment)youcangetnoinfoAKXJуУЛЬ6);
/* 143 */     return (Segment)youcangetnoinfoAKXJуУЛЬ6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void compact() {
/* 151 */     if (((Segment)super).prev == this) throw new IllegalStateException(); 
/* 152 */     if (!((Segment)super).prev.owner)
/* 153 */       return;  int i = ((Segment)super).limit - ((Segment)super).pos;
/* 154 */     int j = 8192 - ((Segment)super).prev.limit + (((Segment)super).prev.shared ? 0 : ((Segment)super).prev.pos);
/* 155 */     if (i > j)
/* 156 */       return;  super.writeTo(((Segment)super).prev, i);
/* 157 */     super.pop();
/* 158 */     SegmentPool.recycle((Segment)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public final void writeTo(Object youcangetnoinfoLNHунЧ9Щ, Object youcangetnoinfoLNIzэщБф) {
/* 163 */     if (!((Segment)youcangetnoinfoLNHунЧ9Щ).owner) throw new IllegalArgumentException(); 
/* 164 */     if (((Segment)youcangetnoinfoLNHунЧ9Щ).limit + youcangetnoinfoLNIzэщБф > 8192) {
/*     */       
/* 166 */       if (((Segment)youcangetnoinfoLNHунЧ9Щ).shared) throw new IllegalArgumentException(); 
/* 167 */       if (((Segment)youcangetnoinfoLNHунЧ9Щ).limit + youcangetnoinfoLNIzэщБф - ((Segment)youcangetnoinfoLNHунЧ9Щ).pos > 8192) throw new IllegalArgumentException(); 
/* 168 */       System.arraycopy(((Segment)youcangetnoinfoLNHунЧ9Щ).data, ((Segment)youcangetnoinfoLNHунЧ9Щ).pos, ((Segment)youcangetnoinfoLNHунЧ9Щ).data, 0, ((Segment)youcangetnoinfoLNHунЧ9Щ).limit - ((Segment)youcangetnoinfoLNHунЧ9Щ).pos);
/* 169 */       ((Segment)youcangetnoinfoLNHунЧ9Щ).limit -= ((Segment)youcangetnoinfoLNHунЧ9Щ).pos;
/* 170 */       ((Segment)youcangetnoinfoLNHунЧ9Щ).pos = 0;
/*     */     } 
/*     */     
/* 173 */     System.arraycopy(((Segment)super).data, ((Segment)super).pos, ((Segment)youcangetnoinfoLNHунЧ9Щ).data, ((Segment)youcangetnoinfoLNHунЧ9Щ).limit, youcangetnoinfoLNIzэщБф);
/* 174 */     ((Segment)youcangetnoinfoLNHунЧ9Щ).limit += youcangetnoinfoLNIzэщБф;
/* 175 */     ((Segment)super).pos += youcangetnoinfoLNIzэщБф;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Segment.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */