/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ReactionSpammer1
/*     */   extends Thread
/*     */ {
/*     */   public final ReactionSpammer2 this$2;
/*     */   public final Map.Entry val$token;
/*     */   
/*     */   public void run() {
/* 156 */     boolean bool = true;
/* 157 */     while (bool) {
/*     */       try {
/* 159 */         Object youcangetnoinfoDQSC7ЪоИН = SpamUtils.getRandomProxy();
/* 160 */         Object youcangetnoinfoDQSDЫиКр4 = SpamUtils.removeReaction(reactChannelField.getText(), reactMessageField
/* 161 */             .getText(), reactEmojiField.getText(), token
/* 162 */             .getValue().toString(), (String)youcangetnoinfoDQSC7ЪоИН);
/* 163 */         if (youcangetnoinfoDQSDЫиКр4 == null) {
/* 164 */           ConsoleGUI.log(youcangetnoinfoDQSC7ЪоИН + "-> Token(" + token
/* 165 */               .getKey() + ")-> Reaction removed");
/* 166 */           bool = false; continue;
/* 167 */         }  if (youcangetnoinfoDQSDЫиКр4.startsWith("<")) {
/* 168 */           ConsoleGUI.log(youcangetnoinfoDQSC7ЪоИН + "-> Token(" + token.getKey() + ")-> Proxy failed. Retrying");
/*     */           continue;
/*     */         } 
/* 171 */         ConsoleGUI.log(youcangetnoinfoDQSC7ЪоИН + "-> Token(" + token.getKey() + ")-> Unknown error: " + youcangetnoinfoDQSDЫиКр4);
/*     */         
/* 173 */         bool = false;
/*     */       }
/* 175 */       catch (IOException youcangetnoinfoDQSE9Хлтн) {
/* 176 */         youcangetnoinfoDQSE9Хлтн.printStackTrace();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ReactionSpammer1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */