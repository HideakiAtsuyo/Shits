/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SegmentedByteString
/*     */   extends ByteString
/*     */ {
/*     */   public final transient int[] directory;
/*     */   public final transient byte[][] segments;
/*     */   
/*     */   public SegmentedByteString(Object youcangetnoinfoBOUSфъШЪЯ, Object youcangetnoinfoBOUTбВ4Оч) {
/*  57 */     super(null);
/*  58 */     Util.checkOffsetAndCount(((Buffer2)youcangetnoinfoBOUSфъШЪЯ).size, 0L, youcangetnoinfoBOUTбВ4Оч);
/*     */ 
/*     */     
/*  61 */     int i = 0;
/*  62 */     byte b = 0;
/*  63 */     for (Object youcangetnoinfoBOUPбчтМЕ = ((Buffer2)youcangetnoinfoBOUSфъШЪЯ).head; i < youcangetnoinfoBOUTбВ4Оч; youcangetnoinfoBOUPбчтМЕ = ((Segment)youcangetnoinfoBOUPбчтМЕ).next) {
/*  64 */       if (((Segment)youcangetnoinfoBOUPбчтМЕ).limit == ((Segment)youcangetnoinfoBOUPбчтМЕ).pos) {
/*  65 */         throw new AssertionError("s.limit == s.pos");
/*     */       }
/*  67 */       i += ((Segment)youcangetnoinfoBOUPбчтМЕ).limit - ((Segment)youcangetnoinfoBOUPбчтМЕ).pos;
/*  68 */       b++;
/*     */     } 
/*     */ 
/*     */     
/*  72 */     ((SegmentedByteString)super).segments = new byte[b][];
/*  73 */     ((SegmentedByteString)super).directory = new int[b * 2];
/*  74 */     i = 0;
/*  75 */     b = 0;
/*  76 */     for (Object youcangetnoinfoBOUQОаКф6 = ((Buffer2)youcangetnoinfoBOUSфъШЪЯ).head; i < youcangetnoinfoBOUTбВ4Оч; youcangetnoinfoBOUQОаКф6 = ((Segment)youcangetnoinfoBOUQОаКф6).next) {
/*  77 */       Object object; ((SegmentedByteString)super).segments[b] = ((Segment)youcangetnoinfoBOUQОаКф6).data;
/*  78 */       i += ((Segment)youcangetnoinfoBOUQОаКф6).limit - ((Segment)youcangetnoinfoBOUQОаКф6).pos;
/*  79 */       if (i > youcangetnoinfoBOUTбВ4Оч) {
/*  80 */         object = youcangetnoinfoBOUTбВ4Оч;
/*     */       }
/*  82 */       ((SegmentedByteString)super).directory[b] = object;
/*  83 */       ((SegmentedByteString)super).directory[b + ((SegmentedByteString)super).segments.length] = ((Segment)youcangetnoinfoBOUQОаКф6).pos;
/*  84 */       ((Segment)youcangetnoinfoBOUQОаКф6).shared = true;
/*  85 */       b++;
/*     */     } 
/*     */   }
/*     */   
/*     */   public String utf8() {
/*  90 */     return super.toByteString().utf8();
/*     */   }
/*     */   
/*     */   public String string(Object youcangetnoinfoEBJFЬЩэпН) {
/*  94 */     return super.toByteString().string((Charset)youcangetnoinfoEBJFЬЩэпН);
/*     */   }
/*     */   
/*     */   public String base64() {
/*  98 */     return super.toByteString().base64();
/*     */   }
/*     */   
/*     */   public String hex() {
/* 102 */     return super.toByteString().hex();
/*     */   }
/*     */   
/*     */   public ByteString toAsciiLowercase() {
/* 106 */     return super.toByteString().toAsciiLowercase();
/*     */   }
/*     */   
/*     */   public ByteString toAsciiUppercase() {
/* 110 */     return super.toByteString().toAsciiUppercase();
/*     */   }
/*     */   
/*     */   public ByteString md5() {
/* 114 */     return super.toByteString().md5();
/*     */   }
/*     */   
/*     */   public ByteString sha1() {
/* 118 */     return super.toByteString().sha1();
/*     */   }
/*     */   
/*     */   public ByteString sha256() {
/* 122 */     return super.toByteString().sha256();
/*     */   }
/*     */   
/*     */   public ByteString hmacSha1(Object youcangetnoinfoBXOIФщчЦТ) {
/* 126 */     return super.toByteString().hmacSha1((ByteString)youcangetnoinfoBXOIФщчЦТ);
/*     */   }
/*     */   
/*     */   public ByteString hmacSha256(Object youcangetnoinfoDIKLПбЗмХ) {
/* 130 */     return super.toByteString().hmacSha256((ByteString)youcangetnoinfoDIKLПбЗмХ);
/*     */   }
/*     */   
/*     */   public String base64Url() {
/* 134 */     return super.toByteString().base64Url();
/*     */   }
/*     */   
/*     */   public ByteString substring(Object youcangetnoinfoQGQСНДту) {
/* 138 */     return super.toByteString().substring(youcangetnoinfoQGQСНДту);
/*     */   }
/*     */   
/*     */   public ByteString substring(Object youcangetnoinfoKRXЯДъпЮ, Object youcangetnoinfoKRY6АЁЯи) {
/* 142 */     return super.toByteString().substring(youcangetnoinfoKRXЯДъпЮ, youcangetnoinfoKRY6АЁЯи);
/*     */   }
/*     */   
/*     */   public byte getByte(Object youcangetnoinfoDFTVФФЩГИ) {
/* 146 */     Util.checkOffsetAndCount(((SegmentedByteString)super).directory[((SegmentedByteString)super).segments.length - 1], youcangetnoinfoDFTVФФЩГИ, 1L);
/* 147 */     int i = super.segment(youcangetnoinfoDFTVФФЩГИ);
/* 148 */     byte b = (i == 0) ? 0 : ((SegmentedByteString)super).directory[i - 1];
/* 149 */     int j = ((SegmentedByteString)super).directory[i + ((SegmentedByteString)super).segments.length];
/* 150 */     return ((SegmentedByteString)super).segments[i][youcangetnoinfoDFTVФФЩГИ - b + j];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int segment(Object youcangetnoinfoBSPJПхэТИ) {
/* 156 */     int i = Arrays.binarySearch(((SegmentedByteString)super).directory, 0, ((SegmentedByteString)super).segments.length, youcangetnoinfoBSPJПхэТИ + 1);
/* 157 */     return (i >= 0) ? i : (i ^ 0xFFFFFFFF);
/*     */   }
/*     */   
/*     */   public int size() {
/* 161 */     return ((SegmentedByteString)super).directory[((SegmentedByteString)super).segments.length - 1];
/*     */   }
/*     */   
/*     */   public byte[] toByteArray() {
/* 165 */     Object youcangetnoinfoBFEIПТфЁ9 = new byte[((SegmentedByteString)super).directory[((SegmentedByteString)super).segments.length - 1]];
/* 166 */     int i = 0; byte b; int j;
/* 167 */     for (b = 0, j = ((SegmentedByteString)super).segments.length; b < j; b++) {
/* 168 */       int k = ((SegmentedByteString)super).directory[j + b];
/* 169 */       int m = ((SegmentedByteString)super).directory[b];
/* 170 */       System.arraycopy(((SegmentedByteString)super).segments[b], k, youcangetnoinfoBFEIПТфЁ9, i, m - i);
/*     */       
/* 172 */       i = m;
/*     */     } 
/* 174 */     return (byte[])youcangetnoinfoBFEIПТфЁ9;
/*     */   }
/*     */   
/*     */   public ByteBuffer asByteBuffer() {
/* 178 */     return ByteBuffer.wrap(super.toByteArray()).asReadOnlyBuffer();
/*     */   }
/*     */   
/*     */   public void write(Object youcangetnoinfoBHKAЧсХту) throws IOException {
/* 182 */     if (youcangetnoinfoBHKAЧсХту == null) throw new IllegalArgumentException("out == null"); 
/* 183 */     int i = 0; byte b; int j;
/* 184 */     for (b = 0, j = ((SegmentedByteString)super).segments.length; b < j; b++) {
/* 185 */       int k = ((SegmentedByteString)super).directory[j + b];
/* 186 */       int m = ((SegmentedByteString)super).directory[b];
/* 187 */       youcangetnoinfoBHKAЧсХту.write(((SegmentedByteString)super).segments[b], k, m - i);
/* 188 */       i = m;
/*     */     } 
/*     */   }
/*     */   
/*     */   public void write(Object youcangetnoinfoAIAB1Тр2ю) {
/* 193 */     int i = 0; byte b; int j;
/* 194 */     for (b = 0, j = ((SegmentedByteString)super).segments.length; b < j; b++) {
/* 195 */       int k = ((SegmentedByteString)super).directory[j + b];
/* 196 */       int m = ((SegmentedByteString)super).directory[b];
/* 197 */       Object youcangetnoinfoAHZXиЬж5Т = new Segment(((SegmentedByteString)super).segments[b], k, k + m - i, true, false);
/*     */       
/* 199 */       if (((Buffer2)youcangetnoinfoAIAB1Тр2ю).head == null) {
/* 200 */         ((Buffer2)youcangetnoinfoAIAB1Тр2ю).head = ((Segment)youcangetnoinfoAHZXиЬж5Т).next = ((Segment)youcangetnoinfoAHZXиЬж5Т).prev = (Segment)youcangetnoinfoAHZXиЬж5Т;
/*     */       } else {
/* 202 */         ((Buffer2)youcangetnoinfoAIAB1Тр2ю).head.prev.push((Segment)youcangetnoinfoAHZXиЬж5Т);
/*     */       } 
/* 204 */       i = m;
/*     */     } 
/* 206 */     ((Buffer2)youcangetnoinfoAIAB1Тр2ю).size += i;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean rangeEquals(Object youcangetnoinfoDIRUй3фЯэ, Object youcangetnoinfoDIRVЁсесБ, Object youcangetnoinfoDIRWЫосСд, Object youcangetnoinfoDIRX3вЗХ2) {
/* 211 */     if (youcangetnoinfoDIRUй3фЯэ < null || youcangetnoinfoDIRUй3фЯэ > super.size() - youcangetnoinfoDIRX3вЗХ2) return false;
/*     */     
/* 213 */     for (int i = super.segment(youcangetnoinfoDIRUй3фЯэ); youcangetnoinfoDIRX3вЗХ2 > null; i++) {
/* 214 */       byte b = (i == 0) ? 0 : ((SegmentedByteString)super).directory[i - 1];
/* 215 */       int n = ((SegmentedByteString)super).directory[i] - b;
/* 216 */       int i1 = Math.min(youcangetnoinfoDIRX3вЗХ2, b + n - youcangetnoinfoDIRUй3фЯэ);
/* 217 */       int i2 = ((SegmentedByteString)super).directory[((SegmentedByteString)super).segments.length + i];
/* 218 */       int i3 = youcangetnoinfoDIRUй3фЯэ - b + i2;
/* 219 */       if (!youcangetnoinfoDIRVЁсесБ.rangeEquals(youcangetnoinfoDIRWЫосСд, ((SegmentedByteString)super).segments[i], i3, i1)) return false; 
/* 220 */       int j = youcangetnoinfoDIRUй3фЯэ + i1;
/* 221 */       int k = youcangetnoinfoDIRWЫосСд + i1;
/* 222 */       int m = youcangetnoinfoDIRX3вЗХ2 - i1;
/*     */     } 
/* 224 */     return true;
/*     */   }
/*     */   
/*     */   public boolean rangeEquals(Object youcangetnoinfoDXGWЪУ9аЦ, Object youcangetnoinfoDXGXпф0Й0, Object youcangetnoinfoDXGYд5ъАЖ, Object youcangetnoinfoDXGZыЙЁЮы) {
/* 228 */     if (youcangetnoinfoDXGWЪУ9аЦ < null || youcangetnoinfoDXGWЪУ9аЦ > super.size() - youcangetnoinfoDXGZыЙЁЮы || youcangetnoinfoDXGYд5ъАЖ < null || youcangetnoinfoDXGYд5ъАЖ > youcangetnoinfoDXGXпф0Й0.length - youcangetnoinfoDXGZыЙЁЮы)
/*     */     {
/* 230 */       return false;
/*     */     }
/*     */     
/* 233 */     for (int i = super.segment(youcangetnoinfoDXGWЪУ9аЦ); youcangetnoinfoDXGZыЙЁЮы > null; i++) {
/* 234 */       byte b = (i == 0) ? 0 : ((SegmentedByteString)super).directory[i - 1];
/* 235 */       int n = ((SegmentedByteString)super).directory[i] - b;
/* 236 */       int i1 = Math.min(youcangetnoinfoDXGZыЙЁЮы, b + n - youcangetnoinfoDXGWЪУ9аЦ);
/* 237 */       int i2 = ((SegmentedByteString)super).directory[((SegmentedByteString)super).segments.length + i];
/* 238 */       int i3 = youcangetnoinfoDXGWЪУ9аЦ - b + i2;
/* 239 */       if (!Util.arrayRangeEquals(((SegmentedByteString)super).segments[i], i3, (byte[])youcangetnoinfoDXGXпф0Й0, youcangetnoinfoDXGYд5ъАЖ, i1)) return false; 
/* 240 */       int j = youcangetnoinfoDXGWЪУ9аЦ + i1;
/* 241 */       int k = youcangetnoinfoDXGYд5ъАЖ + i1;
/* 242 */       int m = youcangetnoinfoDXGZыЙЁЮы - i1;
/*     */     } 
/* 244 */     return true;
/*     */   }
/*     */   
/*     */   public int indexOf(Object youcangetnoinfoGLQ7ЧzЙЛ, Object youcangetnoinfoGLRЦРЗыШ) {
/* 248 */     return super.toByteString().indexOf((byte[])youcangetnoinfoGLQ7ЧzЙЛ, youcangetnoinfoGLRЦРЗыШ);
/*     */   }
/*     */   
/*     */   public int lastIndexOf(Object youcangetnoinfoBFPMи6Гхк, Object youcangetnoinfoBFPNЩ7бЛЗ) {
/* 252 */     return super.toByteString().lastIndexOf((byte[])youcangetnoinfoBFPMи6Гхк, youcangetnoinfoBFPNЩ7бЛЗ);
/*     */   }
/*     */ 
/*     */   
/*     */   public ByteString toByteString() {
/* 257 */     return new ByteString(super.toByteArray());
/*     */   }
/*     */   
/*     */   public byte[] internalArray() {
/* 261 */     return super.toByteArray();
/*     */   }
/*     */   
/*     */   public boolean equals(Object youcangetnoinfoBOPRЯРтА6) {
/* 265 */     if (youcangetnoinfoBOPRЯРтА6 == this) return true; 
/* 266 */     return (youcangetnoinfoBOPRЯРтА6 instanceof ByteString && ((ByteString)youcangetnoinfoBOPRЯРтА6)
/* 267 */       .size() == super.size() && super
/* 268 */       .rangeEquals(0, (ByteString)youcangetnoinfoBOPRЯРтА6, 0, super.size()));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 272 */     int i = ((SegmentedByteString)this).hashCode;
/* 273 */     if (i != 0) return i;
/*     */ 
/*     */     
/* 276 */     i = 1;
/* 277 */     int j = 0; byte b; int k;
/* 278 */     for (b = 0, k = ((SegmentedByteString)super).segments.length; b < k; b++) {
/* 279 */       Object youcangetnoinfoBJLUырЙ6С = ((SegmentedByteString)super).segments[b];
/* 280 */       int m = ((SegmentedByteString)super).directory[k + b];
/* 281 */       int n = ((SegmentedByteString)super).directory[b];
/* 282 */       int i1 = n - j;
/* 283 */       for (int i2 = m, i3 = m + i1; i2 < i3; i2++) {
/* 284 */         i = 31 * i + youcangetnoinfoBJLUырЙ6С[i2];
/*     */       }
/* 286 */       j = n;
/*     */     } 
/* 288 */     return ((SegmentedByteString)this).hashCode = i;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 292 */     return super.toByteString().toString();
/*     */   }
/*     */   
/*     */   public Object writeReplace() {
/* 296 */     return super.toByteString();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\SegmentedByteString.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */