/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import fun.spamis.spammer.SpamIsFun;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.swing.JOptionPane;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.client.entity.UrlEncodedFormEntity;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.impl.client.HttpClients;
/*     */ import org.apache.http.message.BasicNameValuePair;
/*     */ import org.apache.http.util.EntityUtils;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LoginGUI
/*     */   extends Thread
/*     */ {
/*     */   public final LoginGUI2 this$1;
/*     */   
/*     */   public void run() {
/* 112 */     loginBtn.setEnabled(false);
/*     */     try {
/* 114 */       Object youcangetnoinfoCBYKЭя8за = new HttpPost("https://pastebin.com/raw/9XQmuSLp");
/* 115 */       Object youcangetnoinfoCBYLГлоЗЪ = HttpClients.createDefault();
/* 116 */       Object youcangetnoinfoCBYMыдzМя = new ArrayList(2);
/* 117 */       youcangetnoinfoCBYMыдzМя.add(new BasicNameValuePair("username", LoginGUI1.access$000(((LoginGUI)super).this$1.this$0).getText().replace(" ", "")));
/* 118 */       youcangetnoinfoCBYMыдzМя.add(new BasicNameValuePair("password", LoginGUI1.access$100(((LoginGUI)super).this$1.this$0).getText().replace(" ", "")));
/* 119 */       youcangetnoinfoCBYMыдzМя.add(new BasicNameValuePair("hwid2", SecurityUtils.getHWID2()));
/* 120 */       youcangetnoinfoCBYKЭя8за.setEntity((HttpEntity)new UrlEncodedFormEntity((List)youcangetnoinfoCBYMыдzМя, "UTF-8"));
/*     */       
/* 122 */       Object youcangetnoinfoCBYNГОмЧх = youcangetnoinfoCBYLГлоЗЪ.execute((HttpUriRequest)youcangetnoinfoCBYKЭя8за);
/* 123 */       Object youcangetnoinfoCBYOПЮё2Ю = youcangetnoinfoCBYNГОмЧх.getEntity();
/* 124 */       Object youcangetnoinfoCBYPЮуБФъ = EntityUtils.toString((HttpEntity)youcangetnoinfoCBYOПЮё2Ю);
/*     */       
/* 126 */       if (youcangetnoinfoCBYPЮуБФъ.equals("geqTm6lJDosgI2sguc") || youcangetnoinfoCBYPЮуБФъ.equals("HWID set")) {
/* 127 */         SpamUtils.user = LoginGUI1.access$000(((LoginGUI)super).this$1.this$0).getText().replace(" ", "");
/* 128 */         SpamUtils.pw = LoginGUI1.access$100(((LoginGUI)super).this$1.this$0).getText().replace(" ", "");
/* 129 */         SpamUtils.loggedIn = true;
/* 130 */         boolean bool = false;
/*     */         
/* 132 */         if ((new File(SpamIsFun.homeDir + "proxys.spamisfun")).exists()) {
/*     */           try {
/* 134 */             bool = true;
/* 135 */             int i = SpamIsFun.proxys.size();
/* 136 */             Object youcangetnoinfoCBXZ3АэЯч = FileUtils.readFile(SpamIsFun.homeDir + "proxys.spamisfun");
/* 137 */             for (String youcangetnoinfoCBXXрЪхнЯ : Files.readAllLines(Paths.get((String)youcangetnoinfoCBXZ3АэЯч, new String[0]), 
/* 138 */                 Charset.defaultCharset())) {
/* 139 */               i++;
/* 140 */               SpamIsFun.proxys.put(Integer.valueOf(i), youcangetnoinfoCBXXрЪхнЯ);
/*     */             } 
/* 142 */           } catch (Exception youcangetnoinfoCBYA1ж3Цк) {
/* 143 */             (new File(SpamIsFun.homeDir + "proxys.spamisfun")).delete();
/*     */           } 
/*     */         }
/*     */         
/* 147 */         if ((new File(SpamIsFun.homeDir + "tokens.spamisfun")).exists()) {
/*     */           try {
/* 149 */             bool = true;
/* 150 */             int i = SpamIsFun.tokens.size();
/* 151 */             Object youcangetnoinfoCBYEТААрр = FileUtils.readFile(SpamIsFun.homeDir + "tokens.spamisfun");
/* 152 */             for (String youcangetnoinfoCBYCлФМэн : Files.readAllLines(Paths.get((String)youcangetnoinfoCBYEТААрр, new String[0]), 
/* 153 */                 Charset.defaultCharset())) {
/* 154 */               i++;
/* 155 */               Object youcangetnoinfoCBYBТгчнЙ = youcangetnoinfoCBYCлФМэн.split(";");
/* 156 */               SpamIsFun.tokens.put(Integer.valueOf(i), youcangetnoinfoCBYBТгчнЙ[0]);
/*     */             } 
/* 158 */           } catch (Exception youcangetnoinfoCBYFПоА93) {
/* 159 */             (new File(SpamIsFun.homeDir + "tokens.spamisfun")).delete();
/*     */           } 
/*     */         }
/*     */         
/* 163 */         if (youcangetnoinfoCBYPЮуБФъ.equals("HWID set")) {
/* 164 */           JOptionPane.showMessageDialog(LoginGUI1.access$200(((LoginGUI)super).this$1.this$0), "Looks like this is your first login!\nYour account is now linked to your hardware ID. This was done to prevent account sharing.\nIf you have a new pc or if your hardware id changes for another reason, you must contact the administrator to reset your hardware id.");
/*     */         }
/*     */ 
/*     */ 
/*     */         
/* 169 */         if (bool) {
/* 170 */           JOptionPane.showMessageDialog(LoginGUI1.access$200(((LoginGUI)super).this$1.this$0), "Loaded " + SpamIsFun.proxys.size() + " proxies and " + SpamIsFun.tokens
/* 171 */               .size() + " tokens.");
/*     */         }
/* 173 */         Object youcangetnoinfoCBYJмЖеюЮ = new SpamisfunGUI8();
/* 174 */         youcangetnoinfoCBYJмЖеюЮ.setVisible(true);
/*     */         
/* 176 */         ((LoginGUI)super).this$1.this$0.setVisible(false);
/*     */         
/* 178 */         if (saveCheckBox.isSelected()) {
/*     */           try {
/* 180 */             FileUtils.writeFile(SpamIsFun.homeDir + "remember.spamisfun", 
/* 181 */                 SecurityUtils.AESencoder(LoginGUI1.access$000(((LoginGUI)super).this$1.this$0).getText()) + "\n" + 
/* 182 */                 SecurityUtils.AESencoder(LoginGUI1.access$100(((LoginGUI)super).this$1.this$0).getText()));
/* 183 */           } catch (InvalidKeyException|java.security.NoSuchAlgorithmException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException youcangetnoinfoCBYGЬыПнБ) {
/*     */             
/* 185 */             youcangetnoinfoCBYGЬыПнБ.printStackTrace();
/* 186 */           } catch (UnsupportedEncodingException youcangetnoinfoCBYHЙЛтЗ9) {
/* 187 */             youcangetnoinfoCBYHЙЛтЗ9.printStackTrace();
/*     */           } 
/*     */         } else {
/* 190 */           (new File(SpamIsFun.homeDir + "remember.spamisfun")).delete();
/*     */         } 
/* 192 */       } else if (youcangetnoinfoCBYPЮуБФъ.equals("HWID does not match")) {
/* 193 */         JOptionPane.showMessageDialog(LoginGUI1.access$200(((LoginGUI)super).this$1.this$0), "This account is linked to a different hardware ID. Account Sharing is not allowed. Please purchase the program.\n\nIf you have a new PC or your hardware ID has changed for another reason, you need to contact the administrator to reset your hardware ID.");
/*     */ 
/*     */         
/* 196 */         loginBtn.setEnabled(true);
/*     */       } else {
/* 198 */         JOptionPane.showMessageDialog(LoginGUI1.access$200(((LoginGUI)super).this$1.this$0), "Login failed! Try again!");
/* 199 */         loginBtn.setEnabled(true);
/*     */       } 
/* 201 */     } catch (IOException youcangetnoinfoCBYQ0ЛзоЛ) {
/* 202 */       youcangetnoinfoCBYQ0ЛзоЛ.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\LoginGUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */