/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public enum Protocol
/*     */ {
/*     */   HTTP_1_1,
/*     */   SPDY_3,
/*  33 */   HTTP_1_0("http/1.0"), QUIC("http/1.0"), H2_PRIOR_KNOWLEDGE("http/1.0"), HTTP_2("http/1.0");
/*     */   
/*     */   public final String protocol;
/*     */   
/*     */   public static final Protocol[] $VALUES;
/*     */ 
/*     */   
/*     */   static {
/*  41 */     HTTP_1_1 = new Protocol("HTTP_1_1", 1, "http/1.1");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     SPDY_3 = new Protocol("SPDY_3", 2, "spdy/3.1");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     HTTP_2 = new Protocol("HTTP_2", 3, "h2");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  71 */     H2_PRIOR_KNOWLEDGE = new Protocol("H2_PRIOR_KNOWLEDGE", 4, "h2_prior_knowledge");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     QUIC = new Protocol("QUIC", 5, "quic");
/*     */     $VALUES = new Protocol[] { HTTP_1_0, HTTP_1_1, SPDY_3, HTTP_2, H2_PRIOR_KNOWLEDGE, QUIC };
/*     */   }
/*     */   
/*     */   Protocol(Object youcangetnoinfoCJMJсЦоТж) {
/*  86 */     ((Protocol)super).protocol = (String)youcangetnoinfoCJMJсЦоТж;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Protocol get(Object youcangetnoinfoEPBTЬ13мТ) throws IOException {
/*  96 */     if (youcangetnoinfoEPBTЬ13мТ.equals(HTTP_1_0.protocol)) return HTTP_1_0; 
/*  97 */     if (youcangetnoinfoEPBTЬ13мТ.equals(HTTP_1_1.protocol)) return HTTP_1_1; 
/*  98 */     if (youcangetnoinfoEPBTЬ13мТ.equals(H2_PRIOR_KNOWLEDGE.protocol)) return H2_PRIOR_KNOWLEDGE; 
/*  99 */     if (youcangetnoinfoEPBTЬ13мТ.equals(HTTP_2.protocol)) return HTTP_2; 
/* 100 */     if (youcangetnoinfoEPBTЬ13мТ.equals(SPDY_3.protocol)) return SPDY_3; 
/* 101 */     if (youcangetnoinfoEPBTЬ13мТ.equals(QUIC.protocol)) return QUIC; 
/* 102 */     throw new IOException("Unexpected protocol: " + youcangetnoinfoEPBTЬ13мТ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/* 113 */     return ((Protocol)super).protocol;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Protocol.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */