/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.net.InetAddress;
/*    */ import java.net.UnknownHostException;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public interface Dns
/*    */ {
/* 36 */   public static final Dns SYSTEM = Dns::lambda$static$0; static List lambda$static$0(Object youcangetnoinfoDOIEвЗЮмл) throws UnknownHostException {
/* 37 */     if (youcangetnoinfoDOIEвЗЮмл == null) throw new UnknownHostException("hostname == null"); 
/*    */     try {
/* 39 */       return Arrays.asList(InetAddress.getAllByName((String)youcangetnoinfoDOIEвЗЮмл));
/* 40 */     } catch (NullPointerException youcangetnoinfoDOIDВалТС) {
/* 41 */       Object youcangetnoinfoDOICвкХшЩ = new UnknownHostException("Broken system behaviour for dns lookup of " + youcangetnoinfoDOIEвЗЮмл);
/*    */       
/* 43 */       youcangetnoinfoDOICвкХшЩ.initCause((Throwable)youcangetnoinfoDOIDВалТС);
/* 44 */       throw youcangetnoinfoDOICвкХшЩ;
/*    */     } 
/*    */   }
/*    */   
/*    */   List<InetAddress> lookup(String paramString) throws UnknownHostException;
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Dns.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */