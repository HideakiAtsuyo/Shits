/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Okio3
/*     */   implements Sink
/*     */ {
/*     */   public final Timeout val$timeout;
/*     */   public final OutputStream val$out;
/*     */   
/*     */   public Okio3() {
/*  72 */     this();
/*     */   } public void write(Object youcangetnoinfoEJLI3ХЭн0, Object youcangetnoinfoEJLJшпЩьз) throws IOException {
/*  74 */     Util.checkOffsetAndCount(((Buffer2)youcangetnoinfoEJLI3ХЭн0).size, 0L, youcangetnoinfoEJLJшпЩьз);
/*  75 */     while (youcangetnoinfoEJLJшпЩьз > 0L) {
/*  76 */       timeout.throwIfReached();
/*  77 */       Object youcangetnoinfoEJLFВнмЛг = ((Buffer2)youcangetnoinfoEJLI3ХЭн0).head;
/*  78 */       int i = (int)Math.min(youcangetnoinfoEJLJшпЩьз, (((Segment)youcangetnoinfoEJLFВнмЛг).limit - ((Segment)youcangetnoinfoEJLFВнмЛг).pos));
/*  79 */       out.write(((Segment)youcangetnoinfoEJLFВнмЛг).data, ((Segment)youcangetnoinfoEJLFВнмЛг).pos, i);
/*     */       
/*  81 */       ((Segment)youcangetnoinfoEJLFВнмЛг).pos += i;
/*  82 */       long l = youcangetnoinfoEJLJшпЩьз - i;
/*  83 */       ((Buffer2)youcangetnoinfoEJLI3ХЭн0).size -= i;
/*     */       
/*  85 */       if (((Segment)youcangetnoinfoEJLFВнмЛг).pos == ((Segment)youcangetnoinfoEJLFВнмЛг).limit) {
/*  86 */         ((Buffer2)youcangetnoinfoEJLI3ХЭн0).head = youcangetnoinfoEJLFВнмЛг.pop();
/*  87 */         SegmentPool.recycle((Segment)youcangetnoinfoEJLFВнмЛг);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void flush() throws IOException {
/*  93 */     out.flush();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/*  97 */     out.close();
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 101 */     return timeout;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 105 */     return "sink(" + out + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Okio3.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */