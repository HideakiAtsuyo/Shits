/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import javax.net.ssl.SSLParameters;
/*    */ import javax.net.ssl.SSLSocket;
/*    */ import javax.net.ssl.X509TrustManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class Jdk9Platform
/*    */   extends Platform
/*    */ {
/*    */   public final Method getProtocolMethod;
/*    */   public final Method setProtocolMethod;
/*    */   
/*    */   public Jdk9Platform(Object youcangetnoinfoEFKYтПФБф, Object youcangetnoinfoEFKZЪЫлаз) {
/* 34 */     ((Jdk9Platform)super).setProtocolMethod = (Method)youcangetnoinfoEFKYтПФБф;
/* 35 */     ((Jdk9Platform)super).getProtocolMethod = (Method)youcangetnoinfoEFKZЪЫлаз;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void configureTlsExtensions(Object youcangetnoinfoCWXT8ЖШ0я, Object youcangetnoinfoCWXUлэФъТ, Object youcangetnoinfoCWXVчзо0е) {
/*    */     try {
/* 42 */       Object youcangetnoinfoCWXPУЯяхф = youcangetnoinfoCWXT8ЖШ0я.getSSLParameters();
/*    */       
/* 44 */       Object youcangetnoinfoCWXQъВГРЗ = alpnProtocolNames((List)youcangetnoinfoCWXVчзо0е);
/*    */       
/* 46 */       ((Jdk9Platform)super).setProtocolMethod.invoke(youcangetnoinfoCWXPУЯяхф, new Object[] { youcangetnoinfoCWXQъВГРЗ
/* 47 */             .toArray((Object[])new String[youcangetnoinfoCWXQъВГРЗ.size()]) });
/*    */       
/* 49 */       youcangetnoinfoCWXT8ЖШ0я.setSSLParameters((SSLParameters)youcangetnoinfoCWXPУЯяхф);
/* 50 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException youcangetnoinfoCWXRСФ24й) {
/* 51 */       throw new AssertionError("failed to set SSL parameters", youcangetnoinfoCWXRСФ24й);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String getSelectedProtocol(Object youcangetnoinfoCLXSГ6ШзБ) {
/*    */     try {
/* 58 */       Object youcangetnoinfoCLXPжЛЁМН = ((Jdk9Platform)super).getProtocolMethod.invoke(youcangetnoinfoCLXSГ6ШзБ, new Object[0]);
/*    */ 
/*    */ 
/*    */       
/* 62 */       if (youcangetnoinfoCLXPжЛЁМН == null || youcangetnoinfoCLXPжЛЁМН.equals("")) {
/* 63 */         return null;
/*    */       }
/*    */       
/* 66 */       return (String)youcangetnoinfoCLXPжЛЁМН;
/* 67 */     } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException youcangetnoinfoCLXQмЭ1Жт) {
/* 68 */       throw new AssertionError("failed to get ALPN selected protocol", youcangetnoinfoCLXQмЭ1Жт);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public X509TrustManager trustManager(Object youcangetnoinfoKJIУСЧзй) {
/* 77 */     throw new UnsupportedOperationException("clientBuilder.sslSocketFactory(SSLSocketFactory) not supported on JDK 9+");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Jdk9Platform buildIfSupported() {
/*    */     try {
/* 85 */       Object youcangetnoinfoBTPCчСтТ0 = SSLParameters.class.getMethod("setApplicationProtocols", new Class[] { String[].class });
/* 86 */       Object youcangetnoinfoBTPDС8я6Ъ = SSLSocket.class.getMethod("getApplicationProtocol", new Class[0]);
/*    */       
/* 88 */       return new Jdk9Platform((Method)youcangetnoinfoBTPCчСтТ0, (Method)youcangetnoinfoBTPDС8я6Ъ);
/* 89 */     } catch (NoSuchMethodException noSuchMethodException) {
/*    */ 
/*    */ 
/*    */       
/* 93 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Jdk9Platform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */