/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DistinguishedNameParser
/*     */ {
/*     */   public char[] chars;
/*     */   public int beg;
/*     */   public final int length;
/*     */   public final String dn;
/*     */   public int pos;
/*     */   public int cur;
/*     */   public int end;
/*     */   
/*     */   public DistinguishedNameParser(Object youcangetnoinfoCQTHоЕцЪл) {
/*  38 */     this();
/*     */ 
/*     */ 
/*     */     
/*  42 */     ((DistinguishedNameParser)super).dn = youcangetnoinfoCQTHоЕцЪл.getName("RFC2253");
/*  43 */     ((DistinguishedNameParser)super).length = ((DistinguishedNameParser)super).dn.length();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextAT() {
/*  50 */     for (; ((DistinguishedNameParser)super).pos < ((DistinguishedNameParser)super).length && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ' '; ((DistinguishedNameParser)super).pos++);
/*     */     
/*  52 */     if (((DistinguishedNameParser)super).pos == ((DistinguishedNameParser)super).length) {
/*  53 */       return null;
/*     */     }
/*     */ 
/*     */     
/*  57 */     ((DistinguishedNameParser)super).beg = ((DistinguishedNameParser)super).pos;
/*     */ 
/*     */     
/*  60 */     ((DistinguishedNameParser)super).pos++;
/*  61 */     for (; ((DistinguishedNameParser)super).pos < ((DistinguishedNameParser)super).length && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] != '=' && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] != ' '; ((DistinguishedNameParser)super).pos++);
/*     */ 
/*     */ 
/*     */     
/*  65 */     if (((DistinguishedNameParser)super).pos >= ((DistinguishedNameParser)super).length) {
/*  66 */       throw new IllegalStateException("Unexpected end of DN: " + super.dn);
/*     */     }
/*     */ 
/*     */     
/*  70 */     ((DistinguishedNameParser)super).end = ((DistinguishedNameParser)super).pos;
/*     */ 
/*     */ 
/*     */     
/*  74 */     if (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ' ') {
/*  75 */       for (; ((DistinguishedNameParser)super).pos < ((DistinguishedNameParser)super).length && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] != '=' && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ' '; ((DistinguishedNameParser)super).pos++);
/*     */ 
/*     */       
/*  78 */       if (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] != '=' || ((DistinguishedNameParser)super).pos == ((DistinguishedNameParser)super).length) {
/*  79 */         throw new IllegalStateException("Unexpected end of DN: " + super.dn);
/*     */       }
/*     */     } 
/*     */     
/*  83 */     ((DistinguishedNameParser)super).pos++;
/*     */ 
/*     */ 
/*     */     
/*  87 */     for (; ((DistinguishedNameParser)super).pos < ((DistinguishedNameParser)super).length && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ' '; ((DistinguishedNameParser)super).pos++);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     if (((DistinguishedNameParser)super).end - ((DistinguishedNameParser)super).beg > 4 && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).beg + 3] == '.' && (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).beg] == 'O' || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).beg] == 'o') && (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).beg + 1] == 'I' || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).beg + 1] == 'i') && (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).beg + 2] == 'D' || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).beg + 2] == 'd'))
/*     */     {
/*     */ 
/*     */       
/*  96 */       ((DistinguishedNameParser)super).beg += 4;
/*     */     }
/*     */     
/*  99 */     return new String(((DistinguishedNameParser)super).chars, ((DistinguishedNameParser)super).beg, ((DistinguishedNameParser)super).end - ((DistinguishedNameParser)super).beg);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String quotedAV() {
/* 105 */     ((DistinguishedNameParser)super).beg = ++((DistinguishedNameParser)super).pos;
/* 106 */     ((DistinguishedNameParser)super).end = ((DistinguishedNameParser)super).beg;
/*     */     
/*     */     while (true) {
/* 109 */       if (((DistinguishedNameParser)super).pos == ((DistinguishedNameParser)super).length) {
/* 110 */         throw new IllegalStateException("Unexpected end of DN: " + super.dn);
/*     */       }
/*     */       
/* 113 */       if (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == '"') {
/*     */         
/* 115 */         ((DistinguishedNameParser)super).pos++; break;
/*     */       } 
/* 117 */       if (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == '\\') {
/* 118 */         ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).end] = super.getEscaped();
/*     */       } else {
/*     */         
/* 121 */         ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).end] = ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos];
/*     */       } 
/* 123 */       ((DistinguishedNameParser)super).pos++;
/* 124 */       ((DistinguishedNameParser)super).end++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 129 */     for (; ((DistinguishedNameParser)super).pos < ((DistinguishedNameParser)super).length && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ' '; ((DistinguishedNameParser)super).pos++);
/*     */ 
/*     */     
/* 132 */     return new String(((DistinguishedNameParser)super).chars, ((DistinguishedNameParser)super).beg, ((DistinguishedNameParser)super).end - ((DistinguishedNameParser)super).beg);
/*     */   }
/*     */ 
/*     */   
/*     */   public String hexAV() {
/* 137 */     if (((DistinguishedNameParser)super).pos + 4 >= ((DistinguishedNameParser)super).length)
/*     */     {
/* 139 */       throw new IllegalStateException("Unexpected end of DN: " + super.dn);
/*     */     }
/*     */     
/* 142 */     ((DistinguishedNameParser)super).beg = ((DistinguishedNameParser)super).pos;
/* 143 */     ((DistinguishedNameParser)super).pos++;
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 148 */       if (((DistinguishedNameParser)super).pos == ((DistinguishedNameParser)super).length || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == '+' || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ',' || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ';') {
/*     */         
/* 150 */         ((DistinguishedNameParser)super).end = ((DistinguishedNameParser)super).pos;
/*     */         
/*     */         break;
/*     */       } 
/* 154 */       if (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ' ') {
/* 155 */         ((DistinguishedNameParser)super).end = ((DistinguishedNameParser)super).pos;
/* 156 */         ((DistinguishedNameParser)super).pos++;
/*     */ 
/*     */         
/* 159 */         for (; ((DistinguishedNameParser)super).pos < ((DistinguishedNameParser)super).length && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ' '; ((DistinguishedNameParser)super).pos++);
/*     */         break;
/*     */       } 
/* 162 */       if (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] >= 'A' && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] <= 'F') {
/* 163 */         ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] = (char)(((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] + 32);
/*     */       }
/*     */       
/* 166 */       ((DistinguishedNameParser)super).pos++;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 171 */     int i = ((DistinguishedNameParser)super).end - ((DistinguishedNameParser)super).beg;
/* 172 */     if (i < 5 || (i & 0x1) == 0) {
/* 173 */       throw new IllegalStateException("Unexpected end of DN: " + super.dn);
/*     */     }
/*     */ 
/*     */     
/* 177 */     Object youcangetnoinfoALXIЧючЦн = new byte[i / 2]; byte b; int j;
/* 178 */     for (b = 0, j = ((DistinguishedNameParser)super).beg + 1; b < youcangetnoinfoALXIЧючЦн.length; j += 2, b++) {
/* 179 */       youcangetnoinfoALXIЧючЦн[b] = (byte)super.getByte(j);
/*     */     }
/*     */     
/* 182 */     return new String(((DistinguishedNameParser)super).chars, ((DistinguishedNameParser)super).beg, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public String escapedAV() {
/* 187 */     ((DistinguishedNameParser)super).beg = ((DistinguishedNameParser)super).pos;
/* 188 */     ((DistinguishedNameParser)super).end = ((DistinguishedNameParser)super).pos;
/*     */     while (true) {
/* 190 */       if (((DistinguishedNameParser)super).pos >= ((DistinguishedNameParser)super).length)
/*     */       {
/* 192 */         return new String(((DistinguishedNameParser)super).chars, ((DistinguishedNameParser)super).beg, ((DistinguishedNameParser)super).end - ((DistinguishedNameParser)super).beg);
/*     */       }
/*     */       
/* 195 */       switch (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos]) {
/*     */         
/*     */         case '+':
/*     */         case ',':
/*     */         case ';':
/* 200 */           return new String(((DistinguishedNameParser)super).chars, ((DistinguishedNameParser)super).beg, ((DistinguishedNameParser)super).end - ((DistinguishedNameParser)super).beg);
/*     */         
/*     */         case '\\':
/* 203 */           ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).end++] = super.getEscaped();
/* 204 */           ((DistinguishedNameParser)super).pos++;
/*     */           continue;
/*     */ 
/*     */         
/*     */         case ' ':
/* 209 */           ((DistinguishedNameParser)super).cur = ((DistinguishedNameParser)super).end;
/*     */           
/* 211 */           ((DistinguishedNameParser)super).pos++;
/* 212 */           ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).end++] = ' ';
/*     */           
/* 214 */           for (; ((DistinguishedNameParser)super).pos < ((DistinguishedNameParser)super).length && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ' '; ((DistinguishedNameParser)super).pos++) {
/* 215 */             ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).end++] = ' ';
/*     */           }
/* 217 */           if (((DistinguishedNameParser)super).pos == ((DistinguishedNameParser)super).length || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ',' || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == '+' || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] == ';')
/*     */           {
/*     */             
/* 220 */             return new String(((DistinguishedNameParser)super).chars, ((DistinguishedNameParser)super).beg, ((DistinguishedNameParser)super).cur - ((DistinguishedNameParser)super).beg);
/*     */           }
/*     */           continue;
/*     */       } 
/* 224 */       ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).end++] = ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos];
/* 225 */       ((DistinguishedNameParser)super).pos++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public char getEscaped() {
/* 232 */     ((DistinguishedNameParser)super).pos++;
/* 233 */     if (((DistinguishedNameParser)super).pos == ((DistinguishedNameParser)super).length) {
/* 234 */       throw new IllegalStateException("Unexpected end of DN: " + super.dn);
/*     */     }
/*     */     
/* 237 */     switch (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos]) {
/*     */       
/*     */       case ' ':
/*     */       case '"':
/*     */       case '#':
/*     */       case '%':
/*     */       case '*':
/*     */       case '+':
/*     */       case ',':
/*     */       case ';':
/*     */       case '<':
/*     */       case '=':
/*     */       case '>':
/*     */       case '\\':
/*     */       case '_':
/* 252 */         return ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos];
/*     */     } 
/*     */ 
/*     */     
/* 256 */     return super.getUTF8();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public char getUTF8() {
/* 263 */     int i = super.getByte(((DistinguishedNameParser)super).pos);
/* 264 */     ((DistinguishedNameParser)super).pos++;
/*     */     
/* 266 */     if (i < 128)
/* 267 */       return (char)i; 
/* 268 */     if (i >= 192 && i <= 247) {
/*     */       byte b1;
/*     */       
/* 271 */       if (i <= 223) {
/* 272 */         b1 = 1;
/* 273 */         i &= 0x1F;
/* 274 */       } else if (i <= 239) {
/* 275 */         b1 = 2;
/* 276 */         i &= 0xF;
/*     */       } else {
/* 278 */         b1 = 3;
/* 279 */         i &= 0x7;
/*     */       } 
/*     */ 
/*     */       
/* 283 */       for (byte b2 = 0; b2 < b1; b2++) {
/* 284 */         ((DistinguishedNameParser)super).pos++;
/* 285 */         if (((DistinguishedNameParser)super).pos == ((DistinguishedNameParser)super).length || ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] != '\\') {
/* 286 */           return '?';
/*     */         }
/* 288 */         ((DistinguishedNameParser)super).pos++;
/*     */         
/* 290 */         int j = super.getByte(((DistinguishedNameParser)super).pos);
/* 291 */         ((DistinguishedNameParser)super).pos++;
/* 292 */         if ((j & 0xC0) != 128) {
/* 293 */           return '?';
/*     */         }
/*     */         
/* 296 */         i = (i << 6) + (j & 0x3F);
/*     */       } 
/* 298 */       return (char)i;
/*     */     } 
/* 300 */     return '?';
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getByte(Object youcangetnoinfoDFGZипЫея) {
/* 311 */     if (youcangetnoinfoDFGZипЫея + 1 >= ((DistinguishedNameParser)super).length) {
/* 312 */       throw new IllegalStateException("Malformed DN: " + super.dn);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 317 */     int i = ((DistinguishedNameParser)super).chars[youcangetnoinfoDFGZипЫея];
/* 318 */     if (i >= 48 && i <= 57) {
/* 319 */       i = i - 48;
/* 320 */     } else if (i >= 97 && i <= 102) {
/* 321 */       i -= 87;
/* 322 */     } else if (i >= 65 && i <= 70) {
/* 323 */       i -= 55;
/*     */     } else {
/* 325 */       throw new IllegalStateException("Malformed DN: " + super.dn);
/*     */     } 
/*     */     
/* 328 */     int j = ((DistinguishedNameParser)super).chars[youcangetnoinfoDFGZипЫея + 1];
/* 329 */     if (j >= 48 && j <= 57) {
/* 330 */       j = j - 48;
/* 331 */     } else if (j >= 97 && j <= 102) {
/* 332 */       j -= 87;
/* 333 */     } else if (j >= 65 && j <= 70) {
/* 334 */       j -= 55;
/*     */     } else {
/* 336 */       throw new IllegalStateException("Malformed DN: " + super.dn);
/*     */     } 
/*     */     
/* 339 */     return (i << 4) + j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String findMostSpecific(Object youcangetnoinfoADDQЩеЪЖН) {
/* 350 */     ((DistinguishedNameParser)super).pos = 0;
/* 351 */     ((DistinguishedNameParser)super).beg = 0;
/* 352 */     ((DistinguishedNameParser)super).end = 0;
/* 353 */     ((DistinguishedNameParser)super).cur = 0;
/* 354 */     ((DistinguishedNameParser)super).chars = ((DistinguishedNameParser)super).dn.toCharArray();
/*     */     
/* 356 */     Object youcangetnoinfoADDRСуВцв = super.nextAT();
/* 357 */     if (youcangetnoinfoADDRСуВцв == null) {
/* 358 */       return null;
/*     */     }
/*     */     while (true) {
/* 361 */       Object youcangetnoinfoADDOьфТЭс = "";
/*     */       
/* 363 */       if (((DistinguishedNameParser)super).pos == ((DistinguishedNameParser)super).length) {
/* 364 */         return null;
/*     */       }
/*     */       
/* 367 */       switch (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos]) {
/*     */         case '"':
/* 369 */           youcangetnoinfoADDOьфТЭс = super.quotedAV();
/*     */           break;
/*     */         case '#':
/* 372 */           youcangetnoinfoADDOьфТЭс = super.hexAV();
/*     */           break;
/*     */         
/*     */         case '+':
/*     */         case ',':
/*     */         case ';':
/*     */           break;
/*     */         default:
/* 380 */           youcangetnoinfoADDOьфТЭс = super.escapedAV();
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 386 */       if (youcangetnoinfoADDQЩеЪЖН.equalsIgnoreCase((String)youcangetnoinfoADDRСуВцв)) {
/* 387 */         return (String)youcangetnoinfoADDOьфТЭс;
/*     */       }
/*     */       
/* 390 */       if (((DistinguishedNameParser)super).pos >= ((DistinguishedNameParser)super).length) {
/* 391 */         return null;
/*     */       }
/*     */       
/* 394 */       if (((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] != ',' && ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] != ';' && 
/* 395 */         ((DistinguishedNameParser)super).chars[((DistinguishedNameParser)super).pos] != '+') {
/* 396 */         throw new IllegalStateException("Malformed DN: " + super.dn);
/*     */       }
/*     */       
/* 399 */       ((DistinguishedNameParser)super).pos++;
/* 400 */       youcangetnoinfoADDRСуВцв = super.nextAT();
/* 401 */       if (youcangetnoinfoADDRСуВцв == null)
/* 402 */         throw new IllegalStateException("Malformed DN: " + super.dn); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\DistinguishedNameParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */