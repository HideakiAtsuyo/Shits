/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class ConnectionSpec
/*     */ {
/*     */   public static final ConnectionSpec COMPATIBLE_TLS;
/*     */   public final boolean tls;
/*     */   @Nullable
/*     */   public final String[] tlsVersions;
/*  51 */   public static final CipherSuite[] RESTRICTED_CIPHER_SUITES = new CipherSuite[] { CipherSuite.TLS_AES_128_GCM_SHA256, CipherSuite.TLS_AES_256_GCM_SHA384, CipherSuite.TLS_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_AES_128_CCM_SHA256, CipherSuite.TLS_AES_256_CCM_8_SHA256, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public final String[] cipherSuites;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   public static final CipherSuite[] APPROVED_CIPHER_SUITES = new CipherSuite[] { CipherSuite.TLS_AES_128_GCM_SHA256, CipherSuite.TLS_AES_256_GCM_SHA384, CipherSuite.TLS_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_AES_128_CCM_SHA256, CipherSuite.TLS_AES_256_CCM_8_SHA256, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_ECDHE_ECDSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_ECDHE_ECDSA_WITH_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256, CipherSuite.TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA, CipherSuite.TLS_ECDHE_RSA_WITH_AES_256_CBC_SHA, CipherSuite.TLS_RSA_WITH_AES_128_GCM_SHA256, CipherSuite.TLS_RSA_WITH_AES_256_GCM_SHA384, CipherSuite.TLS_RSA_WITH_AES_128_CBC_SHA, CipherSuite.TLS_RSA_WITH_AES_256_CBC_SHA, CipherSuite.TLS_RSA_WITH_3DES_EDE_CBC_SHA };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   public static final ConnectionSpec RESTRICTED_TLS = (new ConnectionSpec1(true))
/*  99 */     .cipherSuites(RESTRICTED_CIPHER_SUITES)
/* 100 */     .tlsVersions(new TlsVersion[] { TlsVersion.TLS_1_3, TlsVersion.TLS_1_2
/* 101 */       }).supportsTlsExtensions(true)
/* 102 */     .build();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 108 */   public static final ConnectionSpec MODERN_TLS = (new ConnectionSpec1(true))
/* 109 */     .cipherSuites(APPROVED_CIPHER_SUITES)
/* 110 */     .tlsVersions(new TlsVersion[] { TlsVersion.TLS_1_3, TlsVersion.TLS_1_2
/* 111 */       }).supportsTlsExtensions(true)
/* 112 */     .build();
/*     */ 
/*     */   
/*     */   public static final ConnectionSpec CLEARTEXT;
/*     */ 
/*     */   
/*     */   public final boolean supportsTlsExtensions;
/*     */ 
/*     */ 
/*     */   
/*     */   static {
/* 123 */     COMPATIBLE_TLS = (new ConnectionSpec1(true)).cipherSuites(APPROVED_CIPHER_SUITES).tlsVersions(new TlsVersion[] { TlsVersion.TLS_1_3, TlsVersion.TLS_1_2, TlsVersion.TLS_1_1, TlsVersion.TLS_1_0 }).supportsTlsExtensions(true).build();
/*     */ 
/*     */     
/* 126 */     CLEARTEXT = (new ConnectionSpec1(false)).build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionSpec(Object youcangetnoinfoDEQGё70иы) {
/* 133 */     this();
/* 134 */     ((ConnectionSpec)super).tls = ((ConnectionSpec1)youcangetnoinfoDEQGё70иы).tls;
/* 135 */     ((ConnectionSpec)super).cipherSuites = ((ConnectionSpec1)youcangetnoinfoDEQGё70иы).cipherSuites;
/* 136 */     ((ConnectionSpec)super).tlsVersions = ((ConnectionSpec1)youcangetnoinfoDEQGё70иы).tlsVersions;
/* 137 */     ((ConnectionSpec)super).supportsTlsExtensions = ((ConnectionSpec1)youcangetnoinfoDEQGё70иы).supportsTlsExtensions;
/*     */   }
/*     */   
/*     */   public boolean isTls() {
/* 141 */     return ((ConnectionSpec)super).tls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List cipherSuites() {
/* 149 */     return (((ConnectionSpec)super).cipherSuites != null) ? CipherSuite.forJavaNames(((ConnectionSpec)super).cipherSuites) : null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public List tlsVersions() {
/* 157 */     return (((ConnectionSpec)super).tlsVersions != null) ? TlsVersion.forJavaNames(((ConnectionSpec)super).tlsVersions) : null;
/*     */   }
/*     */   
/*     */   public boolean supportsTlsExtensions() {
/* 161 */     return ((ConnectionSpec)super).supportsTlsExtensions;
/*     */   }
/*     */ 
/*     */   
/*     */   public void apply(Object youcangetnoinfoOKGЮ6З1р, Object youcangetnoinfoOKHщЕН1ц) {
/* 166 */     Object youcangetnoinfoOKIмл62у = super.supportedSpec((SSLSocket)youcangetnoinfoOKGЮ6З1р, youcangetnoinfoOKHщЕН1ц);
/*     */     
/* 168 */     if (((ConnectionSpec)youcangetnoinfoOKIмл62у).tlsVersions != null) {
/* 169 */       youcangetnoinfoOKGЮ6З1р.setEnabledProtocols(((ConnectionSpec)youcangetnoinfoOKIмл62у).tlsVersions);
/*     */     }
/* 171 */     if (((ConnectionSpec)youcangetnoinfoOKIмл62у).cipherSuites != null) {
/* 172 */       youcangetnoinfoOKGЮ6З1р.setEnabledCipherSuites(((ConnectionSpec)youcangetnoinfoOKIмл62у).cipherSuites);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ConnectionSpec supportedSpec(Object youcangetnoinfoEMZTМЖТШ4, Object youcangetnoinfoEMZUЦЕХзв) {
/* 183 */     Object youcangetnoinfoEMZVДсОСэ = (((ConnectionSpec)super).cipherSuites != null) ? Util1.intersect(CipherSuite.ORDER_BY_NAME, youcangetnoinfoEMZTМЖТШ4.getEnabledCipherSuites(), ((ConnectionSpec)super).cipherSuites) : youcangetnoinfoEMZTМЖТШ4.getEnabledCipherSuites();
/*     */ 
/*     */     
/* 186 */     Object youcangetnoinfoEMZW9Лщкз = (((ConnectionSpec)super).tlsVersions != null) ? Util1.intersect(Util1.NATURAL_ORDER, youcangetnoinfoEMZTМЖТШ4.getEnabledProtocols(), ((ConnectionSpec)super).tlsVersions) : youcangetnoinfoEMZTМЖТШ4.getEnabledProtocols();
/*     */ 
/*     */ 
/*     */     
/* 190 */     Object youcangetnoinfoEMZXгяйЗб = youcangetnoinfoEMZTМЖТШ4.getSupportedCipherSuites();
/* 191 */     int i = Util1.indexOf(CipherSuite.ORDER_BY_NAME, (String[])youcangetnoinfoEMZXгяйЗб, "TLS_FALLBACK_SCSV");
/*     */     
/* 193 */     if (youcangetnoinfoEMZUЦЕХзв != null && i != -1) {
/* 194 */       youcangetnoinfoEMZVДсОСэ = Util1.concat((String[])youcangetnoinfoEMZVДсОСэ, (String)youcangetnoinfoEMZXгяйЗб[i]);
/*     */     }
/*     */ 
/*     */     
/* 198 */     return (new ConnectionSpec1((ConnectionSpec)this))
/* 199 */       .cipherSuites((String[])youcangetnoinfoEMZVДсОСэ)
/* 200 */       .tlsVersions((String[])youcangetnoinfoEMZW9Лщкз)
/* 201 */       .build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCompatible(Object youcangetnoinfoCYGEzВуТТ) {
/* 216 */     if (!((ConnectionSpec)super).tls) {
/* 217 */       return false;
/*     */     }
/*     */     
/* 220 */     if (((ConnectionSpec)super).tlsVersions != null && !Util1.nonEmptyIntersection(Util1.NATURAL_ORDER, ((ConnectionSpec)super).tlsVersions, youcangetnoinfoCYGEzВуТТ
/* 221 */         .getEnabledProtocols())) {
/* 222 */       return false;
/*     */     }
/*     */     
/* 225 */     if (((ConnectionSpec)super).cipherSuites != null && !Util1.nonEmptyIntersection(CipherSuite.ORDER_BY_NAME, ((ConnectionSpec)super).cipherSuites, youcangetnoinfoCYGEzВуТТ
/* 226 */         .getEnabledCipherSuites())) {
/* 227 */       return false;
/*     */     }
/*     */     
/* 230 */     return true;
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object youcangetnoinfoCEFVгпЦЁэ) {
/* 234 */     if (!(youcangetnoinfoCEFVгпЦЁэ instanceof ConnectionSpec)) return false; 
/* 235 */     if (youcangetnoinfoCEFVгпЦЁэ == this) return true;
/*     */     
/* 237 */     Object youcangetnoinfoCEFWх0ГШЩ = youcangetnoinfoCEFVгпЦЁэ;
/* 238 */     if (((ConnectionSpec)super).tls != ((ConnectionSpec)youcangetnoinfoCEFWх0ГШЩ).tls) return false;
/*     */     
/* 240 */     if (((ConnectionSpec)super).tls) {
/* 241 */       if (!Arrays.equals((Object[])((ConnectionSpec)super).cipherSuites, (Object[])((ConnectionSpec)youcangetnoinfoCEFWх0ГШЩ).cipherSuites)) return false; 
/* 242 */       if (!Arrays.equals((Object[])((ConnectionSpec)super).tlsVersions, (Object[])((ConnectionSpec)youcangetnoinfoCEFWх0ГШЩ).tlsVersions)) return false; 
/* 243 */       if (((ConnectionSpec)super).supportsTlsExtensions != ((ConnectionSpec)youcangetnoinfoCEFWх0ГШЩ).supportsTlsExtensions) return false;
/*     */     
/*     */     } 
/* 246 */     return true;
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 250 */     int i = 17;
/* 251 */     if (((ConnectionSpec)super).tls) {
/* 252 */       i = 31 * i + Arrays.hashCode((Object[])((ConnectionSpec)super).cipherSuites);
/* 253 */       i = 31 * i + Arrays.hashCode((Object[])((ConnectionSpec)super).tlsVersions);
/* 254 */       i = 31 * i + (((ConnectionSpec)super).supportsTlsExtensions ? 0 : 1);
/*     */     } 
/* 256 */     return i;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 260 */     if (!((ConnectionSpec)super).tls) {
/* 261 */       return "ConnectionSpec()";
/*     */     }
/*     */     
/* 264 */     return "ConnectionSpec(cipherSuites=" + 
/* 265 */       Objects.toString(super.cipherSuites(), "[all enabled]") + ", tlsVersions=" + 
/* 266 */       Objects.toString(super.tlsVersions(), "[all enabled]") + ", supportsTlsExtensions=" + ((ConnectionSpec)super).supportsTlsExtensions + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ConnectionSpec.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */