/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.LayoutManager;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ import javax.swing.JTextField;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class GuildLeaver2
/*    */   extends JPanel
/*    */ {
/*    */   public static final long serialVersionUID = -5710152243372038428L;
/*    */   
/*    */   public GuildLeaver2() {
/* 25 */     super.initialize();
/*    */   }
/*    */   
/*    */   public void initialize() {
/* 29 */     setLayout((LayoutManager)null);
/*    */     
/* 31 */     Object youcangetnoinfoCVJG1ЕвКЗ = new JLabel("Guild id (Server id)");
/* 32 */     youcangetnoinfoCVJG1ЕвКЗ.setBounds(28, 12, 293, 15);
/* 33 */     add((Component)youcangetnoinfoCVJG1ЕвКЗ);
/*    */     
/* 35 */     Object youcangetnoinfoCVJHЯАЛдж = new JTextField();
/* 36 */     youcangetnoinfoCVJHЯАЛдж.setColumns(10);
/* 37 */     youcangetnoinfoCVJHЯАЛдж.setBounds(27, 29, 341, 32);
/* 38 */     add((Component)youcangetnoinfoCVJHЯАЛдж);
/*    */     
/* 40 */     Object youcangetnoinfoCVJIщцУя9 = new JButton("Leave");
/* 41 */     youcangetnoinfoCVJIщцУя9.setIcon(new ImageIcon(getClass().getResource("/ui/remove.png")));
/* 42 */     youcangetnoinfoCVJIщцУя9.setBounds(27, 73, 341, 32);
/* 43 */     youcangetnoinfoCVJIщцУя9.addActionListener(new GuildLeaver1((GuildLeaver2)this, (JTextField)youcangetnoinfoCVJHЯАЛдж));
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 85 */     add((Component)youcangetnoinfoCVJIщцУя9);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\GuildLeaver2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */