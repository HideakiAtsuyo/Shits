/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FileNotFoundException;
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FileSystem1
/*    */   implements FileSystem
/*    */ {
/*    */   public FileSystem1() {
/* 42 */     this();
/*    */   } public Source source(Object youcangetnoinfoZNXгЛоАц) throws FileNotFoundException {
/* 44 */     return Okio1.source((File)youcangetnoinfoZNXгЛоАц);
/*    */   }
/*    */   
/*    */   public Sink sink(Object youcangetnoinfoCKEYЦл7И6) throws FileNotFoundException {
/*    */     try {
/* 49 */       return Okio1.sink((File)youcangetnoinfoCKEYЦл7И6);
/* 50 */     } catch (FileNotFoundException youcangetnoinfoCKEWХЪГ6Ю) {
/*    */       
/* 52 */       youcangetnoinfoCKEYЦл7И6.getParentFile().mkdirs();
/* 53 */       return Okio1.sink((File)youcangetnoinfoCKEYЦл7И6);
/*    */     } 
/*    */   }
/*    */   
/*    */   public Sink appendingSink(Object youcangetnoinfoPIKгПМкБ) throws FileNotFoundException {
/*    */     try {
/* 59 */       return Okio1.appendingSink((File)youcangetnoinfoPIKгПМкБ);
/* 60 */     } catch (FileNotFoundException youcangetnoinfoPIIБюЁМш) {
/*    */       
/* 62 */       youcangetnoinfoPIKгПМкБ.getParentFile().mkdirs();
/* 63 */       return Okio1.appendingSink((File)youcangetnoinfoPIKгПМкБ);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void delete(Object youcangetnoinfoFXOоХГЁ1) throws IOException {
/* 69 */     if (!youcangetnoinfoFXOоХГЁ1.delete() && youcangetnoinfoFXOоХГЁ1.exists()) {
/* 70 */       throw new IOException("failed to delete " + youcangetnoinfoFXOоХГЁ1);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean exists(Object youcangetnoinfoEKACГЕКц6) {
/* 75 */     return youcangetnoinfoEKACГЕКц6.exists();
/*    */   }
/*    */   
/*    */   public long size(Object youcangetnoinfoBOVOоЖЩСП) {
/* 79 */     return youcangetnoinfoBOVOоЖЩСП.length();
/*    */   }
/*    */   
/*    */   public void rename(Object youcangetnoinfoECEWШдГьъ, Object youcangetnoinfoECEXРГуЬу) throws IOException {
/* 83 */     super.delete((File)youcangetnoinfoECEXРГуЬу);
/* 84 */     if (!youcangetnoinfoECEWШдГьъ.renameTo((File)youcangetnoinfoECEXРГуЬу))
/* 85 */       throw new IOException("failed to rename " + youcangetnoinfoECEWШдГьъ + " to " + youcangetnoinfoECEXРГуЬу); 
/*    */   }
/*    */   
/*    */   public void deleteContents(Object youcangetnoinfoTMAЧ8Тдв) throws IOException {
/*    */     // Byte code:
/*    */     //   0: aload_1
/*    */     //   1: invokevirtual listFiles : ()[Ljava/io/File;
/*    */     //   4: astore_2
/*    */     //   5: aload_2
/*    */     //   6: ifnonnull -> 36
/*    */     //   9: new java/io/IOException
/*    */     //   12: dup
/*    */     //   13: new java/lang/StringBuilder
/*    */     //   16: dup
/*    */     //   17: invokespecial <init> : ()V
/*    */     //   20: ldc 'not a readable directory: '
/*    */     //   22: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   25: aload_1
/*    */     //   26: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*    */     //   29: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   32: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   35: athrow
/*    */     //   36: aload_2
/*    */     //   37: astore_3
/*    */     //   38: aload_3
/*    */     //   39: arraylength
/*    */     //   40: istore #4
/*    */     //   42: iconst_0
/*    */     //   43: istore #5
/*    */     //   45: iload #5
/*    */     //   47: iload #4
/*    */     //   49: if_icmpge -> 114
/*    */     //   52: aload_3
/*    */     //   53: iload #5
/*    */     //   55: aaload
/*    */     //   56: astore #6
/*    */     //   58: aload #6
/*    */     //   60: invokevirtual isDirectory : ()Z
/*    */     //   63: ifeq -> 72
/*    */     //   66: aload_0
/*    */     //   67: aload #6
/*    */     //   69: invokevirtual deleteContents : (Ljava/io/File;)V
/*    */     //   72: aload #6
/*    */     //   74: invokevirtual delete : ()Z
/*    */     //   77: ifne -> 108
/*    */     //   80: new java/io/IOException
/*    */     //   83: dup
/*    */     //   84: new java/lang/StringBuilder
/*    */     //   87: dup
/*    */     //   88: invokespecial <init> : ()V
/*    */     //   91: ldc 'failed to delete '
/*    */     //   93: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
/*    */     //   96: aload #6
/*    */     //   98: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
/*    */     //   101: invokevirtual toString : ()Ljava/lang/String;
/*    */     //   104: invokespecial <init> : (Ljava/lang/String;)V
/*    */     //   107: athrow
/*    */     //   108: iinc #5, 1
/*    */     //   111: goto -> 45
/*    */     //   114: return
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #90	-> 0
/*    */     //   #91	-> 5
/*    */     //   #92	-> 9
/*    */     //   #94	-> 36
/*    */     //   #95	-> 58
/*    */     //   #96	-> 66
/*    */     //   #98	-> 72
/*    */     //   #99	-> 80
/*    */     //   #94	-> 108
/*    */     //   #102	-> 114
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   5	110	2	youcangetnoinfoTMBбэБвс	Ljava/lang/Object;
/*    */     //   0	115	1	youcangetnoinfoTMAЧ8Тдв	Ljava/lang/Object;
/*    */     //   0	115	0	youcangetnoinfoTLZшкапю	Ljava/lang/Object;
/*    */     //   58	50	6	youcangetnoinfoTLYХЩьЩИ	Ljava/lang/Object;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\FileSystem1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */