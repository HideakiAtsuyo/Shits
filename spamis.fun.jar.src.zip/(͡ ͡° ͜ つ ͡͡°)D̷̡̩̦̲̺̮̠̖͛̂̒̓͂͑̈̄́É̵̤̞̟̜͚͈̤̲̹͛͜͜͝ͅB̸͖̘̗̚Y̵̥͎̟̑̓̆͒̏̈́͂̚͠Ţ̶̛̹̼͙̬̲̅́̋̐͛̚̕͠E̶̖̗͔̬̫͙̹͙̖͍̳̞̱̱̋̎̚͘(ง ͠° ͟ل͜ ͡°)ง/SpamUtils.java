/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ import fun.spamis.spammer.SpamIsFun;
/*     */ import java.io.IOException;
/*     */ import java.util.Random;
/*     */ import org.apache.http.HttpEntity;
/*     */ import org.apache.http.HttpHost;
/*     */ import org.apache.http.client.ClientProtocolException;
/*     */ import org.apache.http.client.config.RequestConfig;
/*     */ import org.apache.http.client.methods.HttpDelete;
/*     */ import org.apache.http.client.methods.HttpPost;
/*     */ import org.apache.http.client.methods.HttpPut;
/*     */ import org.apache.http.client.methods.HttpUriRequest;
/*     */ import org.apache.http.entity.StringEntity;
/*     */ import org.apache.http.impl.client.CloseableHttpClient;
/*     */ import org.apache.http.impl.client.HttpClientBuilder;
/*     */ import org.apache.http.util.EntityUtils;
/*     */ import org.json.JSONObject;
/*     */ 
/*     */ public class SpamUtils {
/*     */   public static String user;
/*     */   
/*     */   public SpamUtils() {
/*  23 */     this();
/*     */   }
/*     */   public static CloseableHttpClient httpclient; public static String pw; public static boolean loggedIn = false;
/*     */   
/*     */   static {
/*  28 */     httpclient = HttpClientBuilder.create().build();
/*     */   }
/*     */   
/*     */   public static String join(Object youcangetnoinfoAMMD74югб, Object youcangetnoinfoAMMEИНЫрт, Object youcangetnoinfoAMMF089М6) throws ClientProtocolException, IOException {
/*  32 */     Object youcangetnoinfoAMMGК6хЁц = null;
/*     */     
/*  34 */     Object youcangetnoinfoAMLVёМрЦВ = youcangetnoinfoAMMF089М6.split(":");
/*  35 */     Object youcangetnoinfoAMLWкх4ьВ = new HttpHost((String)youcangetnoinfoAMLVёМрЦВ[0], Integer.parseInt((String)youcangetnoinfoAMLVёМрЦВ[1]), "http");
/*     */ 
/*     */     
/*  38 */     Object youcangetnoinfoAMLXПжБТН = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoAMLWкх4ьВ).setConnectionRequestTimeout(10000).setSocketTimeout(10000).setConnectTimeout(10000).build();
/*  39 */     Object youcangetnoinfoAMLYяЪЩй3 = new HttpPost("https://discordapp.com/api/v6/invites/" + youcangetnoinfoAMMD74югб + "?inputValue=" + youcangetnoinfoAMMD74югб + "&with_counts=true");
/*     */     
/*  41 */     youcangetnoinfoAMLYяЪЩй3.setConfig((RequestConfig)youcangetnoinfoAMLXПжБТН);
/*     */     
/*  43 */     Object youcangetnoinfoAMLZФг7ар = new JSONObject();
/*  44 */     Object youcangetnoinfoAMMA70zжж = new StringEntity(youcangetnoinfoAMLZФг7ар.toString());
/*     */     
/*  46 */     youcangetnoinfoAMLYяЪЩй3.addHeader("Content-type", "application/json");
/*  47 */     youcangetnoinfoAMLYяЪЩй3.addHeader("Authorization", (String)youcangetnoinfoAMMEИНЫрт);
/*  48 */     youcangetnoinfoAMLYяЪЩй3.setEntity((HttpEntity)youcangetnoinfoAMMA70zжж);
/*     */     
/*  50 */     Object youcangetnoinfoAMMBу32б9 = httpclient.execute((HttpUriRequest)youcangetnoinfoAMLYяЪЩй3);
/*  51 */     Object youcangetnoinfoAMMCсШуЗ6 = youcangetnoinfoAMMBу32б9.getEntity();
/*     */     
/*     */     try {
/*  54 */       youcangetnoinfoAMMGК6хЁц = EntityUtils.toString((HttpEntity)youcangetnoinfoAMMCсШуЗ6);
/*  55 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/*  58 */     return (String)youcangetnoinfoAMMGК6хЁц;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String leave(Object youcangetnoinfoEOCSЯжнИж, Object youcangetnoinfoEOCTВогуц, Object youcangetnoinfoEOCUЗШеНЦ) throws IOException, ClientProtocolException {
/*  63 */     Object youcangetnoinfoEOCVнЪ4чх = null;
/*     */     
/*  65 */     Object youcangetnoinfoEOCMзРР1б = youcangetnoinfoEOCUЗШеНЦ.split(":");
/*  66 */     Object youcangetnoinfoEOCNКгвЛ5 = new HttpHost((String)youcangetnoinfoEOCMзРР1б[0], Integer.parseInt((String)youcangetnoinfoEOCMзРР1б[1]), "http");
/*     */ 
/*     */     
/*  69 */     Object youcangetnoinfoEOCOэуДю6 = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoEOCNКгвЛ5).setConnectionRequestTimeout(3000).setSocketTimeout(3000).setConnectTimeout(3000).build();
/*  70 */     Object youcangetnoinfoEOCPИнврд = new HttpDelete("https://discordapp.com/api/v6/users/@me/guilds/" + youcangetnoinfoEOCSЯжнИж);
/*  71 */     youcangetnoinfoEOCPИнврд.setConfig((RequestConfig)youcangetnoinfoEOCOэуДю6);
/*     */     
/*  73 */     youcangetnoinfoEOCPИнврд.addHeader("Authorization", (String)youcangetnoinfoEOCTВогуц);
/*     */     
/*  75 */     Object youcangetnoinfoEOCQёЪЙ5Б = httpclient.execute((HttpUriRequest)youcangetnoinfoEOCPИнврд);
/*  76 */     Object youcangetnoinfoEOCRдВшПШ = youcangetnoinfoEOCQёЪЙ5Б.getEntity();
/*     */     
/*     */     try {
/*  79 */       youcangetnoinfoEOCVнЪ4чх = EntityUtils.toString((HttpEntity)youcangetnoinfoEOCRдВшПШ);
/*  80 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/*  83 */     return (String)youcangetnoinfoEOCVнЪ4чх;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String addReaction(Object youcangetnoinfoFKUЧрЭыШ, Object youcangetnoinfoFKVИажЛц, Object youcangetnoinfoFKWееКщЬ, Object youcangetnoinfoFKXУ6мШ7, Object youcangetnoinfoFKYмОъчх) throws ClientProtocolException, IOException {
/*  88 */     Object youcangetnoinfoFKZОЗЧЪШ = null;
/*     */     
/*  90 */     Object youcangetnoinfoFKOиякгГ = youcangetnoinfoFKYмОъчх.split(":");
/*  91 */     Object youcangetnoinfoFKPИзйЙ8 = new HttpHost((String)youcangetnoinfoFKOиякгГ[0], Integer.parseInt((String)youcangetnoinfoFKOиякгГ[1]), "http");
/*     */ 
/*     */     
/*  94 */     Object youcangetnoinfoFKQЪК4щЗ = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoFKPИзйЙ8).setConnectionRequestTimeout(3000).setSocketTimeout(3000).setConnectTimeout(3000).build();
/*  95 */     Object youcangetnoinfoFKRшЭУ2в = new HttpPut("https://discordapp.com/api/v6/channels/" + youcangetnoinfoFKUЧрЭыШ + "/messages/" + youcangetnoinfoFKVИажЛц + "/reactions/" + youcangetnoinfoFKWееКщЬ + "/%40me");
/*  96 */     youcangetnoinfoFKRшЭУ2в.setConfig((RequestConfig)youcangetnoinfoFKQЪК4щЗ);
/*     */     
/*  98 */     youcangetnoinfoFKRшЭУ2в.addHeader("Authorization", (String)youcangetnoinfoFKXУ6мШ7);
/*     */     
/* 100 */     Object youcangetnoinfoFKSЫВр1ё = httpclient.execute((HttpUriRequest)youcangetnoinfoFKRшЭУ2в);
/* 101 */     Object youcangetnoinfoFKTлЙФяз = youcangetnoinfoFKSЫВр1ё.getEntity();
/*     */     
/*     */     try {
/* 104 */       youcangetnoinfoFKZОЗЧЪШ = EntityUtils.toString((HttpEntity)youcangetnoinfoFKTлЙФяз);
/* 105 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 108 */     return (String)youcangetnoinfoFKZОЗЧЪШ;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String removeReaction(Object youcangetnoinfoCBPRалДО8, Object youcangetnoinfoCBPSвЩТЦС, Object youcangetnoinfoCBPT1аДбЛ, Object youcangetnoinfoCBPU2ыЯя9, Object youcangetnoinfoCBPVяфчв5) throws IOException, ClientProtocolException {
/* 113 */     Object youcangetnoinfoCBPWЮ1Ицй = null;
/*     */     
/* 115 */     Object youcangetnoinfoCBPLТЮРфЫ = youcangetnoinfoCBPVяфчв5.split(":");
/* 116 */     Object youcangetnoinfoCBPMЖОЕюж = new HttpHost((String)youcangetnoinfoCBPLТЮРфЫ[0], Integer.parseInt((String)youcangetnoinfoCBPLТЮРфЫ[1]), "http");
/*     */ 
/*     */     
/* 119 */     Object youcangetnoinfoCBPN3ЙХ4Р = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoCBPMЖОЕюж).setConnectionRequestTimeout(3000).setSocketTimeout(3000).setConnectTimeout(3000).build();
/* 120 */     Object youcangetnoinfoCBPOТвЭуЕ = new HttpDelete("https://discordapp.com/api/v6/channels/" + youcangetnoinfoCBPRалДО8 + "/messages/" + youcangetnoinfoCBPSвЩТЦС + "/reactions/" + youcangetnoinfoCBPT1аДбЛ + "/%40me");
/* 121 */     youcangetnoinfoCBPOТвЭуЕ.setConfig((RequestConfig)youcangetnoinfoCBPN3ЙХ4Р);
/*     */     
/* 123 */     youcangetnoinfoCBPOТвЭуЕ.addHeader("Authorization", (String)youcangetnoinfoCBPU2ыЯя9);
/*     */     
/* 125 */     Object youcangetnoinfoCBPP0Ыкну = httpclient.execute((HttpUriRequest)youcangetnoinfoCBPOТвЭуЕ);
/* 126 */     Object youcangetnoinfoCBPQусГД7 = youcangetnoinfoCBPP0Ыкну.getEntity();
/*     */     
/*     */     try {
/* 129 */       youcangetnoinfoCBPWЮ1Ицй = EntityUtils.toString((HttpEntity)youcangetnoinfoCBPQусГД7);
/* 130 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 133 */     return (String)youcangetnoinfoCBPWЮ1Ицй;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String typing(Object youcangetnoinfoAQGZлАнУБ, Object youcangetnoinfoAQHAННьОЙ, Object youcangetnoinfoAQHBДфаЧВ) throws ClientProtocolException, IOException {
/* 138 */     Object youcangetnoinfoAQHCк4ьоИ = null;
/*     */     
/* 140 */     Object youcangetnoinfoAQGTЛТмфн = youcangetnoinfoAQHBДфаЧВ.split(":");
/* 141 */     Object youcangetnoinfoAQGU9Хэу7 = new HttpHost((String)youcangetnoinfoAQGTЛТмфн[0], Integer.parseInt((String)youcangetnoinfoAQGTЛТмфн[1]), "http");
/*     */ 
/*     */     
/* 144 */     Object youcangetnoinfoAQGV5ХйЪс = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoAQGU9Хэу7).setConnectionRequestTimeout(3000).setSocketTimeout(3000).setConnectTimeout(3000).build();
/* 145 */     Object youcangetnoinfoAQGWЮПчфУ = new HttpPost("https://discordapp.com/api/v6/channels/" + youcangetnoinfoAQGZлАнУБ + "/typing");
/* 146 */     youcangetnoinfoAQGWЮПчфУ.setConfig((RequestConfig)youcangetnoinfoAQGV5ХйЪс);
/*     */     
/* 148 */     youcangetnoinfoAQGWЮПчфУ.addHeader("Authorization", (String)youcangetnoinfoAQHAННьОЙ);
/*     */     
/* 150 */     Object youcangetnoinfoAQGXвцЩ7ж = httpclient.execute((HttpUriRequest)youcangetnoinfoAQGWЮПчфУ);
/* 151 */     Object youcangetnoinfoAQGY4Но3я = youcangetnoinfoAQGXвцЩ7ж.getEntity();
/*     */     
/*     */     try {
/* 154 */       youcangetnoinfoAQHCк4ьоИ = EntityUtils.toString((HttpEntity)youcangetnoinfoAQGY4Но3я);
/* 155 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 158 */     return (String)youcangetnoinfoAQHCк4ьоИ;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String addFriend(Object youcangetnoinfoCYAFУАД5Т, Object youcangetnoinfoCYAG9ЪЗоа, Object youcangetnoinfoCYAHоьЕz1) throws ClientProtocolException, IOException {
/* 163 */     Object youcangetnoinfoCYAIо4УТЁ = null;
/*     */     
/* 165 */     Object youcangetnoinfoCXZXЮиЖ8Н = youcangetnoinfoCYAHоьЕz1.split(":");
/* 166 */     Object youcangetnoinfoCXZYлzнъЕ = new HttpHost((String)youcangetnoinfoCXZXЮиЖ8Н[0], Integer.parseInt((String)youcangetnoinfoCXZXЮиЖ8Н[1]), "http");
/*     */     
/* 168 */     Object youcangetnoinfoCXZZ8Нпзъ = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoCXZYлzнъЕ).setConnectTimeout(5000).build();
/* 169 */     Object youcangetnoinfoCYAA8йШЁи = new HttpPut("https://discordapp.com/api/v6/users/@me/relationships/" + youcangetnoinfoCYAFУАД5Т);
/* 170 */     youcangetnoinfoCYAA8йШЁи.setConfig((RequestConfig)youcangetnoinfoCXZZ8Нпзъ);
/*     */     
/* 172 */     Object youcangetnoinfoCYABфкХцС = new JSONObject();
/* 173 */     Object youcangetnoinfoCYACзАмь4 = new StringEntity(youcangetnoinfoCYABфкХцС.toString());
/*     */     
/* 175 */     youcangetnoinfoCYAA8йШЁи.addHeader("Content-type", "application/json");
/* 176 */     youcangetnoinfoCYAA8йШЁи.addHeader("Authorization", (String)youcangetnoinfoCYAG9ЪЗоа);
/* 177 */     youcangetnoinfoCYAA8йШЁи.setEntity((HttpEntity)youcangetnoinfoCYACзАмь4);
/*     */ 
/*     */     
/* 180 */     Object youcangetnoinfoCYADтфПДЪ = httpclient.execute((HttpUriRequest)youcangetnoinfoCYAA8йШЁи);
/* 181 */     Object youcangetnoinfoCYAEеЯЪцй = youcangetnoinfoCYADтфПДЪ.getEntity();
/*     */     
/*     */     try {
/* 184 */       youcangetnoinfoCYAIо4УТЁ = EntityUtils.toString((HttpEntity)youcangetnoinfoCYAEеЯЪцй);
/* 185 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 188 */     return (String)youcangetnoinfoCYAIо4УТЁ;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String deleteFriend(Object youcangetnoinfoEISLЦлЭВЯ, Object youcangetnoinfoEISM0ЪсКz, Object youcangetnoinfoEISNИжщрЧ) throws ClientProtocolException, IOException {
/* 193 */     Object youcangetnoinfoEISOЫцэ4Щ = null;
/*     */     
/* 195 */     Object youcangetnoinfoEISFибжщЯ = youcangetnoinfoEISNИжщрЧ.split(":");
/* 196 */     Object youcangetnoinfoEISGияУвк = new HttpHost((String)youcangetnoinfoEISFибжщЯ[0], Integer.parseInt((String)youcangetnoinfoEISFибжщЯ[1]), "http");
/*     */     
/* 198 */     Object youcangetnoinfoEISHц2сМш = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoEISGияУвк).setConnectTimeout(500).build();
/* 199 */     Object youcangetnoinfoEISIЦЯйд4 = new HttpDelete("https://discordapp.com/api/v6/users/@me/relationships/" + youcangetnoinfoEISLЦлЭВЯ);
/* 200 */     youcangetnoinfoEISIЦЯйд4.setConfig((RequestConfig)youcangetnoinfoEISHц2сМш);
/*     */     
/* 202 */     youcangetnoinfoEISIЦЯйд4.addHeader("Authorization", (String)youcangetnoinfoEISM0ЪсКz);
/*     */     
/* 204 */     Object youcangetnoinfoEISJгЛрюЧ = httpclient.execute((HttpUriRequest)youcangetnoinfoEISIЦЯйд4);
/* 205 */     Object youcangetnoinfoEISKТЬкхЁ = youcangetnoinfoEISJгЛрюЧ.getEntity();
/*     */     
/*     */     try {
/* 208 */       youcangetnoinfoEISOЫцэ4Щ = EntityUtils.toString((HttpEntity)youcangetnoinfoEISKТЬкхЁ);
/* 209 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 212 */     return (String)youcangetnoinfoEISOЫцэ4Щ;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String sendMsg(Object youcangetnoinfoBBPH1АкХо, Object youcangetnoinfoBBPIЗУЦМд, Object youcangetnoinfoBBPJ2Ыеб6, Object youcangetnoinfoBBPKыэыПс, Object youcangetnoinfoBBPLтчОИэ) throws IOException, ClientProtocolException {
/* 217 */     Object youcangetnoinfoBBPMШД7щ6 = null;
/*     */     
/* 219 */     Object youcangetnoinfoBBOZгеолм = youcangetnoinfoBBPLтчОИэ.split(":");
/* 220 */     Object youcangetnoinfoBBPAкЙл8г = new HttpHost((String)youcangetnoinfoBBOZгеолм[0], Integer.parseInt((String)youcangetnoinfoBBOZгеолм[1]), "http");
/*     */ 
/*     */     
/* 223 */     Object youcangetnoinfoBBPB24Эъэ = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoBBPAкЙл8г).setConnectionRequestTimeout(1000).setSocketTimeout(1000).setConnectTimeout(1000).build();
/* 224 */     Object youcangetnoinfoBBPCТжфчУ = new HttpPost("https://discordapp.com/api/v6/channels/" + youcangetnoinfoBBPH1АкХо + "/messages");
/* 225 */     youcangetnoinfoBBPCТжфчУ.setConfig((RequestConfig)youcangetnoinfoBBPB24Эъэ);
/*     */     
/* 227 */     Object youcangetnoinfoBBPDт9Ёп0 = new JSONObject();
/* 228 */     youcangetnoinfoBBPDт9Ёп0.put("content", youcangetnoinfoBBPIЗУЦМд);
/* 229 */     if (youcangetnoinfoBBPJ2Ыеб6 != null) {
/* 230 */       youcangetnoinfoBBPDт9Ёп0.put("tts", "true");
/*     */     }
/* 232 */     Object youcangetnoinfoBBPEСЛ8юЯ = new StringEntity(youcangetnoinfoBBPDт9Ёп0.toString());
/*     */     
/* 234 */     youcangetnoinfoBBPCТжфчУ.addHeader("Content-type", "application/json");
/* 235 */     youcangetnoinfoBBPCТжфчУ.addHeader("Authorization", (String)youcangetnoinfoBBPKыэыПс);
/* 236 */     youcangetnoinfoBBPCТжфчУ.setEntity((HttpEntity)youcangetnoinfoBBPEСЛ8юЯ);
/*     */     
/* 238 */     Object youcangetnoinfoBBPFЯДЧ6ф = httpclient.execute((HttpUriRequest)youcangetnoinfoBBPCТжфчУ);
/* 239 */     Object youcangetnoinfoBBPG6цк1ч = youcangetnoinfoBBPFЯДЧ6ф.getEntity();
/*     */     
/* 241 */     youcangetnoinfoBBPMШД7щ6 = EntityUtils.toString((HttpEntity)youcangetnoinfoBBPG6цк1ч);
/*     */     
/* 243 */     return (String)youcangetnoinfoBBPMШД7щ6;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String getOwnID(Object youcangetnoinfoDYZCzФЪЕп, Object youcangetnoinfoDYZDЖё1ГР) throws ClientProtocolException, IOException {
/* 248 */     Object youcangetnoinfoDYZEеЁЕеа = null;
/*     */     
/* 250 */     Object youcangetnoinfoDYYUСу53Щ = youcangetnoinfoDYZDЖё1ГР.split(":");
/* 251 */     Object youcangetnoinfoDYYVябг47 = new HttpHost((String)youcangetnoinfoDYYUСу53Щ[0], Integer.parseInt((String)youcangetnoinfoDYYUСу53Щ[1]), "http");
/*     */     
/* 253 */     Object youcangetnoinfoDYYWЁ6ор2 = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoDYYVябг47).setConnectTimeout(5000).build();
/* 254 */     Object youcangetnoinfoDYYX9Хз6и = new HttpPut("https://discordapp.com/api/v6/users/@me/");
/* 255 */     youcangetnoinfoDYYX9Хз6и.setConfig((RequestConfig)youcangetnoinfoDYYWЁ6ор2);
/*     */     
/* 257 */     Object youcangetnoinfoDYYYЗьчЦЧ = new JSONObject();
/* 258 */     Object youcangetnoinfoDYYZжбд5Л = new StringEntity(youcangetnoinfoDYYYЗьчЦЧ.toString());
/*     */     
/* 260 */     youcangetnoinfoDYYX9Хз6и.addHeader("Content-type", "application/json");
/* 261 */     youcangetnoinfoDYYX9Хз6и.addHeader("Authorization", (String)youcangetnoinfoDYZCzФЪЕп);
/* 262 */     youcangetnoinfoDYYX9Хз6и.setEntity((HttpEntity)youcangetnoinfoDYYZжбд5Л);
/*     */ 
/*     */     
/* 265 */     Object youcangetnoinfoDYZAХчрЭ4 = httpclient.execute((HttpUriRequest)youcangetnoinfoDYYX9Хз6и);
/* 266 */     Object youcangetnoinfoDYZBЯдГЪЁ = youcangetnoinfoDYZAХчрЭ4.getEntity();
/*     */     
/*     */     try {
/* 269 */       youcangetnoinfoDYZEеЁЕеа = EntityUtils.toString((HttpEntity)youcangetnoinfoDYZBЯдГЪЁ);
/* 270 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 273 */     return (String)youcangetnoinfoDYZEеЁЕеа;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String openDM(Object youcangetnoinfoBXUYЫяИЪр, Object youcangetnoinfoBXUZьфИМ8, Object youcangetnoinfoBXVAвЦТнЯ) throws ClientProtocolException, IOException {
/* 278 */     Object youcangetnoinfoBXVBЛш3УЙ = null;
/*     */     
/* 280 */     Object youcangetnoinfoBXUQПбж2з = youcangetnoinfoBXVAвЦТнЯ.split(":");
/* 281 */     Object youcangetnoinfoBXURЕБтЬщ = new HttpHost((String)youcangetnoinfoBXUQПбж2з[0], Integer.parseInt((String)youcangetnoinfoBXUQПбж2з[1]), "http");
/*     */ 
/*     */     
/* 284 */     Object youcangetnoinfoBXUS3бгзъ = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoBXURЕБтЬщ).setConnectionRequestTimeout(1000).setSocketTimeout(1000).setConnectTimeout(1000).build();
/* 285 */     Object youcangetnoinfoBXUTи5цдё = new HttpPost("https://discordapp.com/api/v6/users/620344058874822656/channels");
/* 286 */     youcangetnoinfoBXUTи5цдё.setConfig((RequestConfig)youcangetnoinfoBXUS3бгзъ);
/*     */     
/* 288 */     Object youcangetnoinfoBXUUнХшфэ = new JSONObject();
/* 289 */     youcangetnoinfoBXUUнХшфэ.put("recipients", youcangetnoinfoBXUYЫяИЪр);
/*     */     
/* 291 */     Object youcangetnoinfoBXUVДЧЫёЗ = new StringEntity(youcangetnoinfoBXUUнХшфэ.toString());
/*     */     
/* 293 */     youcangetnoinfoBXUTи5цдё.addHeader("Content-type", "application/json");
/* 294 */     youcangetnoinfoBXUTи5цдё.addHeader("Authorization", (String)youcangetnoinfoBXUZьфИМ8);
/* 295 */     youcangetnoinfoBXUTи5цдё.setEntity((HttpEntity)youcangetnoinfoBXUVДЧЫёЗ);
/*     */     
/* 297 */     Object youcangetnoinfoBXUWпЮюБz = httpclient.execute((HttpUriRequest)youcangetnoinfoBXUTи5цдё);
/* 298 */     Object youcangetnoinfoBXUXЧбНС4 = youcangetnoinfoBXUWпЮюБz.getEntity();
/*     */     
/* 300 */     youcangetnoinfoBXVBЛш3УЙ = EntityUtils.toString((HttpEntity)youcangetnoinfoBXUXЧбНС4);
/*     */     
/* 302 */     return (String)youcangetnoinfoBXVBЛш3УЙ;
/*     */   }
/*     */ 
/*     */   
/*     */   public static String sendDM(Object youcangetnoinfoDJSGzвфМа, Object youcangetnoinfoDJSHщ5алж, Object youcangetnoinfoDJSIю7Чви, Object youcangetnoinfoDJSJи6ЩР8, Object youcangetnoinfoDJSKИянлЖ) throws ClientProtocolException, IOException {
/* 307 */     Object youcangetnoinfoDJSLК8Дпп = null;
/*     */     
/* 309 */     Object youcangetnoinfoDJRYцотаР = youcangetnoinfoDJSKИянлЖ.split(":");
/* 310 */     Object youcangetnoinfoDJRZф7Дзд = new HttpHost((String)youcangetnoinfoDJRYцотаР[0], Integer.parseInt((String)youcangetnoinfoDJRYцотаР[1]), "http");
/*     */ 
/*     */     
/* 313 */     Object youcangetnoinfoDJSAЫЧЩм9 = RequestConfig.custom().setProxy((HttpHost)youcangetnoinfoDJRZф7Дзд).setConnectionRequestTimeout(1000).setSocketTimeout(1000).setConnectTimeout(1000).build();
/* 314 */     Object youcangetnoinfoDJSBЕ41ЗХ = new HttpPost("https://discordapp.com/api/v6/channels/" + youcangetnoinfoDJSGzвфМа + "/messages");
/* 315 */     youcangetnoinfoDJSBЕ41ЗХ.setConfig((RequestConfig)youcangetnoinfoDJSAЫЧЩм9);
/*     */     
/* 317 */     Object youcangetnoinfoDJSC3сХ1Ы = new JSONObject();
/* 318 */     youcangetnoinfoDJSC3сХ1Ы.put("content", youcangetnoinfoDJSHщ5алж);
/* 319 */     if (youcangetnoinfoDJSIю7Чви != null) {
/* 320 */       youcangetnoinfoDJSC3сХ1Ы.put("tts", "true");
/*     */     }
/* 322 */     Object youcangetnoinfoDJSDСыа0н = new StringEntity(youcangetnoinfoDJSC3сХ1Ы.toString());
/*     */     
/* 324 */     youcangetnoinfoDJSBЕ41ЗХ.addHeader("Content-type", "application/json");
/* 325 */     youcangetnoinfoDJSBЕ41ЗХ.addHeader("Authorization", (String)youcangetnoinfoDJSJи6ЩР8);
/* 326 */     youcangetnoinfoDJSBЕ41ЗХ.setEntity((HttpEntity)youcangetnoinfoDJSDСыа0н);
/*     */     
/* 328 */     Object youcangetnoinfoDJSEБ2а4Ф = httpclient.execute((HttpUriRequest)youcangetnoinfoDJSBЕ41ЗХ);
/* 329 */     Object youcangetnoinfoDJSFЕубзЦ = youcangetnoinfoDJSEБ2а4Ф.getEntity();
/*     */     
/* 331 */     youcangetnoinfoDJSLК8Дпп = EntityUtils.toString((HttpEntity)youcangetnoinfoDJSFЕубзЦ);
/*     */     
/* 333 */     return (String)youcangetnoinfoDJSLК8Дпп;
/*     */   }
/*     */   
/*     */   public static String getRandomProxy() {
/* 337 */     Object youcangetnoinfoCVHUДСрц4 = SpamIsFun.proxys.keySet().toArray()[(new Random()).nextInt((SpamIsFun.proxys.keySet().toArray()).length)];
/* 338 */     return (String)SpamIsFun.proxys.get(youcangetnoinfoCVHUДСрц4);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\SpamUtils.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */