/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.TreeSet;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class HttpHeaders
/*     */ {
/*  45 */   public static final ByteString QUOTED_STRING_DELIMITERS = ByteString.encodeUtf8("\"\\");
/*  46 */   public static final ByteString TOKEN_DELIMITERS = ByteString.encodeUtf8("\t ,=");
/*     */   public HttpHeaders() {
/*  48 */     this();
/*     */   }
/*     */   
/*     */   public static long contentLength(Object youcangetnoinfoHJDИйбБы) {
/*  52 */     return contentLength(youcangetnoinfoHJDИйбБы.headers());
/*     */   }
/*     */   
/*     */   public static long contentLength(Object youcangetnoinfoCSZWф2Сцс) {
/*  56 */     return stringToLong(youcangetnoinfoCSZWф2Сцс.get("Content-Length"));
/*     */   }
/*     */   
/*     */   public static long stringToLong(Object youcangetnoinfoSPLИ3пЩс) {
/*  60 */     if (youcangetnoinfoSPLИ3пЩс == null) return -1L; 
/*     */     try {
/*  62 */       return Long.parseLong((String)youcangetnoinfoSPLИ3пЩс);
/*  63 */     } catch (NumberFormatException youcangetnoinfoSPKКкщХё) {
/*  64 */       return -1L;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean varyMatches(Object youcangetnoinfoAQNK1д9сТ, Object youcangetnoinfoAQNLЮЦz7К, Object youcangetnoinfoAQNMьЫрзР) {
/*  74 */     for (Object youcangetnoinfoAQNJЫК8ЫА : varyFields((Response)youcangetnoinfoAQNK1д9сТ)) {
/*  75 */       if (!Objects.equals(youcangetnoinfoAQNLЮЦz7К.values((String)youcangetnoinfoAQNJЫК8ЫА), youcangetnoinfoAQNMьЫрзР.headers((String)youcangetnoinfoAQNJЫК8ЫА))) return false; 
/*     */     } 
/*  77 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasVaryAll(Object youcangetnoinfoDSLW1ЁЯЭй) {
/*  84 */     return hasVaryAll(youcangetnoinfoDSLW1ЁЯЭй.headers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasVaryAll(Object youcangetnoinfoCIDDИйи4Ч) {
/*  91 */     return varyFields((Headers)youcangetnoinfoCIDDИйи4Ч).contains("*");
/*     */   }
/*     */   
/*     */   public static Set varyFields(Object youcangetnoinfoCKKMбЗЧУу) {
/*  95 */     return varyFields(youcangetnoinfoCKKMбЗЧУу.headers());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Set varyFields(Object youcangetnoinfoBWQTурзюЛ) {
/* 102 */     Object<?> youcangetnoinfoBWQUбВ1мл = (Object<?>)Collections.emptySet(); byte b; int i;
/* 103 */     for (b = 0, i = youcangetnoinfoBWQTурзюЛ.size(); b < i; b++) {
/* 104 */       if ("Vary".equalsIgnoreCase(youcangetnoinfoBWQTурзюЛ.name(b))) {
/*     */         
/* 106 */         Object youcangetnoinfoBWQQЖвШПч = youcangetnoinfoBWQTурзюЛ.value(b);
/* 107 */         if (youcangetnoinfoBWQUбВ1мл.isEmpty()) {
/* 108 */           youcangetnoinfoBWQUбВ1мл = (Object<?>)new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
/*     */         }
/* 110 */         for (String youcangetnoinfoBWQPzюыт6 : youcangetnoinfoBWQQЖвШПч.split(","))
/* 111 */           youcangetnoinfoBWQUбВ1мл.add(youcangetnoinfoBWQPzюыт6.trim()); 
/*     */       } 
/*     */     } 
/* 114 */     return (Set)youcangetnoinfoBWQUбВ1мл;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Headers varyHeaders(Object youcangetnoinfoCWKDшрфМЙ) {
/* 125 */     Object youcangetnoinfoCWKEяРчЛю = youcangetnoinfoCWKDшрфМЙ.networkResponse().request().headers();
/* 126 */     Object youcangetnoinfoCWKFъёЁзЦ = youcangetnoinfoCWKDшрфМЙ.headers();
/* 127 */     return varyHeaders((Headers)youcangetnoinfoCWKEяРчЛю, (Headers)youcangetnoinfoCWKFъёЁзЦ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Headers varyHeaders(Object youcangetnoinfoEDZKгго1М, Object youcangetnoinfoEDZLяПюМя) {
/* 135 */     Object youcangetnoinfoEDZMЮтЯн1 = varyFields((Headers)youcangetnoinfoEDZLяПюМя);
/* 136 */     if (youcangetnoinfoEDZMЮтЯн1.isEmpty()) return Util1.EMPTY_HEADERS;
/*     */     
/* 138 */     Object youcangetnoinfoEDZNЫцБбё = new Headers1(); byte b; int i;
/* 139 */     for (b = 0, i = youcangetnoinfoEDZKгго1М.size(); b < i; b++) {
/* 140 */       Object youcangetnoinfoEDZHфмЙДС = youcangetnoinfoEDZKгго1М.name(b);
/* 141 */       if (youcangetnoinfoEDZMЮтЯн1.contains(youcangetnoinfoEDZHфмЙДС)) {
/* 142 */         youcangetnoinfoEDZNЫцБбё.add((String)youcangetnoinfoEDZHфмЙДС, youcangetnoinfoEDZKгго1М.value(b));
/*     */       }
/*     */     } 
/* 145 */     return youcangetnoinfoEDZNЫцБбё.build();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static List parseChallenges(Object youcangetnoinfoBHZQВщёМЩ, Object youcangetnoinfoBHZRМ8хЁВ) {
/* 170 */     Object youcangetnoinfoBHZSПеууб = new ArrayList();
/* 171 */     for (byte b = 0; b < youcangetnoinfoBHZQВщёМЩ.size(); b++) {
/* 172 */       if (youcangetnoinfoBHZRМ8хЁВ.equalsIgnoreCase(youcangetnoinfoBHZQВщёМЩ.name(b))) {
/* 173 */         Object youcangetnoinfoBHZOхэХат = (new Buffer2()).writeUtf8(youcangetnoinfoBHZQВщёМЩ.value(b));
/* 174 */         parseChallengeHeader((List)youcangetnoinfoBHZSПеууб, (Buffer2)youcangetnoinfoBHZOхэХат);
/*     */       } 
/*     */     } 
/* 177 */     return (List)youcangetnoinfoBHZSПеууб;
/*     */   }
/*     */   
/*     */   public static void parseChallengeHeader(Object youcangetnoinfoAWHQпАНЖу, Object youcangetnoinfoAWHRФКгРЮ) {
/* 181 */     Object youcangetnoinfoAWHSЧфzчГ = null;
/*     */ 
/*     */     
/*     */     while (true) {
/* 185 */       if (youcangetnoinfoAWHSЧфzчГ == null) {
/* 186 */         skipWhitespaceAndCommas((Buffer2)youcangetnoinfoAWHRФКгРЮ);
/* 187 */         youcangetnoinfoAWHSЧфzчГ = readToken((Buffer2)youcangetnoinfoAWHRФКгРЮ);
/* 188 */         if (youcangetnoinfoAWHSЧфzчГ == null)
/*     */           return; 
/*     */       } 
/* 191 */       Object youcangetnoinfoAWHLеч1Им = youcangetnoinfoAWHSЧфzчГ;
/*     */ 
/*     */       
/* 194 */       boolean bool1 = skipWhitespaceAndCommas((Buffer2)youcangetnoinfoAWHRФКгРЮ);
/* 195 */       youcangetnoinfoAWHSЧфzчГ = readToken((Buffer2)youcangetnoinfoAWHRФКгРЮ);
/* 196 */       if (youcangetnoinfoAWHSЧфzчГ == null) {
/* 197 */         if (!youcangetnoinfoAWHRФКгРЮ.exhausted())
/* 198 */           return;  youcangetnoinfoAWHQпАНЖу.add(new Challenge((String)youcangetnoinfoAWHLеч1Им, Collections.emptyMap()));
/*     */         
/*     */         return;
/*     */       } 
/* 202 */       int i = skipAll((Buffer2)youcangetnoinfoAWHRФКгРЮ, (byte)61);
/* 203 */       boolean bool2 = skipWhitespaceAndCommas((Buffer2)youcangetnoinfoAWHRФКгРЮ);
/*     */ 
/*     */       
/* 206 */       if (!bool1 && (bool2 || youcangetnoinfoAWHRФКгРЮ.exhausted())) {
/* 207 */         youcangetnoinfoAWHQпАНЖу.add(new Challenge((String)youcangetnoinfoAWHLеч1Им, Collections.singletonMap(null, youcangetnoinfoAWHSЧфzчГ + 
/* 208 */                 repeat('=', i))));
/* 209 */         youcangetnoinfoAWHSЧфzчГ = null;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 214 */       Object<Object, Object> youcangetnoinfoAWHPzьН1Г = (Object<Object, Object>)new LinkedHashMap<>();
/* 215 */       i += skipAll((Buffer2)youcangetnoinfoAWHRФКгРЮ, (byte)61);
/*     */       while (true) {
/* 217 */         if (youcangetnoinfoAWHSЧфzчГ == null) {
/* 218 */           youcangetnoinfoAWHSЧфzчГ = readToken((Buffer2)youcangetnoinfoAWHRФКгРЮ);
/* 219 */           if (skipWhitespaceAndCommas((Buffer2)youcangetnoinfoAWHRФКгРЮ))
/* 220 */             break;  i = skipAll((Buffer2)youcangetnoinfoAWHRФКгРЮ, (byte)61);
/*     */         } 
/* 222 */         if (i == 0)
/* 223 */           break;  if (i > 1)
/* 224 */           return;  if (skipWhitespaceAndCommas((Buffer2)youcangetnoinfoAWHRФКгРЮ)) {
/*     */           return;
/*     */         }
/*     */         
/* 228 */         Object youcangetnoinfoAWHJ98Цх3 = (!youcangetnoinfoAWHRФКгРЮ.exhausted() && youcangetnoinfoAWHRФКгРЮ.getByte(0L) == 34) ? readQuotedString((Buffer2)youcangetnoinfoAWHRФКгРЮ) : readToken((Buffer2)youcangetnoinfoAWHRФКгРЮ);
/* 229 */         if (youcangetnoinfoAWHJ98Цх3 == null)
/* 230 */           return;  Object youcangetnoinfoAWHK8МЬЪп = youcangetnoinfoAWHPzьН1Г.put(youcangetnoinfoAWHSЧфzчГ, youcangetnoinfoAWHJ98Цх3);
/* 231 */         youcangetnoinfoAWHSЧфzчГ = null;
/* 232 */         if (youcangetnoinfoAWHK8МЬЪп != null)
/* 233 */           return;  if (!skipWhitespaceAndCommas((Buffer2)youcangetnoinfoAWHRФКгРЮ) && !youcangetnoinfoAWHRФКгРЮ.exhausted())
/*     */           return; 
/* 235 */       }  youcangetnoinfoAWHQпАНЖу.add(new Challenge((String)youcangetnoinfoAWHLеч1Им, (Map)youcangetnoinfoAWHPzьН1Г));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean skipWhitespaceAndCommas(Object youcangetnoinfoIEPППЩ0д) {
/* 241 */     boolean bool = false;
/* 242 */     while (!youcangetnoinfoIEPППЩ0д.exhausted()) {
/* 243 */       byte b = youcangetnoinfoIEPППЩ0д.getByte(0L);
/* 244 */       if (b == 44) {
/* 245 */         youcangetnoinfoIEPППЩ0д.readByte();
/* 246 */         bool = true; continue;
/* 247 */       }  if (b == 32 || b == 9) {
/* 248 */         youcangetnoinfoIEPППЩ0д.readByte();
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 253 */     return bool;
/*     */   }
/*     */   
/*     */   public static int skipAll(Object youcangetnoinfoBPKUбЭЭЫА, Object youcangetnoinfoBPKVВ3ЁТр) {
/* 257 */     byte b = 0;
/* 258 */     while (!youcangetnoinfoBPKUбЭЭЫА.exhausted() && youcangetnoinfoBPKUбЭЭЫА.getByte(0L) == youcangetnoinfoBPKVВ3ЁТр) {
/* 259 */       b++;
/* 260 */       youcangetnoinfoBPKUбЭЭЫА.readByte();
/*     */     } 
/* 262 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String readQuotedString(Object youcangetnoinfoAVAWфкдуу) {
/* 271 */     if (youcangetnoinfoAVAWфкдуу.readByte() != 34) throw new IllegalArgumentException(); 
/* 272 */     Object youcangetnoinfoAVAXшнЫьК = new Buffer2();
/*     */     while (true) {
/* 274 */       long l = youcangetnoinfoAVAWфкдуу.indexOfElement(QUOTED_STRING_DELIMITERS);
/* 275 */       if (l == -1L) return null;
/*     */       
/* 277 */       if (youcangetnoinfoAVAWфкдуу.getByte(l) == 34) {
/* 278 */         youcangetnoinfoAVAXшнЫьК.write((Buffer2)youcangetnoinfoAVAWфкдуу, l);
/* 279 */         youcangetnoinfoAVAWфкдуу.readByte();
/* 280 */         return youcangetnoinfoAVAXшнЫьК.readUtf8();
/*     */       } 
/*     */       
/* 283 */       if (youcangetnoinfoAVAWфкдуу.size() == l + 1L) return null; 
/* 284 */       youcangetnoinfoAVAXшнЫьК.write((Buffer2)youcangetnoinfoAVAWфкдуу, l);
/* 285 */       youcangetnoinfoAVAWфкдуу.readByte();
/* 286 */       youcangetnoinfoAVAXшнЫьК.write((Buffer2)youcangetnoinfoAVAWфкдуу, 1L);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String readToken(Object youcangetnoinfoBRJYЕВёг9) {
/*     */     try {
/* 296 */       long l = youcangetnoinfoBRJYЕВёг9.indexOfElement(TOKEN_DELIMITERS);
/* 297 */       if (l == -1L) l = youcangetnoinfoBRJYЕВёг9.size();
/*     */       
/* 299 */       return (l != 0L) ? 
/* 300 */         youcangetnoinfoBRJYЕВёг9.readUtf8(l) : 
/* 301 */         null;
/* 302 */     } catch (EOFException youcangetnoinfoBRJXпкягЩ) {
/* 303 */       throw new AssertionError();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String repeat(Object youcangetnoinfoEDVYЧВдБь, Object youcangetnoinfoEDVZъ6ЗКю) {
/* 308 */     Object youcangetnoinfoEDWAё7йШП = new char[youcangetnoinfoEDVZъ6ЗКю];
/* 309 */     Arrays.fill((char[])youcangetnoinfoEDWAё7йШП, youcangetnoinfoEDVYЧВдБь);
/* 310 */     return new String((char[])youcangetnoinfoEDWAё7йШП);
/*     */   }
/*     */   
/*     */   public static void receiveHeaders(Object youcangetnoinfoCSBYе74zЗ, Object youcangetnoinfoCSBZЮёыёг, Object youcangetnoinfoCSCA6йЮДЖ) {
/* 314 */     if (youcangetnoinfoCSBYе74zЗ == CookieJar.NO_COOKIES)
/*     */       return; 
/* 316 */     Object youcangetnoinfoCSCBёЁцжё = Cookie1.parseAll((HttpUrl1)youcangetnoinfoCSBZЮёыёг, (Headers)youcangetnoinfoCSCA6йЮДЖ);
/* 317 */     if (youcangetnoinfoCSCBёЁцжё.isEmpty())
/*     */       return; 
/* 319 */     youcangetnoinfoCSBYе74zЗ.saveFromResponse((HttpUrl1)youcangetnoinfoCSBZЮёыёг, (List)youcangetnoinfoCSCBёЁцжё);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasBody(Object youcangetnoinfoAUPхмЦ6Ы) {
/* 325 */     if (youcangetnoinfoAUPхмЦ6Ы.request().method().equals("HEAD")) {
/* 326 */       return false;
/*     */     }
/*     */     
/* 329 */     int i = youcangetnoinfoAUPхмЦ6Ы.code();
/* 330 */     if ((i < 100 || i >= 200) && i != 204 && i != 304)
/*     */     {
/*     */       
/* 333 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 338 */     if (contentLength((Response)youcangetnoinfoAUPхмЦ6Ы) != -1L || "chunked"
/* 339 */       .equalsIgnoreCase(youcangetnoinfoAUPхмЦ6Ы.header("Transfer-Encoding"))) {
/* 340 */       return true;
/*     */     }
/*     */     
/* 343 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int skipUntil(Object youcangetnoinfoBAOF2ддЩШ, Object youcangetnoinfoBAOG5КЗев, Object youcangetnoinfoBAOHмпзУЮ) {
/* 351 */     for (; youcangetnoinfoBAOG5КЗев < youcangetnoinfoBAOF2ддЩШ.length() && 
/* 352 */       youcangetnoinfoBAOHмпзУЮ.indexOf(youcangetnoinfoBAOF2ддЩШ.charAt(youcangetnoinfoBAOG5КЗев)) == -1; youcangetnoinfoBAOG5КЗев++);
/*     */ 
/*     */ 
/*     */     
/* 356 */     return youcangetnoinfoBAOG5КЗев;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int skipWhitespace(Object youcangetnoinfoAZFZгЬЁУя, Object youcangetnoinfoAZGAямНве) {
/* 364 */     for (; youcangetnoinfoAZGAямНве < youcangetnoinfoAZFZгЬЁУя.length(); youcangetnoinfoAZGAямНве++) {
/* 365 */       char c = youcangetnoinfoAZFZгЬЁУя.charAt(youcangetnoinfoAZGAямНве);
/* 366 */       if (c != ' ' && c != '\t') {
/*     */         break;
/*     */       }
/*     */     } 
/* 370 */     return youcangetnoinfoAZGAямНве;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int parseSeconds(Object youcangetnoinfoAQCVеУО6ё, Object youcangetnoinfoAQCWИйщрц) {
/*     */     try {
/* 379 */       long l = Long.parseLong((String)youcangetnoinfoAQCVеУО6ё);
/* 380 */       if (l > 2147483647L)
/* 381 */         return Integer.MAX_VALUE; 
/* 382 */       if (l < 0L) {
/* 383 */         return 0;
/*     */       }
/* 385 */       return (int)l;
/*     */     }
/* 387 */     catch (NumberFormatException youcangetnoinfoAQCUоат7Я) {
/* 388 */       return youcangetnoinfoAQCWИйщрц;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\HttpHeaders.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */