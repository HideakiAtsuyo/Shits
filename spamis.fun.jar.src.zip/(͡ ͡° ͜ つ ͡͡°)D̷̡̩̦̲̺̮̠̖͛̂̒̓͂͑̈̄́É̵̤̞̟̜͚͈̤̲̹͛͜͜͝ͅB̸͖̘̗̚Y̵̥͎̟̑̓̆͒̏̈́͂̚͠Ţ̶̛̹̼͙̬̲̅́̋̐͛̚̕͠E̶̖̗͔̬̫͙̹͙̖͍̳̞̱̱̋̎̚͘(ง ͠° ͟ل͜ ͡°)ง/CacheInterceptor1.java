/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CacheInterceptor1
/*     */   implements Source
/*     */ {
/*     */   public final CacheRequest val$cacheRequest;
/*     */   public boolean cacheRequestClosed;
/*     */   public final BufferedSource val$source;
/*     */   public final CacheInterceptor this$0;
/*     */   public final BufferedSink val$cacheBody;
/*     */   
/*     */   public CacheInterceptor1() {
/* 169 */     this();
/*     */   }
/*     */   
/*     */   public long read(Object youcangetnoinfoCENFМДМ3т, Object youcangetnoinfoCENGЕёЭzъ) throws IOException {
/*     */     long l;
/*     */     try {
/* 175 */       l = source.read((Buffer2)youcangetnoinfoCENFМДМ3т, youcangetnoinfoCENGЕёЭzъ);
/* 176 */     } catch (IOException youcangetnoinfoCENDдп6та) {
/* 177 */       if (!((CacheInterceptor1)super).cacheRequestClosed) {
/* 178 */         ((CacheInterceptor1)super).cacheRequestClosed = true;
/* 179 */         cacheRequest.abort();
/*     */       } 
/* 181 */       throw youcangetnoinfoCENDдп6та;
/*     */     } 
/*     */     
/* 184 */     if (l == -1L) {
/* 185 */       if (!((CacheInterceptor1)super).cacheRequestClosed) {
/* 186 */         ((CacheInterceptor1)super).cacheRequestClosed = true;
/* 187 */         cacheBody.close();
/*     */       } 
/* 189 */       return -1L;
/*     */     } 
/*     */     
/* 192 */     youcangetnoinfoCENFМДМ3т.copyTo(cacheBody.buffer(), youcangetnoinfoCENFМДМ3т.size() - l, l);
/* 193 */     cacheBody.emitCompleteSegments();
/* 194 */     return l;
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 198 */     return source.timeout();
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 202 */     if (!((CacheInterceptor1)super).cacheRequestClosed && 
/* 203 */       !Util1.discard((Source)this, 100, TimeUnit.MILLISECONDS)) {
/* 204 */       ((CacheInterceptor1)super).cacheRequestClosed = true;
/* 205 */       cacheRequest.abort();
/*     */     } 
/* 207 */     source.close();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\CacheInterceptor1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */