/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InterruptedIOException;
/*     */ import java.net.Socket;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.LinkedBlockingQueue;
/*     */ import java.util.concurrent.RejectedExecutionException;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ScheduledThreadPoolExecutor;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.ThreadPoolExecutor;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Connection5
/*     */   implements Closeable
/*     */ {
/*  81 */   public static final ExecutorService listenerExecutor = new ThreadPoolExecutor(0, 2147483647, 60L, TimeUnit.SECONDS, new SynchronousQueue<>(), 
/*     */       
/*  83 */       Util1.threadFactory("OkHttp Http2Connection", true));
/*     */   public static final boolean $assertionsDisabled;
/*     */   public final Map streams;
/*     */   public static final int OKHTTP_CLIENT_WINDOW_SIZE = 16777216;
/*     */   public final String connectionName;
/*     */   public boolean awaitingPong;
/*     */   public final Http2Connection2 readerRunnable;
/*     */   public final Socket socket;
/*     */   public final Settings peerSettings;
/*     */   public Settings okHttpSettings;
/*     */   public int nextStreamId; public int lastGoodStreamId; public long bytesLeftInWriteWindow; public final Http2Writer writer; public final PushObserver pushObserver; public final ExecutorService pushExecutor; public final Http2Connection13 listener; public final boolean client; public long unacknowledgedBytesRead; public boolean shutdown; public boolean receivedInitialPeerSettings; public final ScheduledExecutorService writerExecutor; public final Set<Integer> currentPushRequests; public synchronized int openStreamCount() { return ((Http2Connection5)super).streams.size(); } public synchronized Http2Stream2 getStream(Object youcangetnoinfoEBKY92югО) { return (Http2Stream2)((Http2Connection5)super).streams.get(Integer.valueOf(youcangetnoinfoEBKY92югО)); } public synchronized Http2Stream2 removeStream(Object youcangetnoinfoCIZEэЛифх) { Object youcangetnoinfoCIZFыЧВЯё = ((Http2Connection5)super).streams.remove(Integer.valueOf(youcangetnoinfoCIZEэЛифх)); notifyAll(); return (Http2Stream2)youcangetnoinfoCIZFыЧВЯё; } public synchronized int maxConcurrentStreams() { return ((Http2Connection5)super).peerSettings.getMaxConcurrentStreams(2147483647); } public synchronized void updateConnectionFlowControl(Object youcangetnoinfoDOWCиОпвМ) { ((Http2Connection5)super).unacknowledgedBytesRead += youcangetnoinfoDOWCиОпвМ; if (((Http2Connection5)super).unacknowledgedBytesRead >= (((Http2Connection5)super).okHttpSettings.getInitialWindowSize() / 2)) {
/*     */       super.writeWindowUpdateLater(0, ((Http2Connection5)super).unacknowledgedBytesRead); ((Http2Connection5)super).unacknowledgedBytesRead = 0L;
/*     */     }  } public Http2Stream2 pushStream(Object youcangetnoinfoEKMVёиЙСа, Object youcangetnoinfoEKMWЙ2Ефа, Object youcangetnoinfoEKMXЩщЯТЩ) throws IOException { if (((Http2Connection5)super).client)
/*     */       throw new IllegalStateException("Client cannot push requests.");  return super.newStream(youcangetnoinfoEKMVёиЙСа, (List)youcangetnoinfoEKMWЙ2Ефа, youcangetnoinfoEKMXЩщЯТЩ); } public Http2Stream2 newStream(Object youcangetnoinfoHYBрДzдХ, Object youcangetnoinfoHYCООЯЗы) throws IOException { return super.newStream(0, (List)youcangetnoinfoHYBрДzдХ, youcangetnoinfoHYCООЯЗы); } public Http2Stream2 newStream(Object youcangetnoinfoZNOфБШщТ, Object youcangetnoinfoZNPхэ9г1, Object youcangetnoinfoZNQЙфм84) throws IOException { boolean bool3; Object youcangetnoinfoZNI0Ц2ИИ; boolean bool1 = (youcangetnoinfoZNQЙфм84 == null) ? true : false; boolean bool2 = false; synchronized (((Http2Connection5)super).writer) {
/*     */       int i; synchronized (this) {
/*     */         if (((Http2Connection5)super).nextStreamId > 1073741823)
/*     */           super.shutdown(ErrorCode.REFUSED_STREAM);  if (((Http2Connection5)super).shutdown)
/*     */           throw new ConnectionShutdownException();  i = ((Http2Connection5)super).nextStreamId; ((Http2Connection5)super).nextStreamId += 2; youcangetnoinfoZNI0Ц2ИИ = new Http2Stream2(i, (Http2Connection5)this, bool1, bool2, null); bool3 = (youcangetnoinfoZNQЙфм84 == null || ((Http2Connection5)super).bytesLeftInWriteWindow == 0L || ((Http2Stream2)youcangetnoinfoZNI0Ц2ИИ).bytesLeftInWriteWindow == 0L) ? true : false; if (youcangetnoinfoZNI0Ц2ИИ.isOpen())
/*     */           ((Http2Connection5)super).streams.put(Integer.valueOf(i), youcangetnoinfoZNI0Ц2ИИ); 
/*     */       }  if (youcangetnoinfoZNOфБШщТ == null) {
/*     */         ((Http2Connection5)super).writer.headers(bool1, i, (List)youcangetnoinfoZNPхэ9г1);
/*     */       } else {
/*     */         if (((Http2Connection5)super).client)
/*     */           throw new IllegalArgumentException("client streams shouldn't have associated stream IDs");  ((Http2Connection5)super).writer.pushPromise(youcangetnoinfoZNOфБШщТ, i, (List)youcangetnoinfoZNPхэ9г1);
/*     */       } 
/*     */     } 
/*     */     if (bool3)
/*     */       ((Http2Connection5)super).writer.flush(); 
/*     */     return (Http2Stream2)youcangetnoinfoZNI0Ц2ИИ; } public void writeHeaders(Object youcangetnoinfoDOPUч0Р6Р, Object youcangetnoinfoDOPVу6ёср, Object youcangetnoinfoDOPWшЩШ6щ) throws IOException { ((Http2Connection5)super).writer.headers(youcangetnoinfoDOPVу6ёср, youcangetnoinfoDOPUч0Р6Р, (List)youcangetnoinfoDOPWшЩШ6щ); } public void writeData(Object youcangetnoinfoBXORБяювС, Object youcangetnoinfoBXOSнЯр1О, Object youcangetnoinfoBXOTЙХуюН, Object youcangetnoinfoBXOU1цяЛВ) throws IOException { if (youcangetnoinfoBXOU1цяЛВ == 0L) {
/*     */       ((Http2Connection5)super).writer.data(youcangetnoinfoBXOSнЯр1О, youcangetnoinfoBXORБяювС, (Buffer2)youcangetnoinfoBXOTЙХуюН, 0);
/*     */       return;
/*     */     } 
/*     */     while (youcangetnoinfoBXOU1цяЛВ > 0L) {
/*     */       int i;
/*     */       synchronized (this) {
/*     */         while (true) {
/*     */           try {
/*     */             if (((Http2Connection5)super).bytesLeftInWriteWindow <= 0L) {
/*     */               if (!((Http2Connection5)super).streams.containsKey(Integer.valueOf(youcangetnoinfoBXORБяювС)))
/*     */                 throw new IOException("stream closed"); 
/*     */               wait();
/*     */               continue;
/*     */             } 
/*     */           } catch (InterruptedException youcangetnoinfoBXONСИ9УГ) {
/*     */             Thread.currentThread().interrupt();
/*     */             throw new InterruptedIOException();
/*     */           } 
/*     */           break;
/*     */         } 
/*     */         i = (int)Math.min(youcangetnoinfoBXOU1цяЛВ, ((Http2Connection5)super).bytesLeftInWriteWindow);
/*     */         i = Math.min(i, ((Http2Connection5)super).writer.maxDataLength());
/*     */         ((Http2Connection5)super).bytesLeftInWriteWindow -= i;
/*     */       } 
/*     */       long l = youcangetnoinfoBXOU1цяЛВ - i;
/*     */       ((Http2Connection5)super).writer.data((youcangetnoinfoBXOSнЯр1О != null && l == 0L), youcangetnoinfoBXORБяювС, (Buffer2)youcangetnoinfoBXOTЙХуюН, i);
/* 138 */     }  } public Http2Connection5(Object youcangetnoinfoDXUSщ19НВ) { this();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ((Http2Connection5)super).streams = new LinkedHashMap<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ((Http2Connection5)super).unacknowledgedBytesRead = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ((Http2Connection5)super).okHttpSettings = new Settings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ((Http2Connection5)super).peerSettings = new Settings();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     ((Http2Connection5)super).receivedInitialPeerSettings = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 830 */     ((Http2Connection5)super).currentPushRequests = new LinkedHashSet<>(); ((Http2Connection5)super).pushObserver = ((Http2Connection12)youcangetnoinfoDXUSщ19НВ).pushObserver; ((Http2Connection5)super).client = ((Http2Connection12)youcangetnoinfoDXUSщ19НВ).client; ((Http2Connection5)super).listener = ((Http2Connection12)youcangetnoinfoDXUSщ19НВ).listener; ((Http2Connection5)super).nextStreamId = ((Http2Connection12)youcangetnoinfoDXUSщ19НВ).client ? 1 : 2; if (((Http2Connection12)youcangetnoinfoDXUSщ19НВ).client) ((Http2Connection5)super).nextStreamId += 2;  if (((Http2Connection12)youcangetnoinfoDXUSщ19НВ).client) ((Http2Connection5)super).okHttpSettings.set(7, 16777216);  ((Http2Connection5)super).connectionName = ((Http2Connection12)youcangetnoinfoDXUSщ19НВ).connectionName; ((Http2Connection5)super).writerExecutor = new ScheduledThreadPoolExecutor(1, Util1.threadFactory(Util1.format("OkHttp %s Writer", new Object[] { ((Http2Connection5)super).connectionName }), false)); if (((Http2Connection12)youcangetnoinfoDXUSщ19НВ).pingIntervalMillis != 0) ((Http2Connection5)super).writerExecutor.scheduleAtFixedRate(new Http2Connection8((Http2Connection5)this, false, 0, 0), ((Http2Connection12)youcangetnoinfoDXUSщ19НВ).pingIntervalMillis, ((Http2Connection12)youcangetnoinfoDXUSщ19НВ).pingIntervalMillis, TimeUnit.MILLISECONDS);  ((Http2Connection5)super).pushExecutor = new ThreadPoolExecutor(0, 1, 60L, TimeUnit.SECONDS, new LinkedBlockingQueue<>(), Util1.threadFactory(Util1.format("OkHttp %s Push Observer", new Object[] { ((Http2Connection5)super).connectionName }), true)); ((Http2Connection5)super).peerSettings.set(7, 65535); ((Http2Connection5)super).peerSettings.set(5, 16384); ((Http2Connection5)super).bytesLeftInWriteWindow = ((Http2Connection5)super).peerSettings.getInitialWindowSize(); ((Http2Connection5)super).socket = ((Http2Connection12)youcangetnoinfoDXUSщ19НВ).socket; ((Http2Connection5)super).writer = new Http2Writer(((Http2Connection12)youcangetnoinfoDXUSщ19НВ).sink, ((Http2Connection5)super).client); ((Http2Connection5)super).readerRunnable = new Http2Connection2((Http2Connection5)this, new Http2Reader2(((Http2Connection12)youcangetnoinfoDXUSщ19НВ).source, ((Http2Connection5)super).client)); }
/*     */   public void writeSynResetLater(Object youcangetnoinfoCUSAСБёФЁ, Object youcangetnoinfoCUSBуМъжц) { try { ((Http2Connection5)super).writerExecutor.execute(new Http2Connection9((Http2Connection5)this, "OkHttp %s stream %d", new Object[] { ((Http2Connection5)super).connectionName, Integer.valueOf(youcangetnoinfoCUSAСБёФЁ) }, youcangetnoinfoCUSAСБёФЁ, (ErrorCode)youcangetnoinfoCUSBуМъжц)); } catch (RejectedExecutionException rejectedExecutionException) {} }
/*     */   public void writeSynReset(Object youcangetnoinfoELVUШ2Ъ8В, Object youcangetnoinfoELVV4пЗаР) throws IOException { ((Http2Connection5)super).writer.rstStream(youcangetnoinfoELVUШ2Ъ8В, (ErrorCode)youcangetnoinfoELVV4пЗаР); }
/* 833 */   public void writeWindowUpdateLater(Object youcangetnoinfoDLBBМййыА, Object youcangetnoinfoDLBCфММяО) { try { ((Http2Connection5)super).writerExecutor.execute(new Http2Connection4((Http2Connection5)this, "OkHttp Window Update %s stream %d", new Object[] { ((Http2Connection5)super).connectionName, Integer.valueOf(youcangetnoinfoDLBBМййыА) }, youcangetnoinfoDLBBМййыА, youcangetnoinfoDLBCфММяО)); } catch (RejectedExecutionException rejectedExecutionException) {} } public void pushRequestLater(Object youcangetnoinfoDOHDъЧршг, Object youcangetnoinfoDOHEАмСоЗ) { synchronized (this) {
/* 834 */       if (((Http2Connection5)super).currentPushRequests.contains(Integer.valueOf(youcangetnoinfoDOHDъЧршг))) {
/* 835 */         super.writeSynResetLater(youcangetnoinfoDOHDъЧршг, ErrorCode.PROTOCOL_ERROR);
/*     */         return;
/*     */       } 
/* 838 */       ((Http2Connection5)super).currentPushRequests.add(Integer.valueOf(youcangetnoinfoDOHDъЧршг));
/*     */     } 
/*     */     try {
/* 841 */       super.pushExecutorExecute(new Http2Connection10((Http2Connection5)this, "OkHttp %s Push Request[%s]", new Object[] { ((Http2Connection5)super).connectionName, 
/* 842 */               Integer.valueOf(youcangetnoinfoDOHDъЧршг) }, youcangetnoinfoDOHDъЧршг, (List)youcangetnoinfoDOHEАмСоЗ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 856 */     catch (RejectedExecutionException rejectedExecutionException) {} } public void writePing(Object youcangetnoinfoCUGLцкэм2, Object youcangetnoinfoCUGMжрЫШи, Object youcangetnoinfoCUGNъйьнД) { if (youcangetnoinfoCUGLцкэм2 == null) { boolean bool; synchronized (this) { bool = ((Http2Connection5)super).awaitingPong; ((Http2Connection5)super).awaitingPong = true; }  if (bool) { super.failConnection(); return; }  }  try { ((Http2Connection5)super).writer.ping(youcangetnoinfoCUGLцкэм2, youcangetnoinfoCUGMжрЫШи, youcangetnoinfoCUGNъйьнД); } catch (IOException youcangetnoinfoCUGJНДХ7ф) { Object youcangetnoinfoCUGIхьМВЬ; super.failConnection(); }  } public void writePingAndAwaitPong() throws InterruptedException { super.writePing(false, 1330343787, -257978967); super.awaitPong(); } public synchronized void awaitPong() throws InterruptedException { while (((Http2Connection5)super).awaitingPong) wait();  } public void flush() throws IOException { ((Http2Connection5)super).writer.flush(); } public void shutdown(Object youcangetnoinfoALHJ5ЭнцС) throws IOException { synchronized (((Http2Connection5)super).writer) { int i; synchronized (this) { if (((Http2Connection5)super).shutdown) return;  ((Http2Connection5)super).shutdown = true; i = ((Http2Connection5)super).lastGoodStreamId; }  ((Http2Connection5)super).writer.goAway(i, (ErrorCode)youcangetnoinfoALHJ5ЭнцС, Util1.EMPTY_BYTE_ARRAY); }  } public void close() throws IOException { super.close(ErrorCode.NO_ERROR, ErrorCode.CANCEL); }
/*     */   public void close(Object youcangetnoinfoCVQX9вХёх, Object youcangetnoinfoCVQYЦязРГ) throws IOException { // Byte code:
/*     */     //   0: getstatic (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Http2Connection5.$assertionsDisabled : Z
/*     */     //   3: ifne -> 21
/*     */     //   6: aload_0
/*     */     //   7: invokestatic holdsLock : (Ljava/lang/Object;)Z
/*     */     //   10: ifeq -> 21
/*     */     //   13: new java/lang/AssertionError
/*     */     //   16: dup
/*     */     //   17: invokespecial <init> : ()V
/*     */     //   20: athrow
/*     */     //   21: aconst_null
/*     */     //   22: astore_3
/*     */     //   23: aload_0
/*     */     //   24: aload_1
/*     */     //   25: invokevirtual shutdown : (L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/ErrorCode;)V
/*     */     //   28: goto -> 36
/*     */     //   31: astore #4
/*     */     //   33: aload #4
/*     */     //   35: astore_3
/*     */     //   36: aconst_null
/*     */     //   37: astore #4
/*     */     //   39: aload_0
/*     */     //   40: dup
/*     */     //   41: astore #5
/*     */     //   43: monitorenter
/*     */     //   44: aload_0
/*     */     //   45: getfield streams : Ljava/util/Map;
/*     */     //   48: invokeinterface isEmpty : ()Z
/*     */     //   53: ifne -> 96
/*     */     //   56: aload_0
/*     */     //   57: getfield streams : Ljava/util/Map;
/*     */     //   60: invokeinterface values : ()Ljava/util/Collection;
/*     */     //   65: aload_0
/*     */     //   66: getfield streams : Ljava/util/Map;
/*     */     //   69: invokeinterface size : ()I
/*     */     //   74: anewarray (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Http2Stream2
/*     */     //   77: invokeinterface toArray : ([Ljava/lang/Object;)[Ljava/lang/Object;
/*     */     //   82: checkcast [L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Http2Stream2;
/*     */     //   85: astore #4
/*     */     //   87: aload_0
/*     */     //   88: getfield streams : Ljava/util/Map;
/*     */     //   91: invokeinterface clear : ()V
/*     */     //   96: aload #5
/*     */     //   98: monitorexit
/*     */     //   99: goto -> 110
/*     */     //   102: astore #6
/*     */     //   104: aload #5
/*     */     //   106: monitorexit
/*     */     //   107: aload #6
/*     */     //   109: athrow
/*     */     //   110: aload #4
/*     */     //   112: ifnull -> 165
/*     */     //   115: aload #4
/*     */     //   117: astore #5
/*     */     //   119: aload #5
/*     */     //   121: arraylength
/*     */     //   122: istore #6
/*     */     //   124: iconst_0
/*     */     //   125: istore #7
/*     */     //   127: iload #7
/*     */     //   129: iload #6
/*     */     //   131: if_icmpge -> 165
/*     */     //   134: aload #5
/*     */     //   136: iload #7
/*     */     //   138: aaload
/*     */     //   139: astore #8
/*     */     //   141: aload #8
/*     */     //   143: aload_2
/*     */     //   144: invokevirtual close : (L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/ErrorCode;)V
/*     */     //   147: goto -> 159
/*     */     //   150: astore #9
/*     */     //   152: aload_3
/*     */     //   153: ifnull -> 159
/*     */     //   156: aload #9
/*     */     //   158: astore_3
/*     */     //   159: iinc #7, 1
/*     */     //   162: goto -> 127
/*     */     //   165: aload_0
/*     */     //   166: getfield writer : L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Http2Writer;
/*     */     //   169: invokevirtual close : ()V
/*     */     //   172: goto -> 184
/*     */     //   175: astore #5
/*     */     //   177: aload_3
/*     */     //   178: ifnonnull -> 184
/*     */     //   181: aload #5
/*     */     //   183: astore_3
/*     */     //   184: aload_0
/*     */     //   185: getfield socket : Ljava/net/Socket;
/*     */     //   188: invokevirtual close : ()V
/*     */     //   191: goto -> 199
/*     */     //   194: astore #5
/*     */     //   196: aload #5
/*     */     //   198: astore_3
/*     */     //   199: aload_0
/*     */     //   200: getfield writerExecutor : Ljava/util/concurrent/ScheduledExecutorService;
/*     */     //   203: invokeinterface shutdown : ()V
/*     */     //   208: aload_0
/*     */     //   209: getfield pushExecutor : Ljava/util/concurrent/ExecutorService;
/*     */     //   212: invokeinterface shutdown : ()V
/*     */     //   217: aload_3
/*     */     //   218: ifnull -> 223
/*     */     //   221: aload_3
/*     */     //   222: athrow
/*     */     //   223: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #440	-> 0
/*     */     //   #441	-> 21
/*     */     //   #443	-> 23
/*     */     //   #446	-> 28
/*     */     //   #444	-> 31
/*     */     //   #445	-> 33
/*     */     //   #448	-> 36
/*     */     //   #449	-> 39
/*     */     //   #450	-> 44
/*     */     //   #451	-> 56
/*     */     //   #452	-> 87
/*     */     //   #454	-> 96
/*     */     //   #456	-> 110
/*     */     //   #457	-> 115
/*     */     //   #459	-> 141
/*     */     //   #462	-> 147
/*     */     //   #460	-> 150
/*     */     //   #461	-> 152
/*     */     //   #457	-> 159
/*     */     //   #468	-> 165
/*     */     //   #471	-> 172
/*     */     //   #469	-> 175
/*     */     //   #470	-> 177
/*     */     //   #475	-> 184
/*     */     //   #478	-> 191
/*     */     //   #476	-> 194
/*     */     //   #477	-> 196
/*     */     //   #481	-> 199
/*     */     //   #482	-> 208
/*     */     //   #484	-> 217
/*     */     //   #485	-> 223
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   177	7	5	youcangetnoinfoCVQUЙъЮ1м	Ljava/lang/Object;
/*     */     //   0	224	2	youcangetnoinfoCVQYЦязРГ	Ljava/lang/Object;
/*     */     //   33	3	4	youcangetnoinfoCVQRз4ъz5	Ljava/lang/Object;
/*     */     //   0	224	0	youcangetnoinfoCVQW8лНяы	Ljava/lang/Object;
/*     */     //   23	201	3	youcangetnoinfoCVQZЮЪгб2	Ljava/lang/Object;
/*     */     //   152	7	9	youcangetnoinfoCVQSг5ЩфБ	Ljava/lang/Object;
/*     */     //   141	18	8	youcangetnoinfoCVQTСz03э	Ljava/lang/Object;
/*     */     //   196	3	5	youcangetnoinfoCVQV4нд33	Ljava/lang/Object;
/*     */     //   0	224	1	youcangetnoinfoCVQX9вХёх	Ljava/lang/Object;
/*     */     //   39	185	4	youcangetnoinfoCVRAБсС6ы	Ljava/lang/Object;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   23	28	31	java/io/IOException
/*     */     //   44	99	102	finally
/*     */     //   102	107	102	finally
/*     */     //   141	147	150	java/io/IOException
/*     */     //   165	172	175	java/io/IOException
/*     */     //   184	191	194	java/io/IOException }
/*     */   public void failConnection() { try { super.close(ErrorCode.PROTOCOL_ERROR, ErrorCode.PROTOCOL_ERROR); } catch (IOException iOException) {} }
/*     */   public void start() throws IOException { super.start(true); }
/*     */   public void start(Object youcangetnoinfoBTQHр0ПБМ) throws IOException { if (youcangetnoinfoBTQHр0ПБМ != null) { ((Http2Connection5)super).writer.connectionPreface(); ((Http2Connection5)super).writer.settings(((Http2Connection5)super).okHttpSettings); int i = ((Http2Connection5)super).okHttpSettings.getInitialWindowSize(); if (i != 65535) ((Http2Connection5)super).writer.windowUpdate(0, (i - 65535));  }  (new Thread(((Http2Connection5)super).readerRunnable)).start(); }
/*     */   public void setSettings(Object youcangetnoinfoDPJEцБгУи) throws IOException { synchronized (((Http2Connection5)super).writer) { synchronized (this) { if (((Http2Connection5)super).shutdown) throw new ConnectionShutdownException();  ((Http2Connection5)super).okHttpSettings.merge((Settings)youcangetnoinfoDPJEцБгУи); }  ((Http2Connection5)super).writer.settings((Settings)youcangetnoinfoDPJEцБгУи); }  }
/*     */   public synchronized boolean isShutdown() { return ((Http2Connection5)super).shutdown; }
/*     */   public boolean pushedStream(Object youcangetnoinfoDSQBнР9Ик) { // Byte code:
/*     */     //   0: iload_1
/*     */     //   1: ifeq -> 14
/*     */     //   4: iload_1
/*     */     //   5: iconst_1
/*     */     //   6: iand
/*     */     //   7: ifne -> 14
/*     */     //   10: iconst_1
/*     */     //   11: goto -> 15
/*     */     //   14: iconst_0
/*     */     //   15: ireturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #826	-> 0
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	16	1	youcangetnoinfoDSQBнР9Ик	Ljava/lang/Object;
/*     */     //   0	16	0	youcangetnoinfoDSQAз3еаФ	Ljava/lang/Object; }
/* 864 */   public void pushHeadersLater(Object youcangetnoinfoEAQEО9ЯАф, Object youcangetnoinfoEAQFПЕцКУ, Object youcangetnoinfoEAQGъКФГЧ) { try { super.pushExecutorExecute(new Http2Connection1((Http2Connection5)this, "OkHttp %s Push Headers[%s]", new Object[] { ((Http2Connection5)super).connectionName, 
/* 865 */               Integer.valueOf(youcangetnoinfoEAQEО9ЯАф) }, youcangetnoinfoEAQEО9ЯАф, (List)youcangetnoinfoEAQFПЕцКУ, youcangetnoinfoEAQGъКФГЧ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */        }
/*     */     
/* 879 */     catch (RejectedExecutionException rejectedExecutionException) {} }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushDataLater(Object youcangetnoinfoATTOёй9Мь, Object youcangetnoinfoATTPЬХоъП, Object youcangetnoinfoATTQЛЖбЯщ, Object youcangetnoinfoATTRоъЫz3) throws IOException {
/* 890 */     Object youcangetnoinfoATTSЙ9Пош = new Buffer2();
/* 891 */     youcangetnoinfoATTPЬХоъП.require(youcangetnoinfoATTQЛЖбЯщ);
/* 892 */     youcangetnoinfoATTPЬХоъП.read((Buffer2)youcangetnoinfoATTSЙ9Пош, youcangetnoinfoATTQЛЖбЯщ);
/* 893 */     if (youcangetnoinfoATTSЙ9Пош.size() != youcangetnoinfoATTQЛЖбЯщ) throw new IOException(youcangetnoinfoATTSЙ9Пош.size() + " != " + youcangetnoinfoATTQЛЖбЯщ); 
/* 894 */     super.pushExecutorExecute(new Http2Connection3((Http2Connection5)this, "OkHttp %s Push Data[%s]", new Object[] { ((Http2Connection5)super).connectionName, Integer.valueOf(youcangetnoinfoATTOёй9Мь) }, youcangetnoinfoATTOёй9Мь, (Buffer2)youcangetnoinfoATTSЙ9Пош, youcangetnoinfoATTQЛЖбЯщ, youcangetnoinfoATTRоъЫz3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pushResetLater(Object youcangetnoinfoAOUWШ6Кжв, Object youcangetnoinfoAOUXьИЛаА) {
/* 911 */     super.pushExecutorExecute(new Http2Connection6((Http2Connection5)this, "OkHttp %s Push Reset[%s]", new Object[] { ((Http2Connection5)super).connectionName, Integer.valueOf(youcangetnoinfoAOUWШ6Кжв) }, youcangetnoinfoAOUWШ6Кжв, (ErrorCode)youcangetnoinfoAOUXьИЛаА));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void pushExecutorExecute(Object youcangetnoinfoAQFCдмУсж) {
/* 922 */     if (!super.isShutdown())
/* 923 */       ((Http2Connection5)super).pushExecutor.execute((Runnable)youcangetnoinfoAQFCдмУсж); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http2Connection5.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */