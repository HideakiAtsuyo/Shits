/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class MultipartBody1
/*     */ {
/*     */   public final ByteString boundary;
/*     */   public final List parts;
/*     */   public MediaType type;
/*     */   
/*     */   public MultipartBody1() {
/* 288 */     super(UUID.randomUUID().toString());
/*     */   }
/*     */   public MultipartBody1(Object youcangetnoinfoCMYUд1чНЧ) {
/* 291 */     this(); ((MultipartBody1)super).type = MultipartBody.MIXED; ((MultipartBody1)super).parts = new ArrayList();
/* 292 */     ((MultipartBody1)super).boundary = ByteString.encodeUtf8((String)youcangetnoinfoCMYUд1чНЧ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public MultipartBody1 setType(Object youcangetnoinfoUHIЗЕхуЭ) {
/* 300 */     if (youcangetnoinfoUHIЗЕхуЭ == null) {
/* 301 */       throw new NullPointerException("type == null");
/*     */     }
/* 303 */     if (!youcangetnoinfoUHIЗЕхуЭ.type().equals("multipart")) {
/* 304 */       throw new IllegalArgumentException("multipart != " + youcangetnoinfoUHIЗЕхуЭ);
/*     */     }
/* 306 */     ((MultipartBody1)super).type = (MediaType)youcangetnoinfoUHIЗЕхуЭ;
/* 307 */     return (MultipartBody1)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBody1 addPart(Object youcangetnoinfoCHJQРвшы8) {
/* 312 */     return super.addPart(MultipartBody2.create((RequestBody)youcangetnoinfoCHJQРвшы8));
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBody1 addPart(@Nullable Object youcangetnoinfoAQGLтРцьь, Object youcangetnoinfoAQGMьЛьТв) {
/* 317 */     return super.addPart(MultipartBody2.create((Headers)youcangetnoinfoAQGLтРцьь, (RequestBody)youcangetnoinfoAQGMьЛьТв));
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBody1 addFormDataPart(Object youcangetnoinfoDYDPябкЕР, Object youcangetnoinfoDYDQСвзмч) {
/* 322 */     return super.addPart(MultipartBody2.createFormData((String)youcangetnoinfoDYDPябкЕР, (String)youcangetnoinfoDYDQСвзмч));
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBody1 addFormDataPart(Object youcangetnoinfoBXIIъш0Гш, @Nullable Object youcangetnoinfoBXIJяцЩХИ, Object youcangetnoinfoBXIKЦеЩУе) {
/* 327 */     return super.addPart(MultipartBody2.createFormData((String)youcangetnoinfoBXIIъш0Гш, (String)youcangetnoinfoBXIJяцЩХИ, (RequestBody)youcangetnoinfoBXIKЦеЩУе));
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBody1 addPart(Object youcangetnoinfoILFЮzдЬМ) {
/* 332 */     if (youcangetnoinfoILFЮzдЬМ == null) throw new NullPointerException("part == null"); 
/* 333 */     ((MultipartBody1)super).parts.add(youcangetnoinfoILFЮzдЬМ);
/* 334 */     return (MultipartBody1)this;
/*     */   }
/*     */ 
/*     */   
/*     */   public MultipartBody build() {
/* 339 */     if (((MultipartBody1)super).parts.isEmpty()) {
/* 340 */       throw new IllegalStateException("Multipart body must have at least one part.");
/*     */     }
/* 342 */     return new MultipartBody(((MultipartBody1)super).boundary, ((MultipartBody1)super).type, ((MultipartBody1)super).parts);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\MultipartBody1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */