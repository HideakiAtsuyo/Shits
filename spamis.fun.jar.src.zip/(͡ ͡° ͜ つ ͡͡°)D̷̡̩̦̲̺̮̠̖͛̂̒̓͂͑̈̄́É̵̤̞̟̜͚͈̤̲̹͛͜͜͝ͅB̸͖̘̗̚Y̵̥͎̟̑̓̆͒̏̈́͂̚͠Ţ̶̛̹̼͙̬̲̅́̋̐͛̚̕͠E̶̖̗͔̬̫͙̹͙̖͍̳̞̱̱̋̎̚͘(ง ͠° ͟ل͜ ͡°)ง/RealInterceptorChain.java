/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RealInterceptorChain
/*     */   implements Interceptor1
/*     */ {
/*     */   public final HttpCodec httpCodec;
/*     */   public final EventListener1 eventListener;
/*     */   public final RealConnection1 connection;
/*     */   public int calls;
/*     */   public final Request request;
/*     */   public final int connectTimeout;
/*     */   public final int index;
/*     */   public final int writeTimeout;
/*     */   public final Call call;
/*     */   public final StreamAllocation1 streamAllocation;
/*     */   public final List interceptors;
/*     */   public final int readTimeout;
/*     */   
/*     */   public RealInterceptorChain(Object youcangetnoinfoBGXЬДВзК, Object youcangetnoinfoBGYтюурй, Object youcangetnoinfoBGZзЛ2фц, Object youcangetnoinfoBHAЛЁТЫг, Object youcangetnoinfoBHBчЗЁкН, Object youcangetnoinfoBHCкдЗЪа, Object youcangetnoinfoBHDСвzСм, Object youcangetnoinfoBHEН0вЮЧ, Object youcangetnoinfoBHFФС38и, Object youcangetnoinfoBHGхёйгЗ, Object youcangetnoinfoBHHУбП5щ) {
/*  52 */     this();
/*  53 */     ((RealInterceptorChain)super).interceptors = (List)youcangetnoinfoBGXЬДВзК;
/*  54 */     ((RealInterceptorChain)super).connection = (RealConnection1)youcangetnoinfoBHAЛЁТЫг;
/*  55 */     ((RealInterceptorChain)super).streamAllocation = (StreamAllocation1)youcangetnoinfoBGYтюурй;
/*  56 */     ((RealInterceptorChain)super).httpCodec = (HttpCodec)youcangetnoinfoBGZзЛ2фц;
/*  57 */     ((RealInterceptorChain)super).index = youcangetnoinfoBHBчЗЁкН;
/*  58 */     ((RealInterceptorChain)super).request = (Request)youcangetnoinfoBHCкдЗЪа;
/*  59 */     ((RealInterceptorChain)super).call = (Call)youcangetnoinfoBHDСвzСм;
/*  60 */     ((RealInterceptorChain)super).eventListener = (EventListener1)youcangetnoinfoBHEН0вЮЧ;
/*  61 */     ((RealInterceptorChain)super).connectTimeout = youcangetnoinfoBHFФС38и;
/*  62 */     ((RealInterceptorChain)super).readTimeout = youcangetnoinfoBHGхёйгЗ;
/*  63 */     ((RealInterceptorChain)super).writeTimeout = youcangetnoinfoBHHУбП5щ;
/*     */   }
/*     */   
/*     */   public Connection connection() {
/*  67 */     return ((RealInterceptorChain)super).connection;
/*     */   }
/*     */   
/*     */   public int connectTimeoutMillis() {
/*  71 */     return ((RealInterceptorChain)super).connectTimeout;
/*     */   }
/*     */   
/*     */   public Interceptor1 withConnectTimeout(Object youcangetnoinfoBJGWМЩЛи5, Object youcangetnoinfoBJGXЙЮОЛщ) {
/*  75 */     int i = Util1.checkDuration("timeout", youcangetnoinfoBJGWМЩЛи5, (TimeUnit)youcangetnoinfoBJGXЙЮОЛщ);
/*  76 */     return new RealInterceptorChain(((RealInterceptorChain)super).interceptors, ((RealInterceptorChain)super).streamAllocation, ((RealInterceptorChain)super).httpCodec, ((RealInterceptorChain)super).connection, ((RealInterceptorChain)super).index, ((RealInterceptorChain)super).request, ((RealInterceptorChain)super).call, ((RealInterceptorChain)super).eventListener, i, ((RealInterceptorChain)super).readTimeout, ((RealInterceptorChain)super).writeTimeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public int readTimeoutMillis() {
/*  81 */     return ((RealInterceptorChain)super).readTimeout;
/*     */   }
/*     */   
/*     */   public Interceptor1 withReadTimeout(Object youcangetnoinfoACGAШЕЭд3, Object youcangetnoinfoACGBфётПм) {
/*  85 */     int i = Util1.checkDuration("timeout", youcangetnoinfoACGAШЕЭд3, (TimeUnit)youcangetnoinfoACGBфётПм);
/*  86 */     return new RealInterceptorChain(((RealInterceptorChain)super).interceptors, ((RealInterceptorChain)super).streamAllocation, ((RealInterceptorChain)super).httpCodec, ((RealInterceptorChain)super).connection, ((RealInterceptorChain)super).index, ((RealInterceptorChain)super).request, ((RealInterceptorChain)super).call, ((RealInterceptorChain)super).eventListener, ((RealInterceptorChain)super).connectTimeout, i, ((RealInterceptorChain)super).writeTimeout);
/*     */   }
/*     */ 
/*     */   
/*     */   public int writeTimeoutMillis() {
/*  91 */     return ((RealInterceptorChain)super).writeTimeout;
/*     */   }
/*     */   
/*     */   public Interceptor1 withWriteTimeout(Object youcangetnoinfoDJTIЗйапд, Object youcangetnoinfoDJTJЮХЩГГ) {
/*  95 */     int i = Util1.checkDuration("timeout", youcangetnoinfoDJTIЗйапд, (TimeUnit)youcangetnoinfoDJTJЮХЩГГ);
/*  96 */     return new RealInterceptorChain(((RealInterceptorChain)super).interceptors, ((RealInterceptorChain)super).streamAllocation, ((RealInterceptorChain)super).httpCodec, ((RealInterceptorChain)super).connection, ((RealInterceptorChain)super).index, ((RealInterceptorChain)super).request, ((RealInterceptorChain)super).call, ((RealInterceptorChain)super).eventListener, ((RealInterceptorChain)super).connectTimeout, ((RealInterceptorChain)super).readTimeout, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public StreamAllocation1 streamAllocation() {
/* 101 */     return ((RealInterceptorChain)super).streamAllocation;
/*     */   }
/*     */   
/*     */   public HttpCodec httpStream() {
/* 105 */     return ((RealInterceptorChain)super).httpCodec;
/*     */   }
/*     */   
/*     */   public Call call() {
/* 109 */     return ((RealInterceptorChain)super).call;
/*     */   }
/*     */   
/*     */   public EventListener1 eventListener() {
/* 113 */     return ((RealInterceptorChain)super).eventListener;
/*     */   }
/*     */   
/*     */   public Request request() {
/* 117 */     return ((RealInterceptorChain)super).request;
/*     */   }
/*     */   
/*     */   public Response proceed(Object youcangetnoinfoAGLPхшУЪф) throws IOException {
/* 121 */     return super.proceed((Request)youcangetnoinfoAGLPхшУЪф, ((RealInterceptorChain)super).streamAllocation, ((RealInterceptorChain)super).httpCodec, ((RealInterceptorChain)super).connection);
/*     */   }
/*     */ 
/*     */   
/*     */   public Response proceed(Object youcangetnoinfoBBALКпБлТ, Object youcangetnoinfoBBAMУСоб5, Object youcangetnoinfoBBAN2ФНуъ, Object youcangetnoinfoBBAOГЭ4ЪХ) throws IOException {
/* 126 */     if (((RealInterceptorChain)super).index >= ((RealInterceptorChain)super).interceptors.size()) throw new AssertionError();
/*     */     
/* 128 */     ((RealInterceptorChain)super).calls++;
/*     */ 
/*     */     
/* 131 */     if (((RealInterceptorChain)super).httpCodec != null && !((RealInterceptorChain)super).connection.supportsUrl(youcangetnoinfoBBALКпБлТ.url())) {
/* 132 */       throw new IllegalStateException("network interceptor " + super.interceptors.get(super.index - 1) + " must retain the same host and port");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 137 */     if (((RealInterceptorChain)super).httpCodec != null && ((RealInterceptorChain)super).calls > 1) {
/* 138 */       throw new IllegalStateException("network interceptor " + super.interceptors.get(super.index - 1) + " must call proceed() exactly once");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 143 */     Object youcangetnoinfoBBAPПЭёО0 = new RealInterceptorChain(((RealInterceptorChain)super).interceptors, (StreamAllocation1)youcangetnoinfoBBAMУСоб5, (HttpCodec)youcangetnoinfoBBAN2ФНуъ, (RealConnection1)youcangetnoinfoBBAOГЭ4ЪХ, ((RealInterceptorChain)super).index + 1, (Request)youcangetnoinfoBBALКпБлТ, ((RealInterceptorChain)super).call, ((RealInterceptorChain)super).eventListener, ((RealInterceptorChain)super).connectTimeout, ((RealInterceptorChain)super).readTimeout, ((RealInterceptorChain)super).writeTimeout);
/*     */ 
/*     */     
/* 146 */     Object youcangetnoinfoBBAQКчСЗб = ((RealInterceptorChain)super).interceptors.get(((RealInterceptorChain)super).index);
/* 147 */     Object youcangetnoinfoBBARвьямя = youcangetnoinfoBBAQКчСЗб.intercept((Interceptor1)youcangetnoinfoBBAPПЭёО0);
/*     */ 
/*     */     
/* 150 */     if (youcangetnoinfoBBAN2ФНуъ != null && ((RealInterceptorChain)super).index + 1 < ((RealInterceptorChain)super).interceptors.size() && ((RealInterceptorChain)youcangetnoinfoBBAPПЭёО0).calls != 1) {
/* 151 */       throw new IllegalStateException("network interceptor " + youcangetnoinfoBBAQКчСЗб + " must call proceed() exactly once");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 156 */     if (youcangetnoinfoBBARвьямя == null) {
/* 157 */       throw new NullPointerException("interceptor " + youcangetnoinfoBBAQКчСЗб + " returned null");
/*     */     }
/*     */     
/* 160 */     if (youcangetnoinfoBBARвьямя.body() == null) {
/* 161 */       throw new IllegalStateException("interceptor " + youcangetnoinfoBBAQКчСЗб + " returned a response with no body");
/*     */     }
/*     */ 
/*     */     
/* 165 */     return (Response)youcangetnoinfoBBARвьямя;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RealInterceptorChain.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */