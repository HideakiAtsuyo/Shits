/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import fun.spamis.spammer.SpamIsFun;
/*     */ import java.awt.Component;
/*     */ import java.awt.Font;
/*     */ import java.awt.LayoutManager;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JSeparator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Dashboard2
/*     */   extends JPanel
/*     */ {
/*     */   public static final long serialVersionUID = -4832417595555064885L;
/*     */   
/*     */   public Dashboard2() {
/*  32 */     if (SpamUtils.user == null || SpamUtils.pw == null || !SpamUtils.loggedIn)
/*  33 */       System.exit(69); 
/*  34 */     super.initialize();
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  38 */     setLayout((LayoutManager)null);
/*     */     
/*  40 */     Object youcangetnoinfoBGBXтявНЙ = new JLabel("Welcome, " + SpamUtils.user + ".");
/*  41 */     youcangetnoinfoBGBXтявНЙ.setFont(new Font("Dialog", 1, 20));
/*  42 */     youcangetnoinfoBGBXтявНЙ.setBounds(12, 12, 341, 23);
/*  43 */     add((Component)youcangetnoinfoBGBXтявНЙ);
/*     */     
/*  45 */     Object youcangetnoinfoBGBY82ШИГ = new JLabel("Theme");
/*  46 */     youcangetnoinfoBGBY82ШИГ.setBounds(70, 247, 115, 15);
/*  47 */     add((Component)youcangetnoinfoBGBY82ШИГ);
/*     */     
/*  49 */     Object youcangetnoinfoBGBZмАеЗБ = new JSeparator();
/*  50 */     youcangetnoinfoBGBZмАеЗБ.setBounds(12, 265, 173, 2);
/*  51 */     add((Component)youcangetnoinfoBGBZмАеЗБ);
/*     */     
/*  53 */     Object youcangetnoinfoBGCAАЁ8ЕД = new ButtonGroup();
/*     */     
/*  55 */     Object youcangetnoinfoBGCBЬ16ЪБ = new JRadioButton("Light blue");
/*  56 */     youcangetnoinfoBGCBЬ16ЪБ.setSelected(true);
/*  57 */     youcangetnoinfoBGCBЬ16ЪБ.setBounds(51, 275, 149, 23);
/*  58 */     youcangetnoinfoBGCBЬ16ЪБ.addActionListener(new Dashboard((Dashboard2)this, (JRadioButton)youcangetnoinfoBGCBЬ16ЪБ));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  67 */     add((Component)youcangetnoinfoBGCBЬ16ЪБ);
/*  68 */     youcangetnoinfoBGCAАЁ8ЕД.add((AbstractButton)youcangetnoinfoBGCBЬ16ЪБ);
/*     */     
/*  70 */     Object youcangetnoinfoBGCCлэКГы = new JRadioButton("Dark blue");
/*  71 */     youcangetnoinfoBGCCлэКГы.setBounds(51, 312, 149, 23);
/*  72 */     youcangetnoinfoBGCCлэКГы.addActionListener(new Dashboard4((Dashboard2)this, (JRadioButton)youcangetnoinfoBGCCлэКГы));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  81 */     add((Component)youcangetnoinfoBGCCлэКГы);
/*  82 */     youcangetnoinfoBGCAАЁ8ЕД.add((AbstractButton)youcangetnoinfoBGCCлэКГы);
/*     */     
/*  84 */     Object youcangetnoinfoBGCDФЮЭИа = new JRadioButton("Light orange");
/*  85 */     youcangetnoinfoBGCDФЮЭИа.setBounds(226, 275, 149, 23);
/*  86 */     youcangetnoinfoBGCDФЮЭИа.addActionListener(new Dashboard3((Dashboard2)this, (JRadioButton)youcangetnoinfoBGCDФЮЭИа));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     add((Component)youcangetnoinfoBGCDФЮЭИа);
/*  96 */     youcangetnoinfoBGCAАЁ8ЕД.add((AbstractButton)youcangetnoinfoBGCDФЮЭИа);
/*     */     
/*  98 */     Object youcangetnoinfoBGCEШЬцВ1 = new JRadioButton("Dark purple");
/*  99 */     youcangetnoinfoBGCEШЬцВ1.setBounds(226, 312, 149, 23);
/* 100 */     youcangetnoinfoBGCEШЬцВ1.addActionListener(new Dashboard1((Dashboard2)this, (JRadioButton)youcangetnoinfoBGCEШЬцВ1));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     add((Component)youcangetnoinfoBGCEШЬцВ1);
/* 110 */     youcangetnoinfoBGCAАЁ8ЕД.add((AbstractButton)youcangetnoinfoBGCEШЬцВ1);
/*     */ 
/*     */ 
/*     */     
/* 114 */     if ((new File(SpamIsFun.homeDir + "theme.spamisfun")).exists())
/*     */       try {
/* 116 */         Object youcangetnoinfoBGBU9Н7ьй = FileUtils.readFile(SpamIsFun.homeDir + "theme.spamisfun");
/* 117 */         switch (youcangetnoinfoBGBU9Н7ьй) {
/*     */           case "lightblue":
/* 119 */             youcangetnoinfoBGCBЬ16ЪБ.setSelected(true);
/*     */             return;
/*     */           case "lightrange":
/* 122 */             youcangetnoinfoBGCDФЮЭИа.setSelected(true);
/*     */             return;
/*     */           case "darkblue":
/* 125 */             youcangetnoinfoBGCCлэКГы.setSelected(true);
/*     */             return;
/*     */           case "darkpurple":
/* 128 */             youcangetnoinfoBGCEШЬцВ1.setSelected(true);
/*     */             return;
/*     */         } 
/* 131 */         youcangetnoinfoBGCBЬ16ЪБ.setSelected(true);
/*     */       }
/* 133 */       catch (IOException youcangetnoinfoBGBVкюлнд) {
/* 134 */         youcangetnoinfoBGBVкюлнд.printStackTrace();
/*     */       }  
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Dashboard2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */