/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http1Codec7
/*     */   implements HttpCodec
/*     */ {
/*     */   public final BufferedSource source;
/*     */   public static final int STATE_READ_RESPONSE_HEADERS = 3;
/*     */   public static final int STATE_WRITING_REQUEST_BODY = 2;
/*     */   public static final int HEADER_LIMIT = 262144;
/*     */   public static final int STATE_OPEN_RESPONSE_BODY = 4;
/*     */   public Headers trailers;
/*     */   public static final int STATE_IDLE = 0;
/*     */   public final OkHttpClient client;
/*     */   public final StreamAllocation1 streamAllocation;
/*     */   public static final int STATE_READING_RESPONSE_BODY = 5;
/*     */   public static final int STATE_CLOSED = 6;
/*     */   public int state;
/*     */   public long headerLimit;
/*     */   public static final int STATE_OPEN_REQUEST_BODY = 1;
/*     */   public final BufferedSink sink;
/*     */   
/*     */   public Http1Codec7(Object youcangetnoinfoPSKа5Д7М, Object youcangetnoinfoPSLоЕдНа, Object youcangetnoinfoPSMФЖ5ЫУ, Object youcangetnoinfoPSNсХыТг) {
/*  96 */     this(); ((Http1Codec7)super).state = 0; ((Http1Codec7)super).headerLimit = 262144L;
/*  97 */     ((Http1Codec7)super).client = (OkHttpClient)youcangetnoinfoPSKа5Д7М;
/*  98 */     ((Http1Codec7)super).streamAllocation = (StreamAllocation1)youcangetnoinfoPSLоЕдНа;
/*  99 */     ((Http1Codec7)super).source = (BufferedSource)youcangetnoinfoPSMФЖ5ЫУ;
/* 100 */     ((Http1Codec7)super).sink = (BufferedSink)youcangetnoinfoPSNсХыТг;
/*     */   }
/*     */   
/*     */   public Sink createRequestBody(Object youcangetnoinfoTRNыСЕюъ, Object youcangetnoinfoTROТвЁНм) {
/* 104 */     if ("chunked".equalsIgnoreCase(youcangetnoinfoTRNыСЕюъ.header("Transfer-Encoding")))
/*     */     {
/* 106 */       return super.newChunkedSink();
/*     */     }
/*     */     
/* 109 */     if (youcangetnoinfoTROТвЁНм != -1L)
/*     */     {
/* 111 */       return super.newFixedLengthSink(youcangetnoinfoTROТвЁНм);
/*     */     }
/*     */     
/* 114 */     throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
/*     */   }
/*     */ 
/*     */   
/*     */   public void cancel() {
/* 119 */     Object youcangetnoinfoBQDC6гТУ7 = ((Http1Codec7)super).streamAllocation.connection();
/* 120 */     if (youcangetnoinfoBQDC6гТУ7 != null) youcangetnoinfoBQDC6гТУ7.cancel();
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writeRequestHeaders(Object youcangetnoinfoHXMПЪИтЬ) throws IOException {
/* 134 */     Object youcangetnoinfoHXNСГЙю2 = RequestLine.get((Request)youcangetnoinfoHXMПЪИтЬ, ((Http1Codec7)super).streamAllocation
/* 135 */         .connection().route().proxy().type());
/* 136 */     super.writeRequest(youcangetnoinfoHXMПЪИтЬ.headers(), (String)youcangetnoinfoHXNСГЙю2);
/*     */   }
/*     */   
/*     */   public ResponseBody openResponseBody(Object youcangetnoinfoNFXШдёЁя) throws IOException {
/* 140 */     ((Http1Codec7)super).streamAllocation.eventListener.responseBodyStart(((Http1Codec7)super).streamAllocation.call);
/* 141 */     Object youcangetnoinfoNFYцтzДж = youcangetnoinfoNFXШдёЁя.header("Content-Type");
/*     */     
/* 143 */     if (!HttpHeaders.hasBody((Response)youcangetnoinfoNFXШдёЁя)) {
/* 144 */       Object youcangetnoinfoNFTйФ0иР = super.newFixedLengthSource(0L);
/* 145 */       return new RealResponseBody((String)youcangetnoinfoNFYцтzДж, 0L, Okio1.buffer((Source)youcangetnoinfoNFTйФ0иР));
/*     */     } 
/*     */     
/* 148 */     if ("chunked".equalsIgnoreCase(youcangetnoinfoNFXШдёЁя.header("Transfer-Encoding"))) {
/* 149 */       Object youcangetnoinfoNFUыхп8Я = super.newChunkedSource(youcangetnoinfoNFXШдёЁя.request().url());
/* 150 */       return new RealResponseBody((String)youcangetnoinfoNFYцтzДж, -1L, Okio1.buffer((Source)youcangetnoinfoNFUыхп8Я));
/*     */     } 
/*     */     
/* 153 */     long l = HttpHeaders.contentLength((Response)youcangetnoinfoNFXШдёЁя);
/* 154 */     if (l != -1L) {
/* 155 */       Object youcangetnoinfoNFVчНл3Й = super.newFixedLengthSource(l);
/* 156 */       return new RealResponseBody((String)youcangetnoinfoNFYцтzДж, l, Okio1.buffer((Source)youcangetnoinfoNFVчНл3Й));
/*     */     } 
/*     */     
/* 159 */     return new RealResponseBody((String)youcangetnoinfoNFYцтzДж, -1L, Okio1.buffer(super.newUnknownLengthSource()));
/*     */   }
/*     */   
/*     */   public Headers trailers() throws IOException {
/* 163 */     if (((Http1Codec7)super).state != 6) {
/* 164 */       throw new IllegalStateException("too early; can't read the trailers yet");
/*     */     }
/* 166 */     return (((Http1Codec7)super).trailers != null) ? ((Http1Codec7)super).trailers : Util1.EMPTY_HEADERS;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 171 */     return (((Http1Codec7)super).state == 6);
/*     */   }
/*     */   
/*     */   public void flushRequest() throws IOException {
/* 175 */     ((Http1Codec7)super).sink.flush();
/*     */   }
/*     */   
/*     */   public void finishRequest() throws IOException {
/* 179 */     ((Http1Codec7)super).sink.flush();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeRequest(Object youcangetnoinfoOKZфмткэ, Object youcangetnoinfoOLAжцачв) throws IOException {
/* 184 */     if (((Http1Codec7)super).state != 0) throw new IllegalStateException("state: " + super.state); 
/* 185 */     ((Http1Codec7)super).sink.writeUtf8((String)youcangetnoinfoOLAжцачв).writeUtf8("\r\n"); byte b; int i;
/* 186 */     for (b = 0, i = youcangetnoinfoOKZфмткэ.size(); b < i; b++) {
/* 187 */       ((Http1Codec7)super).sink.writeUtf8(youcangetnoinfoOKZфмткэ.name(b))
/* 188 */         .writeUtf8(": ")
/* 189 */         .writeUtf8(youcangetnoinfoOKZфмткэ.value(b))
/* 190 */         .writeUtf8("\r\n");
/*     */     }
/* 192 */     ((Http1Codec7)super).sink.writeUtf8("\r\n");
/* 193 */     ((Http1Codec7)super).state = 1;
/*     */   }
/*     */   
/*     */   public Response1 readResponseHeaders(Object youcangetnoinfoNIPтЕА1п) throws IOException {
/* 197 */     if (((Http1Codec7)super).state != 1 && ((Http1Codec7)super).state != 3) {
/* 198 */       throw new IllegalStateException("state: " + super.state);
/*     */     }
/*     */     
/*     */     try {
/* 202 */       Object youcangetnoinfoNILжшоЗу = StatusLine.parse(super.readHeaderLine());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 208 */       Object youcangetnoinfoNIM2ъйаП = (new Response1()).protocol(((StatusLine)youcangetnoinfoNILжшоЗу).protocol).code(((StatusLine)youcangetnoinfoNILжшоЗу).code).message(((StatusLine)youcangetnoinfoNILжшоЗу).message).headers(super.readHeaders());
/*     */       
/* 210 */       if (youcangetnoinfoNIPтЕА1п != null && ((StatusLine)youcangetnoinfoNILжшоЗу).code == 100)
/* 211 */         return null; 
/* 212 */       if (((StatusLine)youcangetnoinfoNILжшоЗу).code == 100) {
/* 213 */         ((Http1Codec7)super).state = 3;
/* 214 */         return (Response1)youcangetnoinfoNIM2ъйаП;
/*     */       } 
/*     */       
/* 217 */       ((Http1Codec7)super).state = 4;
/* 218 */       return (Response1)youcangetnoinfoNIM2ъйаП;
/* 219 */     } catch (EOFException youcangetnoinfoNINяР2Зю) {
/*     */       
/* 221 */       throw new IOException("unexpected end of stream on " + super.streamAllocation, youcangetnoinfoNINяР2Зю);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String readHeaderLine() throws IOException {
/* 226 */     Object youcangetnoinfoADBLЯеЭбу = ((Http1Codec7)super).source.readUtf8LineStrict(((Http1Codec7)super).headerLimit);
/* 227 */     ((Http1Codec7)super).headerLimit -= youcangetnoinfoADBLЯеЭбу.length();
/* 228 */     return (String)youcangetnoinfoADBLЯеЭбу;
/*     */   }
/*     */ 
/*     */   
/*     */   public Headers readHeaders() throws IOException {
/* 233 */     Object youcangetnoinfoAIJTлдЗФи = new Headers1();
/*     */     Object youcangetnoinfoAIJRОЙ5З2;
/* 235 */     while ((youcangetnoinfoAIJRОЙ5З2 = super.readHeaderLine()).length() != 0) {
/* 236 */       Internal.instance.addLenient((Headers1)youcangetnoinfoAIJTлдЗФи, (String)youcangetnoinfoAIJRОЙ5З2);
/*     */     }
/* 238 */     return youcangetnoinfoAIJTлдЗФи.build();
/*     */   }
/*     */   
/*     */   public Sink newChunkedSink() {
/* 242 */     if (((Http1Codec7)super).state != 1) throw new IllegalStateException("state: " + super.state); 
/* 243 */     ((Http1Codec7)super).state = 2;
/* 244 */     return new Http1Codec1((Http1Codec7)this);
/*     */   }
/*     */   
/*     */   public Sink newFixedLengthSink(Object youcangetnoinfoCHKEАзБшЩ) {
/* 248 */     if (((Http1Codec7)super).state != 1) throw new IllegalStateException("state: " + super.state); 
/* 249 */     ((Http1Codec7)super).state = 2;
/* 250 */     return new Http1Codec2((Http1Codec7)this, youcangetnoinfoCHKEАзБшЩ);
/*     */   }
/*     */   
/*     */   public Source newFixedLengthSource(Object youcangetnoinfoDFLIТУлцЦ) throws IOException {
/* 254 */     if (((Http1Codec7)super).state != 4) throw new IllegalStateException("state: " + super.state); 
/* 255 */     ((Http1Codec7)super).state = 5;
/* 256 */     return new Http1Codec3((Http1Codec7)this, youcangetnoinfoDFLIТУлцЦ);
/*     */   }
/*     */   
/*     */   public Source newChunkedSource(Object youcangetnoinfoEFKEП3даИ) throws IOException {
/* 260 */     if (((Http1Codec7)super).state != 4) throw new IllegalStateException("state: " + super.state); 
/* 261 */     ((Http1Codec7)super).state = 5;
/* 262 */     return new Http1Codec6((Http1Codec7)this, (HttpUrl1)youcangetnoinfoEFKEП3даИ);
/*     */   }
/*     */   
/*     */   public Source newUnknownLengthSource() throws IOException {
/* 266 */     if (((Http1Codec7)super).state != 4) throw new IllegalStateException("state: " + super.state); 
/* 267 */     if (((Http1Codec7)super).streamAllocation == null) throw new IllegalStateException("streamAllocation == null"); 
/* 268 */     ((Http1Codec7)super).state = 5;
/* 269 */     ((Http1Codec7)super).streamAllocation.noNewStreams();
/* 270 */     return new Http1Codec((Http1Codec7)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void detachTimeout(Object youcangetnoinfoDNBCМЪНДд) {
/* 279 */     Object youcangetnoinfoDNBDКПи8ч = youcangetnoinfoDNBCМЪНДд.delegate();
/* 280 */     youcangetnoinfoDNBCМЪНДд.setDelegate(Timeout.NONE);
/* 281 */     youcangetnoinfoDNBDКПи8ч.clearDeadline();
/* 282 */     youcangetnoinfoDNBDКПи8ч.clearTimeout();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http1Codec7.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */