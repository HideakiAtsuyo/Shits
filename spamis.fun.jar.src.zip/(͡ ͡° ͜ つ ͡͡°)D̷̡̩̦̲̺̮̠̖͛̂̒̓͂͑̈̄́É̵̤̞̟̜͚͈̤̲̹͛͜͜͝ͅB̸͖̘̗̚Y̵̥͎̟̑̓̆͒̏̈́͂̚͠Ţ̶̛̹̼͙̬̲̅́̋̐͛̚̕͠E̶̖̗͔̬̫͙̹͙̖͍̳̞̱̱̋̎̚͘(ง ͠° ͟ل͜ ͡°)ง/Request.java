/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Request
/*     */ {
/*     */   @Nullable
/*     */   public CacheControl cacheControl;
/*     */   public final String method;
/*     */   public final Map<Class<?>, Object> tags;
/*     */   public final Headers headers;
/*     */   public final HttpUrl1 url;
/*     */   @Nullable
/*     */   public final RequestBody body;
/*     */   
/*     */   public Request(Object youcangetnoinfoDDPXиз1ВТ) {
/*  40 */     this();
/*  41 */     ((Request)super).url = ((Request1)youcangetnoinfoDDPXиз1ВТ).url;
/*  42 */     ((Request)super).method = ((Request1)youcangetnoinfoDDPXиз1ВТ).method;
/*  43 */     ((Request)super).headers = ((Request1)youcangetnoinfoDDPXиз1ВТ).headers.build();
/*  44 */     ((Request)super).body = ((Request1)youcangetnoinfoDDPXиз1ВТ).body;
/*  45 */     ((Request)super).tags = Util1.immutableMap(((Request1)youcangetnoinfoDDPXиз1ВТ).tags);
/*     */   }
/*     */   
/*     */   public HttpUrl1 url() {
/*  49 */     return ((Request)super).url;
/*     */   }
/*     */   
/*     */   public String method() {
/*  53 */     return ((Request)super).method;
/*     */   }
/*     */   
/*     */   public Headers headers() {
/*  57 */     return ((Request)super).headers;
/*     */   }
/*     */   @Nullable
/*     */   public String header(Object youcangetnoinfoCPUQпРПбд) {
/*  61 */     return ((Request)super).headers.get((String)youcangetnoinfoCPUQпРПбд);
/*     */   }
/*     */   
/*     */   public List<String> headers(Object youcangetnoinfoBFUKшчЫтЩ) {
/*  65 */     return ((Request)super).headers.values((String)youcangetnoinfoBFUKшчЫтЩ);
/*     */   }
/*     */   @Nullable
/*     */   public RequestBody body() {
/*  69 */     return ((Request)super).body;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Object tag() {
/*  81 */     return super.tag(Object.class);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public <T> T tag(Object youcangetnoinfoEMQBШБЙЩ7) {
/*  89 */     return youcangetnoinfoEMQBШБЙЩ7.cast(((Request)super).tags.get(youcangetnoinfoEMQBШБЙЩ7));
/*     */   }
/*     */   
/*     */   public Request1 newBuilder() {
/*  93 */     return new Request1((Request)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl cacheControl() {
/* 101 */     Object youcangetnoinfoZHJкхъзЩ = ((Request)super).cacheControl;
/* 102 */     return (youcangetnoinfoZHJкхъзЩ != null) ? (CacheControl)youcangetnoinfoZHJкхъзЩ : (((Request)super).cacheControl = CacheControl.parse(((Request)super).headers));
/*     */   }
/*     */   
/*     */   public boolean isHttps() {
/* 106 */     return ((Request)super).url.isHttps();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 110 */     return "Request{method=" + ((Request)super).method + ", url=" + ((Request)super).url + ", tags=" + ((Request)super).tags + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Request.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */