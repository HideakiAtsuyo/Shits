/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Response
/*     */   implements Closeable
/*     */ {
/*     */   @Nullable
/*     */   public final Handshake handshake;
/*     */   public final long sentRequestAtMillis;
/*     */   public final int code;
/*     */   public final String message;
/*     */   public final Protocol protocol;
/*     */   public final long receivedResponseAtMillis;
/*     */   @Nullable
/*     */   public final Response cacheResponse;
/*     */   public final Headers headers;
/*     */   @Nullable
/*     */   public final HttpCodec httpCodec;
/*     */   @Nullable
/*     */   public final ResponseBody body;
/*     */   public final Request request;
/*     */   @Nullable
/*     */   public final Response networkResponse;
/*     */   @Nullable
/*     */   public CacheControl cacheControl;
/*     */   @Nullable
/*     */   public final Response priorResponse;
/*     */   
/*     */   public Response(Object youcangetnoinfoCQIUЩиМЮЮ) {
/*  61 */     this();
/*  62 */     ((Response)super).request = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).request;
/*  63 */     ((Response)super).protocol = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).protocol;
/*  64 */     ((Response)super).code = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).code;
/*  65 */     ((Response)super).message = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).message;
/*  66 */     ((Response)super).handshake = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).handshake;
/*  67 */     ((Response)super).headers = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).headers.build();
/*  68 */     ((Response)super).body = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).body;
/*  69 */     ((Response)super).networkResponse = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).networkResponse;
/*  70 */     ((Response)super).cacheResponse = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).cacheResponse;
/*  71 */     ((Response)super).priorResponse = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).priorResponse;
/*  72 */     ((Response)super).sentRequestAtMillis = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).sentRequestAtMillis;
/*  73 */     ((Response)super).receivedResponseAtMillis = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).receivedResponseAtMillis;
/*  74 */     ((Response)super).httpCodec = ((Response1)youcangetnoinfoCQIUЩиМЮЮ).httpCodec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Request request() {
/*  89 */     return ((Response)super).request;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Protocol protocol() {
/*  96 */     return ((Response)super).protocol;
/*     */   }
/*     */ 
/*     */   
/*     */   public int code() {
/* 101 */     return ((Response)super).code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSuccessful() {
/* 109 */     return (((Response)super).code >= 200 && ((Response)super).code < 300);
/*     */   }
/*     */ 
/*     */   
/*     */   public String message() {
/* 114 */     return ((Response)super).message;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Handshake handshake() {
/* 122 */     return ((Response)super).handshake;
/*     */   }
/*     */   
/*     */   public List<String> headers(Object youcangetnoinfoUSRПфШф4) {
/* 126 */     return ((Response)super).headers.values((String)youcangetnoinfoUSRПфШф4);
/*     */   }
/*     */   @Nullable
/*     */   public String header(Object youcangetnoinfoAQIDБЮуЪж) {
/* 130 */     return super.header((String)youcangetnoinfoAQIDБЮуЪж, null);
/*     */   }
/*     */   @Nullable
/*     */   public String header(Object youcangetnoinfoDEMРвлчи, @Nullable Object youcangetnoinfoDENЁаъсН) {
/* 134 */     Object youcangetnoinfoDEO8zгьК = ((Response)super).headers.get((String)youcangetnoinfoDEMРвлчи);
/* 135 */     return (youcangetnoinfoDEO8zгьК != null) ? (String)youcangetnoinfoDEO8zгьК : (String)youcangetnoinfoDENЁаъсН;
/*     */   }
/*     */   
/*     */   public Headers headers() {
/* 139 */     return ((Response)super).headers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Headers trailers() throws IOException {
/* 147 */     return ((Response)super).httpCodec.trailers();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ResponseBody peekBody(Object youcangetnoinfoBUBVЗй0Ке) throws IOException {
/* 162 */     Object youcangetnoinfoBUBWеу4БЬ = ((Response)super).body.source().peek();
/* 163 */     Object youcangetnoinfoBUBXЙВ3рк = new Buffer2();
/* 164 */     youcangetnoinfoBUBWеу4БЬ.request(youcangetnoinfoBUBVЗй0Ке);
/* 165 */     youcangetnoinfoBUBXЙВ3рк.write((Source)youcangetnoinfoBUBWеу4БЬ, Math.min(youcangetnoinfoBUBVЗй0Ке, youcangetnoinfoBUBWеу4БЬ.getBuffer().size()));
/* 166 */     return ResponseBody.create(((Response)super).body.contentType(), youcangetnoinfoBUBXЙВ3рк.size(), (BufferedSource)youcangetnoinfoBUBXЙВ3рк);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public ResponseBody body() {
/* 178 */     return ((Response)super).body;
/*     */   }
/*     */   
/*     */   public Response1 newBuilder() {
/* 182 */     return new Response1((Response)this);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRedirect() {
/* 187 */     switch (((Response)super).code) {
/*     */       case 300:
/*     */       case 301:
/*     */       case 302:
/*     */       case 303:
/*     */       case 307:
/*     */       case 308:
/* 194 */         return true;
/*     */     } 
/* 196 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Response networkResponse() {
/* 206 */     return ((Response)super).networkResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Response cacheResponse() {
/* 215 */     return ((Response)super).cacheResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Nullable
/*     */   public Response priorResponse() {
/* 225 */     return ((Response)super).priorResponse;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List challenges() {
/*     */     Object youcangetnoinfoCMLZч3ЗСЭ;
/* 241 */     if (((Response)super).code == 401) {
/* 242 */       Object youcangetnoinfoCMLYЩЩЬЗЖ = "WWW-Authenticate";
/* 243 */     } else if (((Response)super).code == 407) {
/* 244 */       youcangetnoinfoCMLZч3ЗСЭ = "Proxy-Authenticate";
/*     */     } else {
/* 246 */       return Collections.emptyList();
/*     */     } 
/* 248 */     return HttpHeaders.parseChallenges(super.headers(), (String)youcangetnoinfoCMLZч3ЗСЭ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CacheControl cacheControl() {
/* 256 */     Object youcangetnoinfoHFSжмНат = ((Response)super).cacheControl;
/* 257 */     return (youcangetnoinfoHFSжмНат != null) ? (CacheControl)youcangetnoinfoHFSжмНат : (((Response)super).cacheControl = CacheControl.parse(((Response)super).headers));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long sentRequestAtMillis() {
/* 266 */     return ((Response)super).sentRequestAtMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long receivedResponseAtMillis() {
/* 275 */     return ((Response)super).receivedResponseAtMillis;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 286 */     if (((Response)super).body == null) {
/* 287 */       throw new IllegalStateException("response is not eligible for a body and must not be closed");
/*     */     }
/* 289 */     ((Response)super).body.close();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 293 */     return "Response{protocol=" + ((Response)super).protocol + ", code=" + ((Response)super).code + ", message=" + ((Response)super).message + ", url=" + ((Response)super).request
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 300 */       .url() + '}';
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Response.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */