/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.net.Proxy;
/*     */ import java.net.ProxySelector;
/*     */ import java.security.GeneralSecurityException;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.net.SocketFactory;
/*     */ import javax.net.ssl.HostnameVerifier;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.TrustManager;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OkHttpClient
/*     */   implements WebSocket, Cloneable, Call1
/*     */ {
/*     */   public final int writeTimeout;
/*     */   public final boolean followRedirects;
/*     */   public final int callTimeout;
/*     */   public final ProxySelector proxySelector;
/*     */   public final Authenticator authenticator;
/*     */   public final CertificatePinner1 certificatePinner;
/*     */   public final List protocols;
/*     */   public final List networkInterceptors;
/*     */   public final Authenticator proxyAuthenticator;
/*     */   public final HostnameVerifier hostnameVerifier;
/*     */   public static final List DEFAULT_CONNECTION_SPECS;
/*     */   public final EventListener2 eventListenerFactory;
/*     */   public final List interceptors;
/*     */   public final boolean retryOnConnectionFailure;
/*     */   @Nullable
/*     */   public final Proxy proxy;
/*     */   public final Dispatcher dispatcher;
/*     */   public final boolean followSslRedirects;
/*     */   public final ConnectionPool connectionPool;
/*     */   public final int pingInterval;
/*     */   @Nullable
/*     */   public final Cache6 cache;
/*     */   public final int connectTimeout;
/*     */   @Nullable
/*     */   public final InternalCache internalCache;
/*     */   public final SocketFactory socketFactory;
/*     */   public final int readTimeout;
/*     */   public final CookieJar cookieJar;
/*     */   public final CertificateChainCleaner certificateChainCleaner;
/* 127 */   public static final List DEFAULT_PROTOCOLS = Util1.immutableList(new Protocol[] { Protocol.HTTP_2, Protocol.HTTP_1_1 });
/*     */   
/*     */   static {
/* 130 */     DEFAULT_CONNECTION_SPECS = Util1.immutableList(new ConnectionSpec[] { ConnectionSpec.MODERN_TLS, ConnectionSpec.CLEARTEXT });
/*     */ 
/*     */ 
/*     */     
/* 134 */     Internal.instance = new OkHttpClient2();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final SSLSocketFactory sslSocketFactory;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final Dns dns;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final List connectionSpecs;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OkHttpClient() {
/* 235 */     super(new OkHttpClient1());
/*     */   }
/*     */   public OkHttpClient(Object youcangetnoinfoCZKDЩнцеФ) {
/* 238 */     this();
/* 239 */     ((OkHttpClient)super).dispatcher = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).dispatcher;
/* 240 */     ((OkHttpClient)super).proxy = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).proxy;
/* 241 */     ((OkHttpClient)super).protocols = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).protocols;
/* 242 */     ((OkHttpClient)super).connectionSpecs = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).connectionSpecs;
/* 243 */     ((OkHttpClient)super).interceptors = Util1.immutableList(((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).interceptors);
/* 244 */     ((OkHttpClient)super).networkInterceptors = Util1.immutableList(((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).networkInterceptors);
/* 245 */     ((OkHttpClient)super).eventListenerFactory = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).eventListenerFactory;
/* 246 */     ((OkHttpClient)super).proxySelector = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).proxySelector;
/* 247 */     ((OkHttpClient)super).cookieJar = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).cookieJar;
/* 248 */     ((OkHttpClient)super).cache = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).cache;
/* 249 */     ((OkHttpClient)super).internalCache = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).internalCache;
/* 250 */     ((OkHttpClient)super).socketFactory = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).socketFactory;
/*     */     
/* 252 */     boolean bool = false;
/* 253 */     for (Object youcangetnoinfoCZKAяКшХё : ((OkHttpClient)super).connectionSpecs) {
/* 254 */       bool = (bool || youcangetnoinfoCZKAяКшХё.isTls()) ? true : false;
/*     */     }
/*     */     
/* 257 */     if (((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).sslSocketFactory != null || !bool) {
/* 258 */       ((OkHttpClient)super).sslSocketFactory = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).sslSocketFactory;
/* 259 */       ((OkHttpClient)super).certificateChainCleaner = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).certificateChainCleaner;
/*     */     } else {
/* 261 */       Object youcangetnoinfoCZKBЮмщс6 = Util1.platformTrustManager();
/* 262 */       ((OkHttpClient)super).sslSocketFactory = newSslSocketFactory((X509TrustManager)youcangetnoinfoCZKBЮмщс6);
/* 263 */       ((OkHttpClient)super).certificateChainCleaner = CertificateChainCleaner.get((X509TrustManager)youcangetnoinfoCZKBЮмщс6);
/*     */     } 
/*     */     
/* 266 */     if (((OkHttpClient)super).sslSocketFactory != null) {
/* 267 */       Platform.get().configureSslSocketFactory(((OkHttpClient)super).sslSocketFactory);
/*     */     }
/*     */     
/* 270 */     ((OkHttpClient)super).hostnameVerifier = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).hostnameVerifier;
/* 271 */     ((OkHttpClient)super).certificatePinner = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).certificatePinner.withCertificateChainCleaner(((OkHttpClient)super).certificateChainCleaner);
/*     */     
/* 273 */     ((OkHttpClient)super).proxyAuthenticator = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).proxyAuthenticator;
/* 274 */     ((OkHttpClient)super).authenticator = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).authenticator;
/* 275 */     ((OkHttpClient)super).connectionPool = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).connectionPool;
/* 276 */     ((OkHttpClient)super).dns = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).dns;
/* 277 */     ((OkHttpClient)super).followSslRedirects = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).followSslRedirects;
/* 278 */     ((OkHttpClient)super).followRedirects = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).followRedirects;
/* 279 */     ((OkHttpClient)super).retryOnConnectionFailure = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).retryOnConnectionFailure;
/* 280 */     ((OkHttpClient)super).callTimeout = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).callTimeout;
/* 281 */     ((OkHttpClient)super).connectTimeout = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).connectTimeout;
/* 282 */     ((OkHttpClient)super).readTimeout = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).readTimeout;
/* 283 */     ((OkHttpClient)super).writeTimeout = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).writeTimeout;
/* 284 */     ((OkHttpClient)super).pingInterval = ((OkHttpClient1)youcangetnoinfoCZKDЩнцеФ).pingInterval;
/*     */     
/* 286 */     if (((OkHttpClient)super).interceptors.contains(null)) {
/* 287 */       throw new IllegalStateException("Null interceptor: " + super.interceptors);
/*     */     }
/* 289 */     if (((OkHttpClient)super).networkInterceptors.contains(null)) {
/* 290 */       throw new IllegalStateException("Null network interceptor: " + super.networkInterceptors);
/*     */     }
/*     */   }
/*     */   
/*     */   public static SSLSocketFactory newSslSocketFactory(Object youcangetnoinfoEMOQэЭюЧъ) {
/*     */     try {
/* 296 */       Object youcangetnoinfoEMOOВняЬК = Platform.get().getSSLContext();
/* 297 */       youcangetnoinfoEMOOВняЬК.init(null, new TrustManager[] { (TrustManager)youcangetnoinfoEMOQэЭюЧъ }, null);
/* 298 */       return youcangetnoinfoEMOOВняЬК.getSocketFactory();
/* 299 */     } catch (GeneralSecurityException youcangetnoinfoEMOPЛ2бЖЖ) {
/* 300 */       throw new AssertionError("No System TLS", youcangetnoinfoEMOPЛ2бЖЖ);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int callTimeoutMillis() {
/* 309 */     return ((OkHttpClient)super).callTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public int connectTimeoutMillis() {
/* 314 */     return ((OkHttpClient)super).connectTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public int readTimeoutMillis() {
/* 319 */     return ((OkHttpClient)super).readTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public int writeTimeoutMillis() {
/* 324 */     return ((OkHttpClient)super).writeTimeout;
/*     */   }
/*     */ 
/*     */   
/*     */   public int pingIntervalMillis() {
/* 329 */     return ((OkHttpClient)super).pingInterval;
/*     */   }
/*     */   @Nullable
/*     */   public Proxy proxy() {
/* 333 */     return ((OkHttpClient)super).proxy;
/*     */   }
/*     */   
/*     */   public ProxySelector proxySelector() {
/* 337 */     return ((OkHttpClient)super).proxySelector;
/*     */   }
/*     */   
/*     */   public CookieJar cookieJar() {
/* 341 */     return ((OkHttpClient)super).cookieJar;
/*     */   }
/*     */   @Nullable
/*     */   public Cache6 cache() {
/* 345 */     return ((OkHttpClient)super).cache;
/*     */   }
/*     */   @Nullable
/*     */   public InternalCache internalCache() {
/* 349 */     return (((OkHttpClient)super).cache != null) ? ((OkHttpClient)super).cache.internalCache : ((OkHttpClient)super).internalCache;
/*     */   }
/*     */   
/*     */   public Dns dns() {
/* 353 */     return ((OkHttpClient)super).dns;
/*     */   }
/*     */   
/*     */   public SocketFactory socketFactory() {
/* 357 */     return ((OkHttpClient)super).socketFactory;
/*     */   }
/*     */   
/*     */   public SSLSocketFactory sslSocketFactory() {
/* 361 */     return ((OkHttpClient)super).sslSocketFactory;
/*     */   }
/*     */   
/*     */   public HostnameVerifier hostnameVerifier() {
/* 365 */     return ((OkHttpClient)super).hostnameVerifier;
/*     */   }
/*     */   
/*     */   public CertificatePinner1 certificatePinner() {
/* 369 */     return ((OkHttpClient)super).certificatePinner;
/*     */   }
/*     */   
/*     */   public Authenticator authenticator() {
/* 373 */     return ((OkHttpClient)super).authenticator;
/*     */   }
/*     */   
/*     */   public Authenticator proxyAuthenticator() {
/* 377 */     return ((OkHttpClient)super).proxyAuthenticator;
/*     */   }
/*     */   
/*     */   public ConnectionPool connectionPool() {
/* 381 */     return ((OkHttpClient)super).connectionPool;
/*     */   }
/*     */   
/*     */   public boolean followSslRedirects() {
/* 385 */     return ((OkHttpClient)super).followSslRedirects;
/*     */   }
/*     */   
/*     */   public boolean followRedirects() {
/* 389 */     return ((OkHttpClient)super).followRedirects;
/*     */   }
/*     */   
/*     */   public boolean retryOnConnectionFailure() {
/* 393 */     return ((OkHttpClient)super).retryOnConnectionFailure;
/*     */   }
/*     */   
/*     */   public Dispatcher dispatcher() {
/* 397 */     return ((OkHttpClient)super).dispatcher;
/*     */   }
/*     */   
/*     */   public List protocols() {
/* 401 */     return ((OkHttpClient)super).protocols;
/*     */   }
/*     */   
/*     */   public List connectionSpecs() {
/* 405 */     return ((OkHttpClient)super).connectionSpecs;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List interceptors() {
/* 414 */     return ((OkHttpClient)super).interceptors;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List networkInterceptors() {
/* 423 */     return ((OkHttpClient)super).networkInterceptors;
/*     */   }
/*     */   
/*     */   public EventListener2 eventListenerFactory() {
/* 427 */     return ((OkHttpClient)super).eventListenerFactory;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Call newCall(Object youcangetnoinfoCXOEШюЬью) {
/* 434 */     return RealCall2.newRealCall((OkHttpClient)this, (Request)youcangetnoinfoCXOEШюЬью, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WebSocket1 newWebSocket(Object youcangetnoinfoNCГс439, Object youcangetnoinfoNDфЪЬ7х) {
/* 441 */     Object youcangetnoinfoNEлйжсХ = new RealWebSocket5((Request)youcangetnoinfoNCГс439, (WebSocketListener)youcangetnoinfoNDфЪЬ7х, new Random(), ((OkHttpClient)super).pingInterval);
/* 442 */     youcangetnoinfoNEлйжсХ.connect((OkHttpClient)this);
/* 443 */     return (WebSocket1)youcangetnoinfoNEлйжсХ;
/*     */   }
/*     */   
/*     */   public OkHttpClient1 newBuilder() {
/* 447 */     return new OkHttpClient1((OkHttpClient)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\OkHttpClient.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */