/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import android.os.Build;
/*     */ import android.util.Log;
/*     */ import java.io.IOException;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.net.SocketAddress;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AndroidPlatform2
/*     */   extends Platform
/*     */ {
/*     */   public final Method getAlpnSelectedProtocol;
/*     */   public final AndroidPlatform closeGuard;
/*     */   public final Method setAlpnProtocols;
/*     */   public final Class<?> sslParametersClass;
/*     */   public final Method setHostname;
/*     */   public final Method setUseSessionTickets;
/*     */   public static final int MAX_LOG_LENGTH = 4000;
/*     */   
/*     */   public AndroidPlatform2(Object youcangetnoinfoBSBRФХУжЁ, Object youcangetnoinfoBSBSШКЭс7, Object youcangetnoinfoBSBTГхаё7, Object youcangetnoinfoBSBUиНЁёс, Object youcangetnoinfoBSBVувz0ё) {
/*  52 */     ((AndroidPlatform2)super).closeGuard = AndroidPlatform.get();
/*     */ 
/*     */ 
/*     */     
/*  56 */     ((AndroidPlatform2)super).sslParametersClass = (Class<?>)youcangetnoinfoBSBRФХУжЁ;
/*  57 */     ((AndroidPlatform2)super).setUseSessionTickets = (Method)youcangetnoinfoBSBSШКЭс7;
/*  58 */     ((AndroidPlatform2)super).setHostname = (Method)youcangetnoinfoBSBTГхаё7;
/*  59 */     ((AndroidPlatform2)super).getAlpnSelectedProtocol = (Method)youcangetnoinfoBSBUиНЁёс;
/*  60 */     ((AndroidPlatform2)super).setAlpnProtocols = (Method)youcangetnoinfoBSBVувz0ё;
/*     */   }
/*     */ 
/*     */   
/*     */   public void connectSocket(Object youcangetnoinfoCYRTъЕПяС, Object youcangetnoinfoCYRUП6жЕЧ, Object youcangetnoinfoCYRVКЕщчб) throws IOException {
/*     */     try {
/*  66 */       youcangetnoinfoCYRTъЕПяС.connect((SocketAddress)youcangetnoinfoCYRUП6жЕЧ, youcangetnoinfoCYRVКЕщчб);
/*  67 */     } catch (AssertionError youcangetnoinfoCYRQЪ1ЯщЛ) {
/*  68 */       if (Util1.isAndroidGetsocknameError((AssertionError)youcangetnoinfoCYRQЪ1ЯщЛ)) throw new IOException(youcangetnoinfoCYRQЪ1ЯщЛ); 
/*  69 */       throw youcangetnoinfoCYRQЪ1ЯщЛ;
/*  70 */     } catch (ClassCastException youcangetnoinfoCYRRэъОоц) {
/*     */ 
/*     */       
/*  73 */       if (Build.VERSION.SDK_INT == 26) {
/*  74 */         throw new IOException("Exception in connect", youcangetnoinfoCYRRэъОоц);
/*     */       }
/*  76 */       throw youcangetnoinfoCYRRэъОоц;
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public X509TrustManager trustManager(Object youcangetnoinfoAAUZЕДФУИ) {
/*  82 */     Object youcangetnoinfoAAVAиСВzк = readFieldOrNull(youcangetnoinfoAAUZЕДФУИ, ((AndroidPlatform2)super).sslParametersClass, "sslParameters");
/*  83 */     if (youcangetnoinfoAAVAиСВzк == null) {
/*     */       
/*     */       try {
/*     */         
/*  87 */         Object<?> youcangetnoinfoAAUWыйдДк = (Object<?>)Class.forName("com.google.android.gms.org.conscrypt.SSLParametersImpl", false, youcangetnoinfoAAUZЕДФУИ
/*     */             
/*  89 */             .getClass().getClassLoader());
/*  90 */         youcangetnoinfoAAVAиСВzк = readFieldOrNull(youcangetnoinfoAAUZЕДФУИ, (Class<?>)youcangetnoinfoAAUWыйдДк, "sslParameters");
/*  91 */       } catch (ClassNotFoundException youcangetnoinfoAAUXНсоУВ) {
/*  92 */         return super.trustManager((SSLSocketFactory)youcangetnoinfoAAUZЕДФУИ);
/*     */       } 
/*     */     }
/*     */     
/*  96 */     Object youcangetnoinfoAAVBУзтвэ = readFieldOrNull(youcangetnoinfoAAVAиСВzк, X509TrustManager.class, "x509TrustManager");
/*     */     
/*  98 */     if (youcangetnoinfoAAVBУзтвэ != null) return (X509TrustManager)youcangetnoinfoAAVBУзтвэ;
/*     */     
/* 100 */     return readFieldOrNull(youcangetnoinfoAAVAиСВzк, X509TrustManager.class, "trustManager");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureTlsExtensions(Object youcangetnoinfoCQVEВЪ2аЕ, Object youcangetnoinfoCQVFБлЯчЛ, Object youcangetnoinfoCQVGеяЕфИ) {
/*     */     try {
/* 107 */       if (youcangetnoinfoCQVFБлЯчЛ != null) {
/* 108 */         ((AndroidPlatform2)super).setUseSessionTickets.invoke(youcangetnoinfoCQVEВЪ2аЕ, new Object[] { Boolean.valueOf(true) });
/*     */         
/* 110 */         ((AndroidPlatform2)super).setHostname.invoke(youcangetnoinfoCQVEВЪ2аЕ, new Object[] { youcangetnoinfoCQVFБлЯчЛ });
/*     */       } 
/*     */ 
/*     */       
/* 114 */       ((AndroidPlatform2)super).setAlpnProtocols.invoke(youcangetnoinfoCQVEВЪ2аЕ, new Object[] { concatLengthPrefixed((List)youcangetnoinfoCQVGеяЕфИ) });
/* 115 */     } catch (IllegalAccessException|InvocationTargetException youcangetnoinfoCQVCжЯЩёМ) {
/* 116 */       throw new AssertionError(youcangetnoinfoCQVCжЯЩёМ);
/*     */     } 
/*     */   }
/*     */   @Nullable
/*     */   public String getSelectedProtocol(Object youcangetnoinfoBGXEъЪьтЦ) {
/*     */     try {
/* 122 */       Object youcangetnoinfoBGXBзшНЯХ = ((AndroidPlatform2)super).getAlpnSelectedProtocol.invoke(youcangetnoinfoBGXEъЪьтЦ, new Object[0]);
/* 123 */       return (youcangetnoinfoBGXBзшНЯХ != null) ? new String((byte[])youcangetnoinfoBGXBзшНЯХ, StandardCharsets.UTF_8) : null;
/* 124 */     } catch (IllegalAccessException|InvocationTargetException youcangetnoinfoBGXCщБуИ4) {
/* 125 */       throw new AssertionError(youcangetnoinfoBGXCщБуИ4);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void log(Object youcangetnoinfoECOEСёнйш, Object youcangetnoinfoECOFЗжЧт5, @Nullable Object youcangetnoinfoECOGдСй1ъ) {
/* 130 */     byte b = (youcangetnoinfoECOEСёнйш == 5) ? 5 : 3;
/* 131 */     if (youcangetnoinfoECOGдСй1ъ != null) youcangetnoinfoECOFЗжЧт5 = youcangetnoinfoECOFЗжЧт5 + '\n' + Log.getStackTraceString((Throwable)youcangetnoinfoECOGдСй1ъ);
/*     */ 
/*     */     
/* 134 */     for (int i = 0, j = youcangetnoinfoECOFЗжЧт5.length(); i < j; ) {
/* 135 */       int k = youcangetnoinfoECOFЗжЧт5.indexOf('\n', i);
/* 136 */       k = (k != -1) ? k : j;
/*     */       while (true) {
/* 138 */         int m = Math.min(k, i + 4000);
/* 139 */         Log.println(b, "OkHttp", youcangetnoinfoECOFЗжЧт5.substring(i, m));
/* 140 */         i = m;
/* 141 */         if (i >= k)
/*     */           i++; 
/*     */       } 
/*     */     } 
/*     */   } public Object getStackTraceForCloseable(Object youcangetnoinfoIEMжпЯмв) {
/* 146 */     return ((AndroidPlatform2)super).closeGuard.createAndOpen((String)youcangetnoinfoIEMжпЯмв);
/*     */   }
/*     */   
/*     */   public void logCloseableLeak(Object youcangetnoinfoVWXЮ71ёл, Object youcangetnoinfoVWYЗЛЛИг) {
/* 150 */     boolean bool = ((AndroidPlatform2)super).closeGuard.warnIfOpen(youcangetnoinfoVWYЗЛЛИг);
/* 151 */     if (!bool)
/*     */     {
/* 153 */       super.log(5, (String)youcangetnoinfoVWXЮ71ёл, (Throwable)null);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isCleartextTrafficPermitted(Object youcangetnoinfoEEMRхХХо2) {
/*     */     try {
/* 159 */       Object<?> youcangetnoinfoEEMLЧфеЫа = (Object<?>)Class.forName("android.security.NetworkSecurityPolicy");
/* 160 */       Object youcangetnoinfoEEMMЦЁЕЁе = youcangetnoinfoEEMLЧфеЫа.getMethod("getInstance", new Class[0]);
/* 161 */       Object youcangetnoinfoEEMNФЗхШЮ = youcangetnoinfoEEMMЦЁЕЁе.invoke(null, new Object[0]);
/* 162 */       return super.api24IsCleartextTrafficPermitted((String)youcangetnoinfoEEMRхХХо2, (Class<?>)youcangetnoinfoEEMLЧфеЫа, youcangetnoinfoEEMNФЗхШЮ);
/* 163 */     } catch (ClassNotFoundException|NoSuchMethodException youcangetnoinfoEEMOяПШлк) {
/* 164 */       return super.isCleartextTrafficPermitted((String)youcangetnoinfoEEMRхХХо2);
/* 165 */     } catch (IllegalAccessException|IllegalArgumentException|InvocationTargetException youcangetnoinfoEEMPыйэШЭ) {
/* 166 */       throw new AssertionError("unable to determine cleartext support", youcangetnoinfoEEMPыйэШЭ);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean api24IsCleartextTrafficPermitted(Object youcangetnoinfoDWKRцКЮЫё, Object youcangetnoinfoDWKSслШна, Object youcangetnoinfoDWKTщажГ8) throws IllegalAccessException, InvocationTargetException {
/*     */     try {
/* 174 */       Object youcangetnoinfoDWKOФы0ёЭ = youcangetnoinfoDWKSслШна.getMethod("isCleartextTrafficPermitted", new Class[] { String.class });
/* 175 */       return ((Boolean)youcangetnoinfoDWKOФы0ёЭ.invoke(youcangetnoinfoDWKTщажГ8, new Object[] { youcangetnoinfoDWKRцКЮЫё })).booleanValue();
/* 176 */     } catch (NoSuchMethodException youcangetnoinfoDWKPКМЕпв) {
/* 177 */       return super.api23IsCleartextTrafficPermitted((String)youcangetnoinfoDWKRцКЮЫё, (Class<?>)youcangetnoinfoDWKSслШна, youcangetnoinfoDWKTщажГ8);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean api23IsCleartextTrafficPermitted(Object youcangetnoinfoAMUKРНКеК, Object youcangetnoinfoAMULПЛГлм, Object youcangetnoinfoAMUMЙШгн6) throws InvocationTargetException, IllegalAccessException {
/*     */     try {
/* 185 */       Object youcangetnoinfoAMUHдннЕЪ = youcangetnoinfoAMULПЛГлм.getMethod("isCleartextTrafficPermitted", new Class[0]);
/* 186 */       return ((Boolean)youcangetnoinfoAMUHдннЕЪ.invoke(youcangetnoinfoAMUMЙШгн6, new Object[0])).booleanValue();
/* 187 */     } catch (NoSuchMethodException youcangetnoinfoAMUIзШгПЕ) {
/* 188 */       return super.isCleartextTrafficPermitted((String)youcangetnoinfoAMUKРНКеК);
/*     */     } 
/*     */   }
/*     */   
/*     */   public CertificateChainCleaner buildCertificateChainCleaner(Object youcangetnoinfoCWSGтфёКБ) {
/*     */     try {
/* 194 */       Object<?> youcangetnoinfoCWSAэтаэЛ = (Object<?>)Class.forName("android.net.http.X509TrustManagerExtensions");
/* 195 */       Object<?> youcangetnoinfoCWSBилдМч = (Object<?>)youcangetnoinfoCWSAэтаэЛ.getConstructor(new Class[] { X509TrustManager.class });
/* 196 */       Object youcangetnoinfoCWSCцЙгры = youcangetnoinfoCWSBилдМч.newInstance(new Object[] { youcangetnoinfoCWSGтфёКБ });
/* 197 */       Object youcangetnoinfoCWSDмыЬЪВ = youcangetnoinfoCWSAэтаэЛ.getMethod("checkServerTrusted", new Class[] { X509Certificate[].class, String.class, String.class });
/*     */       
/* 199 */       return new AndroidPlatform1(youcangetnoinfoCWSCцЙгры, (Method)youcangetnoinfoCWSDмыЬЪВ);
/* 200 */     } catch (Exception youcangetnoinfoCWSE73мхъ) {
/* 201 */       throw new AssertionError(youcangetnoinfoCWSE73мхъ);
/*     */     } 
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public static Platform buildIfSupported() {
/*     */     Object<?> youcangetnoinfoRGLГМЙЛ1;
/*     */     Object<?> youcangetnoinfoRGMя2уЫ1;
/*     */     try {
/* 210 */       youcangetnoinfoRGLГМЙЛ1 = (Object<?>)Class.forName("com.android.org.conscrypt.SSLParametersImpl");
/* 211 */       youcangetnoinfoRGMя2уЫ1 = (Object<?>)Class.forName("com.android.org.conscrypt.OpenSSLSocketImpl");
/* 212 */     } catch (ClassNotFoundException youcangetnoinfoRGNмьёрц) {
/* 213 */       return null;
/*     */     } 
/* 215 */     if (Build.VERSION.SDK_INT >= 21) {
/*     */       try {
/* 217 */         Object youcangetnoinfoRGOУждЦП = youcangetnoinfoRGMя2уЫ1.getDeclaredMethod("setUseSessionTickets", new Class[] { boolean.class });
/*     */         
/* 219 */         Object youcangetnoinfoRGPГ9цЭЖ = youcangetnoinfoRGMя2уЫ1.getMethod("setHostname", new Class[] { String.class });
/* 220 */         Object youcangetnoinfoRGQжхХмШ = youcangetnoinfoRGMя2уЫ1.getMethod("getAlpnSelectedProtocol", new Class[0]);
/* 221 */         Object youcangetnoinfoRGRъ9иИы = youcangetnoinfoRGMя2уЫ1.getMethod("setAlpnProtocols", new Class[] { byte[].class });
/* 222 */         return new AndroidPlatform2((Class<?>)youcangetnoinfoRGLГМЙЛ1, (Method)youcangetnoinfoRGOУждЦП, (Method)youcangetnoinfoRGPГ9цЭЖ, (Method)youcangetnoinfoRGQжхХмШ, (Method)youcangetnoinfoRGRъ9иИы);
/*     */       }
/* 224 */       catch (NoSuchMethodException noSuchMethodException) {}
/*     */     }
/*     */     
/* 227 */     throw new IllegalStateException("Expected Android API level 21+ but was " + Build.VERSION.SDK_INT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SSLContext getSSLContext() {
/*     */     boolean bool;
/*     */     try {
/* 332 */       bool = (Build.VERSION.SDK_INT >= 16 && Build.VERSION.SDK_INT < 22) ? true : false;
/* 333 */     } catch (NoClassDefFoundError youcangetnoinfoCIEOрйБцч) {
/*     */ 
/*     */       
/* 336 */       bool = true;
/*     */     } 
/*     */     
/* 339 */     if (bool) {
/*     */       try {
/* 341 */         return SSLContext.getInstance("TLSv1.2");
/* 342 */       } catch (NoSuchAlgorithmException noSuchAlgorithmException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 348 */       return SSLContext.getInstance("TLS");
/* 349 */     } catch (NoSuchAlgorithmException youcangetnoinfoCIEPЩЖНсД) {
/* 350 */       throw new IllegalStateException("No TLS provider", youcangetnoinfoCIEPЩЖНсД);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\AndroidPlatform2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */