/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ForwardingSource
/*    */   implements Source
/*    */ {
/*    */   public final Source delegate;
/*    */   
/*    */   public ForwardingSource(Object youcangetnoinfoMSMлъОПс) {
/* 24 */     this();
/* 25 */     if (youcangetnoinfoMSMлъОПс == null) throw new IllegalArgumentException("delegate == null"); 
/* 26 */     ((ForwardingSource)super).delegate = (Source)youcangetnoinfoMSMлъОПс;
/*    */   }
/*    */ 
/*    */   
/*    */   public final Source delegate() {
/* 31 */     return ((ForwardingSource)super).delegate;
/*    */   }
/*    */   
/*    */   public long read(Object youcangetnoinfoEORZэОътд, Object youcangetnoinfoEOSAО300П) throws IOException {
/* 35 */     return ((ForwardingSource)super).delegate.read((Buffer2)youcangetnoinfoEORZэОътд, youcangetnoinfoEOSAО300П);
/*    */   }
/*    */   
/*    */   public Timeout timeout() {
/* 39 */     return ((ForwardingSource)super).delegate.timeout();
/*    */   }
/*    */   
/*    */   public void close() throws IOException {
/* 43 */     ((ForwardingSource)super).delegate.close();
/*    */   }
/*    */   
/*    */   public String toString() {
/* 47 */     return getClass().getSimpleName() + "(" + ((ForwardingSource)super).delegate.toString() + ")";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ForwardingSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */