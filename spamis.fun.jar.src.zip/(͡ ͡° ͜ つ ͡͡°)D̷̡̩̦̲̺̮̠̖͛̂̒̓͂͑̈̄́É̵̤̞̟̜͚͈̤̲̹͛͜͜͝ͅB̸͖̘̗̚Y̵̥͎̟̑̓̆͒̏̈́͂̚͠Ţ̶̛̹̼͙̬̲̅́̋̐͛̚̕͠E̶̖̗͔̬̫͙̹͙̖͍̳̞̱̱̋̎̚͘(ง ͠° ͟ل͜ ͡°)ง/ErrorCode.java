/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum ErrorCode
/*    */ {
/*    */   public static final ErrorCode[] $VALUES;
/*    */   public final int httpCode;
/*    */   REFUSED_STREAM,
/*    */   ENHANCE_YOUR_CALM,
/*    */   CANCEL,
/*    */   COMPRESSION_ERROR,
/* 21 */   NO_ERROR(0),
/*    */   
/* 23 */   PROTOCOL_ERROR(1), HTTP_1_1_REQUIRED(1), FLOW_CONTROL_ERROR(1), CONNECT_ERROR(1), INADEQUATE_SECURITY(1),
/*    */   
/* 25 */   INTERNAL_ERROR(2);
/*    */   static {
/* 27 */     FLOW_CONTROL_ERROR = new ErrorCode("FLOW_CONTROL_ERROR", 3, 3);
/*    */     
/* 29 */     REFUSED_STREAM = new ErrorCode("REFUSED_STREAM", 4, 7);
/*    */     
/* 31 */     CANCEL = new ErrorCode("CANCEL", 5, 8);
/*    */     
/* 33 */     COMPRESSION_ERROR = new ErrorCode("COMPRESSION_ERROR", 6, 9);
/*    */     
/* 35 */     CONNECT_ERROR = new ErrorCode("CONNECT_ERROR", 7, 10);
/*    */     
/* 37 */     ENHANCE_YOUR_CALM = new ErrorCode("ENHANCE_YOUR_CALM", 8, 11);
/*    */     
/* 39 */     INADEQUATE_SECURITY = new ErrorCode("INADEQUATE_SECURITY", 9, 12);
/*    */     
/* 41 */     HTTP_1_1_REQUIRED = new ErrorCode("HTTP_1_1_REQUIRED", 10, 13);
/*    */     $VALUES = new ErrorCode[] { 
/*    */         NO_ERROR, PROTOCOL_ERROR, INTERNAL_ERROR, FLOW_CONTROL_ERROR, REFUSED_STREAM, CANCEL, COMPRESSION_ERROR, CONNECT_ERROR, ENHANCE_YOUR_CALM, INADEQUATE_SECURITY, 
/*    */         HTTP_1_1_REQUIRED };
/*    */   } ErrorCode(Object youcangetnoinfoCAJOХРкГШ) {
/* 46 */     ((ErrorCode)super).httpCode = youcangetnoinfoCAJOХРкГШ;
/*    */   }
/*    */   
/*    */   public static ErrorCode fromHttp2(Object youcangetnoinfoDUYEхлрТО) {
/* 50 */     for (ErrorCode youcangetnoinfoDUYDрКфа8 : values()) {
/* 51 */       if (youcangetnoinfoDUYDрКфа8.httpCode == youcangetnoinfoDUYEхлрТО) return youcangetnoinfoDUYDрКфа8; 
/*    */     } 
/* 53 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ErrorCode.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */