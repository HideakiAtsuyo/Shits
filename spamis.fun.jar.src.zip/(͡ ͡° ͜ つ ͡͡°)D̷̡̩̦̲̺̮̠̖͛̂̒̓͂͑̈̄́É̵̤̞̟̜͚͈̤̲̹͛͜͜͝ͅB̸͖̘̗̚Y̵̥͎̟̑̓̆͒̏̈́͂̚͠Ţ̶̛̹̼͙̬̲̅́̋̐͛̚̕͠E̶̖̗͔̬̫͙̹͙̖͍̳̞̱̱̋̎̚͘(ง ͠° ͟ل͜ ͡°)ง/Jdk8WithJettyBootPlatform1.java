/*    */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*    */ 
/*    */ import java.lang.reflect.InvocationTargetException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Proxy;
/*    */ import java.util.List;
/*    */ import javax.annotation.Nullable;
/*    */ import javax.net.ssl.SSLSocket;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Jdk8WithJettyBootPlatform1
/*    */   extends Platform
/*    */ {
/*    */   public final Method removeMethod;
/*    */   public final Class<?> serverProviderClass;
/*    */   public final Method getMethod;
/*    */   public final Method putMethod;
/*    */   public final Class<?> clientProviderClass;
/*    */   
/*    */   public Jdk8WithJettyBootPlatform1(Object youcangetnoinfoDHQRЛнщцт, Object youcangetnoinfoDHQSЪпиЁ3, Object youcangetnoinfoDHQT4ЭикЖ, Object youcangetnoinfoDHQUУ5юлО, Object youcangetnoinfoDHQVяz9Э0) {
/* 38 */     ((Jdk8WithJettyBootPlatform1)super).putMethod = (Method)youcangetnoinfoDHQRЛнщцт;
/* 39 */     ((Jdk8WithJettyBootPlatform1)super).getMethod = (Method)youcangetnoinfoDHQSЪпиЁ3;
/* 40 */     ((Jdk8WithJettyBootPlatform1)super).removeMethod = (Method)youcangetnoinfoDHQT4ЭикЖ;
/* 41 */     ((Jdk8WithJettyBootPlatform1)super).clientProviderClass = (Class<?>)youcangetnoinfoDHQUУ5юлО;
/* 42 */     ((Jdk8WithJettyBootPlatform1)super).serverProviderClass = (Class<?>)youcangetnoinfoDHQVяz9Э0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void configureTlsExtensions(Object youcangetnoinfoJTYсМущб, Object youcangetnoinfoJTZжВМсы, Object youcangetnoinfoJUA6z6Пz) {
/* 47 */     Object youcangetnoinfoJUBльАУЦ = alpnProtocolNames((List)youcangetnoinfoJUA6z6Пz);
/*    */     
/*    */     try {
/* 50 */       Object youcangetnoinfoJTVиб9ЬШ = Proxy.newProxyInstance(Platform.class.getClassLoader(), new Class[] { ((Jdk8WithJettyBootPlatform1)super).clientProviderClass, ((Jdk8WithJettyBootPlatform1)super).serverProviderClass }, new Jdk8WithJettyBootPlatform((List<String>)youcangetnoinfoJUBльАУЦ));
/*    */       
/* 52 */       ((Jdk8WithJettyBootPlatform1)super).putMethod.invoke(null, new Object[] { youcangetnoinfoJTYсМущб, youcangetnoinfoJTVиб9ЬШ });
/* 53 */     } catch (InvocationTargetException|IllegalAccessException youcangetnoinfoJTWфМвла) {
/* 54 */       throw new AssertionError("failed to set ALPN", youcangetnoinfoJTWфМвла);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void afterHandshake(Object youcangetnoinfoQCZЦооКг) {
/*    */     try {
/* 60 */       ((Jdk8WithJettyBootPlatform1)super).removeMethod.invoke(null, new Object[] { youcangetnoinfoQCZЦооКг });
/* 61 */     } catch (IllegalAccessException|InvocationTargetException youcangetnoinfoQCXИтМДО) {
/* 62 */       throw new AssertionError("failed to remove ALPN", youcangetnoinfoQCXИтМДО);
/*    */     } 
/*    */   }
/*    */   
/*    */   @Nullable
/*    */   public String getSelectedProtocol(Object youcangetnoinfoDOZFЕуХхЭ) {
/*    */     try {
/* 69 */       Object youcangetnoinfoDOZCеЪХЛЯ = Proxy.getInvocationHandler(((Jdk8WithJettyBootPlatform1)super).getMethod.invoke(null, new Object[] { youcangetnoinfoDOZFЕуХхЭ }));
/* 70 */       if (!((Jdk8WithJettyBootPlatform)youcangetnoinfoDOZCеЪХЛЯ).unsupported && ((Jdk8WithJettyBootPlatform)youcangetnoinfoDOZCеЪХЛЯ).selected == null) {
/* 71 */         Platform.get().log(4, "ALPN callback dropped: HTTP/2 is disabled. Is alpn-boot on the boot class path?", null);
/*    */         
/* 73 */         return null;
/*    */       } 
/* 75 */       return ((Jdk8WithJettyBootPlatform)youcangetnoinfoDOZCеЪХЛЯ).unsupported ? null : ((Jdk8WithJettyBootPlatform)youcangetnoinfoDOZCеЪХЛЯ).selected;
/* 76 */     } catch (InvocationTargetException|IllegalAccessException youcangetnoinfoDOZDкикЖ7) {
/* 77 */       throw new AssertionError("failed to get ALPN selected protocol", youcangetnoinfoDOZDкикЖ7);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static Platform buildIfSupported() {
/*    */     try {
/* 84 */       Object youcangetnoinfoCNZXъщМф4 = "org.eclipse.jetty.alpn.ALPN";
/* 85 */       Object<?> youcangetnoinfoCNZYыСЛмЯ = (Object<?>)Class.forName((String)youcangetnoinfoCNZXъщМф4);
/* 86 */       Object<?> youcangetnoinfoCNZZzШПяЖ = (Object<?>)Class.forName(youcangetnoinfoCNZXъщМф4 + "$Provider");
/* 87 */       Object<?> youcangetnoinfoCOAAОцЭхХ = (Object<?>)Class.forName(youcangetnoinfoCNZXъщМф4 + "$ClientProvider");
/* 88 */       Object<?> youcangetnoinfoCOABЖЧо2ж = (Object<?>)Class.forName(youcangetnoinfoCNZXъщМф4 + "$ServerProvider");
/* 89 */       Object youcangetnoinfoCOACжщиъР = youcangetnoinfoCNZYыСЛмЯ.getMethod("put", new Class[] { SSLSocket.class, (Class)youcangetnoinfoCNZZzШПяЖ });
/* 90 */       Object youcangetnoinfoCOADеЫ4ьР = youcangetnoinfoCNZYыСЛмЯ.getMethod("get", new Class[] { SSLSocket.class });
/* 91 */       Object youcangetnoinfoCOAEмпвди = youcangetnoinfoCNZYыСЛмЯ.getMethod("remove", new Class[] { SSLSocket.class });
/* 92 */       return new Jdk8WithJettyBootPlatform1((Method)youcangetnoinfoCOACжщиъР, (Method)youcangetnoinfoCOADеЫ4ьР, (Method)youcangetnoinfoCOAEмпвди, (Class<?>)youcangetnoinfoCOAAОцЭхХ, (Class<?>)youcangetnoinfoCOABЖЧо2ж);
/*    */     }
/* 94 */     catch (ClassNotFoundException|NoSuchMethodException classNotFoundException) {
/*    */ 
/*    */       
/* 97 */       return null;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Jdk8WithJettyBootPlatform1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */