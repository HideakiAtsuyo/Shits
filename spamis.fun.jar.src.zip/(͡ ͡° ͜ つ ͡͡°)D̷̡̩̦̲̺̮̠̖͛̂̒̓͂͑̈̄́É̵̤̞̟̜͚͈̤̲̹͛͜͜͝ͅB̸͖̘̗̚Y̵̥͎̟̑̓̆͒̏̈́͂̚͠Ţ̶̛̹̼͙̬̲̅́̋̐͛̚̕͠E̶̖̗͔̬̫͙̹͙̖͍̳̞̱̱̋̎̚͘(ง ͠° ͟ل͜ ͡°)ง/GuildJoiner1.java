/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.LayoutManager;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuildJoiner1
/*     */   extends JPanel
/*     */ {
/*     */   public static final long serialVersionUID = -6492511715459084070L;
/*     */   
/*     */   public GuildJoiner1() {
/*  30 */     super.initialize();
/*     */   }
/*     */   
/*     */   public void initialize() {
/*  34 */     setLayout((LayoutManager)null);
/*     */     
/*  36 */     Object youcangetnoinfoDMWXы3НЮ9 = new JLabel("Invite link or code");
/*  37 */     youcangetnoinfoDMWXы3НЮ9.setBounds(28, 12, 293, 15);
/*  38 */     add((Component)youcangetnoinfoDMWXы3НЮ9);
/*     */     
/*  40 */     Object youcangetnoinfoDMWYё3дрц = new JTextField();
/*  41 */     youcangetnoinfoDMWYё3дрц.setBounds(28, 28, 341, 32);
/*  42 */     add((Component)youcangetnoinfoDMWYё3дрц);
/*  43 */     youcangetnoinfoDMWYё3дрц.setColumns(10);
/*     */     
/*  45 */     Object youcangetnoinfoDMWZъ8ёёо = new JLabel("Delay: 30ms");
/*  46 */     youcangetnoinfoDMWZъ8ёёо.setBounds(38, 64, 283, 15);
/*  47 */     add((Component)youcangetnoinfoDMWZъ8ёёо);
/*     */     
/*  49 */     Object youcangetnoinfoDMXAлэШ39 = new JSlider();
/*  50 */     youcangetnoinfoDMXAлэШ39.setValue(30);
/*  51 */     youcangetnoinfoDMXAлэШ39.setMinimum(1);
/*  52 */     youcangetnoinfoDMXAлэШ39.setMaximum(10000);
/*  53 */     youcangetnoinfoDMXAлэШ39.setBounds(38, 80, 319, 32);
/*  54 */     youcangetnoinfoDMXAлэШ39.addChangeListener(new GuildJoiner2((GuildJoiner1)this, (JLabel)youcangetnoinfoDMWZъ8ёёо, (JSlider)youcangetnoinfoDMXAлэШ39));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     add((Component)youcangetnoinfoDMXAлэШ39);
/*     */     
/*  62 */     Object youcangetnoinfoDMXB19лыЭ = new JCheckBox("Remove dead tokens");
/*  63 */     youcangetnoinfoDMXB19лыЭ.setSelected(true);
/*  64 */     youcangetnoinfoDMXB19лыЭ.setBounds(38, 112, 249, 23);
/*  65 */     add((Component)youcangetnoinfoDMXB19лыЭ);
/*     */     
/*  67 */     Object youcangetnoinfoDMXC4схМВ = new JButton("Join");
/*  68 */     youcangetnoinfoDMXC4схМВ.setIcon(new ImageIcon(getClass().getResource("/ui/add.png")));
/*  69 */     youcangetnoinfoDMXC4схМВ.addActionListener(new GuildJoiner((GuildJoiner1)this, (JTextField)youcangetnoinfoDMWYё3дрц, (JCheckBox)youcangetnoinfoDMXB19лыЭ, (JSlider)youcangetnoinfoDMXAлэШ39));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     youcangetnoinfoDMXC4схМВ.setBounds(28, 142, 341, 32);
/* 135 */     add((Component)youcangetnoinfoDMXC4схМВ);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\GuildJoiner1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */