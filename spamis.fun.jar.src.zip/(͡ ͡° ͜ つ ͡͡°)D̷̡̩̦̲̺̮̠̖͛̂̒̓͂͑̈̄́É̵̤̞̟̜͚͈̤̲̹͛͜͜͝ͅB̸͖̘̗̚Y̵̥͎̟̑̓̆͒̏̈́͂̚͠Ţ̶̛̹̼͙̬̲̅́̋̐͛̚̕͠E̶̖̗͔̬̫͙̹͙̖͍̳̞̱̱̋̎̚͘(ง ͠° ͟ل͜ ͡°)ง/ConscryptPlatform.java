/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.Provider;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ import javax.net.ssl.SSLContext;
/*     */ import javax.net.ssl.SSLSocket;
/*     */ import javax.net.ssl.SSLSocketFactory;
/*     */ import javax.net.ssl.X509TrustManager;
/*     */ import org.conscrypt.Conscrypt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ConscryptPlatform
/*     */   extends Platform
/*     */ {
/*     */   public Provider getProvider() {
/*  39 */     return Conscrypt.newProviderBuilder().provideTrustManager().build();
/*     */   }
/*     */   @Nullable
/*     */   public X509TrustManager trustManager(Object youcangetnoinfoBHCIЯЁИМР) {
/*  43 */     if (!Conscrypt.isConscrypt((SSLSocketFactory)youcangetnoinfoBHCIЯЁИМР)) {
/*  44 */       return super.trustManager((SSLSocketFactory)youcangetnoinfoBHCIЯЁИМР);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  50 */       Object youcangetnoinfoBHCFИДз78 = readFieldOrNull(youcangetnoinfoBHCIЯЁИМР, Object.class, "sslParameters");
/*     */       
/*  52 */       if (youcangetnoinfoBHCFИДз78 != null) {
/*  53 */         return readFieldOrNull(youcangetnoinfoBHCFИДз78, X509TrustManager.class, "x509TrustManager");
/*     */       }
/*     */       
/*  56 */       return null;
/*  57 */     } catch (Exception youcangetnoinfoBHCGлЮуГй) {
/*  58 */       throw new UnsupportedOperationException("clientBuilder.sslSocketFactory(SSLSocketFactory) not supported on Conscrypt", youcangetnoinfoBHCGлЮуГй);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void configureTlsExtensions(Object youcangetnoinfoDTJGЭсбшЧ, Object youcangetnoinfoDTJHЛСкВи, Object youcangetnoinfoDTJIЦ9шИе) {
/*  65 */     if (Conscrypt.isConscrypt((SSLSocket)youcangetnoinfoDTJGЭсбшЧ)) {
/*     */       
/*  67 */       if (youcangetnoinfoDTJHЛСкВи != null) {
/*  68 */         Conscrypt.setUseSessionTickets((SSLSocket)youcangetnoinfoDTJGЭсбшЧ, true);
/*  69 */         Conscrypt.setHostname((SSLSocket)youcangetnoinfoDTJGЭсбшЧ, (String)youcangetnoinfoDTJHЛСкВи);
/*     */       } 
/*     */ 
/*     */       
/*  73 */       Object youcangetnoinfoDTJEжЬБШх = Platform.alpnProtocolNames((List)youcangetnoinfoDTJIЦ9шИе);
/*  74 */       Conscrypt.setApplicationProtocols((SSLSocket)youcangetnoinfoDTJGЭсбшЧ, (String[])youcangetnoinfoDTJEжЬБШх.toArray((Object[])new String[0]));
/*     */     } else {
/*  76 */       super.configureTlsExtensions((SSLSocket)youcangetnoinfoDTJGЭсбшЧ, (String)youcangetnoinfoDTJHЛСкВи, (List)youcangetnoinfoDTJIЦ9шИе);
/*     */     } 
/*     */   }
/*     */   @Nullable
/*     */   public String getSelectedProtocol(Object youcangetnoinfoCJAGЯСФсо) {
/*  81 */     if (Conscrypt.isConscrypt((SSLSocket)youcangetnoinfoCJAGЯСФсо)) {
/*  82 */       return Conscrypt.getApplicationProtocol((SSLSocket)youcangetnoinfoCJAGЯСФсо);
/*     */     }
/*  84 */     return super.getSelectedProtocol((SSLSocket)youcangetnoinfoCJAGЯСФсо);
/*     */   }
/*     */ 
/*     */   
/*     */   public SSLContext getSSLContext() {
/*     */     try {
/*  90 */       return SSLContext.getInstance("TLSv1.3", super.getProvider());
/*  91 */     } catch (NoSuchAlgorithmException youcangetnoinfoAFBBц1чАВ) {
/*     */       
/*     */       try {
/*  94 */         return SSLContext.getInstance("TLS", super.getProvider());
/*  95 */       } catch (NoSuchAlgorithmException youcangetnoinfoAFBAи1ТНФ) {
/*  96 */         throw new IllegalStateException("No TLS provider", youcangetnoinfoAFBBц1чАВ);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static ConscryptPlatform buildIfSupported() {
/*     */     try {
/* 104 */       Class.forName("org.conscrypt.Conscrypt");
/*     */       
/* 106 */       if (!Conscrypt.isAvailable()) {
/* 107 */         return null;
/*     */       }
/*     */       
/* 110 */       return new ConscryptPlatform();
/* 111 */     } catch (ClassNotFoundException youcangetnoinfoAVMXичжХй) {
/* 112 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureSslSocketFactory(Object youcangetnoinfoDRHUzзсЖй) {
/* 118 */     if (Conscrypt.isConscrypt((SSLSocketFactory)youcangetnoinfoDRHUzзсЖй))
/* 119 */       Conscrypt.setUseEngineSocket((SSLSocketFactory)youcangetnoinfoDRHUzзсЖй, true); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\ConscryptPlatform.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */