/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.security.Principal;
/*     */ import java.security.cert.Certificate;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.annotation.Nullable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Handshake
/*     */ {
/*     */   public final TlsVersion tlsVersion;
/*     */   public final List<Certificate> peerCertificates;
/*     */   public final CipherSuite cipherSuite;
/*     */   public final List<Certificate> localCertificates;
/*     */   
/*     */   public Handshake(Object youcangetnoinfoAVKZЙФСЧк, Object youcangetnoinfoAVLA84ЁЁО, Object youcangetnoinfoAVLBя2гКч, Object youcangetnoinfoAVLCхКzЗй) {
/*  44 */     this();
/*  45 */     ((Handshake)super).tlsVersion = (TlsVersion)youcangetnoinfoAVKZЙФСЧк;
/*  46 */     ((Handshake)super).cipherSuite = (CipherSuite)youcangetnoinfoAVLA84ЁЁО;
/*  47 */     ((Handshake)super).peerCertificates = (List<Certificate>)youcangetnoinfoAVLBя2гКч;
/*  48 */     ((Handshake)super).localCertificates = (List<Certificate>)youcangetnoinfoAVLCхКzЗй;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Handshake get(Object youcangetnoinfoEEWAфПпТЛ) throws IOException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokeinterface getCipherSuite : ()Ljava/lang/String;
/*     */     //   6: astore_1
/*     */     //   7: aload_1
/*     */     //   8: ifnonnull -> 21
/*     */     //   11: new java/lang/IllegalStateException
/*     */     //   14: dup
/*     */     //   15: ldc 'cipherSuite == null'
/*     */     //   17: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   20: athrow
/*     */     //   21: ldc 'SSL_NULL_WITH_NULL_NULL'
/*     */     //   23: aload_1
/*     */     //   24: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   27: ifeq -> 40
/*     */     //   30: new java/io/IOException
/*     */     //   33: dup
/*     */     //   34: ldc 'cipherSuite == SSL_NULL_WITH_NULL_NULL'
/*     */     //   36: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   39: athrow
/*     */     //   40: aload_1
/*     */     //   41: invokestatic forJavaName : (Ljava/lang/String;)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/CipherSuite;
/*     */     //   44: astore_2
/*     */     //   45: aload_0
/*     */     //   46: invokeinterface getProtocol : ()Ljava/lang/String;
/*     */     //   51: astore_3
/*     */     //   52: aload_3
/*     */     //   53: ifnonnull -> 66
/*     */     //   56: new java/lang/IllegalStateException
/*     */     //   59: dup
/*     */     //   60: ldc 'tlsVersion == null'
/*     */     //   62: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   65: athrow
/*     */     //   66: ldc 'NONE'
/*     */     //   68: aload_3
/*     */     //   69: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   72: ifeq -> 85
/*     */     //   75: new java/io/IOException
/*     */     //   78: dup
/*     */     //   79: ldc 'tlsVersion == NONE'
/*     */     //   81: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   84: athrow
/*     */     //   85: aload_3
/*     */     //   86: invokestatic forJavaName : (Ljava/lang/String;)L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/TlsVersion;
/*     */     //   89: astore #4
/*     */     //   91: aload_0
/*     */     //   92: invokeinterface getPeerCertificates : ()[Ljava/security/cert/Certificate;
/*     */     //   97: astore #5
/*     */     //   99: goto -> 107
/*     */     //   102: astore #6
/*     */     //   104: aconst_null
/*     */     //   105: astore #5
/*     */     //   107: aload #5
/*     */     //   109: ifnull -> 120
/*     */     //   112: aload #5
/*     */     //   114: invokestatic immutableList : ([Ljava/lang/Object;)Ljava/util/List;
/*     */     //   117: goto -> 123
/*     */     //   120: invokestatic emptyList : ()Ljava/util/List;
/*     */     //   123: astore #6
/*     */     //   125: aload_0
/*     */     //   126: invokeinterface getLocalCertificates : ()[Ljava/security/cert/Certificate;
/*     */     //   131: astore #7
/*     */     //   133: aload #7
/*     */     //   135: ifnull -> 146
/*     */     //   138: aload #7
/*     */     //   140: invokestatic immutableList : ([Ljava/lang/Object;)Ljava/util/List;
/*     */     //   143: goto -> 149
/*     */     //   146: invokestatic emptyList : ()Ljava/util/List;
/*     */     //   149: astore #8
/*     */     //   151: new (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/Handshake
/*     */     //   154: dup
/*     */     //   155: aload #4
/*     */     //   157: aload_2
/*     */     //   158: aload #6
/*     */     //   160: aload #8
/*     */     //   162: invokespecial <init> : (L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/TlsVersion;L(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง/CipherSuite;Ljava/util/List;Ljava/util/List;)V
/*     */     //   165: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #52	-> 0
/*     */     //   #53	-> 7
/*     */     //   #54	-> 21
/*     */     //   #55	-> 30
/*     */     //   #57	-> 40
/*     */     //   #59	-> 45
/*     */     //   #60	-> 52
/*     */     //   #61	-> 66
/*     */     //   #62	-> 85
/*     */     //   #66	-> 91
/*     */     //   #69	-> 99
/*     */     //   #67	-> 102
/*     */     //   #68	-> 104
/*     */     //   #70	-> 107
/*     */     //   #71	-> 112
/*     */     //   #72	-> 120
/*     */     //   #74	-> 125
/*     */     //   #75	-> 133
/*     */     //   #76	-> 138
/*     */     //   #77	-> 146
/*     */     //   #79	-> 151
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   45	121	2	youcangetnoinfoEEWCРЫжАб	Ljava/lang/Object;
/*     */     //   52	114	3	youcangetnoinfoEEWD2мъкс	Ljava/lang/Object;
/*     */     //   7	159	1	youcangetnoinfoEEWBеа3лл	Ljava/lang/Object;
/*     */     //   107	59	5	youcangetnoinfoEEWFфюнЬХ	Ljava/lang/Object;
/*     */     //   125	41	6	youcangetnoinfoEEWGЭгьц0	Ljava/lang/Object;
/*     */     //   0	166	0	youcangetnoinfoEEWAфПпТЛ	Ljava/lang/Object;
/*     */     //   151	15	8	youcangetnoinfoEEWIощУСХ	Ljava/lang/Object;
/*     */     //   104	3	6	youcangetnoinfoEEVZСщАнЬ	Ljava/lang/Object;
/*     */     //   133	33	7	youcangetnoinfoEEWHЖЩчЮи	Ljava/lang/Object;
/*     */     //   91	75	4	youcangetnoinfoEEWEzП1ФЧ	Ljava/lang/Object;
/*     */     //   99	3	5	youcangetnoinfoEEVYнм1дШ	Ljava/lang/Object;
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   91	99	102	javax/net/ssl/SSLPeerUnverifiedException
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Handshake get(Object youcangetnoinfoCUQ4Бф4р, Object youcangetnoinfoCURЗЁф1М, Object youcangetnoinfoCUSРкЮпС, Object youcangetnoinfoCUTТЦйъз) {
/*  84 */     if (youcangetnoinfoCUQ4Бф4р == null) throw new NullPointerException("tlsVersion == null"); 
/*  85 */     if (youcangetnoinfoCURЗЁф1М == null) throw new NullPointerException("cipherSuite == null"); 
/*  86 */     return new Handshake((TlsVersion)youcangetnoinfoCUQ4Бф4р, (CipherSuite)youcangetnoinfoCURЗЁф1М, Util1.immutableList((List<?>)youcangetnoinfoCUSРкЮпС), 
/*  87 */         Util1.immutableList((List<?>)youcangetnoinfoCUTТЦйъз));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TlsVersion tlsVersion() {
/*  95 */     return ((Handshake)super).tlsVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   public CipherSuite cipherSuite() {
/* 100 */     return ((Handshake)super).cipherSuite;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Certificate> peerCertificates() {
/* 105 */     return ((Handshake)super).peerCertificates;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Principal peerPrincipal() {
/* 110 */     return !((Handshake)super).peerCertificates.isEmpty() ? (
/* 111 */       (X509Certificate)((Handshake)super).peerCertificates.get(0)).getSubjectX500Principal() : 
/* 112 */       null;
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Certificate> localCertificates() {
/* 117 */     return ((Handshake)super).localCertificates;
/*     */   }
/*     */   
/*     */   @Nullable
/*     */   public Principal localPrincipal() {
/* 122 */     return !((Handshake)super).localCertificates.isEmpty() ? (
/* 123 */       (X509Certificate)((Handshake)super).localCertificates.get(0)).getSubjectX500Principal() : 
/* 124 */       null;
/*     */   }
/*     */   
/*     */   public boolean equals(@Nullable Object youcangetnoinfoPLOРГдаЧ) {
/* 128 */     if (!(youcangetnoinfoPLOРГдаЧ instanceof Handshake)) return false; 
/* 129 */     Object youcangetnoinfoPLPДаМЫТ = youcangetnoinfoPLOРГдаЧ;
/* 130 */     return (((Handshake)super).tlsVersion.equals(((Handshake)youcangetnoinfoPLPДаМЫТ).tlsVersion) && ((Handshake)super).cipherSuite
/* 131 */       .equals(((Handshake)youcangetnoinfoPLPДаМЫТ).cipherSuite) && ((Handshake)super).peerCertificates
/* 132 */       .equals(((Handshake)youcangetnoinfoPLPДаМЫТ).peerCertificates) && ((Handshake)super).localCertificates
/* 133 */       .equals(((Handshake)youcangetnoinfoPLPДаМЫТ).localCertificates));
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 137 */     int i = 17;
/* 138 */     i = 31 * i + ((Handshake)super).tlsVersion.hashCode();
/* 139 */     i = 31 * i + ((Handshake)super).cipherSuite.hashCode();
/* 140 */     i = 31 * i + ((Handshake)super).peerCertificates.hashCode();
/* 141 */     i = 31 * i + ((Handshake)super).localCertificates.hashCode();
/* 142 */     return i;
/*     */   }
/*     */   
/*     */   public String toString() {
/* 146 */     return "Handshake{tlsVersion=" + ((Handshake)super).tlsVersion + " cipherSuite=" + ((Handshake)super).cipherSuite + " peerCertificates=" + super
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 152 */       .names(((Handshake)super).peerCertificates) + " localCertificates=" + super
/*     */       
/* 154 */       .names(((Handshake)super).localCertificates) + '}';
/*     */   }
/*     */ 
/*     */   
/*     */   public List<String> names(Object youcangetnoinfoDXHYФьУОа) {
/* 159 */     Object youcangetnoinfoDXHZРДИрг = new ArrayList();
/*     */     
/* 161 */     for (Object youcangetnoinfoDXHWаЯРпЖ : youcangetnoinfoDXHYФьУОа) {
/* 162 */       if (youcangetnoinfoDXHWаЯРпЖ instanceof X509Certificate) {
/* 163 */         youcangetnoinfoDXHZРДИрг.add(String.valueOf(((X509Certificate)youcangetnoinfoDXHWаЯРпЖ).getSubjectDN())); continue;
/*     */       } 
/* 165 */       youcangetnoinfoDXHZРДИрг.add(youcangetnoinfoDXHWаЯРпЖ.getType());
/*     */     } 
/*     */ 
/*     */     
/* 169 */     return (List<String>)youcangetnoinfoDXHZРДИрг;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Handshake.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */