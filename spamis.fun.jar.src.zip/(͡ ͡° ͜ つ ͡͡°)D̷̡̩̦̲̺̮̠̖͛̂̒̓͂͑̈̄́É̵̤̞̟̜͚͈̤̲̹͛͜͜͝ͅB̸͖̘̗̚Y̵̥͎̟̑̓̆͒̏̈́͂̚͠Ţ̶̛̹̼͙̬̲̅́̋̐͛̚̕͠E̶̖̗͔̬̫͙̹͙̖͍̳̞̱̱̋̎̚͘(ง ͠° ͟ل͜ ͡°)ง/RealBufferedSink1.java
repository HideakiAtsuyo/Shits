/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.EOFException;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class RealBufferedSink1
/*     */   implements BufferedSink
/*     */ {
/*     */   public boolean closed;
/*     */   public final Buffer2 buffer;
/*     */   public final Sink sink;
/*     */   
/*     */   public RealBufferedSink1(Object youcangetnoinfoDZITдшЪ9В) {
/*  29 */     this(); ((RealBufferedSink1)super).buffer = new Buffer2();
/*  30 */     if (youcangetnoinfoDZITдшЪ9В == null) throw new NullPointerException("sink == null"); 
/*  31 */     ((RealBufferedSink1)super).sink = (Sink)youcangetnoinfoDZITдшЪ9В;
/*     */   }
/*     */   
/*     */   public Buffer2 buffer() {
/*  35 */     return ((RealBufferedSink1)super).buffer;
/*     */   }
/*     */ 
/*     */   
/*     */   public void write(Object youcangetnoinfoDNXMооХуБ, Object youcangetnoinfoDNXNеыТХя) throws IOException {
/*  40 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  41 */     ((RealBufferedSink1)super).buffer.write((Buffer2)youcangetnoinfoDNXMооХуБ, youcangetnoinfoDNXNеыТХя);
/*  42 */     super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink write(Object youcangetnoinfoCQOZй24ЦИ) throws IOException {
/*  46 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  47 */     ((RealBufferedSink1)super).buffer.write((ByteString)youcangetnoinfoCQOZй24ЦИ);
/*  48 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeUtf8(Object youcangetnoinfoAPKPьыЖ3Х) throws IOException {
/*  52 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  53 */     ((RealBufferedSink1)super).buffer.writeUtf8((String)youcangetnoinfoAPKPьыЖ3Х);
/*  54 */     return super.emitCompleteSegments();
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedSink writeUtf8(Object youcangetnoinfoRFL9цКОэ, Object youcangetnoinfoRFMыЕББМ, Object youcangetnoinfoRFNёЛоиВ) throws IOException {
/*  59 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  60 */     ((RealBufferedSink1)super).buffer.writeUtf8((String)youcangetnoinfoRFL9цКОэ, youcangetnoinfoRFMыЕББМ, youcangetnoinfoRFNёЛоиВ);
/*  61 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeUtf8CodePoint(Object youcangetnoinfoAQISЩжШюо) throws IOException {
/*  65 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  66 */     ((RealBufferedSink1)super).buffer.writeUtf8CodePoint(youcangetnoinfoAQISЩжШюо);
/*  67 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeString(Object youcangetnoinfoBATPЕыЙБЖ, Object youcangetnoinfoBATQЕГРГ6) throws IOException {
/*  71 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  72 */     ((RealBufferedSink1)super).buffer.writeString((String)youcangetnoinfoBATPЕыЙБЖ, (Charset)youcangetnoinfoBATQЕГРГ6);
/*  73 */     return super.emitCompleteSegments();
/*     */   }
/*     */ 
/*     */   
/*     */   public BufferedSink writeString(Object youcangetnoinfoARTGЫШоЭЙ, Object youcangetnoinfoARTHzСацМ, Object youcangetnoinfoARTIщуЯць, Object youcangetnoinfoARTJБТШСР) throws IOException {
/*  78 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  79 */     ((RealBufferedSink1)super).buffer.writeString((String)youcangetnoinfoARTGЫШоЭЙ, youcangetnoinfoARTHzСацМ, youcangetnoinfoARTIщуЯць, (Charset)youcangetnoinfoARTJБТШСР);
/*  80 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink write(Object youcangetnoinfoIQLгКикЛ) throws IOException {
/*  84 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  85 */     ((RealBufferedSink1)super).buffer.write((byte[])youcangetnoinfoIQLгКикЛ);
/*  86 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink write(Object youcangetnoinfoARZYМШ7щЕ, Object youcangetnoinfoARZZпвкЁ8, Object youcangetnoinfoASAAТ5Фь2) throws IOException {
/*  90 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  91 */     ((RealBufferedSink1)super).buffer.write((byte[])youcangetnoinfoARZYМШ7щЕ, youcangetnoinfoARZZпвкЁ8, youcangetnoinfoASAAТ5Фь2);
/*  92 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public int write(Object youcangetnoinfoEMPJцнЗх9) throws IOException {
/*  96 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/*  97 */     int i = ((RealBufferedSink1)super).buffer.write((ByteBuffer)youcangetnoinfoEMPJцнЗх9);
/*  98 */     super.emitCompleteSegments();
/*  99 */     return i;
/*     */   }
/*     */   
/*     */   public long writeAll(Object youcangetnoinfoCYWFЁЦеРм) throws IOException {
/* 103 */     if (youcangetnoinfoCYWFЁЦеРм == null) throw new IllegalArgumentException("source == null"); 
/* 104 */     long l1 = 0L; long l2;
/* 105 */     while ((l2 = youcangetnoinfoCYWFЁЦеРм.read(((RealBufferedSink1)super).buffer, 8192L)) != -1L) {
/* 106 */       l1 += l2;
/* 107 */       super.emitCompleteSegments();
/*     */     } 
/* 109 */     return l1;
/*     */   }
/*     */   
/*     */   public BufferedSink write(Object youcangetnoinfoCJFXпд5Цё, Object youcangetnoinfoCJFYЕсрЙ0) throws IOException {
/* 113 */     while (youcangetnoinfoCJFYЕсрЙ0 > 0L) {
/* 114 */       long l2 = youcangetnoinfoCJFXпд5Цё.read(((RealBufferedSink1)super).buffer, youcangetnoinfoCJFYЕсрЙ0);
/* 115 */       if (l2 == -1L) throw new EOFException(); 
/* 116 */       long l1 = youcangetnoinfoCJFYЕсрЙ0 - l2;
/* 117 */       super.emitCompleteSegments();
/*     */     } 
/* 119 */     return (BufferedSink)this;
/*     */   }
/*     */   
/*     */   public BufferedSink writeByte(Object youcangetnoinfoAARGЩО0щ5) throws IOException {
/* 123 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 124 */     ((RealBufferedSink1)super).buffer.writeByte(youcangetnoinfoAARGЩО0щ5);
/* 125 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeShort(Object youcangetnoinfoATIM1ХЁФо) throws IOException {
/* 129 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 130 */     ((RealBufferedSink1)super).buffer.writeShort(youcangetnoinfoATIM1ХЁФо);
/* 131 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeShortLe(Object youcangetnoinfoDUST8еКт8) throws IOException {
/* 135 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 136 */     ((RealBufferedSink1)super).buffer.writeShortLe(youcangetnoinfoDUST8еКт8);
/* 137 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeInt(Object youcangetnoinfoKGIВфЕоТ) throws IOException {
/* 141 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 142 */     ((RealBufferedSink1)super).buffer.writeInt(youcangetnoinfoKGIВфЕоТ);
/* 143 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeIntLe(Object youcangetnoinfoBOFJъаоЪж) throws IOException {
/* 147 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 148 */     ((RealBufferedSink1)super).buffer.writeIntLe(youcangetnoinfoBOFJъаоЪж);
/* 149 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeLong(Object youcangetnoinfoDHWUТгъЪз) throws IOException {
/* 153 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 154 */     ((RealBufferedSink1)super).buffer.writeLong(youcangetnoinfoDHWUТгъЪз);
/* 155 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeLongLe(Object youcangetnoinfoDAQFИЛ2ХТ) throws IOException {
/* 159 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 160 */     ((RealBufferedSink1)super).buffer.writeLongLe(youcangetnoinfoDAQFИЛ2ХТ);
/* 161 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeDecimalLong(Object youcangetnoinfoBSLKьёо57) throws IOException {
/* 165 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 166 */     ((RealBufferedSink1)super).buffer.writeDecimalLong(youcangetnoinfoBSLKьёо57);
/* 167 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink writeHexadecimalUnsignedLong(Object youcangetnoinfoDCUV03дШз) throws IOException {
/* 171 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 172 */     ((RealBufferedSink1)super).buffer.writeHexadecimalUnsignedLong(youcangetnoinfoDCUV03дШз);
/* 173 */     return super.emitCompleteSegments();
/*     */   }
/*     */   
/*     */   public BufferedSink emitCompleteSegments() throws IOException {
/* 177 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 178 */     long l = ((RealBufferedSink1)super).buffer.completeSegmentByteCount();
/* 179 */     if (l > 0L) ((RealBufferedSink1)super).sink.write(((RealBufferedSink1)super).buffer, l); 
/* 180 */     return (BufferedSink)this;
/*     */   }
/*     */   
/*     */   public BufferedSink emit() throws IOException {
/* 184 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 185 */     long l = ((RealBufferedSink1)super).buffer.size();
/* 186 */     if (l > 0L) ((RealBufferedSink1)super).sink.write(((RealBufferedSink1)super).buffer, l); 
/* 187 */     return (BufferedSink)this;
/*     */   }
/*     */   
/*     */   public OutputStream outputStream() {
/* 191 */     return new RealBufferedSink((RealBufferedSink1)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 222 */     if (((RealBufferedSink1)super).closed) throw new IllegalStateException("closed"); 
/* 223 */     if (((RealBufferedSink1)super).buffer.size > 0L) {
/* 224 */       ((RealBufferedSink1)super).sink.write(((RealBufferedSink1)super).buffer, ((RealBufferedSink1)super).buffer.size);
/*     */     }
/* 226 */     ((RealBufferedSink1)super).sink.flush();
/*     */   }
/*     */   
/*     */   public boolean isOpen() {
/* 230 */     return !((RealBufferedSink1)super).closed;
/*     */   }
/*     */   
/*     */   public void close() throws IOException {
/* 234 */     if (((RealBufferedSink1)super).closed) {
/*     */       return;
/*     */     }
/*     */     
/* 238 */     Object youcangetnoinfoVEAшЛж6А = null;
/*     */     try {
/* 240 */       if (((RealBufferedSink1)super).buffer.size > 0L) {
/* 241 */         ((RealBufferedSink1)super).sink.write(((RealBufferedSink1)super).buffer, ((RealBufferedSink1)super).buffer.size);
/*     */       }
/* 243 */     } catch (Throwable youcangetnoinfoVDXЖЧы9ж) {
/* 244 */       youcangetnoinfoVEAшЛж6А = youcangetnoinfoVDXЖЧы9ж;
/*     */     } 
/*     */     
/*     */     try {
/* 248 */       ((RealBufferedSink1)super).sink.close();
/* 249 */     } catch (Throwable youcangetnoinfoVDYДЭЮЦЁ) {
/* 250 */       if (youcangetnoinfoVEAшЛж6А == null) youcangetnoinfoVEAшЛж6А = youcangetnoinfoVDYДЭЮЦЁ; 
/*     */     } 
/* 252 */     ((RealBufferedSink1)super).closed = true;
/*     */     
/* 254 */     if (youcangetnoinfoVEAшЛж6А != null) Util.sneakyRethrow((Throwable)youcangetnoinfoVEAшЛж6А); 
/*     */   }
/*     */   
/*     */   public Timeout timeout() {
/* 258 */     return ((RealBufferedSink1)super).sink.timeout();
/*     */   }
/*     */   
/*     */   public String toString() {
/* 262 */     return "buffer(" + ((RealBufferedSink1)super).sink + ")";
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\RealBufferedSink1.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */