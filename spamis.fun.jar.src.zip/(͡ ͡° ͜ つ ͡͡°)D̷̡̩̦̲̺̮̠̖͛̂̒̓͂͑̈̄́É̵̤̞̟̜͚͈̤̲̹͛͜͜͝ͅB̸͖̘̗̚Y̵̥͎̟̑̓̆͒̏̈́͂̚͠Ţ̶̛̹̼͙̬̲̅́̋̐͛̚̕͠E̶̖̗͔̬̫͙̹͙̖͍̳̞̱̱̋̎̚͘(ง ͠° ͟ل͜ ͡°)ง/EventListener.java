package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;

public class EventListener extends EventListener1 {}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\EventListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */