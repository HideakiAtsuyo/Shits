package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;

public interface Interceptor1 {
  Interceptor1 withReadTimeout(int paramInt, TimeUnit paramTimeUnit);
  
  Request request();
  
  @Nullable
  Connection connection();
  
  int readTimeoutMillis();
  
  int writeTimeoutMillis();
  
  Interceptor1 withConnectTimeout(int paramInt, TimeUnit paramTimeUnit);
  
  Interceptor1 withWriteTimeout(int paramInt, TimeUnit paramTimeUnit);
  
  int connectTimeoutMillis();
  
  Call call();
  
  Response proceed(Request paramRequest) throws IOException;
}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Interceptor1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */