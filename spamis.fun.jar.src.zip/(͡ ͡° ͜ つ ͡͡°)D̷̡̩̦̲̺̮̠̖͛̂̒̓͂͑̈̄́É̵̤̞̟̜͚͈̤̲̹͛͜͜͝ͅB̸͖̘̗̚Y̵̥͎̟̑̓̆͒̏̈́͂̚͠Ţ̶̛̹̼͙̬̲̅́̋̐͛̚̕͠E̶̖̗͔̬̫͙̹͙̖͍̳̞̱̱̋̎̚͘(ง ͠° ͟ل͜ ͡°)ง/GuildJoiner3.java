/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import fun.spamis.spammer.SpamIsFun;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GuildJoiner3
/*     */   extends Thread
/*     */ {
/*     */   public final GuildJoiner4 this$2;
/*     */   public final Map.Entry val$token;
/*     */   
/*     */   public void run() {
/*  86 */     boolean bool = true;
/*  87 */     while (bool) {
/*     */       try {
/*  89 */         Object youcangetnoinfoKTPЛЯмТ2 = SpamUtils.getRandomProxy();
/*     */         
/*  91 */         Object youcangetnoinfoKTQмДмгВ = joinGuildTxt.getText().replace("https://discord.gg/", "").replace("https://discordapp.com/invite/", "");
/*  92 */         Object youcangetnoinfoKTRлГРнз = SpamUtils.join((String)youcangetnoinfoKTQмДмгВ, token.getValue().toString(), (String)youcangetnoinfoKTPЛЯмТ2);
/*  93 */         if (youcangetnoinfoKTRлГРнз.contains("\"guild\":")) {
/*  94 */           ConsoleGUI.log(youcangetnoinfoKTPЛЯмТ2 + "-> Token(" + token
/*  95 */               .getKey() + ")-> Joined " + youcangetnoinfoKTQмДмгВ);
/*  96 */           bool = false; continue;
/*  97 */         }  if (youcangetnoinfoKTRлГРнз.startsWith("<") || youcangetnoinfoKTRлГРнз == null) {
/*  98 */           ConsoleGUI.log(youcangetnoinfoKTPЛЯмТ2 + "-> Token(" + token.getKey() + ")-> Proxy failed. Retrying"); continue;
/*     */         } 
/* 100 */         if (youcangetnoinfoKTRлГРнз.startsWith("{\"code\": 0") || youcangetnoinfoKTRлГРнз
/* 101 */           .startsWith("{\"code\": 40002") || youcangetnoinfoKTRлГРнз
/* 102 */           .contains("Unauthorized")) {
/* 103 */           if (removeDeadTokensCheck.isSelected()) {
/* 104 */             SpamIsFun.tokens.remove(token.getKey());
/*     */           }
/* 106 */           ConsoleGUI.log(youcangetnoinfoKTPЛЯмТ2 + "-> Token(" + token
/* 107 */               .getKey() + ")-> Token is dead");
/* 108 */           bool = false; continue;
/* 109 */         }  if (youcangetnoinfoKTRлГРнз.startsWith("{\"code\": 10006")) {
/* 110 */           ConsoleGUI.log(youcangetnoinfoKTPЛЯмТ2 + "-> Token(" + token.getKey() + ")-> Banned on " + youcangetnoinfoKTQмДмгВ);
/*     */           
/* 112 */           bool = false; continue;
/*     */         } 
/* 114 */         ConsoleGUI.log(youcangetnoinfoKTPЛЯмТ2 + "-> Token(" + token.getKey() + ")-> Unknown error: " + youcangetnoinfoKTRлГРнз);
/*     */         
/* 116 */         bool = false;
/*     */       }
/* 118 */       catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\GuildJoiner3.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */