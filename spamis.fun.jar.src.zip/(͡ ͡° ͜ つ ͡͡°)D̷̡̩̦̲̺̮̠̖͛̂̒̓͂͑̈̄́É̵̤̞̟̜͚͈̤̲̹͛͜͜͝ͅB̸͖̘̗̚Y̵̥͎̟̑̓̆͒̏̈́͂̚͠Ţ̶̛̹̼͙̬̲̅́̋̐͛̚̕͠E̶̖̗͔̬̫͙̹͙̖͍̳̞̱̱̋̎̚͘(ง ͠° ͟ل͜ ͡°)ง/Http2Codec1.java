/*     */ package (͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.ProtocolException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Http2Codec1
/*     */   implements HttpCodec
/*     */ {
/*     */   public static final List<String> HTTP_2_SKIPPED_RESPONSE_HEADERS;
/*     */   public boolean canceled;
/*     */   public final StreamAllocation1 streamAllocation;
/*     */   public static final String CONNECTION = "connection";
/*     */   public static final String UPGRADE = "upgrade";
/*  68 */   public static final List<String> HTTP_2_SKIPPED_REQUEST_HEADERS = Util1.immutableList(new String[] { "connection", "host", "keep-alive", "proxy-connection", "te", "transfer-encoding", "encoding", "upgrade", ":method", ":path", ":scheme", ":authority" });
/*     */   public static final String ENCODING = "encoding";
/*     */   public static final String HOST = "host";
/*     */   public final Interceptor1 chain;
/*     */   public static final String PROXY_CONNECTION = "proxy-connection";
/*     */   public static final String TRANSFER_ENCODING = "transfer-encoding";
/*     */   public Http2Stream2 stream;
/*     */   public static final String TE = "te";
/*     */   public final Protocol protocol;
/*     */   public final Http2Connection5 connection;
/*     */   public static final String KEEP_ALIVE = "keep-alive";
/*     */   
/*     */   static {
/*  81 */     HTTP_2_SKIPPED_RESPONSE_HEADERS = Util1.immutableList(new String[] { "connection", "host", "keep-alive", "proxy-connection", "te", "transfer-encoding", "encoding", "upgrade" });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Http2Codec1(Object youcangetnoinfoDRMRЦч9аЖ, Object youcangetnoinfoDRMSИ8ишП, Object youcangetnoinfoDRMTАшлАЫ, Object youcangetnoinfoDRMU8чгОХ) {
/*  99 */     this();
/* 100 */     ((Http2Codec1)super).chain = (Interceptor1)youcangetnoinfoDRMSИ8ишП;
/* 101 */     ((Http2Codec1)super).streamAllocation = (StreamAllocation1)youcangetnoinfoDRMTАшлАЫ;
/* 102 */     ((Http2Codec1)super).connection = (Http2Connection5)youcangetnoinfoDRMU8чгОХ;
/* 103 */     ((Http2Codec1)super)
/*     */       
/* 105 */       .protocol = youcangetnoinfoDRMRЦч9аЖ.protocols().contains(Protocol.H2_PRIOR_KNOWLEDGE) ? Protocol.H2_PRIOR_KNOWLEDGE : Protocol.HTTP_2;
/*     */   }
/*     */   
/*     */   public Sink createRequestBody(Object youcangetnoinfoBIIPцzОма, Object youcangetnoinfoBIIQ9еКкЫ) {
/* 109 */     return ((Http2Codec1)super).stream.getSink();
/*     */   }
/*     */   
/*     */   public void writeRequestHeaders(Object youcangetnoinfoWXNсЦчzф) throws IOException {
/* 113 */     if (((Http2Codec1)super).stream != null)
/*     */       return; 
/* 115 */     boolean bool = (youcangetnoinfoWXNсЦчzф.body() != null) ? true : false;
/* 116 */     Object youcangetnoinfoWXPшзцие = http2HeadersList((Request)youcangetnoinfoWXNсЦчzф);
/* 117 */     ((Http2Codec1)super).stream = ((Http2Codec1)super).connection.newStream((List)youcangetnoinfoWXPшзцие, bool);
/*     */ 
/*     */     
/* 120 */     if (((Http2Codec1)super).canceled) {
/* 121 */       ((Http2Codec1)super).stream.closeLater(ErrorCode.CANCEL);
/* 122 */       throw new IOException("Canceled");
/*     */     } 
/* 124 */     ((Http2Codec1)super).stream.readTimeout().timeout(((Http2Codec1)super).chain.readTimeoutMillis(), TimeUnit.MILLISECONDS);
/* 125 */     ((Http2Codec1)super).stream.writeTimeout().timeout(((Http2Codec1)super).chain.writeTimeoutMillis(), TimeUnit.MILLISECONDS);
/*     */   }
/*     */   
/*     */   public void flushRequest() throws IOException {
/* 129 */     ((Http2Codec1)super).connection.flush();
/*     */   }
/*     */   
/*     */   public void finishRequest() throws IOException {
/* 133 */     ((Http2Codec1)super).stream.getSink().close();
/*     */   }
/*     */   
/*     */   public Response1 readResponseHeaders(Object youcangetnoinfoCVCMщцклч) throws IOException {
/* 137 */     Object youcangetnoinfoCVCNДЯБ8Я = ((Http2Codec1)super).stream.takeHeaders();
/* 138 */     Object youcangetnoinfoCVCOвТЁФК = readHttp2HeadersList((Headers)youcangetnoinfoCVCNДЯБ8Я, ((Http2Codec1)super).protocol);
/* 139 */     if (youcangetnoinfoCVCMщцклч != null && Internal.instance.code((Response1)youcangetnoinfoCVCOвТЁФК) == 100) {
/* 140 */       return null;
/*     */     }
/* 142 */     return (Response1)youcangetnoinfoCVCOвТЁФК;
/*     */   }
/*     */   
/*     */   public static List http2HeadersList(Object youcangetnoinfoJMFшЖЩЬЬ) {
/* 146 */     Object youcangetnoinfoJMGЁвдЫЧ = youcangetnoinfoJMFшЖЩЬЬ.headers();
/* 147 */     Object youcangetnoinfoJMHфбАвР = new ArrayList(youcangetnoinfoJMGЁвдЫЧ.size() + 4);
/* 148 */     youcangetnoinfoJMHфбАвР.add(new Header(Header.TARGET_METHOD, youcangetnoinfoJMFшЖЩЬЬ.method()));
/* 149 */     youcangetnoinfoJMHфбАвР.add(new Header(Header.TARGET_PATH, RequestLine.requestPath(youcangetnoinfoJMFшЖЩЬЬ.url())));
/* 150 */     Object youcangetnoinfoJMIкщ7НЖ = youcangetnoinfoJMFшЖЩЬЬ.header("Host");
/* 151 */     if (youcangetnoinfoJMIкщ7НЖ != null) {
/* 152 */       youcangetnoinfoJMHфбАвР.add(new Header(Header.TARGET_AUTHORITY, (String)youcangetnoinfoJMIкщ7НЖ));
/*     */     }
/* 154 */     youcangetnoinfoJMHфбАвР.add(new Header(Header.TARGET_SCHEME, youcangetnoinfoJMFшЖЩЬЬ.url().scheme())); byte b;
/*     */     int i;
/* 156 */     for (b = 0, i = youcangetnoinfoJMGЁвдЫЧ.size(); b < i; b++) {
/*     */       
/* 158 */       Object youcangetnoinfoJMCщЛ3Фь = youcangetnoinfoJMGЁвдЫЧ.name(b).toLowerCase(Locale.US);
/* 159 */       if (!HTTP_2_SKIPPED_REQUEST_HEADERS.contains(youcangetnoinfoJMCщЛ3Фь) || (youcangetnoinfoJMCщЛ3Фь
/* 160 */         .equals("te") && youcangetnoinfoJMGЁвдЫЧ.value(b).equals("trailers"))) {
/* 161 */         youcangetnoinfoJMHфбАвР.add(new Header((String)youcangetnoinfoJMCщЛ3Фь, youcangetnoinfoJMGЁвдЫЧ.value(b)));
/*     */       }
/*     */     } 
/* 164 */     return (List)youcangetnoinfoJMHфбАвР;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Response1 readHttp2HeadersList(Object youcangetnoinfoBK9аЩ7и, Object youcangetnoinfoBLо2фСЫ) throws IOException {
/* 170 */     Object youcangetnoinfoBMъс0яЖ = null;
/* 171 */     Object youcangetnoinfoBNЗжzчГ = new Headers1(); byte b; int i;
/* 172 */     for (b = 0, i = youcangetnoinfoBK9аЩ7и.size(); b < i; b++) {
/* 173 */       Object youcangetnoinfoBGХЩхпЁ = youcangetnoinfoBK9аЩ7и.name(b);
/* 174 */       Object youcangetnoinfoBHоЩИА6 = youcangetnoinfoBK9аЩ7и.value(b);
/* 175 */       if (youcangetnoinfoBGХЩхпЁ.equals(":status")) {
/* 176 */         youcangetnoinfoBMъс0яЖ = StatusLine.parse("HTTP/1.1 " + youcangetnoinfoBHоЩИА6);
/* 177 */       } else if (!HTTP_2_SKIPPED_RESPONSE_HEADERS.contains(youcangetnoinfoBGХЩхпЁ)) {
/* 178 */         Internal.instance.addLenient((Headers1)youcangetnoinfoBNЗжzчГ, (String)youcangetnoinfoBGХЩхпЁ, (String)youcangetnoinfoBHоЩИА6);
/*     */       } 
/*     */     } 
/* 181 */     if (youcangetnoinfoBMъс0яЖ == null) throw new ProtocolException("Expected ':status' header not present");
/*     */     
/* 183 */     return (new Response1())
/* 184 */       .protocol((Protocol)youcangetnoinfoBLо2фСЫ)
/* 185 */       .code(((StatusLine)youcangetnoinfoBMъс0яЖ).code)
/* 186 */       .message(((StatusLine)youcangetnoinfoBMъс0яЖ).message)
/* 187 */       .headers(youcangetnoinfoBNЗжzчГ.build());
/*     */   }
/*     */   
/*     */   public ResponseBody openResponseBody(Object youcangetnoinfoBLIWСжюцЭ) throws IOException {
/* 191 */     ((Http2Codec1)super).streamAllocation.eventListener.responseBodyStart(((Http2Codec1)super).streamAllocation.call);
/* 192 */     Object youcangetnoinfoBLIX8ьГ3У = youcangetnoinfoBLIWСжюцЭ.header("Content-Type");
/* 193 */     long l = HttpHeaders.contentLength((Response)youcangetnoinfoBLIWСжюцЭ);
/* 194 */     Object youcangetnoinfoBLIZОТРдг = new Http2Codec((Http2Codec1)this, ((Http2Codec1)super).stream.getSource());
/* 195 */     return new RealResponseBody((String)youcangetnoinfoBLIX8ьГ3У, l, Okio1.buffer((Source)youcangetnoinfoBLIZОТРдг));
/*     */   }
/*     */   
/*     */   public Headers trailers() throws IOException {
/* 199 */     return ((Http2Codec1)super).stream.trailers();
/*     */   }
/*     */   
/*     */   public void cancel() {
/* 203 */     ((Http2Codec1)super).canceled = true;
/* 204 */     if (((Http2Codec1)super).stream != null) ((Http2Codec1)super).stream.closeLater(ErrorCode.CANCEL); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\(͡ ͡° ͜ つ ͡͡°)D̷̡̩̦̲̺̮̠̖͛̂̒̓͂͑̈̄́É̵̤̞̟̜͚͈̤̲̹͛͜͜͝ͅB̸͖̘̗̚Y̵̥͎̟̑̓̆͒̏̈́͂̚͠Ţ̶̛̹̼͙̬̲̅́̋̐͛̚̕͠E̶̖̗͔̬̫͙̹͙̖͍̳̞̱̱̋̎̚͘(ง ͠° ͟ل͜ ͡°)ง\Http2Codec1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */