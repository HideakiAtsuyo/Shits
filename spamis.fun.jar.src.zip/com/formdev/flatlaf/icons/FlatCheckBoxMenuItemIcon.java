/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import java.awt.BasicStroke;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Path2D;
/*    */ import javax.swing.AbstractButton;
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatCheckBoxMenuItemIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public final Color selectionForeground;
/*    */   public final Color checkmarkColor;
/*    */   public final Color disabledCheckmarkColor;
/*    */   
/*    */   public FlatCheckBoxMenuItemIcon() {
/* 45 */     super(15, 15, null);
/*    */     ((FlatCheckBoxMenuItemIcon)super).checkmarkColor = UIManager.getColor("MenuItemCheckBox.icon.checkmarkColor");
/*    */     ((FlatCheckBoxMenuItemIcon)super).disabledCheckmarkColor = UIManager.getColor("MenuItemCheckBox.icon.disabledCheckmarkColor");
/*    */     ((FlatCheckBoxMenuItemIcon)super).selectionForeground = UIManager.getColor("Menu.selectionForeground");
/*    */   } public void paintIcon(Object youcangetnoinfoIJNСфГую, Object youcangetnoinfoIJOшЗЭ2Х) {
/* 50 */     boolean bool = (youcangetnoinfoIJNСфГую instanceof AbstractButton && ((AbstractButton)youcangetnoinfoIJNСфГую).isSelected()) ? true : false;
/*    */ 
/*    */     
/* 53 */     if (bool) {
/* 54 */       youcangetnoinfoIJOшЗЭ2Х.setColor(super.getCheckmarkColor((Component)youcangetnoinfoIJNСфГую));
/* 55 */       super.paintCheckmark((Graphics2D)youcangetnoinfoIJOшЗЭ2Х);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void paintCheckmark(Object youcangetnoinfoAIWHЪйДЕФ) {
/* 60 */     Object youcangetnoinfoAIWIТЩ8эЧ = new Path2D.Float();
/* 61 */     youcangetnoinfoAIWIТЩ8эЧ.moveTo(4.5F, 7.5F);
/* 62 */     youcangetnoinfoAIWIТЩ8эЧ.lineTo(6.6F, 10.0F);
/* 63 */     youcangetnoinfoAIWIТЩ8эЧ.lineTo(11.25F, 3.5F);
/*    */     
/* 65 */     youcangetnoinfoAIWHЪйДЕФ.setStroke(new BasicStroke(1.9F, 1, 1));
/* 66 */     youcangetnoinfoAIWHЪйДЕФ.draw((Shape)youcangetnoinfoAIWIТЩ8эЧ);
/*    */   }
/*    */   
/*    */   public Color getCheckmarkColor(Object youcangetnoinfoEFTIуВуц0) {
/* 70 */     if (youcangetnoinfoEFTIуВуц0 instanceof JMenuItem && ((JMenuItem)youcangetnoinfoEFTIуВуц0).isArmed()) {
/* 71 */       return ((FlatCheckBoxMenuItemIcon)super).selectionForeground;
/*    */     }
/* 73 */     return youcangetnoinfoEFTIуВуц0.isEnabled() ? ((FlatCheckBoxMenuItemIcon)super).checkmarkColor : ((FlatCheckBoxMenuItemIcon)super).disabledCheckmarkColor;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatCheckBoxMenuItemIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */