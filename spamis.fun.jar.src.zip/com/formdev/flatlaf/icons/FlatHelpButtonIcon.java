/*     */ package com.formdev.flatlaf.icons;
/*     */ 
/*     */ import com.formdev.flatlaf.ui.FlatButtonUI;
/*     */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.awt.geom.Path2D;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatHelpButtonIcon
/*     */   extends FlatAbstractIcon
/*     */ {
/*     */   public final Color questionMarkColor;
/*     */   public final Color pressedBackground;
/*     */   public final Color hoverBorderColor;
/*     */   public final Color disabledBackground;
/*     */   public final Color background;
/*     */   public final int iconSize;
/*     */   public final Color disabledQuestionMarkColor;
/*     */   public final Color disabledBorderColor;
/*     */   public final int focusWidth;
/*     */   public final Color focusedBorderColor;
/*     */   public final Color borderColor;
/*     */   public final Color focusedBackground;
/*     */   public final Color hoverBackground;
/*     */   public final Color focusColor;
/*     */   
/*     */   public FlatHelpButtonIcon() {
/*  69 */     super(0, 0, null);
/*     */     ((FlatHelpButtonIcon)super).focusWidth = UIManager.getInt("Component.focusWidth");
/*     */     ((FlatHelpButtonIcon)super).focusColor = UIManager.getColor("Component.focusColor");
/*     */     ((FlatHelpButtonIcon)super).borderColor = UIManager.getColor("HelpButton.borderColor");
/*     */     ((FlatHelpButtonIcon)super).disabledBorderColor = UIManager.getColor("HelpButton.disabledBorderColor");
/*     */     ((FlatHelpButtonIcon)super).focusedBorderColor = UIManager.getColor("HelpButton.focusedBorderColor");
/*     */     ((FlatHelpButtonIcon)super).hoverBorderColor = UIManager.getColor("HelpButton.hoverBorderColor");
/*     */     ((FlatHelpButtonIcon)super).background = UIManager.getColor("HelpButton.background");
/*     */     ((FlatHelpButtonIcon)super).disabledBackground = UIManager.getColor("HelpButton.disabledBackground");
/*     */     ((FlatHelpButtonIcon)super).focusedBackground = UIManager.getColor("HelpButton.focusedBackground");
/*     */     ((FlatHelpButtonIcon)super).hoverBackground = UIManager.getColor("HelpButton.hoverBackground");
/*     */     ((FlatHelpButtonIcon)super).pressedBackground = UIManager.getColor("HelpButton.pressedBackground");
/*     */     ((FlatHelpButtonIcon)super).questionMarkColor = UIManager.getColor("HelpButton.questionMarkColor");
/*     */     ((FlatHelpButtonIcon)super).disabledQuestionMarkColor = UIManager.getColor("HelpButton.disabledQuestionMarkColor");
/*     */     ((FlatHelpButtonIcon)super).iconSize = 22 + ((FlatHelpButtonIcon)super).focusWidth * 2; } public void paintIcon(Object youcangetnoinfoBZIJКькйz, Object youcangetnoinfoBZIKЁ7Н2А) {
/*  84 */     boolean bool1 = youcangetnoinfoBZIJКькйz.isEnabled();
/*  85 */     boolean bool2 = youcangetnoinfoBZIJКькйz.hasFocus();
/*     */ 
/*     */     
/*  88 */     if (bool2) {
/*  89 */       youcangetnoinfoBZIKЁ7Н2А.setColor(((FlatHelpButtonIcon)super).focusColor);
/*  90 */       youcangetnoinfoBZIKЁ7Н2А.fill(new Ellipse2D.Float(0.5F, 0.5F, (((FlatHelpButtonIcon)super).iconSize - 1), (((FlatHelpButtonIcon)super).iconSize - 1)));
/*     */     } 
/*     */ 
/*     */     
/*  94 */     youcangetnoinfoBZIKЁ7Н2А.setColor(FlatButtonUI.buttonStateColor((Component)youcangetnoinfoBZIJКькйz, ((FlatHelpButtonIcon)super).borderColor, ((FlatHelpButtonIcon)super).disabledBorderColor, ((FlatHelpButtonIcon)super).focusedBorderColor, ((FlatHelpButtonIcon)super).hoverBorderColor, null));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     youcangetnoinfoBZIKЁ7Н2А.fill(new Ellipse2D.Float(((FlatHelpButtonIcon)super).focusWidth + 0.5F, ((FlatHelpButtonIcon)super).focusWidth + 0.5F, 21.0F, 21.0F));
/*     */ 
/*     */     
/* 103 */     FlatUIUtils.setColor((Graphics)youcangetnoinfoBZIKЁ7Н2А, FlatButtonUI.buttonStateColor((Component)youcangetnoinfoBZIJКькйz, ((FlatHelpButtonIcon)super).background, ((FlatHelpButtonIcon)super).disabledBackground, ((FlatHelpButtonIcon)super).focusedBackground, ((FlatHelpButtonIcon)super).hoverBackground, ((FlatHelpButtonIcon)super).pressedBackground), ((FlatHelpButtonIcon)super).background);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     youcangetnoinfoBZIKЁ7Н2А.fill(new Ellipse2D.Float(((FlatHelpButtonIcon)super).focusWidth + 1.5F, ((FlatHelpButtonIcon)super).focusWidth + 1.5F, 19.0F, 19.0F));
/*     */ 
/*     */     
/* 112 */     Object youcangetnoinfoBZINЮсяуо = new Path2D.Float();
/* 113 */     youcangetnoinfoBZINЮсяуо.moveTo(11.0D, 5.0D);
/* 114 */     youcangetnoinfoBZINЮсяуо.curveTo(8.8D, 5.0D, 7.0D, 6.8D, 7.0D, 9.0D);
/* 115 */     youcangetnoinfoBZINЮсяуо.lineTo(9.0D, 9.0D);
/* 116 */     youcangetnoinfoBZINЮсяуо.curveTo(9.0D, 7.9D, 9.9D, 7.0D, 11.0D, 7.0D);
/* 117 */     youcangetnoinfoBZINЮсяуо.curveTo(12.1D, 7.0D, 13.0D, 7.9D, 13.0D, 9.0D);
/* 118 */     youcangetnoinfoBZINЮсяуо.curveTo(13.0D, 11.0D, 10.0D, 10.75D, 10.0D, 14.0D);
/* 119 */     youcangetnoinfoBZINЮсяуо.lineTo(12.0D, 14.0D);
/* 120 */     youcangetnoinfoBZINЮсяуо.curveTo(12.0D, 11.75D, 15.0D, 11.5D, 15.0D, 9.0D);
/* 121 */     youcangetnoinfoBZINЮсяуо.curveTo(15.0D, 6.8D, 13.2D, 5.0D, 11.0D, 5.0D);
/* 122 */     youcangetnoinfoBZINЮсяуо.closePath();
/*     */     
/* 124 */     youcangetnoinfoBZIKЁ7Н2А.translate(((FlatHelpButtonIcon)super).focusWidth, ((FlatHelpButtonIcon)super).focusWidth);
/* 125 */     youcangetnoinfoBZIKЁ7Н2А.setColor(bool1 ? ((FlatHelpButtonIcon)super).questionMarkColor : ((FlatHelpButtonIcon)super).disabledQuestionMarkColor);
/* 126 */     youcangetnoinfoBZIKЁ7Н2А.fill((Shape)youcangetnoinfoBZINЮсяуо);
/* 127 */     youcangetnoinfoBZIKЁ7Н2А.fillRect(10, 15, 2, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIconWidth() {
/* 132 */     return UIScale.scale(((FlatHelpButtonIcon)super).iconSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getIconHeight() {
/* 137 */     return UIScale.scale(((FlatHelpButtonIcon)super).iconSize);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatHelpButtonIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */