/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatButtonUI;
/*    */ import java.awt.BasicStroke;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Line2D;
/*    */ import java.awt.geom.Path2D;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatInternalFrameCloseIcon
/*    */   extends FlatInternalFrameAbstractIcon
/*    */ {
/*    */   public final Color hoverForeground;
/*    */   public final Color pressedForeground;
/*    */   
/*    */   public FlatInternalFrameCloseIcon() {
/* 43 */     super(UIManager.getDimension("InternalFrame.buttonSize"), 
/* 44 */         UIManager.getColor("InternalFrame.closeHoverBackground"), 
/* 45 */         UIManager.getColor("InternalFrame.closePressedBackground"));
/*    */     ((FlatInternalFrameCloseIcon)super).hoverForeground = UIManager.getColor("InternalFrame.closeHoverForeground");
/*    */     ((FlatInternalFrameCloseIcon)super).pressedForeground = UIManager.getColor("InternalFrame.closePressedForeground");
/*    */   }
/*    */   public void paintIcon(Object youcangetnoinfoCRLMгЬшЗЮ, Object youcangetnoinfoCRLNГжДер) {
/* 50 */     paintBackground((Component)youcangetnoinfoCRLMгЬшЗЮ, (Graphics2D)youcangetnoinfoCRLNГжДер);
/*    */     
/* 52 */     youcangetnoinfoCRLNГжДер.setColor(FlatButtonUI.buttonStateColor((Component)youcangetnoinfoCRLMгЬшЗЮ, youcangetnoinfoCRLMгЬшЗЮ.getForeground(), null, null, ((FlatInternalFrameCloseIcon)super).hoverForeground, ((FlatInternalFrameCloseIcon)super).pressedForeground));
/*    */     
/* 54 */     float f1 = (((FlatInternalFrameCloseIcon)this).width / 2);
/* 55 */     float f2 = (((FlatInternalFrameCloseIcon)this).height / 2);
/* 56 */     float f3 = 3.25F;
/*    */     
/* 58 */     Object youcangetnoinfoCRLRЧиеzЁ = new Path2D.Float(0);
/* 59 */     youcangetnoinfoCRLRЧиеzЁ.append(new Line2D.Float(f1 - f3, f2 - f3, f1 + f3, f2 + f3), false);
/* 60 */     youcangetnoinfoCRLRЧиеzЁ.append(new Line2D.Float(f1 - f3, f2 + f3, f1 + f3, f2 - f3), false);
/* 61 */     youcangetnoinfoCRLNГжДер.setStroke(new BasicStroke(1.0F));
/* 62 */     youcangetnoinfoCRLNГжДер.draw((Shape)youcangetnoinfoCRLRЧиеzЁ);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatInternalFrameCloseIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */