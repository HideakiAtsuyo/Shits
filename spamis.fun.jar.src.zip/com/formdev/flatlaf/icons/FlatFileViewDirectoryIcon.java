/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatFileViewDirectoryIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatFileViewDirectoryIcon() {
/* 35 */     super(16, 16, UIManager.getColor("Objects.Grey"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoGZBЛ7ЬТш, Object youcangetnoinfoGZCЩЙ0ьЫ) {
/* 46 */     youcangetnoinfoGZCЩЙ0ьЫ.fill(FlatUIUtils.createPath(new double[] { 1.0D, 2.0D, 6.0D, 2.0D, 8.0D, 4.0D, 15.0D, 4.0D, 15.0D, 13.0D, 1.0D, 13.0D }));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatFileViewDirectoryIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */