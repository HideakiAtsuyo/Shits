/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Path2D;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatFileViewFloppyDriveIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatFileViewFloppyDriveIcon() {
/* 36 */     super(16, 16, UIManager.getColor("Objects.Grey"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoCZHIВХЧВл, Object youcangetnoinfoCZHJТ6АОП) {
/* 50 */     Object youcangetnoinfoCZHKЯЖ0об = new Path2D.Float(0);
/* 51 */     youcangetnoinfoCZHKЯЖ0об.append(FlatUIUtils.createPath(new double[] { 11.0D, 14.0D, 11.0D, 11.0D, 5.0D, 11.0D, 5.0D, 14.0D, 2.0D, 14.0D, 2.0D, 2.0D, 14.0D, 2.0D, 14.0D, 14.0D, 11.0D, 14.0D }, ), false);
/* 52 */     youcangetnoinfoCZHKЯЖ0об.append(FlatUIUtils.createPath(new double[] { 4.0D, 4.0D, 4.0D, 8.0D, 12.0D, 8.0D, 12.0D, 4.0D, 4.0D, 4.0D }, ), false);
/* 53 */     youcangetnoinfoCZHJТ6АОП.fill((Shape)youcangetnoinfoCZHKЯЖ0об);
/*    */     
/* 55 */     youcangetnoinfoCZHJТ6АОП.fillRect(6, 12, 4, 2);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatFileViewFloppyDriveIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */