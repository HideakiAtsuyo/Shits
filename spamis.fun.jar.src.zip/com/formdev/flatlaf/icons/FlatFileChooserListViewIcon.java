/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatFileChooserListViewIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatFileChooserListViewIcon() {
/* 34 */     super(16, 16, UIManager.getColor("Actions.Grey"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoLQH60Щюц, Object youcangetnoinfoLQI0еРеы) {
/* 50 */     youcangetnoinfoLQI0еРеы.fillRect(3, 3, 4, 4);
/* 51 */     youcangetnoinfoLQI0еРеы.fillRect(3, 9, 4, 4);
/* 52 */     youcangetnoinfoLQI0еРеы.fillRect(9, 9, 4, 4);
/* 53 */     youcangetnoinfoLQI0еРеы.fillRect(9, 3, 4, 4);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatFileChooserListViewIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */