/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatFileChooserDetailsViewIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatFileChooserDetailsViewIcon() {
/* 34 */     super(16, 16, UIManager.getColor("Actions.Grey"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoALHMЯЩФмё, Object youcangetnoinfoALHNzЪцбц) {
/* 52 */     youcangetnoinfoALHNzЪцбц.fillRect(2, 3, 2, 2);
/* 53 */     youcangetnoinfoALHNzЪцбц.fillRect(2, 7, 2, 2);
/* 54 */     youcangetnoinfoALHNzЪцбц.fillRect(2, 11, 2, 2);
/* 55 */     youcangetnoinfoALHNzЪцбц.fillRect(6, 3, 8, 2);
/* 56 */     youcangetnoinfoALHNzЪцбц.fillRect(6, 7, 8, 2);
/* 57 */     youcangetnoinfoALHNzЪцбц.fillRect(6, 11, 8, 2);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatFileChooserDetailsViewIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */