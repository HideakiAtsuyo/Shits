/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatTreeExpandedIcon
/*    */   extends FlatTreeCollapsedIcon
/*    */ {
/*    */   public FlatTreeExpandedIcon() {
/* 34 */     super(UIManager.getColor("Tree.icon.expandedColor"));
/*    */   }
/*    */ 
/*    */   
/*    */   public void rotate(Object youcangetnoinfoPOSПМЙМх, Object youcangetnoinfoPOTсфкхЫ) {
/* 39 */     youcangetnoinfoPOTсфкхЫ.rotate(Math.toRadians(90.0D), ((FlatTreeExpandedIcon)this).width / 2.0D, ((FlatTreeExpandedIcon)this).height / 2.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatTreeExpandedIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */