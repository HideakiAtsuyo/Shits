/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatFileViewFileIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatFileViewFileIcon() {
/* 35 */     super(16, 16, UIManager.getColor("Objects.Grey"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoDCAFЭщЙЪ0, Object youcangetnoinfoDCAGисъщп) {
/* 49 */     youcangetnoinfoDCAGисъщп.fill(FlatUIUtils.createPath(new double[] { 8.0D, 6.0D, 8.0D, 1.0D, 13.0D, 1.0D, 13.0D, 15.0D, 3.0D, 15.0D, 3.0D, 6.0D }));
/* 50 */     youcangetnoinfoDCAGисъщп.fill(FlatUIUtils.createPath(new double[] { 3.0D, 5.0D, 7.0D, 5.0D, 7.0D, 1.0D }));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatFileViewFileIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */