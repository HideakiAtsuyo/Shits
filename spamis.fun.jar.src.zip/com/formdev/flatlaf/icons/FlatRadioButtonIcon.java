/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.geom.Ellipse2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatRadioButtonIcon
/*    */   extends FlatCheckBoxIcon
/*    */ {
/*    */   public final int centerDiameter;
/*    */   
/*    */   public FlatRadioButtonIcon() {
/* 37 */     ((FlatRadioButtonIcon)super).centerDiameter = FlatUIUtils.getUIInt("RadioButton.icon.centerDiameter", 8);
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintFocusBorder(Object youcangetnoinfoAFYNРИайя) {
/* 42 */     int i = 15 + ((FlatRadioButtonIcon)this).focusWidth * 2;
/* 43 */     youcangetnoinfoAFYNРИайя.fillOval(-((FlatRadioButtonIcon)this).focusWidth, -((FlatRadioButtonIcon)this).focusWidth, i, i);
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintBorder(Object youcangetnoinfoXDMЁеВ4Р) {
/* 48 */     youcangetnoinfoXDMЁеВ4Р.fillOval(0, 0, 15, 15);
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintBackground(Object youcangetnoinfoCHAQсЧЧф0) {
/* 53 */     youcangetnoinfoCHAQсЧЧф0.fillOval(1, 1, 13, 13);
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintCheckmark(Object youcangetnoinfoEPLTстьве) {
/* 58 */     float f = (15 - ((FlatRadioButtonIcon)super).centerDiameter) / 2.0F;
/* 59 */     youcangetnoinfoEPLTстьве.fill(new Ellipse2D.Float(f, f, ((FlatRadioButtonIcon)super).centerDiameter, ((FlatRadioButtonIcon)super).centerDiameter));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatRadioButtonIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */