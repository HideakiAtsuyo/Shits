/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatInternalFrameMaximizeIcon
/*    */   extends FlatInternalFrameAbstractIcon
/*    */ {
/*    */   public void paintIcon(Object youcangetnoinfoDIXНЗФСН, Object youcangetnoinfoDIYёуЩнъ) {
/* 36 */     paintBackground((Component)youcangetnoinfoDIXНЗФСН, (Graphics2D)youcangetnoinfoDIYёуЩнъ);
/*    */     
/* 38 */     youcangetnoinfoDIYёуЩнъ.setColor(youcangetnoinfoDIXНЗФСН.getForeground());
/* 39 */     youcangetnoinfoDIYёуЩнъ.fill(FlatUIUtils.createRectangle((((FlatInternalFrameMaximizeIcon)this).width / 2 - 4), (((FlatInternalFrameMaximizeIcon)this).height / 2 - 4), 8.0F, 8.0F, 1.0F));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatInternalFrameMaximizeIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */