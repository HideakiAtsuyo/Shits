package com.formdev.flatlaf.icons;

public class FlatMenuItemArrowIcon extends FlatMenuArrowIcon {
  public void paintIcon(Object youcangetnoinfoAKSQп4яяЮ, Object youcangetnoinfoAKSRЫНжмь, Object youcangetnoinfoAKSSбЪякй, Object youcangetnoinfoAKSTугПГЗ) {}
  
  public void paintIcon(Object youcangetnoinfoBNAPяцДга, Object youcangetnoinfoBNAQ7Пс13) {}
}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatMenuItemArrowIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */