/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatRadioButtonMenuItemIcon
/*    */   extends FlatCheckBoxMenuItemIcon
/*    */ {
/*    */   public void paintCheckmark(Object youcangetnoinfoELHIНеА6б) {
/* 31 */     youcangetnoinfoELHIНеА6б.fillOval(4, 4, 7, 7);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatRadioButtonMenuItemIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */