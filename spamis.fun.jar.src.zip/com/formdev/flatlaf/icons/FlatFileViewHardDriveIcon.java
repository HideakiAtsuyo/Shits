/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Path2D;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatFileViewHardDriveIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatFileViewHardDriveIcon() {
/* 36 */     super(16, 16, UIManager.getColor("Objects.Grey"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoCFHJ0ШРоЗ, Object youcangetnoinfoCFHKЕЦшоЭ) {
/* 47 */     Object youcangetnoinfoCFHLхОЦФд = new Path2D.Float(0);
/* 48 */     youcangetnoinfoCFHLхОЦФд.append(new Rectangle2D.Float(2.0F, 6.0F, 12.0F, 4.0F), false);
/* 49 */     youcangetnoinfoCFHLхОЦФд.append(new Rectangle2D.Float(12.0F, 8.0F, 1.0F, 1.0F), false);
/* 50 */     youcangetnoinfoCFHLхОЦФд.append(new Rectangle2D.Float(10.0F, 8.0F, 1.0F, 1.0F), false);
/* 51 */     youcangetnoinfoCFHKЕЦшоЭ.fill((Shape)youcangetnoinfoCFHLхОЦФд);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatFileViewHardDriveIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */