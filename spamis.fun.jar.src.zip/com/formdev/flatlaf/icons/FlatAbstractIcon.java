/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics2D;
/*    */ import javax.swing.Icon;
/*    */ import javax.swing.plaf.UIResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FlatAbstractIcon
/*    */   implements UIResource, Icon
/*    */ {
/*    */   public final int height;
/*    */   public final int width;
/*    */   public final Color color;
/*    */   
/*    */   public FlatAbstractIcon(Object youcangetnoinfoCDXGвЕЩшЬ, Object youcangetnoinfoCDXHюКоЁа, Object youcangetnoinfoCDXIзЬК1Ю) {
/* 44 */     this();
/* 45 */     ((FlatAbstractIcon)super).width = youcangetnoinfoCDXGвЕЩшЬ;
/* 46 */     ((FlatAbstractIcon)super).height = youcangetnoinfoCDXHюКоЁа;
/* 47 */     ((FlatAbstractIcon)super).color = (Color)youcangetnoinfoCDXIзЬК1Ю;
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoEDШстЧх, Object youcangetnoinfoEEСцЙёН, Object youcangetnoinfoEFлюКш2, Object youcangetnoinfoEG0хеКА) {
/* 52 */     Object youcangetnoinfoEHфЬ45Ъ = youcangetnoinfoEEСцЙёН.create();
/*    */     try {
/* 54 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoEHфЬ45Ъ);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 60 */       youcangetnoinfoEHфЬ45Ъ.translate(youcangetnoinfoEFлюКш2, youcangetnoinfoEG0хеКА);
/* 61 */       UIScale.scaleGraphics((Graphics2D)youcangetnoinfoEHфЬ45Ъ);
/*    */       
/* 63 */       if (((FlatAbstractIcon)super).color != null) {
/* 64 */         youcangetnoinfoEHфЬ45Ъ.setColor(((FlatAbstractIcon)super).color);
/*    */       }
/* 66 */       super.paintIcon((Component)youcangetnoinfoEDШстЧх, (Graphics2D)youcangetnoinfoEHфЬ45Ъ);
/*    */     } finally {
/* 68 */       youcangetnoinfoEHфЬ45Ъ.dispose();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int getIconWidth() {
/* 76 */     return UIScale.scale(((FlatAbstractIcon)super).width);
/*    */   }
/*    */ 
/*    */   
/*    */   public int getIconHeight() {
/* 81 */     return UIScale.scale(((FlatAbstractIcon)super).height);
/*    */   }
/*    */   
/*    */   public abstract void paintIcon(Component paramComponent, Graphics2D paramGraphics2D);
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatAbstractIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */