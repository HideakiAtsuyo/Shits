/*     */ package com.formdev.flatlaf.icons;
/*     */ 
/*     */ import com.formdev.flatlaf.FlatClientProperties;
/*     */ import com.formdev.flatlaf.ui.FlatButtonUI;
/*     */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Path2D;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatCheckBoxIcon
/*     */   extends FlatAbstractIcon
/*     */ {
/*     */   public final Color background;
/*     */   public final Color selectedBorderColor;
/*     */   public final Color selectedHoverBackground;
/*     */   public final int arc;
/*     */   public final Color selectedPressedBackground;
/*     */   public final Color checkmarkColor;
/*     */   public static final int ICON_SIZE = 15;
/*     */   public final Color pressedBackground;
/*     */   public final Color disabledBorderColor;
/*     */   public final int focusWidth;
/*     */   public final Color selectedBackground;
/*     */   public final Color focusColor;
/*     */   public final Color disabledCheckmarkColor;
/*     */   public final Color hoverBorderColor;
/*     */   public final Color hoverBackground;
/*     */   public final Color borderColor;
/*     */   public final Color focusedBackground;
/*     */   public final Color disabledBackground;
/*     */   public final Color selectedFocusedBorderColor;
/*     */   public final Color focusedBorderColor;
/*     */   
/*     */   public FlatCheckBoxIcon() {
/*  90 */     super(15, 15, null); ((FlatCheckBoxIcon)super).focusWidth = UIManager.getInt("Component.focusWidth"); ((FlatCheckBoxIcon)super).focusColor = FlatUIUtils.getUIColor("CheckBox.icon.focusedColor", UIManager.getColor("Component.focusColor")); ((FlatCheckBoxIcon)super).arc = FlatUIUtils.getUIInt("CheckBox.arc", 2); ((FlatCheckBoxIcon)super).borderColor = UIManager.getColor("CheckBox.icon.borderColor"); ((FlatCheckBoxIcon)super).disabledBorderColor = UIManager.getColor("CheckBox.icon.disabledBorderColor"); ((FlatCheckBoxIcon)super).selectedBorderColor = UIManager.getColor("CheckBox.icon.selectedBorderColor"); ((FlatCheckBoxIcon)super).focusedBorderColor = UIManager.getColor("CheckBox.icon.focusedBorderColor"); ((FlatCheckBoxIcon)super).hoverBorderColor = UIManager.getColor("CheckBox.icon.hoverBorderColor"); ((FlatCheckBoxIcon)super).selectedFocusedBorderColor = UIManager.getColor("CheckBox.icon.selectedFocusedBorderColor"); ((FlatCheckBoxIcon)super).background = UIManager.getColor("CheckBox.icon.background"); ((FlatCheckBoxIcon)super).disabledBackground = UIManager.getColor("CheckBox.icon.disabledBackground"); ((FlatCheckBoxIcon)super).focusedBackground = UIManager.getColor("CheckBox.icon.focusedBackground"); ((FlatCheckBoxIcon)super).hoverBackground = UIManager.getColor("CheckBox.icon.hoverBackground"); ((FlatCheckBoxIcon)super).pressedBackground = UIManager.getColor("CheckBox.icon.pressedBackground");
/*     */     ((FlatCheckBoxIcon)super).selectedBackground = UIManager.getColor("CheckBox.icon.selectedBackground");
/*     */     ((FlatCheckBoxIcon)super).selectedHoverBackground = UIManager.getColor("CheckBox.icon.selectedHoverBackground");
/*     */     ((FlatCheckBoxIcon)super).selectedPressedBackground = UIManager.getColor("CheckBox.icon.selectedPressedBackground");
/*     */     ((FlatCheckBoxIcon)super).checkmarkColor = UIManager.getColor("CheckBox.icon.checkmarkColor");
/*  95 */     ((FlatCheckBoxIcon)super).disabledCheckmarkColor = UIManager.getColor("CheckBox.icon.disabledCheckmarkColor"); } public void paintIcon(Object youcangetnoinfoEPOUъЩдуь, Object youcangetnoinfoEPOV2ЛЩЩъ) { boolean bool1 = (youcangetnoinfoEPOUъЩдуь instanceof JComponent && FlatClientProperties.clientPropertyEquals((JComponent)youcangetnoinfoEPOUъЩдуь, "JButton.selectedState", "indeterminate")) ? true : false;
/*  96 */     boolean bool2 = (bool1 || (youcangetnoinfoEPOUъЩдуь instanceof AbstractButton && ((AbstractButton)youcangetnoinfoEPOUъЩдуь).isSelected())) ? true : false;
/*     */ 
/*     */     
/*  99 */     if (youcangetnoinfoEPOUъЩдуь.hasFocus() && ((FlatCheckBoxIcon)super).focusWidth > 0) {
/* 100 */       youcangetnoinfoEPOV2ЛЩЩъ.setColor(((FlatCheckBoxIcon)super).focusColor);
/* 101 */       super.paintFocusBorder((Graphics2D)youcangetnoinfoEPOV2ЛЩЩъ);
/*     */     } 
/*     */ 
/*     */     
/* 105 */     youcangetnoinfoEPOV2ЛЩЩъ.setColor(FlatButtonUI.buttonStateColor((Component)youcangetnoinfoEPOUъЩдуь, 
/* 106 */           bool2 ? ((FlatCheckBoxIcon)super).selectedBorderColor : ((FlatCheckBoxIcon)super).borderColor, ((FlatCheckBoxIcon)super).disabledBorderColor, (
/*     */           
/* 108 */           bool2 && ((FlatCheckBoxIcon)super).selectedFocusedBorderColor != null) ? ((FlatCheckBoxIcon)super).selectedFocusedBorderColor : ((FlatCheckBoxIcon)super).focusedBorderColor, ((FlatCheckBoxIcon)super).hoverBorderColor, null));
/*     */ 
/*     */     
/* 111 */     super.paintBorder((Graphics2D)youcangetnoinfoEPOV2ЛЩЩъ);
/*     */ 
/*     */     
/* 114 */     FlatUIUtils.setColor((Graphics)youcangetnoinfoEPOV2ЛЩЩъ, FlatButtonUI.buttonStateColor((Component)youcangetnoinfoEPOUъЩдуь, 
/* 115 */           bool2 ? ((FlatCheckBoxIcon)super).selectedBackground : ((FlatCheckBoxIcon)super).background, ((FlatCheckBoxIcon)super).disabledBackground, ((FlatCheckBoxIcon)super).focusedBackground, (
/*     */ 
/*     */           
/* 118 */           bool2 && ((FlatCheckBoxIcon)super).selectedHoverBackground != null) ? ((FlatCheckBoxIcon)super).selectedHoverBackground : ((FlatCheckBoxIcon)super).hoverBackground, 
/* 119 */           (bool2 && ((FlatCheckBoxIcon)super).selectedPressedBackground != null) ? ((FlatCheckBoxIcon)super).selectedPressedBackground : ((FlatCheckBoxIcon)super).pressedBackground), ((FlatCheckBoxIcon)super).background);
/*     */     
/* 121 */     super.paintBackground((Graphics2D)youcangetnoinfoEPOV2ЛЩЩъ);
/*     */ 
/*     */     
/* 124 */     if (bool2 || bool1) {
/* 125 */       youcangetnoinfoEPOV2ЛЩЩъ.setColor(youcangetnoinfoEPOUъЩдуь.isEnabled() ? ((FlatCheckBoxIcon)super).checkmarkColor : ((FlatCheckBoxIcon)super).disabledCheckmarkColor);
/* 126 */       if (bool1) {
/* 127 */         super.paintIndeterminate((Graphics2D)youcangetnoinfoEPOV2ЛЩЩъ);
/*     */       } else {
/* 129 */         super.paintCheckmark((Graphics2D)youcangetnoinfoEPOV2ЛЩЩъ);
/*     */       } 
/*     */     }  }
/*     */ 
/*     */   
/*     */   public void paintFocusBorder(Object youcangetnoinfoAJODАИЮЙН) {
/* 135 */     int i = 14 + ((FlatCheckBoxIcon)super).focusWidth * 2;
/* 136 */     int j = ((FlatCheckBoxIcon)super).arc + ((FlatCheckBoxIcon)super).focusWidth * 2;
/* 137 */     youcangetnoinfoAJODАИЮЙН.fillRoundRect(-((FlatCheckBoxIcon)super).focusWidth + 1, -((FlatCheckBoxIcon)super).focusWidth, i, i, j, j);
/*     */   }
/*     */   
/*     */   public void paintBorder(Object youcangetnoinfoBQXXЛовzЮ) {
/* 141 */     int i = ((FlatCheckBoxIcon)super).arc;
/* 142 */     youcangetnoinfoBQXXЛовzЮ.fillRoundRect(1, 0, 14, 14, i, i);
/*     */   }
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoEDOFЖсВоР) {
/* 146 */     int i = ((FlatCheckBoxIcon)super).arc - 1;
/* 147 */     youcangetnoinfoEDOFЖсВоР.fillRoundRect(2, 1, 12, 12, i, i);
/*     */   }
/*     */   
/*     */   public void paintCheckmark(Object youcangetnoinfoDSOBКгкЪМ) {
/* 151 */     Object youcangetnoinfoDSOCсш9шъ = new Path2D.Float();
/* 152 */     youcangetnoinfoDSOCсш9шъ.moveTo(4.5F, 7.5F);
/* 153 */     youcangetnoinfoDSOCсш9шъ.lineTo(6.6F, 10.0F);
/* 154 */     youcangetnoinfoDSOCсш9шъ.lineTo(11.25F, 3.5F);
/*     */     
/* 156 */     youcangetnoinfoDSOBКгкЪМ.setStroke(new BasicStroke(1.9F, 1, 1));
/* 157 */     youcangetnoinfoDSOBКгкЪМ.draw((Shape)youcangetnoinfoDSOCсш9шъ);
/*     */   }
/*     */   
/*     */   public void paintIndeterminate(Object youcangetnoinfoDKGZшЩщЬХ) {
/* 161 */     youcangetnoinfoDKGZшЩщЬХ.fill(new RoundRectangle2D.Float(3.75F, 5.75F, 8.5F, 2.5F, 2.0F, 2.0F));
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatCheckBoxIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */