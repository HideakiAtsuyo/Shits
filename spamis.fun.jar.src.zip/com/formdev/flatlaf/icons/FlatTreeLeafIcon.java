/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatTreeLeafIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatTreeLeafIcon() {
/* 35 */     super(16, 16, UIManager.getColor("Tree.icon.leafColor"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoCAUWЪ59Е4, Object youcangetnoinfoCAUXЭЩ9вз) {
/* 49 */     youcangetnoinfoCAUXЭЩ9вз.fill(FlatUIUtils.createPath(new double[] { 8.0D, 6.0D, 8.0D, 1.0D, 13.0D, 1.0D, 13.0D, 15.0D, 3.0D, 15.0D, 3.0D, 6.0D }));
/* 50 */     youcangetnoinfoCAUXЭЩ9вз.fill(FlatUIUtils.createPath(new double[] { 3.0D, 5.0D, 7.0D, 5.0D, 7.0D, 1.0D }));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatTreeLeafIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */