/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.Color;
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Path2D;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FlatOptionPaneAbstractIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public final Color foreground;
/*    */   
/*    */   public FlatOptionPaneAbstractIcon(Object youcangetnoinfoDIPSТХолЧ, Object youcangetnoinfoDIPTиРП1Ф) {
/* 40 */     super(32, 32, FlatUIUtils.getUIColor((String)youcangetnoinfoDIPSТХолЧ, (String)youcangetnoinfoDIPTиРП1Ф));
/*    */     ((FlatOptionPaneAbstractIcon)super).foreground = UIManager.getColor("OptionPane.icon.foreground");
/*    */   }
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoNGXПхшЁж, Object youcangetnoinfoNGYбн0МЖ) {
/* 45 */     if (((FlatOptionPaneAbstractIcon)super).foreground != null) {
/* 46 */       youcangetnoinfoNGYбн0МЖ.fill(super.createOutside());
/*    */       
/* 48 */       youcangetnoinfoNGYбн0МЖ.setColor(((FlatOptionPaneAbstractIcon)super).foreground);
/* 49 */       youcangetnoinfoNGYбн0МЖ.fill(super.createInside());
/*    */     } else {
/* 51 */       Object youcangetnoinfoNGVЫПвьЭ = new Path2D.Float(0);
/* 52 */       youcangetnoinfoNGVЫПвьЭ.append(super.createOutside(), false);
/* 53 */       youcangetnoinfoNGVЫПвьЭ.append(super.createInside(), false);
/* 54 */       youcangetnoinfoNGYбн0МЖ.fill((Shape)youcangetnoinfoNGVЫПвьЭ);
/*    */     } 
/*    */   }
/*    */   
/*    */   public abstract Shape createInside();
/*    */   
/*    */   public abstract Shape createOutside();
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatOptionPaneAbstractIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */