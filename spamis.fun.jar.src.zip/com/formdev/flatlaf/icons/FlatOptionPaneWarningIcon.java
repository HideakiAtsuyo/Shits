/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Path2D;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatOptionPaneWarningIcon
/*    */   extends FlatOptionPaneAbstractIcon
/*    */ {
/*    */   public FlatOptionPaneWarningIcon() {
/* 36 */     super("OptionPane.icon.warningColor", "Actions.Yellow");
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Shape createOutside() {
/* 51 */     return FlatUIUtils.createPath(new double[] { 16.0D, 2.0D, 31.0D, 28.0D, 1.0D, 28.0D });
/*    */   }
/*    */ 
/*    */   
/*    */   public Shape createInside() {
/* 56 */     Object youcangetnoinfoDUHLтФтчЯ = new Path2D.Float(0);
/* 57 */     youcangetnoinfoDUHLтФтчЯ.append(new Rectangle2D.Float(14.0F, 10.0F, 4.0F, 8.0F), false);
/* 58 */     youcangetnoinfoDUHLтФтчЯ.append(new Rectangle2D.Float(14.0F, 21.0F, 4.0F, 4.0F), false);
/* 59 */     return (Shape)youcangetnoinfoDUHLтФтчЯ;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatOptionPaneWarningIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */