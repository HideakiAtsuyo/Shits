/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatTreeClosedIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatTreeClosedIcon() {
/* 35 */     super(16, 16, UIManager.getColor("Tree.icon.closedColor"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoAPGEхЦпшЬ, Object youcangetnoinfoAPGFт8вХю) {
/* 46 */     youcangetnoinfoAPGFт8вХю.fill(FlatUIUtils.createPath(new double[] { 1.0D, 2.0D, 6.0D, 2.0D, 8.0D, 4.0D, 15.0D, 4.0D, 15.0D, 13.0D, 1.0D, 13.0D }));
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatTreeClosedIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */