/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics2D;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatTreeCollapsedIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public final boolean chevron;
/*    */   
/*    */   public FlatTreeCollapsedIcon() {
/* 39 */     super(UIManager.getColor("Tree.icon.collapsedColor"));
/*    */   }
/*    */   
/*    */   public FlatTreeCollapsedIcon(Object youcangetnoinfoAVXGжйГЭЦ) {
/* 43 */     super(11, 11, (Color)youcangetnoinfoAVXGжйГЭЦ);
/* 44 */     ((FlatTreeCollapsedIcon)super).chevron = "chevron".equals(UIManager.getString("Component.arrowType"));
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoEXKЬрВщ1, Object youcangetnoinfoEXLТчЗът) {
/* 49 */     super.rotate((Component)youcangetnoinfoEXKЬрВщ1, (Graphics2D)youcangetnoinfoEXLТчЗът);
/*    */     
/* 51 */     if (((FlatTreeCollapsedIcon)super).chevron) {
/*    */       
/* 53 */       youcangetnoinfoEXLТчЗът.fill(FlatUIUtils.createPath(new double[] { 3.0D, 1.0D, 3.0D, 2.5D, 6.0D, 5.5D, 3.0D, 8.5D, 3.0D, 10.0D, 4.5D, 10.0D, 9.0D, 5.5D, 4.5D, 1.0D }));
/*    */     } else {
/*    */       
/* 56 */       youcangetnoinfoEXLТчЗът.fill(FlatUIUtils.createPath(new double[] { 2.0D, 1.0D, 2.0D, 10.0D, 10.0D, 5.5D }));
/*    */     } 
/*    */   }
/*    */   
/*    */   public void rotate(Object youcangetnoinfoDEQZЕоъХш, Object youcangetnoinfoDERA5ЯЛКУ) {
/* 61 */     if (!youcangetnoinfoDEQZЕоъХш.getComponentOrientation().isLeftToRight())
/* 62 */       youcangetnoinfoDERA5ЯЛКУ.rotate(Math.toRadians(180.0D), ((FlatTreeCollapsedIcon)this).width / 2.0D, ((FlatTreeCollapsedIcon)this).height / 2.0D); 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatTreeCollapsedIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */