/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Path2D;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatFileViewComputerIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public FlatFileViewComputerIcon() {
/* 36 */     super(16, 16, UIManager.getColor("Objects.Grey"));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void paintIcon(Object youcangetnoinfoAZBYбЗуРШ, Object youcangetnoinfoAZBZбифяТ) {
/* 50 */     Object youcangetnoinfoAZCA5Щрщы = new Path2D.Float(0);
/* 51 */     youcangetnoinfoAZCA5Щрщы.append(new Rectangle2D.Float(2.0F, 3.0F, 12.0F, 8.0F), false);
/* 52 */     youcangetnoinfoAZCA5Щрщы.append(new Rectangle2D.Float(4.0F, 5.0F, 8.0F, 4.0F), false);
/* 53 */     youcangetnoinfoAZBZбифяТ.fill((Shape)youcangetnoinfoAZCA5Щрщы);
/*    */     
/* 55 */     youcangetnoinfoAZBZбифяТ.fillRect(2, 12, 12, 2);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatFileViewComputerIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */