/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.BasicStroke;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Shape;
/*    */ import javax.swing.JMenu;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatMenuArrowIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public final Color arrowColor;
/*    */   public final boolean chevron;
/*    */   public final Color disabledArrowColor;
/*    */   public final Color selectionForeground;
/*    */   
/*    */   public FlatMenuArrowIcon() {
/* 47 */     super(6, 10, null);
/*    */     ((FlatMenuArrowIcon)super).chevron = "chevron".equals(UIManager.getString("Component.arrowType"));
/*    */     ((FlatMenuArrowIcon)super).arrowColor = UIManager.getColor("Menu.icon.arrowColor");
/*    */     ((FlatMenuArrowIcon)super).disabledArrowColor = UIManager.getColor("Menu.icon.disabledArrowColor");
/*    */     ((FlatMenuArrowIcon)super).selectionForeground = UIManager.getColor("Menu.selectionForeground"); } public void paintIcon(Object youcangetnoinfoRQT3жУЙЦ, Object youcangetnoinfoRQU912Рд) {
/* 52 */     if (!youcangetnoinfoRQT3жУЙЦ.getComponentOrientation().isLeftToRight()) {
/* 53 */       youcangetnoinfoRQU912Рд.rotate(Math.toRadians(180.0D), ((FlatMenuArrowIcon)this).width / 2.0D, ((FlatMenuArrowIcon)this).height / 2.0D);
/*    */     }
/* 55 */     youcangetnoinfoRQU912Рд.setColor(super.getArrowColor((Component)youcangetnoinfoRQT3жУЙЦ));
/* 56 */     if (((FlatMenuArrowIcon)super).chevron) {
/*    */       
/* 58 */       Object youcangetnoinfoRQRzЦоУ5 = FlatUIUtils.createPath(false, new double[] { 1.0D, 1.0D, 5.0D, 5.0D, 1.0D, 9.0D });
/* 59 */       youcangetnoinfoRQU912Рд.setStroke(new BasicStroke(1.0F));
/* 60 */       youcangetnoinfoRQU912Рд.draw((Shape)youcangetnoinfoRQRzЦоУ5);
/*    */     } else {
/*    */       
/* 63 */       youcangetnoinfoRQU912Рд.fill(FlatUIUtils.createPath(new double[] { 0.0D, 0.5D, 5.0D, 5.0D, 0.0D, 9.5D }));
/*    */     } 
/*    */   }
/*    */   
/*    */   public Color getArrowColor(Object youcangetnoinfoXOKллА1о) {
/* 68 */     if (youcangetnoinfoXOKллА1о instanceof JMenu && ((JMenu)youcangetnoinfoXOKллА1о).isSelected()) {
/* 69 */       return ((FlatMenuArrowIcon)super).selectionForeground;
/*    */     }
/* 71 */     return youcangetnoinfoXOKллА1о.isEnabled() ? ((FlatMenuArrowIcon)super).arrowColor : ((FlatMenuArrowIcon)super).disabledArrowColor;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatMenuArrowIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */