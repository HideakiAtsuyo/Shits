/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatInternalFrameIconifyIcon
/*    */   extends FlatInternalFrameAbstractIcon
/*    */ {
/*    */   public void paintIcon(Object youcangetnoinfoBJGLЛ7КюУ, Object youcangetnoinfoBJGMщ5ш1Р) {
/* 35 */     paintBackground((Component)youcangetnoinfoBJGLЛ7КюУ, (Graphics2D)youcangetnoinfoBJGMщ5ш1Р);
/*    */     
/* 37 */     youcangetnoinfoBJGMщ5ш1Р.setColor(youcangetnoinfoBJGLЛ7КюУ.getForeground());
/* 38 */     youcangetnoinfoBJGMщ5ш1Р.fillRect(((FlatInternalFrameIconifyIcon)this).width / 2 - 4, ((FlatInternalFrameIconifyIcon)this).height / 2, 8, 1);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatInternalFrameIconifyIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */