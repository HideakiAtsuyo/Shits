/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Shape;
/*    */ import java.awt.geom.Area;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatInternalFrameMinimizeIcon
/*    */   extends FlatInternalFrameAbstractIcon
/*    */ {
/*    */   public void paintIcon(Object youcangetnoinfoBCNKГР9От, Object youcangetnoinfoBCNL2кАЭЫ) {
/* 39 */     paintBackground((Component)youcangetnoinfoBCNKГР9От, (Graphics2D)youcangetnoinfoBCNL2кАЭЫ);
/*    */     
/* 41 */     youcangetnoinfoBCNL2кАЭЫ.setColor(youcangetnoinfoBCNKГР9От.getForeground());
/*    */     
/* 43 */     int i = ((FlatInternalFrameMinimizeIcon)this).width / 2 - 4;
/* 44 */     int j = ((FlatInternalFrameMinimizeIcon)this).height / 2 - 4;
/* 45 */     Object youcangetnoinfoBCNOтЧКзЛ = FlatUIUtils.createRectangle((i + 1), (j - 1), 8.0F, 8.0F, 1.0F);
/* 46 */     Object youcangetnoinfoBCNPЁнеСт = FlatUIUtils.createRectangle((i - 1), (j + 1), 8.0F, 8.0F, 1.0F);
/*    */     
/* 48 */     Object youcangetnoinfoBCNQ82ИУя = new Area((Shape)youcangetnoinfoBCNOтЧКзЛ);
/* 49 */     youcangetnoinfoBCNQ82ИУя.subtract(new Area(new Rectangle2D.Float((i - 1), (j + 1), 8.0F, 8.0F)));
/* 50 */     youcangetnoinfoBCNL2кАЭЫ.fill((Shape)youcangetnoinfoBCNQ82ИУя);
/*    */     
/* 52 */     youcangetnoinfoBCNL2кАЭЫ.fill((Shape)youcangetnoinfoBCNPЁнеСт);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatInternalFrameMinimizeIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */