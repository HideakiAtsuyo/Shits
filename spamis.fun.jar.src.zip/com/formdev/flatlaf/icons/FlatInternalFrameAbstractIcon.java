/*    */ package com.formdev.flatlaf.icons;
/*    */ 
/*    */ import com.formdev.flatlaf.ui.FlatButtonUI;
/*    */ import com.formdev.flatlaf.ui.FlatUIUtils;
/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class FlatInternalFrameAbstractIcon
/*    */   extends FlatAbstractIcon
/*    */ {
/*    */   public final Color hoverBackground;
/*    */   public final Color pressedBackground;
/*    */   
/*    */   public FlatInternalFrameAbstractIcon() {
/* 42 */     super(UIManager.getDimension("InternalFrame.buttonSize"), 
/* 43 */         UIManager.getColor("InternalFrame.buttonHoverBackground"), 
/* 44 */         UIManager.getColor("InternalFrame.buttonPressedBackground"));
/*    */   }
/*    */   
/*    */   public FlatInternalFrameAbstractIcon(Object youcangetnoinfoACAOтЮчч2, Object youcangetnoinfoACAPг3хмъ, Object youcangetnoinfoACAQьб4Э5) {
/* 48 */     super(((Dimension)youcangetnoinfoACAOтЮчч2).width, ((Dimension)youcangetnoinfoACAOтЮчч2).height, null);
/* 49 */     ((FlatInternalFrameAbstractIcon)super).hoverBackground = (Color)youcangetnoinfoACAPг3хмъ;
/* 50 */     ((FlatInternalFrameAbstractIcon)super).pressedBackground = (Color)youcangetnoinfoACAQьб4Э5;
/*    */   }
/*    */   
/*    */   public void paintBackground(Object youcangetnoinfoDHEXХБ5ПЛ, Object youcangetnoinfoDHEYЫАло0) {
/* 54 */     Object youcangetnoinfoDHEZКЮТГг = FlatButtonUI.buttonStateColor((Component)youcangetnoinfoDHEXХБ5ПЛ, null, null, null, ((FlatInternalFrameAbstractIcon)super).hoverBackground, ((FlatInternalFrameAbstractIcon)super).pressedBackground);
/* 55 */     if (youcangetnoinfoDHEZКЮТГг != null) {
/* 56 */       FlatUIUtils.setColor((Graphics)youcangetnoinfoDHEYЫАло0, (Color)youcangetnoinfoDHEZКЮТГг, youcangetnoinfoDHEXХБ5ПЛ.getBackground());
/* 57 */       youcangetnoinfoDHEYЫАло0.fillRect(0, 0, ((FlatInternalFrameAbstractIcon)this).width, ((FlatInternalFrameAbstractIcon)this).height);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\icons\FlatInternalFrameAbstractIcon.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */