/*    */ package com.formdev.flatlaf.json;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Json$DefaultHandler
/*    */   extends JsonHandler<List<Object>, Map<String, Object>>
/*    */ {
/*    */   public Object value;
/*    */   
/*    */   public void endArrayValue(Object paramObject) {
/* 41 */     super.endArrayValue((List<Object>)paramObject); } public void endObjectValue(Object paramObject, String paramString) { super.endObjectValue((Map<String, Object>)paramObject, paramString); } public void endObject(Object paramObject) { super.endObject((Map<String, Object>)paramObject); } public void endArray(Object paramObject) { super.endArray((List<Object>)paramObject); } public Object startObject() { return super.startObject(); } public Object startArray() { return super.startArray(); }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public List<Object> startArray() {
/* 48 */     return new ArrayList();
/*    */   }
/*    */ 
/*    */   
/*    */   public Map<String, Object> startObject() {
/* 53 */     return new LinkedHashMap<>();
/*    */   }
/*    */ 
/*    */   
/*    */   public void endNull() {
/* 58 */     ((Json$DefaultHandler)super).value = "null";
/*    */   }
/*    */ 
/*    */   
/*    */   public void endBoolean(Object youcangetnoinfoBSZBТТгпК) {
/* 63 */     ((Json$DefaultHandler)super).value = (youcangetnoinfoBSZBТТгпК != null) ? "true" : "false";
/*    */   }
/*    */ 
/*    */   
/*    */   public void endString(Object youcangetnoinfoAQJIцйЖфЦ) {
/* 68 */     ((Json$DefaultHandler)super).value = youcangetnoinfoAQJIцйЖфЦ;
/*    */   }
/*    */ 
/*    */   
/*    */   public void endNumber(Object youcangetnoinfoAEJDТрдБв) {
/* 73 */     ((Json$DefaultHandler)super).value = youcangetnoinfoAEJDТрдБв;
/*    */   }
/*    */ 
/*    */   
/*    */   public void endArray(Object youcangetnoinfoBZXPбсКЁЛ) {
/* 78 */     ((Json$DefaultHandler)super).value = youcangetnoinfoBZXPбсКЁЛ;
/*    */   }
/*    */ 
/*    */   
/*    */   public void endObject(Object youcangetnoinfoUGЙ6м8Ш) {
/* 83 */     ((Json$DefaultHandler)super).value = youcangetnoinfoUGЙ6м8Ш;
/*    */   }
/*    */ 
/*    */   
/*    */   public void endArrayValue(Object youcangetnoinfoBHTM3ьмЙ7) {
/* 88 */     youcangetnoinfoBHTM3ьмЙ7.add(((Json$DefaultHandler)super).value);
/*    */   }
/*    */ 
/*    */   
/*    */   public void endObjectValue(Object youcangetnoinfoCDVIгцНиЮ, Object youcangetnoinfoCDVJИНЗ2з) {
/* 93 */     youcangetnoinfoCDVIгцНиЮ.put(youcangetnoinfoCDVJИНЗ2з, ((Json$DefaultHandler)super).value);
/*    */   }
/*    */   
/*    */   public Object getValue() {
/* 97 */     return ((Json$DefaultHandler)super).value;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\json\Json$DefaultHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */