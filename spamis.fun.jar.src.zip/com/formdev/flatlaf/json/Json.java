/*    */ package com.formdev.flatlaf.json;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.Reader;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Json
/*    */ {
/*    */   public Json() {
/* 29 */     this();
/*    */   }
/*    */ 
/*    */   
/*    */   public static Object parse(Object youcangetnoinfoDCDFиФюзЩ) throws IOException, ParseException {
/* 34 */     Object youcangetnoinfoDCDG3зХп7 = new Json$DefaultHandler();
/* 35 */     (new JsonParser((JsonHandler<?, ?>)youcangetnoinfoDCDG3зХп7)).parse((Reader)youcangetnoinfoDCDFиФюзЩ);
/* 36 */     return youcangetnoinfoDCDG3зХп7.getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\json\Json.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */