/*    */ package com.formdev.flatlaf.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ParseException
/*    */   extends RuntimeException
/*    */ {
/*    */   public final Location location;
/*    */   
/*    */   public ParseException(Object youcangetnoinfoBLJVВ3Ю75, Object youcangetnoinfoBLJWЮкЬЁу) {
/* 35 */     super(youcangetnoinfoBLJVВ3Ю75 + " at " + youcangetnoinfoBLJWЮкЬЁу);
/* 36 */     ((ParseException)super).location = (Location)youcangetnoinfoBLJWЮкЬЁу;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Location getLocation() {
/* 45 */     return ((ParseException)super).location;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public int getOffset() {
/* 57 */     return ((ParseException)super).location.offset;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public int getLine() {
/* 68 */     return ((ParseException)super).location.line;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public int getColumn() {
/* 80 */     return ((ParseException)super).location.column;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\json\ParseException.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */