/*     */ package com.formdev.flatlaf.json;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.Reader;
/*     */ import java.io.StringReader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JsonParser
/*     */ {
/*     */   public char[] buffer;
/*     */   public int lineOffset;
/*     */   public int index;
/*     */   public static final int MAX_NESTING_LEVEL = 1000;
/*     */   public final JsonHandler<Object, Object> handler;
/*     */   public StringBuilder captureBuffer;
/*     */   public static final int MIN_BUFFER_SIZE = 10;
/*     */   public int current;
/*     */   public int bufferOffset;
/*     */   public static final int DEFAULT_BUFFER_SIZE = 1024;
/*     */   public int captureStart;
/*     */   public int fill;
/*     */   public Reader reader;
/*     */   public int nestingLevel;
/*     */   public int line;
/*     */   
/*     */   public JsonParser(Object youcangetnoinfoDHZUЮцьиа) {
/*  71 */     this();
/*  72 */     if (youcangetnoinfoDHZUЮцьиа == null) {
/*  73 */       throw new NullPointerException("handler is null");
/*     */     }
/*  75 */     ((JsonParser)super).handler = (JsonHandler<Object, Object>)youcangetnoinfoDHZUЮцьиа;
/*  76 */     ((JsonHandler)youcangetnoinfoDHZUЮцьиа).parser = (JsonParser)this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(Object youcangetnoinfoARSLТФЬЯЩ) {
/*  89 */     if (youcangetnoinfoARSLТФЬЯЩ == null) {
/*  90 */       throw new NullPointerException("string is null");
/*     */     }
/*  92 */     int i = Math.max(10, Math.min(1024, youcangetnoinfoARSLТФЬЯЩ.length()));
/*     */     try {
/*  94 */       super.parse(new StringReader((String)youcangetnoinfoARSLТФЬЯЩ), i);
/*  95 */     } catch (IOException youcangetnoinfoARSJУплЯз) {
/*     */       
/*  97 */       throw new RuntimeException(youcangetnoinfoARSJУплЯз);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(Object youcangetnoinfoSSLПзаЬо) throws IOException {
/* 117 */     super.parse((Reader)youcangetnoinfoSSLПзаЬо, 1024);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parse(Object youcangetnoinfoDZZWмШсЁг, Object youcangetnoinfoDZZXАмлЕЖ) throws IOException {
/* 138 */     if (youcangetnoinfoDZZWмШсЁг == null) {
/* 139 */       throw new NullPointerException("reader is null");
/*     */     }
/* 141 */     if (youcangetnoinfoDZZXАмлЕЖ <= null) {
/* 142 */       throw new IllegalArgumentException("buffersize is zero or negative");
/*     */     }
/* 144 */     ((JsonParser)super).reader = (Reader)youcangetnoinfoDZZWмШсЁг;
/* 145 */     ((JsonParser)super).buffer = new char[youcangetnoinfoDZZXАмлЕЖ];
/* 146 */     ((JsonParser)super).bufferOffset = 0;
/* 147 */     ((JsonParser)super).index = 0;
/* 148 */     ((JsonParser)super).fill = 0;
/* 149 */     ((JsonParser)super).line = 1;
/* 150 */     ((JsonParser)super).lineOffset = 0;
/* 151 */     ((JsonParser)super).current = 0;
/* 152 */     ((JsonParser)super).captureStart = -1;
/* 153 */     super.read();
/* 154 */     super.skipWhiteSpace();
/* 155 */     super.readValue();
/* 156 */     super.skipWhiteSpace();
/* 157 */     if (!super.isEndOfText()) {
/* 158 */       throw super.error("Unexpected character");
/*     */     }
/*     */   }
/*     */   
/*     */   public void readValue() throws IOException {
/* 163 */     switch (((JsonParser)super).current) {
/*     */       case 110:
/* 165 */         super.readNull();
/*     */         return;
/*     */       case 116:
/* 168 */         super.readTrue();
/*     */         return;
/*     */       case 102:
/* 171 */         super.readFalse();
/*     */         return;
/*     */       case 34:
/* 174 */         super.readString();
/*     */         return;
/*     */       case 91:
/* 177 */         super.readArray();
/*     */         return;
/*     */       case 123:
/* 180 */         super.readObject();
/*     */         return;
/*     */       case 45:
/*     */       case 48:
/*     */       case 49:
/*     */       case 50:
/*     */       case 51:
/*     */       case 52:
/*     */       case 53:
/*     */       case 54:
/*     */       case 55:
/*     */       case 56:
/*     */       case 57:
/* 193 */         super.readNumber();
/*     */         return;
/*     */     } 
/* 196 */     throw super.expected("value");
/*     */   }
/*     */ 
/*     */   
/*     */   public void readArray() throws IOException {
/* 201 */     Object youcangetnoinfoABMGрОйше = ((JsonParser)super).handler.startArray();
/* 202 */     super.read();
/* 203 */     if (++((JsonParser)super).nestingLevel > 1000) {
/* 204 */       throw super.error("Nesting too deep");
/*     */     }
/* 206 */     super.skipWhiteSpace();
/* 207 */     if (super.readChar(']')) {
/* 208 */       ((JsonParser)super).nestingLevel--;
/* 209 */       ((JsonParser)super).handler.endArray(youcangetnoinfoABMGрОйше);
/*     */       return;
/*     */     } 
/*     */     while (true) {
/* 213 */       super.skipWhiteSpace();
/* 214 */       ((JsonParser)super).handler.startArrayValue(youcangetnoinfoABMGрОйше);
/* 215 */       super.readValue();
/* 216 */       ((JsonParser)super).handler.endArrayValue(youcangetnoinfoABMGрОйше);
/* 217 */       super.skipWhiteSpace();
/* 218 */       if (!super.readChar(',')) {
/* 219 */         if (!super.readChar(']')) {
/* 220 */           throw super.expected("',' or ']'");
/*     */         }
/* 222 */         ((JsonParser)super).nestingLevel--;
/* 223 */         ((JsonParser)super).handler.endArray(youcangetnoinfoABMGрОйше);
/*     */         return;
/*     */       } 
/*     */     }  }
/* 227 */   public void readObject() throws IOException { Object youcangetnoinfoEGNKЛЩЫОк = ((JsonParser)super).handler.startObject();
/* 228 */     super.read();
/* 229 */     if (++((JsonParser)super).nestingLevel > 1000) {
/* 230 */       throw super.error("Nesting too deep");
/*     */     }
/* 232 */     super.skipWhiteSpace();
/* 233 */     if (super.readChar('}')) {
/* 234 */       ((JsonParser)super).nestingLevel--;
/* 235 */       ((JsonParser)super).handler.endObject(youcangetnoinfoEGNKЛЩЫОк);
/*     */       return;
/*     */     } 
/*     */     while (true) {
/* 239 */       super.skipWhiteSpace();
/* 240 */       ((JsonParser)super).handler.startObjectName(youcangetnoinfoEGNKЛЩЫОк);
/* 241 */       Object youcangetnoinfoEGNIЫНлэЁ = super.readName();
/* 242 */       ((JsonParser)super).handler.endObjectName(youcangetnoinfoEGNKЛЩЫОк, (String)youcangetnoinfoEGNIЫНлэЁ);
/* 243 */       super.skipWhiteSpace();
/* 244 */       if (!super.readChar(':')) {
/* 245 */         throw super.expected("':'");
/*     */       }
/* 247 */       super.skipWhiteSpace();
/* 248 */       ((JsonParser)super).handler.startObjectValue(youcangetnoinfoEGNKЛЩЫОк, (String)youcangetnoinfoEGNIЫНлэЁ);
/* 249 */       super.readValue();
/* 250 */       ((JsonParser)super).handler.endObjectValue(youcangetnoinfoEGNKЛЩЫОк, (String)youcangetnoinfoEGNIЫНлэЁ);
/* 251 */       super.skipWhiteSpace();
/* 252 */       if (!super.readChar(',')) {
/* 253 */         if (!super.readChar('}')) {
/* 254 */           throw super.expected("',' or '}'");
/*     */         }
/* 256 */         ((JsonParser)super).nestingLevel--;
/* 257 */         ((JsonParser)super).handler.endObject(youcangetnoinfoEGNKЛЩЫОк);
/*     */         return;
/*     */       } 
/*     */     }  } public String readName() throws IOException {
/* 261 */     if (((JsonParser)super).current != 34) {
/* 262 */       throw super.expected("name");
/*     */     }
/* 264 */     return super.readStringInternal();
/*     */   }
/*     */   
/*     */   public void readNull() throws IOException {
/* 268 */     ((JsonParser)super).handler.startNull();
/* 269 */     super.read();
/* 270 */     super.readRequiredChar('u');
/* 271 */     super.readRequiredChar('l');
/* 272 */     super.readRequiredChar('l');
/* 273 */     ((JsonParser)super).handler.endNull();
/*     */   }
/*     */   
/*     */   public void readTrue() throws IOException {
/* 277 */     ((JsonParser)super).handler.startBoolean();
/* 278 */     super.read();
/* 279 */     super.readRequiredChar('r');
/* 280 */     super.readRequiredChar('u');
/* 281 */     super.readRequiredChar('e');
/* 282 */     ((JsonParser)super).handler.endBoolean(true);
/*     */   }
/*     */   
/*     */   public void readFalse() throws IOException {
/* 286 */     ((JsonParser)super).handler.startBoolean();
/* 287 */     super.read();
/* 288 */     super.readRequiredChar('a');
/* 289 */     super.readRequiredChar('l');
/* 290 */     super.readRequiredChar('s');
/* 291 */     super.readRequiredChar('e');
/* 292 */     ((JsonParser)super).handler.endBoolean(false);
/*     */   }
/*     */   
/*     */   public void readRequiredChar(Object youcangetnoinfoBWWEцВяАа) throws IOException {
/* 296 */     if (!super.readChar(youcangetnoinfoBWWEцВяАа)) {
/* 297 */       throw super.expected("'" + youcangetnoinfoBWWEцВяАа + "'");
/*     */     }
/*     */   }
/*     */   
/*     */   public void readString() throws IOException {
/* 302 */     ((JsonParser)super).handler.startString();
/* 303 */     ((JsonParser)super).handler.endString(super.readStringInternal());
/*     */   }
/*     */   
/*     */   public String readStringInternal() throws IOException {
/* 307 */     super.read();
/* 308 */     super.startCapture();
/* 309 */     while (((JsonParser)super).current != 34) {
/* 310 */       if (((JsonParser)super).current == 92) {
/* 311 */         super.pauseCapture();
/* 312 */         super.readEscape();
/* 313 */         super.startCapture(); continue;
/* 314 */       }  if (((JsonParser)super).current < 32) {
/* 315 */         throw super.expected("valid string character");
/*     */       }
/* 317 */       super.read();
/*     */     } 
/*     */     
/* 320 */     Object youcangetnoinfoCTEQТАТ6П = super.endCapture();
/* 321 */     super.read();
/* 322 */     return (String)youcangetnoinfoCTEQТАТ6П;
/*     */   } public void readEscape() throws IOException {
/*     */     Object youcangetnoinfoBSDLзуЭбБ;
/*     */     byte b;
/* 326 */     super.read();
/* 327 */     switch (((JsonParser)super).current) {
/*     */       case 34:
/*     */       case 47:
/*     */       case 92:
/* 331 */         ((JsonParser)super).captureBuffer.append((char)((JsonParser)super).current);
/*     */         break;
/*     */       case 98:
/* 334 */         ((JsonParser)super).captureBuffer.append('\b');
/*     */         break;
/*     */       case 102:
/* 337 */         ((JsonParser)super).captureBuffer.append('\f');
/*     */         break;
/*     */       case 110:
/* 340 */         ((JsonParser)super).captureBuffer.append('\n');
/*     */         break;
/*     */       case 114:
/* 343 */         ((JsonParser)super).captureBuffer.append('\r');
/*     */         break;
/*     */       case 116:
/* 346 */         ((JsonParser)super).captureBuffer.append('\t');
/*     */         break;
/*     */       case 117:
/* 349 */         youcangetnoinfoBSDLзуЭбБ = new char[4];
/* 350 */         for (b = 0; b < 4; b++) {
/* 351 */           super.read();
/* 352 */           if (!super.isHexDigit()) {
/* 353 */             throw super.expected("hexadecimal digit");
/*     */           }
/* 355 */           youcangetnoinfoBSDLзуЭбБ[b] = (char)((JsonParser)super).current;
/*     */         } 
/* 357 */         ((JsonParser)super).captureBuffer.append((char)Integer.parseInt(new String((char[])youcangetnoinfoBSDLзуЭбБ), 16));
/*     */         break;
/*     */       default:
/* 360 */         throw super.expected("valid escape sequence");
/*     */     } 
/* 362 */     super.read();
/*     */   }
/*     */   
/*     */   public void readNumber() throws IOException {
/* 366 */     ((JsonParser)super).handler.startNumber();
/* 367 */     super.startCapture();
/* 368 */     super.readChar('-');
/* 369 */     int i = ((JsonParser)super).current;
/* 370 */     if (!super.readDigit()) {
/* 371 */       throw super.expected("digit");
/*     */     }
/* 373 */     if (i != 48) {
/* 374 */       while (super.readDigit());
/*     */     }
/*     */     
/* 377 */     super.readFraction();
/* 378 */     super.readExponent();
/* 379 */     ((JsonParser)super).handler.endNumber(super.endCapture());
/*     */   }
/*     */   
/*     */   public boolean readFraction() throws IOException {
/* 383 */     if (!super.readChar('.')) {
/* 384 */       return false;
/*     */     }
/* 386 */     if (!super.readDigit()) {
/* 387 */       throw super.expected("digit");
/*     */     }
/* 389 */     while (super.readDigit());
/*     */     
/* 391 */     return true;
/*     */   }
/*     */   
/*     */   public boolean readExponent() throws IOException {
/* 395 */     if (!super.readChar('e') && !super.readChar('E')) {
/* 396 */       return false;
/*     */     }
/* 398 */     if (!super.readChar('+')) {
/* 399 */       super.readChar('-');
/*     */     }
/* 401 */     if (!super.readDigit()) {
/* 402 */       throw super.expected("digit");
/*     */     }
/* 404 */     while (super.readDigit());
/*     */     
/* 406 */     return true;
/*     */   }
/*     */   
/*     */   public boolean readChar(Object youcangetnoinfoDBKРдО8Щ) throws IOException {
/* 410 */     if (((JsonParser)super).current != youcangetnoinfoDBKРдО8Щ) {
/* 411 */       return false;
/*     */     }
/* 413 */     super.read();
/* 414 */     return true;
/*     */   }
/*     */   
/*     */   public boolean readDigit() throws IOException {
/* 418 */     if (!super.isDigit()) {
/* 419 */       return false;
/*     */     }
/* 421 */     super.read();
/* 422 */     return true;
/*     */   }
/*     */   
/*     */   public void skipWhiteSpace() throws IOException {
/* 426 */     while (super.isWhiteSpace()) {
/* 427 */       super.read();
/*     */     }
/*     */   }
/*     */   
/*     */   public void read() throws IOException {
/* 432 */     if (((JsonParser)super).index == ((JsonParser)super).fill) {
/* 433 */       if (((JsonParser)super).captureStart != -1) {
/* 434 */         ((JsonParser)super).captureBuffer.append(((JsonParser)super).buffer, ((JsonParser)super).captureStart, ((JsonParser)super).fill - ((JsonParser)super).captureStart);
/* 435 */         ((JsonParser)super).captureStart = 0;
/*     */       } 
/* 437 */       ((JsonParser)super).bufferOffset += ((JsonParser)super).fill;
/* 438 */       ((JsonParser)super).fill = ((JsonParser)super).reader.read(((JsonParser)super).buffer, 0, ((JsonParser)super).buffer.length);
/* 439 */       ((JsonParser)super).index = 0;
/* 440 */       if (((JsonParser)super).fill == -1) {
/* 441 */         ((JsonParser)super).current = -1;
/* 442 */         ((JsonParser)super).index++;
/*     */         return;
/*     */       } 
/*     */     } 
/* 446 */     if (((JsonParser)super).current == 10) {
/* 447 */       ((JsonParser)super).line++;
/* 448 */       ((JsonParser)super).lineOffset = ((JsonParser)super).bufferOffset + ((JsonParser)super).index;
/*     */     } 
/* 450 */     ((JsonParser)super).current = ((JsonParser)super).buffer[((JsonParser)super).index++];
/*     */   }
/*     */   
/*     */   public void startCapture() {
/* 454 */     if (((JsonParser)super).captureBuffer == null) {
/* 455 */       ((JsonParser)super).captureBuffer = new StringBuilder();
/*     */     }
/* 457 */     ((JsonParser)super).captureStart = ((JsonParser)super).index - 1;
/*     */   }
/*     */   
/*     */   public void pauseCapture() {
/* 461 */     int i = (((JsonParser)super).current == -1) ? ((JsonParser)super).index : (((JsonParser)super).index - 1);
/* 462 */     ((JsonParser)super).captureBuffer.append(((JsonParser)super).buffer, ((JsonParser)super).captureStart, i - ((JsonParser)super).captureStart);
/* 463 */     ((JsonParser)super).captureStart = -1;
/*     */   }
/*     */   
/*     */   public String endCapture() {
/* 467 */     int i = ((JsonParser)super).captureStart;
/* 468 */     int j = ((JsonParser)super).index - 1;
/* 469 */     ((JsonParser)super).captureStart = -1;
/* 470 */     if (((JsonParser)super).captureBuffer.length() > 0) {
/* 471 */       ((JsonParser)super).captureBuffer.append(((JsonParser)super).buffer, i, j - i);
/* 472 */       Object youcangetnoinfoDFVYЯУъТЖ = ((JsonParser)super).captureBuffer.toString();
/* 473 */       ((JsonParser)super).captureBuffer.setLength(0);
/* 474 */       return (String)youcangetnoinfoDFVYЯУъТЖ;
/*     */     } 
/* 476 */     return new String(((JsonParser)super).buffer, i, j - i);
/*     */   }
/*     */   
/*     */   public Location getLocation() {
/* 480 */     int i = ((JsonParser)super).bufferOffset + ((JsonParser)super).index - 1;
/* 481 */     int j = i - ((JsonParser)super).lineOffset + 1;
/* 482 */     return new Location(i, ((JsonParser)super).line, j);
/*     */   }
/*     */   
/*     */   public ParseException expected(Object youcangetnoinfoBZYWКzУюц) {
/* 486 */     if (super.isEndOfText()) {
/* 487 */       return super.error("Unexpected end of input");
/*     */     }
/* 489 */     return super.error("Expected " + youcangetnoinfoBZYWКzУюц);
/*     */   }
/*     */   
/*     */   public ParseException error(Object youcangetnoinfoUZN6zЩг1) {
/* 493 */     return new ParseException((String)youcangetnoinfoUZN6zЩг1, super.getLocation());
/*     */   }
/*     */   
/*     */   public boolean isWhiteSpace() {
/* 497 */     return (((JsonParser)super).current == 32 || ((JsonParser)super).current == 9 || ((JsonParser)super).current == 10 || ((JsonParser)super).current == 13);
/*     */   }
/*     */   
/*     */   public boolean isDigit() {
/* 501 */     return (((JsonParser)super).current >= 48 && ((JsonParser)super).current <= 57);
/*     */   }
/*     */   
/*     */   public boolean isHexDigit() {
/* 505 */     return ((((JsonParser)super).current >= 48 && ((JsonParser)super).current <= 57) || (((JsonParser)super).current >= 97 && ((JsonParser)super).current <= 102) || (((JsonParser)super).current >= 65 && ((JsonParser)super).current <= 70));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isEndOfText() {
/* 511 */     return (((JsonParser)super).current == -1);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\json\JsonParser.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */