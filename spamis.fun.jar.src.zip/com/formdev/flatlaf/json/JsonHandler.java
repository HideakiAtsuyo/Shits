/*     */ package com.formdev.flatlaf.json;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class JsonHandler<A, O>
/*     */ {
/*     */   public JsonParser parser;
/*     */   
/*     */   public JsonHandler() {
/*  58 */     this();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Location getLocation() {
/*  68 */     return ((JsonHandler)super).parser.getLocation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startNull() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endNull() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startBoolean() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endBoolean(Object youcangetnoinfoDFCNУЖьюЛ) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startString() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endString(Object youcangetnoinfoAPOAЯ2ДШя) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startNumber() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endNumber(Object youcangetnoinfoCGGXжШдэ5) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public A startArray() {
/* 149 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endArray(Object youcangetnoinfoDPVZрс8Й7) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void startArrayValue(Object youcangetnoinfoDPBLшюДЭБ) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void endArrayValue(Object youcangetnoinfoAZMAк2НЯЧ) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public O startObject() {
/* 203 */     return null;
/*     */   }
/*     */   
/*     */   public void endObject(Object youcangetnoinfoCRQC9щГчл) {}
/*     */   
/*     */   public void startObjectName(Object youcangetnoinfoACRIЗ1аОЯ) {}
/*     */   
/*     */   public void endObjectName(Object youcangetnoinfoCQKR7фЬzВ, Object youcangetnoinfoCQKSМэОЧГ) {}
/*     */   
/*     */   public void startObjectValue(Object youcangetnoinfoAFJJУпЬЪЪ, Object youcangetnoinfoAFJKуСКсе) {}
/*     */   
/*     */   public void endObjectValue(Object youcangetnoinfoBQYI7РАГр, Object youcangetnoinfoBQYJБ0ЭРК) {}
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\json\JsonHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */