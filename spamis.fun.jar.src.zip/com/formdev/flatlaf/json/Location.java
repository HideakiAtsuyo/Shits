/*    */ package com.formdev.flatlaf.json;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Location
/*    */ {
/*    */   public final int line;
/*    */   public final int offset;
/*    */   public final int column;
/*    */   
/*    */   public Location(Object youcangetnoinfoCBSXЯzДУэ, Object youcangetnoinfoCBSYцАчаС, Object youcangetnoinfoCBSZьюБл4) {
/* 48 */     this();
/* 49 */     ((Location)super).offset = youcangetnoinfoCBSXЯzДУэ;
/* 50 */     ((Location)super).column = youcangetnoinfoCBSZьюБл4;
/* 51 */     ((Location)super).line = youcangetnoinfoCBSYцАчаС;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 56 */     return ((Location)super).line + ":" + ((Location)super).column;
/*    */   }
/*    */ 
/*    */   
/*    */   public int hashCode() {
/* 61 */     return ((Location)super).offset;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object youcangetnoinfoCFVYЯОкйй) {
/* 66 */     if (this == youcangetnoinfoCFVYЯОкйй) {
/* 67 */       return true;
/*    */     }
/* 69 */     if (youcangetnoinfoCFVYЯОкйй == null) {
/* 70 */       return false;
/*    */     }
/* 72 */     if (getClass() != youcangetnoinfoCFVYЯОкйй.getClass()) {
/* 73 */       return false;
/*    */     }
/* 75 */     Object youcangetnoinfoCFVZЙ40Цо = youcangetnoinfoCFVYЯОкйй;
/* 76 */     return (((Location)super).offset == ((Location)youcangetnoinfoCFVZЙ40Цо).offset && ((Location)super).column == ((Location)youcangetnoinfoCFVZЙ40Цо).column && ((Location)super).line == ((Location)youcangetnoinfoCFVZЙ40Цо).line);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatlaf\json\Location.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */