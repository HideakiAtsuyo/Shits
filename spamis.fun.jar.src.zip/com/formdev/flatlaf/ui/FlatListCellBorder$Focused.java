package com.formdev.flatlaf.ui;

public class FlatListCellBorder$Focused extends FlatListCellBorder {}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatListCellBorder$Focused.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */