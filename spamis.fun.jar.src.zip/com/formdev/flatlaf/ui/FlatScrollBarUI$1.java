/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.basic.BasicScrollBarUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatScrollBarUI$1
/*     */   extends BasicScrollBarUI.PropertyChangeHandler
/*     */ {
/*     */   public final FlatScrollBarUI this$0;
/*     */   
/*     */   public FlatScrollBarUI$1() {
/* 127 */     super((BasicScrollBarUI)youcangetnoinfoCURQкФсюв);
/*     */   } public void propertyChange(Object youcangetnoinfoRZEпжСян) {
/*     */     Object youcangetnoinfoRZCМнТфй;
/* 130 */     super.propertyChange((PropertyChangeEvent)youcangetnoinfoRZEпжСян);
/*     */     
/* 132 */     switch (youcangetnoinfoRZEпжСян.getPropertyName()) {
/*     */       case "JScrollBar.showButtons":
/* 134 */         FlatScrollBarUI.access$100(((FlatScrollBarUI$1)super).this$0).revalidate();
/* 135 */         FlatScrollBarUI.access$200(((FlatScrollBarUI$1)super).this$0).repaint();
/*     */         break;
/*     */ 
/*     */       
/*     */       case "componentOrientation":
/* 140 */         youcangetnoinfoRZCМнТфй = UIManager.get("ScrollBar.ancestorInputMap");
/* 141 */         if (!FlatScrollBarUI.access$300(((FlatScrollBarUI$1)super).this$0).getComponentOrientation().isLeftToRight()) {
/* 142 */           Object youcangetnoinfoRZBЁРи11 = UIManager.get("ScrollBar.ancestorInputMap.RightToLeft");
/* 143 */           if (youcangetnoinfoRZBЁРи11 != null) {
/* 144 */             youcangetnoinfoRZBЁРи11.setParent((InputMap)youcangetnoinfoRZCМнТфй);
/* 145 */             youcangetnoinfoRZCМнТфй = youcangetnoinfoRZBЁРи11;
/*     */           } 
/*     */         } 
/* 148 */         SwingUtilities.replaceUIInputMap(FlatScrollBarUI.access$400(((FlatScrollBarUI$1)super).this$0), 1, (InputMap)youcangetnoinfoRZCМнТфй);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatScrollBarUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */