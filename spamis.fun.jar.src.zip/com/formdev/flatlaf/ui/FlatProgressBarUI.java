/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.FlatClientProperties;
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Area;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicProgressBarUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatProgressBarUI
/*     */   extends BasicProgressBarUI
/*     */ {
/*     */   public int arc;
/*     */   public Dimension verticalSize;
/*     */   public PropertyChangeListener propertyChangeListener;
/*     */   public Dimension horizontalSize;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoDJAJКн5сщ) {
/*  68 */     return new FlatProgressBarUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  73 */     super.installDefaults();
/*     */     
/*  75 */     LookAndFeel.installProperty(((FlatProgressBarUI)this).progressBar, "opaque", Boolean.valueOf(false));
/*     */     
/*  77 */     ((FlatProgressBarUI)super).arc = UIManager.getInt("ProgressBar.arc");
/*  78 */     ((FlatProgressBarUI)super).horizontalSize = UIManager.getDimension("ProgressBar.horizontalSize");
/*  79 */     ((FlatProgressBarUI)super).verticalSize = UIManager.getDimension("ProgressBar.verticalSize");
/*     */   }
/*     */   
/*     */   public void installListeners()
/*     */   {
/*  84 */     super.installListeners();
/*     */     
/*  86 */     ((FlatProgressBarUI)super).propertyChangeListener = this::lambda$installListeners$0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  95 */     ((FlatProgressBarUI)this).progressBar.addPropertyChangeListener(((FlatProgressBarUI)super).propertyChangeListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners() {
/* 100 */     super.uninstallListeners();
/*     */     
/* 102 */     ((FlatProgressBarUI)this).progressBar.removePropertyChangeListener(((FlatProgressBarUI)super).propertyChangeListener);
/* 103 */     ((FlatProgressBarUI)super).propertyChangeListener = null; }
/*     */   public void lambda$installListeners$0(Object youcangetnoinfoATHM8ЯШну) { switch (youcangetnoinfoATHM8ЯШну.getPropertyName()) {
/*     */       case "JProgressBar.largeHeight":
/*     */       case "JProgressBar.square":
/*     */         ((FlatProgressBarUI)this).progressBar.revalidate(); ((FlatProgressBarUI)this).progressBar.repaint(); break;
/* 108 */     }  } public Dimension getPreferredSize(Object youcangetnoinfoCFTGЕштие) { Object youcangetnoinfoCFTHеЯДкс = super.getPreferredSize((JComponent)youcangetnoinfoCFTGЕштие);
/*     */     
/* 110 */     if (((FlatProgressBarUI)this).progressBar.isStringPainted() || FlatClientProperties.clientPropertyBoolean((JComponent)youcangetnoinfoCFTGЕштие, "JProgressBar.largeHeight", false)) {
/*     */       
/* 112 */       Object youcangetnoinfoCFTDфРф9ч = ((FlatProgressBarUI)this).progressBar.getInsets();
/* 113 */       Object youcangetnoinfoCFTEяГсБд = ((FlatProgressBarUI)this).progressBar.getFontMetrics(((FlatProgressBarUI)this).progressBar.getFont());
/* 114 */       if (((FlatProgressBarUI)this).progressBar.getOrientation() == 0) {
/* 115 */         ((Dimension)youcangetnoinfoCFTHеЯДкс).height = Math.max(youcangetnoinfoCFTEяГсБд.getHeight() + ((Insets)youcangetnoinfoCFTDфРф9ч).top + ((Insets)youcangetnoinfoCFTDфРф9ч).bottom, (super.getPreferredInnerHorizontal()).height);
/*     */       } else {
/* 117 */         ((Dimension)youcangetnoinfoCFTHеЯДкс).width = Math.max(youcangetnoinfoCFTEяГсБд.getHeight() + ((Insets)youcangetnoinfoCFTDфРф9ч).left + ((Insets)youcangetnoinfoCFTDфРф9ч).right, (super.getPreferredInnerVertical()).width);
/*     */       } 
/*     */     } 
/* 120 */     return (Dimension)youcangetnoinfoCFTHеЯДкс; }
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredInnerHorizontal() {
/* 125 */     return UIScale.scale(((FlatProgressBarUI)super).horizontalSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredInnerVertical() {
/* 130 */     return UIScale.scale(((FlatProgressBarUI)super).verticalSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public void update(Object youcangetnoinfoDGNёцСо9, Object youcangetnoinfoDGOю6щрЭ) {
/* 135 */     if (youcangetnoinfoDGOю6щрЭ.isOpaque()) {
/* 136 */       FlatUIUtils.paintParentBackground((Graphics)youcangetnoinfoDGNёцСо9, (JComponent)youcangetnoinfoDGOю6щрЭ);
/*     */     }
/* 138 */     super.paint((Graphics)youcangetnoinfoDGNёцСо9, (JComponent)youcangetnoinfoDGOю6щрЭ);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Object youcangetnoinfoDZJFч0Шыа, Object youcangetnoinfoDZJGЮуДгЬ) {
/* 143 */     Object youcangetnoinfoDZJHЯЕЙ7э = ((FlatProgressBarUI)this).progressBar.getInsets();
/* 144 */     int i = ((Insets)youcangetnoinfoDZJHЯЕЙ7э).left;
/* 145 */     int j = ((Insets)youcangetnoinfoDZJHЯЕЙ7э).top;
/* 146 */     int k = ((FlatProgressBarUI)this).progressBar.getWidth() - ((Insets)youcangetnoinfoDZJHЯЕЙ7э).right + ((Insets)youcangetnoinfoDZJHЯЕЙ7э).left;
/* 147 */     int m = ((FlatProgressBarUI)this).progressBar.getHeight() - ((Insets)youcangetnoinfoDZJHЯЕЙ7э).top + ((Insets)youcangetnoinfoDZJHЯЕЙ7э).bottom;
/*     */     
/* 149 */     if (k <= 0 || m <= 0) {
/*     */       return;
/*     */     }
/* 152 */     boolean bool1 = (((FlatProgressBarUI)this).progressBar.getOrientation() == 0) ? true : false;
/*     */ 
/*     */     
/* 155 */     boolean bool2 = FlatClientProperties.clientPropertyBoolean((JComponent)youcangetnoinfoDZJGЮуДгЬ, "JProgressBar.square", false) ? false : Math.min(UIScale.scale(((FlatProgressBarUI)super).arc), bool1 ? m : k);
/*     */     
/* 157 */     FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoDZJFч0Шыа);
/*     */ 
/*     */     
/* 160 */     Object youcangetnoinfoDZJOЯЬЬБм = new RoundRectangle2D.Float(i, j, k, m, bool2, bool2);
/* 161 */     youcangetnoinfoDZJFч0Шыа.setColor(((FlatProgressBarUI)this).progressBar.getBackground());
/* 162 */     ((Graphics2D)youcangetnoinfoDZJFч0Шыа).fill((Shape)youcangetnoinfoDZJOЯЬЬБм);
/*     */ 
/*     */     
/* 165 */     if (((FlatProgressBarUI)this).progressBar.isIndeterminate()) {
/* 166 */       ((FlatProgressBarUI)this).boxRect = getBox(((FlatProgressBarUI)this).boxRect);
/* 167 */       if (((FlatProgressBarUI)this).boxRect != null) {
/* 168 */         youcangetnoinfoDZJFч0Шыа.setColor(((FlatProgressBarUI)this).progressBar.getForeground());
/* 169 */         ((Graphics2D)youcangetnoinfoDZJFч0Шыа).fill(new RoundRectangle2D.Float(((FlatProgressBarUI)this).boxRect.x, ((FlatProgressBarUI)this).boxRect.y, ((FlatProgressBarUI)this).boxRect.width, ((FlatProgressBarUI)this).boxRect.height, bool2, bool2));
/*     */       } 
/*     */ 
/*     */       
/* 173 */       if (((FlatProgressBarUI)this).progressBar.isStringPainted())
/* 174 */         paintString((Graphics)youcangetnoinfoDZJFч0Шыа, i, j, k, m, 0, (Insets)youcangetnoinfoDZJHЯЕЙ7э); 
/*     */     } else {
/* 176 */       int n = getAmountFull((Insets)youcangetnoinfoDZJHЯЕЙ7э, k, m);
/*     */       
/* 178 */       if (bool1) {  }
/*     */       else
/*     */       {  }
/* 181 */        Object youcangetnoinfoDZJDвшюЗз = new RoundRectangle2D.Float(i, (j + m - n), k, n, bool2, bool2);
/*     */       
/* 183 */       youcangetnoinfoDZJFч0Шыа.setColor(((FlatProgressBarUI)this).progressBar.getForeground());
/* 184 */       if (n < (bool1 ? m : k)) {
/*     */         
/* 186 */         Object youcangetnoinfoDZJBЯДЛЕФ = new Area((Shape)youcangetnoinfoDZJOЯЬЬБм);
/* 187 */         youcangetnoinfoDZJBЯДЛЕФ.intersect(new Area((Shape)youcangetnoinfoDZJDвшюЗз));
/* 188 */         ((Graphics2D)youcangetnoinfoDZJFч0Шыа).fill((Shape)youcangetnoinfoDZJBЯДЛЕФ);
/*     */       } else {
/* 190 */         ((Graphics2D)youcangetnoinfoDZJFч0Шыа).fill((Shape)youcangetnoinfoDZJDвшюЗз);
/*     */       } 
/* 192 */       if (((FlatProgressBarUI)this).progressBar.isStringPainted()) {
/* 193 */         paintString((Graphics)youcangetnoinfoDZJFч0Шыа, i, j, k, m, n, (Insets)youcangetnoinfoDZJHЯЕЙ7э);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setAnimationIndex(Object youcangetnoinfoALLZа5ВЭЁ) {
/* 199 */     super.setAnimationIndex(youcangetnoinfoALLZа5ВЭЁ);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     double d = UIScale.getSystemScaleFactor(((FlatProgressBarUI)this).progressBar.getGraphicsConfiguration());
/* 208 */     if ((int)d != d)
/* 209 */       ((FlatProgressBarUI)this).progressBar.repaint(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatProgressBarUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */