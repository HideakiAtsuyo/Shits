/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTextPaneUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTextPaneUI
/*     */   extends BasicTextPaneUI
/*     */ {
/*     */   public Object oldHonorDisplayProperties;
/*     */   public boolean isIntelliJTheme;
/*     */   public int minimumWidth;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoCPUTзЬТтЯ) {
/*  64 */     return new FlatTextPaneUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  69 */     super.installDefaults();
/*     */     
/*  71 */     ((FlatTextPaneUI)super).minimumWidth = UIManager.getInt("Component.minimumWidth");
/*  72 */     ((FlatTextPaneUI)super).isIntelliJTheme = UIManager.getBoolean("Component.isIntelliJTheme");
/*     */ 
/*     */     
/*  75 */     ((FlatTextPaneUI)super).oldHonorDisplayProperties = getComponent().getClientProperty("JEditorPane.honorDisplayProperties");
/*  76 */     getComponent().putClientProperty("JEditorPane.honorDisplayProperties", Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/*  81 */     super.uninstallDefaults();
/*     */     
/*  83 */     getComponent().putClientProperty("JEditorPane.honorDisplayProperties", ((FlatTextPaneUI)super).oldHonorDisplayProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoBWUEЬzзЩ3) {
/*  88 */     return super.applyMinimumWidth(super.getPreferredSize((JComponent)youcangetnoinfoBWUEЬzзЩ3));
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(Object youcangetnoinfoCAYHМЮ5эе) {
/*  93 */     return super.applyMinimumWidth(super.getMinimumSize((JComponent)youcangetnoinfoCAYHМЮ5эе));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension applyMinimumWidth(Object youcangetnoinfoAXZйшКв3) {
/* 101 */     int i = FlatUIUtils.minimumWidth(getComponent(), ((FlatTextPaneUI)super).minimumWidth);
/* 102 */     ((Dimension)youcangetnoinfoAXZйшКв3).width = Math.max(((Dimension)youcangetnoinfoAXZйшКв3).width, UIScale.scale(i) - UIScale.scale(1) * 2);
/* 103 */     return (Dimension)youcangetnoinfoAXZйшКв3;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoKWPЮГъЁФ) {
/* 108 */     Object youcangetnoinfoKWQСдкхХ = getComponent();
/*     */ 
/*     */     
/* 111 */     if (((FlatTextPaneUI)super).isIntelliJTheme && (!youcangetnoinfoKWQСдкхХ.isEnabled() || !youcangetnoinfoKWQСдкхХ.isEditable()) && youcangetnoinfoKWQСдкхХ.getBackground() instanceof javax.swing.plaf.UIResource) {
/* 112 */       FlatUIUtils.paintParentBackground((Graphics)youcangetnoinfoKWPЮГъЁФ, (JComponent)youcangetnoinfoKWQСдкхХ);
/*     */       
/*     */       return;
/*     */     } 
/* 116 */     super.paintBackground((Graphics)youcangetnoinfoKWPЮГъЁФ);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTextPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */