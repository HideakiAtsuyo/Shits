/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Insets;
/*    */ import java.awt.geom.Rectangle2D;
/*    */ import javax.swing.JMenuBar;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatMenuBarBorder
/*    */   extends FlatMarginBorder
/*    */ {
/*    */   public final Color borderColor;
/*    */   
/*    */   public FlatMenuBarBorder() {
/* 39 */     ((FlatMenuBarBorder)super).borderColor = UIManager.getColor("MenuBar.borderColor");
/*    */   }
/*    */   
/*    */   public void paintBorder(Object youcangetnoinfoCPSXлтс0щ, Object youcangetnoinfoCPSYАЕуzэ, Object youcangetnoinfoCPSZ0вШпе, Object youcangetnoinfoCPTAГЗЬцМ, Object youcangetnoinfoCPTBпяШеШ, Object youcangetnoinfoCPTCзЕЕэб) {
/* 43 */     Object youcangetnoinfoCPTDЦУр15 = youcangetnoinfoCPSYАЕуzэ.create();
/*    */     try {
/* 45 */       float f = UIScale.scale(1.0F);
/*    */       
/* 47 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoCPTDЦУр15);
/* 48 */       youcangetnoinfoCPTDЦУр15.setColor(((FlatMenuBarBorder)super).borderColor);
/* 49 */       youcangetnoinfoCPTDЦУр15.fill(new Rectangle2D.Float(youcangetnoinfoCPSZ0вШпе, (youcangetnoinfoCPTAГЗЬцМ + youcangetnoinfoCPTCзЕЕэб) - f, youcangetnoinfoCPTBпяШеШ, f));
/*    */     } finally {
/* 51 */       youcangetnoinfoCPTDЦУр15.dispose();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public Insets getBorderInsets(Object youcangetnoinfoBHRNЦТщеД, Object youcangetnoinfoBHROТйХВЩ) {
/* 58 */     Object youcangetnoinfoBHRPШс4мП = (youcangetnoinfoBHRNЦТщеД instanceof JMenuBar) ? ((JMenuBar)youcangetnoinfoBHRNЦТщеД).getMargin() : new Insets(0, 0, 0, 0);
/*    */     
/* 60 */     ((Insets)youcangetnoinfoBHROТйХВЩ).top = UIScale.scale(((Insets)youcangetnoinfoBHRPШс4мП).top);
/* 61 */     ((Insets)youcangetnoinfoBHROТйХВЩ).left = UIScale.scale(((Insets)youcangetnoinfoBHRPШс4мП).left);
/* 62 */     ((Insets)youcangetnoinfoBHROТйХВЩ).bottom = UIScale.scale(((Insets)youcangetnoinfoBHRPШс4мП).bottom + 1);
/* 63 */     ((Insets)youcangetnoinfoBHROТйХВЩ).right = UIScale.scale(((Insets)youcangetnoinfoBHRPШс4мП).right);
/* 64 */     return (Insets)youcangetnoinfoBHROТйХВЩ;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatMenuBarBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */