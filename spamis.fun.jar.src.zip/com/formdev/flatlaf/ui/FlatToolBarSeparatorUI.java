/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicToolBarSeparatorUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatToolBarSeparatorUI
/*     */   extends BasicToolBarSeparatorUI
/*     */ {
/*     */   public Color separatorColor;
/*     */   public static final int LINE_WIDTH = 1;
/*     */   public boolean defaults_initialized;
/*     */   public int separatorWidth;
/*     */   public static ComponentUI instance;
/*     */   
/*     */   public FlatToolBarSeparatorUI() {
/*  51 */     ((FlatToolBarSeparatorUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoROзЭъАз) {
/*  56 */     if (instance == null)
/*  57 */       instance = new FlatToolBarSeparatorUI(); 
/*  58 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults(Object youcangetnoinfoISR7Ё9и2) {
/*  63 */     super.installDefaults((JSeparator)youcangetnoinfoISR7Ё9и2);
/*     */     
/*  65 */     if (!((FlatToolBarSeparatorUI)super).defaults_initialized) {
/*  66 */       ((FlatToolBarSeparatorUI)super).separatorWidth = UIManager.getInt("ToolBar.separatorWidth");
/*  67 */       ((FlatToolBarSeparatorUI)super).separatorColor = UIManager.getColor("ToolBar.separatorColor");
/*     */       
/*  69 */       ((FlatToolBarSeparatorUI)super).defaults_initialized = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  74 */     youcangetnoinfoISR7Ё9и2.setAlignmentX(0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults(Object youcangetnoinfoAEIZдшЦЯс) {
/*  79 */     super.uninstallDefaults((JSeparator)youcangetnoinfoAEIZдшЦЯс);
/*  80 */     ((FlatToolBarSeparatorUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoCMWOОхрюЦ) {
/*  85 */     Object youcangetnoinfoCMWPЙРЦъО = ((JToolBar.Separator)youcangetnoinfoCMWOОхрюЦ).getSeparatorSize();
/*     */     
/*  87 */     if (youcangetnoinfoCMWPЙРЦъО != null) {
/*  88 */       return UIScale.scale((Dimension)youcangetnoinfoCMWPЙРЦъО);
/*     */     }
/*     */     
/*  91 */     int i = UIScale.scale((((FlatToolBarSeparatorUI)super).separatorWidth - 1) / 2) * 2 + UIScale.scale(1);
/*     */     
/*  93 */     boolean bool = super.isVertical((JComponent)youcangetnoinfoCMWOОхрюЦ);
/*  94 */     return new Dimension(bool ? i : 0, bool ? 0 : i);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumSize(Object youcangetnoinfoDQBLГБ5ьи) {
/*  99 */     Object youcangetnoinfoDQBMДЦЁЛт = super.getPreferredSize((JComponent)youcangetnoinfoDQBLГБ5ьи);
/* 100 */     if (super.isVertical((JComponent)youcangetnoinfoDQBLГБ5ьи)) {
/* 101 */       return new Dimension(((Dimension)youcangetnoinfoDQBMДЦЁЛт).width, 32767);
/*     */     }
/* 103 */     return new Dimension(32767, ((Dimension)youcangetnoinfoDQBMДЦЁЛт).height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Object youcangetnoinfoBWNUХ5ПЙз, Object youcangetnoinfoBWNVЬУхВп) {
/* 108 */     int i = youcangetnoinfoBWNVЬУхВп.getWidth();
/* 109 */     int j = youcangetnoinfoBWNVЬУхВп.getHeight();
/* 110 */     float f1 = UIScale.scale(1.0F);
/* 111 */     float f2 = UIScale.scale(2.0F);
/*     */     
/* 113 */     FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoBWNUХ5ПЙз);
/* 114 */     youcangetnoinfoBWNUХ5ПЙз.setColor(((FlatToolBarSeparatorUI)super).separatorColor);
/*     */     
/* 116 */     if (super.isVertical((JComponent)youcangetnoinfoBWNVЬУхВп)) {
/* 117 */       ((Graphics2D)youcangetnoinfoBWNUХ5ПЙз).fill(new Rectangle2D.Float(Math.round((i - f1) / 2.0F), f2, f1, j - f2 * 2.0F));
/*     */     } else {
/* 119 */       ((Graphics2D)youcangetnoinfoBWNUХ5ПЙз).fill(new Rectangle2D.Float(f2, Math.round((j - f1) / 2.0F), i - f2 * 2.0F, f1));
/*     */     } 
/*     */   }
/*     */   public boolean isVertical(Object youcangetnoinfoDNYз7гнЦ) {
/* 123 */     return (((JToolBar.Separator)youcangetnoinfoDNYз7гнЦ).getOrientation() == 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatToolBarSeparatorUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */