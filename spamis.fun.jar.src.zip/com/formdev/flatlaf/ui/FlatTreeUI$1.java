/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.basic.BasicTreeUI;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTreeUI$1
/*     */   extends BasicTreeUI.MouseHandler
/*     */ {
/*     */   public final FlatTreeUI this$0;
/*     */   
/*     */   public FlatTreeUI$1() {
/* 145 */     super((BasicTreeUI)youcangetnoinfoDUPKаСШОд);
/*     */   }
/*     */   public void mousePressed(Object youcangetnoinfoQDJхХЩБЮ) {
/* 148 */     super.mousePressed(super.handleWideMouseEvent((MouseEvent)youcangetnoinfoQDJхХЩБЮ));
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseReleased(Object youcangetnoinfoCPHP1юдУЙ) {
/* 153 */     super.mouseReleased(super.handleWideMouseEvent((MouseEvent)youcangetnoinfoCPHP1юдУЙ));
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseDragged(Object youcangetnoinfoCYWCёвтпЛ) {
/* 158 */     super.mouseDragged(super.handleWideMouseEvent((MouseEvent)youcangetnoinfoCYWCёвтпЛ));
/*     */   }
/*     */   
/*     */   public MouseEvent handleWideMouseEvent(Object youcangetnoinfoSJJик6Жй) {
/* 162 */     if (!FlatTreeUI.access$000(((FlatTreeUI$1)super).this$0).isEnabled() || !SwingUtilities.isLeftMouseButton((MouseEvent)youcangetnoinfoSJJик6Жй) || youcangetnoinfoSJJик6Жй.isConsumed()) {
/* 163 */       return (MouseEvent)youcangetnoinfoSJJик6Жй;
/*     */     }
/* 165 */     int i = youcangetnoinfoSJJик6Жй.getX();
/* 166 */     int j = youcangetnoinfoSJJик6Жй.getY();
/* 167 */     Object youcangetnoinfoSJM9бяёА = ((FlatTreeUI$1)super).this$0.getClosestPathForLocation(FlatTreeUI.access$100(((FlatTreeUI$1)super).this$0), i, j);
/* 168 */     if (youcangetnoinfoSJM9бяёА == null || FlatTreeUI.access$200(((FlatTreeUI$1)super).this$0, (TreePath)youcangetnoinfoSJM9бяёА, i, j)) {
/* 169 */       return (MouseEvent)youcangetnoinfoSJJик6Жй;
/*     */     }
/* 171 */     Object youcangetnoinfoSJNлЛЮЩЦ = ((FlatTreeUI$1)super).this$0.getPathBounds(FlatTreeUI.access$300(((FlatTreeUI$1)super).this$0), (TreePath)youcangetnoinfoSJM9бяёА);
/* 172 */     if (youcangetnoinfoSJNлЛЮЩЦ == null || j < ((Rectangle)youcangetnoinfoSJNлЛЮЩЦ).y || j >= ((Rectangle)youcangetnoinfoSJNлЛЮЩЦ).y + ((Rectangle)youcangetnoinfoSJNлЛЮЩЦ).height) {
/* 173 */       return (MouseEvent)youcangetnoinfoSJJик6Жй;
/*     */     }
/* 175 */     int k = Math.max(((Rectangle)youcangetnoinfoSJNлЛЮЩЦ).x, Math.min(i, ((Rectangle)youcangetnoinfoSJNлЛЮЩЦ).x + ((Rectangle)youcangetnoinfoSJNлЛЮЩЦ).width - 1));
/* 176 */     if (k == i) {
/* 177 */       return (MouseEvent)youcangetnoinfoSJJик6Жй;
/*     */     }
/*     */     
/* 180 */     return new MouseEvent(youcangetnoinfoSJJик6Жй.getComponent(), youcangetnoinfoSJJик6Жй.getID(), youcangetnoinfoSJJик6Жй.getWhen(), youcangetnoinfoSJJик6Жй
/* 181 */         .getModifiers() | youcangetnoinfoSJJик6Жй.getModifiersEx(), k, youcangetnoinfoSJJик6Жй.getY(), youcangetnoinfoSJJик6Жй
/* 182 */         .getClickCount(), youcangetnoinfoSJJик6Жй.isPopupTrigger(), youcangetnoinfoSJJик6Жй.getButton());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTreeUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */