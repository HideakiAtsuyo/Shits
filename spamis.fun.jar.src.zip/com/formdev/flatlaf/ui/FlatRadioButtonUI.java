/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.icons.FlatCheckBoxIcon;
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicRadioButtonUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatRadioButtonUI
/*     */   extends BasicRadioButtonUI
/*     */ {
/*     */   public static ComponentUI instance;
/*     */   public Color disabledText;
/*     */   public boolean defaults_initialized;
/*     */   
/*     */   public FlatRadioButtonUI() {
/*  62 */     ((FlatRadioButtonUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoJIRНШ79Ф) {
/*  67 */     if (instance == null)
/*  68 */       instance = new FlatRadioButtonUI(); 
/*  69 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults(Object youcangetnoinfoAPVТзШ2z) {
/*  74 */     super.installDefaults((AbstractButton)youcangetnoinfoAPVТзШ2z);
/*     */     
/*  76 */     if (!((FlatRadioButtonUI)super).defaults_initialized) {
/*  77 */       Object youcangetnoinfoAPTЭъИРЦ = getPropertyPrefix();
/*     */       
/*  79 */       ((FlatRadioButtonUI)super).iconTextGap = FlatUIUtils.getUIInt(youcangetnoinfoAPTЭъИРЦ + "iconTextGap", 4);
/*  80 */       ((FlatRadioButtonUI)super).disabledText = UIManager.getColor(youcangetnoinfoAPTЭъИРЦ + "disabledText");
/*     */       
/*  82 */       ((FlatRadioButtonUI)super).defaults_initialized = true;
/*     */     } 
/*     */     
/*  85 */     LookAndFeel.installProperty((JComponent)youcangetnoinfoAPVТзШ2z, "opaque", Boolean.valueOf(false));
/*  86 */     LookAndFeel.installProperty((JComponent)youcangetnoinfoAPVТзШ2z, "iconTextGap", Integer.valueOf(UIScale.scale(((FlatRadioButtonUI)super).iconTextGap)));
/*     */     
/*  88 */     MigLayoutVisualPadding.install((JComponent)youcangetnoinfoAPVТзШ2z, (Insets)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults(Object youcangetnoinfoDOMXНтzаф) {
/*  93 */     super.uninstallDefaults((AbstractButton)youcangetnoinfoDOMXНтzаф);
/*     */     
/*  95 */     MigLayoutVisualPadding.uninstall((JComponent)youcangetnoinfoDOMXНтzаф);
/*  96 */     ((FlatRadioButtonUI)super).defaults_initialized = false;
/*     */   }
/*     */   
/*  99 */   public static Insets tempInsets = new Insets(0, 0, 0, 0);
/*     */   public int iconTextGap;
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoATZO61ЬВ2) {
/* 103 */     Object youcangetnoinfoATZPЙЖгЖм = super.getPreferredSize((JComponent)youcangetnoinfoATZO61ЬВ2);
/* 104 */     if (youcangetnoinfoATZPЙЖгЖм == null) {
/* 105 */       return null;
/*     */     }
/*     */     
/* 108 */     int i = super.getIconFocusWidth((JComponent)youcangetnoinfoATZO61ЬВ2);
/* 109 */     if (i > 0) {
/*     */ 
/*     */ 
/*     */       
/* 113 */       Object youcangetnoinfoATZMвФ08Ы = youcangetnoinfoATZO61ЬВ2.getInsets(tempInsets);
/* 114 */       ((Dimension)youcangetnoinfoATZPЙЖгЖм).width += Math.max(i - ((Insets)youcangetnoinfoATZMвФ08Ы).left, 0) + Math.max(i - ((Insets)youcangetnoinfoATZMвФ08Ы).right, 0);
/* 115 */       ((Dimension)youcangetnoinfoATZPЙЖгЖм).height += Math.max(i - ((Insets)youcangetnoinfoATZMвФ08Ы).top, 0) + Math.max(i - ((Insets)youcangetnoinfoATZMвФ08Ы).bottom, 0);
/*     */     } 
/*     */     
/* 118 */     return (Dimension)youcangetnoinfoATZPЙЖгЖм;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Object youcangetnoinfoAIHIУ4чли, Object youcangetnoinfoAIHJсУдД7) {
/* 127 */     if (!youcangetnoinfoAIHJсУдД7.isOpaque() && ((AbstractButton)youcangetnoinfoAIHJсУдД7)
/* 128 */       .isContentAreaFilled() && (youcangetnoinfoAIHJсУдД7
/* 129 */       .getParent() instanceof javax.swing.CellRendererPane || !(youcangetnoinfoAIHJсУдД7.getBackground() instanceof javax.swing.plaf.UIResource))) {
/*     */       
/* 131 */       youcangetnoinfoAIHIУ4чли.setColor(youcangetnoinfoAIHJсУдД7.getBackground());
/* 132 */       youcangetnoinfoAIHIУ4чли.fillRect(0, 0, youcangetnoinfoAIHJсУдД7.getWidth(), youcangetnoinfoAIHJсУдД7.getHeight());
/*     */     } 
/*     */ 
/*     */     
/* 136 */     int i = super.getIconFocusWidth((JComponent)youcangetnoinfoAIHJсУдД7);
/* 137 */     if (i > 0) {
/* 138 */       boolean bool = youcangetnoinfoAIHJсУдД7.getComponentOrientation().isLeftToRight();
/* 139 */       Object youcangetnoinfoAIHFчщёём = youcangetnoinfoAIHJсУдД7.getInsets(tempInsets);
/* 140 */       int j = bool ? ((Insets)youcangetnoinfoAIHFчщёём).left : ((Insets)youcangetnoinfoAIHFчщёём).right;
/* 141 */       if (i > j) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 146 */         int k = i - j;
/* 147 */         if (!bool) {
/* 148 */           k = -k;
/*     */         }
/*     */         
/* 151 */         youcangetnoinfoAIHIУ4чли.translate(k, 0);
/* 152 */         super.paint((Graphics)youcangetnoinfoAIHIУ4чли, (JComponent)youcangetnoinfoAIHJсУдД7);
/* 153 */         youcangetnoinfoAIHIУ4чли.translate(-k, 0);
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/* 158 */     super.paint((Graphics)youcangetnoinfoAIHIУ4чли, (JComponent)youcangetnoinfoAIHJсУдД7);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintText(Object youcangetnoinfoDURX613хи, Object youcangetnoinfoDURYГбШдЬ, Object youcangetnoinfoDURZЦбёХа, Object youcangetnoinfoDUSAДыэзь) {
/* 163 */     FlatButtonUI.paintText((Graphics)youcangetnoinfoDURX613хи, (AbstractButton)youcangetnoinfoDURYГбШдЬ, (Rectangle)youcangetnoinfoDURZЦбёХа, (String)youcangetnoinfoDUSAДыэзь, youcangetnoinfoDURYГбШдЬ.isEnabled() ? youcangetnoinfoDURYГбШдЬ.getForeground() : ((FlatRadioButtonUI)super).disabledText);
/*     */   }
/*     */   
/*     */   public int getIconFocusWidth(Object youcangetnoinfoBBYMЫьчкм) {
/* 167 */     Object youcangetnoinfoBBYNкЫаЧн = youcangetnoinfoBBYMЫьчкм;
/* 168 */     return (youcangetnoinfoBBYNкЫаЧн.getIcon() == null && getDefaultIcon() instanceof FlatCheckBoxIcon) ? 
/* 169 */       UIScale.scale(((FlatCheckBoxIcon)getDefaultIcon()).focusWidth) : 
/* 170 */       0;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatRadioButtonUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */