package com.formdev.flatlaf.ui;

public class FlatListCellBorder$Default extends FlatListCellBorder {
  public void paintBorder(Object youcangetnoinfoARGвГЕк3, Object youcangetnoinfoARHдЦЯЁ0, Object youcangetnoinfoARIдЙ5цz, Object youcangetnoinfoARJч3Ш4Г, Object youcangetnoinfoARK6ЮБГн, Object youcangetnoinfoARLЛЁеБм) {}
}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatListCellBorder$Default.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */