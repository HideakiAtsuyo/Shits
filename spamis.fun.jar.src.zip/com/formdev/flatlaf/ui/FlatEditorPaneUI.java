/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicEditorPaneUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatEditorPaneUI
/*     */   extends BasicEditorPaneUI
/*     */ {
/*     */   public int minimumWidth;
/*     */   public boolean isIntelliJTheme;
/*     */   public Object oldHonorDisplayProperties;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoDNPLЛЛа5в) {
/*  64 */     return new FlatEditorPaneUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  69 */     super.installDefaults();
/*     */     
/*  71 */     ((FlatEditorPaneUI)super).minimumWidth = UIManager.getInt("Component.minimumWidth");
/*  72 */     ((FlatEditorPaneUI)super).isIntelliJTheme = UIManager.getBoolean("Component.isIntelliJTheme");
/*     */ 
/*     */     
/*  75 */     ((FlatEditorPaneUI)super).oldHonorDisplayProperties = getComponent().getClientProperty("JEditorPane.honorDisplayProperties");
/*  76 */     getComponent().putClientProperty("JEditorPane.honorDisplayProperties", Boolean.valueOf(true));
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/*  81 */     super.uninstallDefaults();
/*     */     
/*  83 */     getComponent().putClientProperty("JEditorPane.honorDisplayProperties", ((FlatEditorPaneUI)super).oldHonorDisplayProperties);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoBVKQЪсю6к) {
/*  88 */     return super.applyMinimumWidth(super.getPreferredSize((JComponent)youcangetnoinfoBVKQЪсю6к));
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(Object youcangetnoinfoDCWMж063К) {
/*  93 */     return super.applyMinimumWidth(super.getMinimumSize((JComponent)youcangetnoinfoDCWMж063К));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension applyMinimumWidth(Object youcangetnoinfoCOQUнлШ2У) {
/* 101 */     int i = FlatUIUtils.minimumWidth(getComponent(), ((FlatEditorPaneUI)super).minimumWidth);
/* 102 */     ((Dimension)youcangetnoinfoCOQUнлШ2У).width = Math.max(((Dimension)youcangetnoinfoCOQUнлШ2У).width, UIScale.scale(i) - UIScale.scale(1) * 2);
/* 103 */     return (Dimension)youcangetnoinfoCOQUнлШ2У;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoIUCЧжфВв) {
/* 108 */     Object youcangetnoinfoIUDГПЪЖК = getComponent();
/*     */ 
/*     */     
/* 111 */     if (((FlatEditorPaneUI)super).isIntelliJTheme && (!youcangetnoinfoIUDГПЪЖК.isEnabled() || !youcangetnoinfoIUDГПЪЖК.isEditable()) && youcangetnoinfoIUDГПЪЖК.getBackground() instanceof javax.swing.plaf.UIResource) {
/* 112 */       FlatUIUtils.paintParentBackground((Graphics)youcangetnoinfoIUCЧжфВв, (JComponent)youcangetnoinfoIUDГПЪЖК);
/*     */       
/*     */       return;
/*     */     } 
/* 116 */     super.paintBackground((Graphics)youcangetnoinfoIUCЧжфВв);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatEditorPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */