/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTableHeaderUI$FlatTableCellHeaderRenderer
/*     */   implements UIResource, Border, TableCellRenderer
/*     */ {
/*     */   public int oldHorizontalTextPosition;
/*     */   public Border origBorder;
/*     */   public final TableCellRenderer delegate;
/*     */   public final FlatTableHeaderUI this$0;
/*     */   public Icon sortIcon;
/*     */   
/*     */   public FlatTableHeaderUI$FlatTableCellHeaderRenderer(Object youcangetnoinfoNWGьрфыТ) {
/* 264 */     this(); ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).oldHorizontalTextPosition = -1;
/* 265 */     ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).delegate = (TableCellRenderer)youcangetnoinfoNWGьрфыТ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Component getTableCellRendererComponent(Object youcangetnoinfoCUNHгя4щж, Object youcangetnoinfoCUNIЯ3уКХ, Object youcangetnoinfoCUNJсРРыК, Object youcangetnoinfoCUNKаШвШ6, Object youcangetnoinfoCUNLШщХИЦ, Object youcangetnoinfoCUNMОМюш6) {
/* 272 */     Object youcangetnoinfoCUNNэиБШЙ = ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).delegate.getTableCellRendererComponent((JTable)youcangetnoinfoCUNHгя4щж, youcangetnoinfoCUNIЯ3уКХ, youcangetnoinfoCUNJсРРыК, youcangetnoinfoCUNKаШвШ6, youcangetnoinfoCUNLШщХИЦ, youcangetnoinfoCUNMОМюш6);
/* 273 */     if (!(youcangetnoinfoCUNNэиБШЙ instanceof JLabel)) {
/* 274 */       return (Component)youcangetnoinfoCUNNэиБШЙ;
/*     */     }
/* 276 */     Object youcangetnoinfoCUNOЁФ3Зб = youcangetnoinfoCUNNэиБШЙ;
/*     */     
/* 278 */     if (FlatTableHeaderUI.this.sortIconPosition == 2) {
/* 279 */       if (((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).oldHorizontalTextPosition < 0)
/* 280 */         ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).oldHorizontalTextPosition = youcangetnoinfoCUNOЁФ3Зб.getHorizontalTextPosition(); 
/* 281 */       youcangetnoinfoCUNOЁФ3Зб.setHorizontalTextPosition(4);
/*     */     } else {
/*     */       
/* 284 */       ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).sortIcon = youcangetnoinfoCUNOЁФ3Зб.getIcon();
/* 285 */       ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).origBorder = youcangetnoinfoCUNOЁФ3Зб.getBorder();
/* 286 */       youcangetnoinfoCUNOЁФ3Зб.setIcon((Icon)null);
/* 287 */       youcangetnoinfoCUNOЁФ3Зб.setBorder((Border)this);
/*     */     } 
/*     */     
/* 290 */     return (Component)youcangetnoinfoCUNOЁФ3Зб;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 294 */     if (FlatTableHeaderUI.this.sortIconPosition == 2 && ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).oldHorizontalTextPosition >= 0) {
/* 295 */       Object youcangetnoinfoDSIXЫрЕВГ = super.getTableCellRendererComponent(FlatTableHeaderUI.access$100(FlatTableHeaderUI.this).getTable(), "", false, false, -1, 0);
/* 296 */       if (youcangetnoinfoDSIXЫрЕВГ instanceof JLabel && ((JLabel)youcangetnoinfoDSIXЫрЕВГ).getHorizontalTextPosition() == 4) {
/* 297 */         ((JLabel)youcangetnoinfoDSIXЫрЕВГ).setHorizontalTextPosition(((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).oldHorizontalTextPosition);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintBorder(Object youcangetnoinfoDSUGТЖЪЬь, Object youcangetnoinfoDSUHьzмсА, Object youcangetnoinfoDSUIцХюыЩ, Object youcangetnoinfoDSUJЁкБнУ, Object youcangetnoinfoDSUKzжЮэУ, Object youcangetnoinfoDSULЖУБ1z) {
/* 303 */     if (((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).origBorder != null) {
/* 304 */       ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).origBorder.paintBorder((Component)youcangetnoinfoDSUGТЖЪЬь, (Graphics)youcangetnoinfoDSUHьzмсА, youcangetnoinfoDSUIцХюыЩ, youcangetnoinfoDSUJЁкБнУ, youcangetnoinfoDSUKzжЮэУ, youcangetnoinfoDSULЖУБ1z);
/*     */     }
/* 306 */     if (((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).sortIcon != null) {
/* 307 */       int i = youcangetnoinfoDSUIцХюыЩ + (youcangetnoinfoDSUKzжЮэУ - ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).sortIcon.getIconWidth()) / 2;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 312 */       int j = (FlatTableHeaderUI.this.sortIconPosition == 1) ? (youcangetnoinfoDSUJЁкБнУ + UIScale.scale(1)) : (youcangetnoinfoDSUJЁкБнУ + youcangetnoinfoDSULЖУБ1z - ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).sortIcon.getIconHeight() - 1 - (int)(1.0F * UIScale.getUserScaleFactor()));
/* 313 */       ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).sortIcon.paintIcon((Component)youcangetnoinfoDSUGТЖЪЬь, (Graphics)youcangetnoinfoDSUHьzмсА, i, j);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Insets getBorderInsets(Object youcangetnoinfoDUAYЖЪ1Ч2) {
/* 319 */     return (((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).origBorder != null) ? ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).origBorder.getBorderInsets((Component)youcangetnoinfoDUAYЖЪ1Ч2) : new Insets(0, 0, 0, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBorderOpaque() {
/* 324 */     return (((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).origBorder != null) ? ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)super).origBorder.isBorderOpaque() : false;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTableHeaderUI$FlatTableCellHeaderRenderer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */