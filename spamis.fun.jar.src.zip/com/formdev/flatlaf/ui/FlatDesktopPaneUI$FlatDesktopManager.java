/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import javax.swing.DefaultDesktopManager;
/*    */ import javax.swing.JInternalFrame;
/*    */ import javax.swing.plaf.UIResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatDesktopPaneUI$FlatDesktopManager
/*    */   extends DefaultDesktopManager
/*    */   implements UIResource
/*    */ {
/*    */   public final FlatDesktopPaneUI this$0;
/*    */   
/*    */   public FlatDesktopPaneUI$FlatDesktopManager(Object youcangetnoinfoKIJ2еЕГЗ) {
/* 54 */     super((FlatDesktopPaneUI)youcangetnoinfoKIIк0иАо);
/*    */   }
/*    */   
/*    */   public FlatDesktopPaneUI$FlatDesktopManager() {}
/*    */   
/*    */   public void iconifyFrame(Object youcangetnoinfoBWYGбДЮСМ) {
/* 60 */     super.iconifyFrame((JInternalFrame)youcangetnoinfoBWYGбДЮСМ);
/*    */     
/* 62 */     ((FlatDesktopIconUI)youcangetnoinfoBWYGбДЮСМ.getDesktopIcon().getUI()).updateDockIcon();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatDesktopPaneUI$FlatDesktopManager.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */