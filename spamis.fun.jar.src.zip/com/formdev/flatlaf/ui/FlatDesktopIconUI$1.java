/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.beans.PropertyVetoException;
/*     */ import javax.swing.event.MouseInputAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatDesktopIconUI$1
/*     */   extends MouseInputAdapter
/*     */ {
/*     */   public final FlatDesktopIconUI this$0;
/*     */   
/*     */   public void mouseReleased(Object youcangetnoinfoBSWFрйзД6) {
/* 156 */     if (FlatDesktopIconUI.access$100(((FlatDesktopIconUI$1)super).this$0).isIcon() && FlatDesktopIconUI.access$200(((FlatDesktopIconUI$1)super).this$0).contains(youcangetnoinfoBSWFрйзД6.getX(), youcangetnoinfoBSWFрйзД6.getY())) {
/* 157 */       FlatDesktopIconUI.access$300(((FlatDesktopIconUI$1)super).this$0);
/* 158 */       FlatDesktopIconUI.access$400(((FlatDesktopIconUI$1)super).this$0).setVisible(false);
/*     */       
/*     */       try {
/* 161 */         FlatDesktopIconUI.access$500(((FlatDesktopIconUI$1)super).this$0).setIcon(false);
/* 162 */       } catch (PropertyVetoException propertyVetoException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseEntered(Object youcangetnoinfoXQHЫz9ПЛ) {
/* 170 */     FlatDesktopIconUI.access$600(((FlatDesktopIconUI$1)super).this$0);
/* 171 */     if (FlatDesktopIconUI.access$700(((FlatDesktopIconUI$1)super).this$0).isClosable()) {
/* 172 */       FlatDesktopIconUI.access$400(((FlatDesktopIconUI$1)super).this$0).setVisible(true);
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseExited(Object youcangetnoinfoELBFВЁЭ8Е) {
/* 177 */     FlatDesktopIconUI.access$300(((FlatDesktopIconUI$1)super).this$0);
/* 178 */     FlatDesktopIconUI.access$400(((FlatDesktopIconUI$1)super).this$0).setVisible(false);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatDesktopIconUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */