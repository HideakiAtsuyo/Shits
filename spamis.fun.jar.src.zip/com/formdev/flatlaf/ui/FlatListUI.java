/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.event.FocusListener;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicListUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatListUI
/*     */   extends BasicListUI
/*     */ {
/*     */   public Color selectionInactiveForeground;
/*     */   public Color selectionForeground;
/*     */   public Color selectionBackground;
/*     */   public Color selectionInactiveBackground;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoBAZNЛ7ФЗ5) {
/*  72 */     return new FlatListUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  77 */     super.installDefaults();
/*     */     
/*  79 */     ((FlatListUI)super).selectionBackground = UIManager.getColor("List.selectionBackground");
/*  80 */     ((FlatListUI)super).selectionForeground = UIManager.getColor("List.selectionForeground");
/*  81 */     ((FlatListUI)super).selectionInactiveBackground = UIManager.getColor("List.selectionInactiveBackground");
/*  82 */     ((FlatListUI)super).selectionInactiveForeground = UIManager.getColor("List.selectionInactiveForeground");
/*     */     
/*  84 */     super.toggleSelectionColors(((FlatListUI)this).list.hasFocus());
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/*  89 */     super.uninstallDefaults();
/*     */     
/*  91 */     ((FlatListUI)super).selectionBackground = null;
/*  92 */     ((FlatListUI)super).selectionForeground = null;
/*  93 */     ((FlatListUI)super).selectionInactiveBackground = null;
/*  94 */     ((FlatListUI)super).selectionInactiveForeground = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public FocusListener createFocusListener() {
/*  99 */     return new FlatListUI$1((FlatListUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toggleSelectionColors(Object youcangetnoinfoVTQСзЁзБ) {
/* 124 */     if (youcangetnoinfoVTQСзЁзБ != null) {
/* 125 */       if (((FlatListUI)this).list.getSelectionBackground() == ((FlatListUI)super).selectionInactiveBackground)
/* 126 */         ((FlatListUI)this).list.setSelectionBackground(((FlatListUI)super).selectionBackground); 
/* 127 */       if (((FlatListUI)this).list.getSelectionForeground() == ((FlatListUI)super).selectionInactiveForeground)
/* 128 */         ((FlatListUI)this).list.setSelectionForeground(((FlatListUI)super).selectionForeground); 
/*     */     } else {
/* 130 */       if (((FlatListUI)this).list.getSelectionBackground() == ((FlatListUI)super).selectionBackground)
/* 131 */         ((FlatListUI)this).list.setSelectionBackground(((FlatListUI)super).selectionInactiveBackground); 
/* 132 */       if (((FlatListUI)this).list.getSelectionForeground() == ((FlatListUI)super).selectionForeground)
/* 133 */         ((FlatListUI)this).list.setSelectionForeground(((FlatListUI)super).selectionInactiveForeground); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatListUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */