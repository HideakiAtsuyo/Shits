/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridBagConstraints;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicHTML;
/*     */ import javax.swing.plaf.basic.BasicOptionPaneUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatOptionPaneUI
/*     */   extends BasicOptionPaneUI
/*     */ {
/*     */   public int iconMessageGap;
/*     */   public int maxCharactersPerLine;
/*     */   public int focusWidth;
/*     */   public int messagePadding;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoDBXOрюВбЪ) {
/*  93 */     return new FlatOptionPaneUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  98 */     super.installDefaults();
/*     */     
/* 100 */     ((FlatOptionPaneUI)super).iconMessageGap = UIManager.getInt("OptionPane.iconMessageGap");
/* 101 */     ((FlatOptionPaneUI)super).messagePadding = UIManager.getInt("OptionPane.messagePadding");
/* 102 */     ((FlatOptionPaneUI)super).maxCharactersPerLine = UIManager.getInt("OptionPane.maxCharactersPerLine");
/* 103 */     ((FlatOptionPaneUI)super).focusWidth = UIManager.getInt("Component.focusWidth");
/*     */   }
/*     */ 
/*     */   
/*     */   public void installComponents() {
/* 108 */     super.installComponents();
/*     */     
/* 110 */     super.updateChildPanels(((FlatOptionPaneUI)this).optionPane);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumOptionPaneSize() {
/* 115 */     return UIScale.scale(super.getMinimumOptionPaneSize());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getMaxCharactersPerLineCount() {
/* 120 */     int i = super.getMaxCharactersPerLineCount();
/* 121 */     return (((FlatOptionPaneUI)super).maxCharactersPerLine > 0 && i == Integer.MAX_VALUE) ? ((FlatOptionPaneUI)super).maxCharactersPerLine : i;
/*     */   }
/*     */ 
/*     */   
/*     */   public Container createMessageArea() {
/* 126 */     Object youcangetnoinfoARIUы9ВБв = super.createMessageArea();
/*     */ 
/*     */     
/* 129 */     if (((FlatOptionPaneUI)super).iconMessageGap > 0) {
/* 130 */       Object youcangetnoinfoARISм3фау = super.findByName((Container)youcangetnoinfoARIUы9ВБв, "OptionPane.separator");
/* 131 */       if (youcangetnoinfoARISм3фау != null) {
/* 132 */         youcangetnoinfoARISм3фау.setPreferredSize(new Dimension(UIScale.scale(((FlatOptionPaneUI)super).iconMessageGap), 1));
/*     */       }
/*     */     } 
/* 135 */     return (Container)youcangetnoinfoARIUы9ВБв;
/*     */   }
/*     */ 
/*     */   
/*     */   public Container createButtonArea() {
/* 140 */     Object youcangetnoinfoCTVC0чфЧС = super.createButtonArea();
/*     */ 
/*     */     
/* 143 */     if (youcangetnoinfoCTVC0чфЧС.getLayout() instanceof BasicOptionPaneUI.ButtonAreaLayout) {
/* 144 */       Object youcangetnoinfoCTVA2ХхъР = youcangetnoinfoCTVC0чфЧС.getLayout();
/* 145 */       youcangetnoinfoCTVA2ХхъР.setPadding(UIScale.scale(youcangetnoinfoCTVA2ХхъР.getPadding() - ((FlatOptionPaneUI)super).focusWidth * 2));
/*     */     } 
/*     */     
/* 148 */     return (Container)youcangetnoinfoCTVC0чфЧС;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addMessageComponents(Object youcangetnoinfoDZRLчЭ4ЯК, Object youcangetnoinfoDZRMСЩя6э, Object youcangetnoinfoDZRNКкэУЯ, Object youcangetnoinfoDZRO2ХМшЛ, Object youcangetnoinfoDZRP2ЫМмр) {
/*     */     int i;
/* 156 */     if (((FlatOptionPaneUI)super).messagePadding > 0) {
/* 157 */       ((GridBagConstraints)youcangetnoinfoDZRMСЩя6э).insets.bottom = UIScale.scale(((FlatOptionPaneUI)super).messagePadding);
/*     */     }
/*     */     
/* 160 */     if (youcangetnoinfoDZRNКкэУЯ instanceof String && BasicHTML.isHTMLString((String)youcangetnoinfoDZRNКкэУЯ)) {
/* 161 */       i = Integer.MAX_VALUE;
/*     */     }
/* 163 */     super.addMessageComponents((Container)youcangetnoinfoDZRLчЭ4ЯК, (GridBagConstraints)youcangetnoinfoDZRMСЩя6э, youcangetnoinfoDZRNКкэУЯ, i, youcangetnoinfoDZRP2ЫМмр);
/*     */   }
/*     */   
/*     */   public void updateChildPanels(Object youcangetnoinfoBIO6юфУц) {
/* 167 */     for (Component youcangetnoinfoBIMхЙмбЭ : youcangetnoinfoBIO6юфУц.getComponents()) {
/* 168 */       if (youcangetnoinfoBIMхЙмбЭ instanceof javax.swing.JPanel) {
/* 169 */         Object youcangetnoinfoBIKПzВДд = youcangetnoinfoBIMхЙмбЭ;
/*     */ 
/*     */         
/* 172 */         youcangetnoinfoBIKПzВДд.setOpaque(false);
/*     */ 
/*     */         
/* 175 */         Object youcangetnoinfoBILБШйЮО = youcangetnoinfoBIKПzВДд.getBorder();
/* 176 */         if (youcangetnoinfoBILБШйЮО instanceof javax.swing.plaf.UIResource) {
/* 177 */           youcangetnoinfoBIKПzВДд.setBorder(new FlatOptionPaneUI$NonUIResourceBorder((Border)youcangetnoinfoBILБШйЮО));
/*     */         }
/*     */       } 
/* 180 */       if (youcangetnoinfoBIMхЙмбЭ instanceof Container) {
/* 181 */         super.updateChildPanels((Container)youcangetnoinfoBIMхЙмбЭ);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public Component findByName(Object youcangetnoinfoAEXQб8Ыи5, Object youcangetnoinfoAEXRуЧб90) {
/* 187 */     for (Component youcangetnoinfoAEXOЖЕ3э9 : youcangetnoinfoAEXQб8Ыи5.getComponents()) {
/* 188 */       if (youcangetnoinfoAEXRуЧб90.equals(youcangetnoinfoAEXOЖЕ3э9.getName())) {
/* 189 */         return youcangetnoinfoAEXOЖЕ3э9;
/*     */       }
/* 191 */       if (youcangetnoinfoAEXOЖЕ3э9 instanceof Container) {
/* 192 */         Object youcangetnoinfoAEXN8Авщз = super.findByName((Container)youcangetnoinfoAEXOЖЕ3э9, (String)youcangetnoinfoAEXRуЧб90);
/* 193 */         if (youcangetnoinfoAEXN8Авщз != null)
/* 194 */           return (Component)youcangetnoinfoAEXN8Авщз; 
/*     */       } 
/*     */     } 
/* 197 */     return null;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatOptionPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */