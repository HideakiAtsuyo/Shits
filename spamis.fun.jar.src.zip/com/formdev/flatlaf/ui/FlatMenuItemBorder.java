/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import java.awt.Component;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatMenuItemBorder
/*    */   extends FlatMarginBorder
/*    */ {
/*    */   public final Insets menuBarItemMargins;
/*    */   
/*    */   public FlatMenuItemBorder() {
/* 36 */     ((FlatMenuItemBorder)super).menuBarItemMargins = UIManager.getInsets("MenuBar.itemMargins");
/*    */   }
/*    */   
/*    */   public Insets getBorderInsets(Object youcangetnoinfoDSYK66хМй, Object youcangetnoinfoDSYLртсвУ) {
/* 40 */     if (youcangetnoinfoDSYK66хМй.getParent() instanceof javax.swing.JMenuBar) {
/* 41 */       ((Insets)youcangetnoinfoDSYLртсвУ).top = UIScale.scale(((FlatMenuItemBorder)super).menuBarItemMargins.top);
/* 42 */       ((Insets)youcangetnoinfoDSYLртсвУ).left = UIScale.scale(((FlatMenuItemBorder)super).menuBarItemMargins.left);
/* 43 */       ((Insets)youcangetnoinfoDSYLртсвУ).bottom = UIScale.scale(((FlatMenuItemBorder)super).menuBarItemMargins.bottom + 1);
/* 44 */       ((Insets)youcangetnoinfoDSYLртсвУ).right = UIScale.scale(((FlatMenuItemBorder)super).menuBarItemMargins.right);
/* 45 */       return (Insets)youcangetnoinfoDSYLртсвУ;
/*    */     } 
/* 47 */     return super.getBorderInsets((Component)youcangetnoinfoDSYK66хМй, (Insets)youcangetnoinfoDSYLртсвУ);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatMenuItemBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */