/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.beans.PropertyChangeListener;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatSpinnerUI$Handler
/*     */   implements LayoutManager, FocusListener, PropertyChangeListener
/*     */ {
/*     */   public final FlatSpinnerUI this$0;
/*     */   public Component editor;
/*     */   public Component previousButton;
/*     */   public Component nextButton;
/*     */   
/*     */   public FlatSpinnerUI$Handler(Object youcangetnoinfoACRFСИКйЮ, Object youcangetnoinfoACRGн8Ы95) {
/* 295 */     super((FlatSpinnerUI)youcangetnoinfoACRFСИКйЮ); } public FlatSpinnerUI$Handler() { this();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 300 */     ((FlatSpinnerUI$Handler)super).editor = null; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void addLayoutComponent(Object youcangetnoinfoDZFGЩУЛхЩ, Object youcangetnoinfoDZFHЧцД5М) {
/* 306 */     switch (youcangetnoinfoDZFGЩУЛхЩ) { case "Editor":
/* 307 */         ((FlatSpinnerUI$Handler)super).editor = (Component)youcangetnoinfoDZFHЧцД5М; break;
/* 308 */       case "Next": ((FlatSpinnerUI$Handler)super).nextButton = (Component)youcangetnoinfoDZFHЧцД5М; break;
/* 309 */       case "Previous": ((FlatSpinnerUI$Handler)super).previousButton = (Component)youcangetnoinfoDZFHЧцД5М;
/*     */         break; }
/*     */   
/*     */   }
/*     */   
/*     */   public void removeLayoutComponent(Object youcangetnoinfoEFNRммще0) {
/* 315 */     if (youcangetnoinfoEFNRммще0 == ((FlatSpinnerUI$Handler)super).editor) {
/* 316 */       ((FlatSpinnerUI$Handler)super).editor = null;
/* 317 */     } else if (youcangetnoinfoEFNRммще0 == ((FlatSpinnerUI$Handler)super).nextButton) {
/* 318 */       ((FlatSpinnerUI$Handler)super).nextButton = null;
/* 319 */     } else if (youcangetnoinfoEFNRммще0 == ((FlatSpinnerUI$Handler)super).previousButton) {
/* 320 */       ((FlatSpinnerUI$Handler)super).previousButton = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public Dimension preferredLayoutSize(Object youcangetnoinfoAKFZйВкП8) {
/* 325 */     Object youcangetnoinfoAKGAогЁД7 = youcangetnoinfoAKFZйВкП8.getInsets();
/* 326 */     Object youcangetnoinfoAKGBэиПфч = (((FlatSpinnerUI$Handler)super).editor != null) ? ((FlatSpinnerUI$Handler)super).editor.getPreferredSize() : new Dimension(0, 0);
/*     */ 
/*     */     
/* 329 */     int i = FlatUIUtils.minimumWidth(FlatSpinnerUI.access$200(FlatSpinnerUI.this), FlatSpinnerUI.this.minimumWidth);
/* 330 */     int j = ((Dimension)youcangetnoinfoAKGBэиПфч).height + FlatSpinnerUI.this.padding.top + FlatSpinnerUI.this.padding.bottom;
/* 331 */     return new Dimension(
/* 332 */         Math.max(((Insets)youcangetnoinfoAKGAогЁД7).left + ((Insets)youcangetnoinfoAKGAогЁД7).right + ((Dimension)youcangetnoinfoAKGBэиПфч).width + FlatSpinnerUI.this.padding.left + FlatSpinnerUI.this.padding.right + j, UIScale.scale(i + FlatSpinnerUI.this.focusWidth * 2)), ((Insets)youcangetnoinfoAKGAогЁД7).top + ((Insets)youcangetnoinfoAKGAогЁД7).bottom + j);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension minimumLayoutSize(Object youcangetnoinfoCZPGыЮфш8) {
/* 338 */     return super.preferredLayoutSize((Container)youcangetnoinfoCZPGыЮфш8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void layoutContainer(Object youcangetnoinfoCWOR8еНиЧ) {
/* 343 */     Object youcangetnoinfoCWOSР6пСО = youcangetnoinfoCWOR8еНиЧ.getSize();
/* 344 */     Object youcangetnoinfoCWOTЩгй6м = youcangetnoinfoCWOR8еНиЧ.getInsets();
/* 345 */     Object youcangetnoinfoCWOUиКгЖэ = FlatUIUtils.subtractInsets(new Rectangle((Dimension)youcangetnoinfoCWOSР6пСО), (Insets)youcangetnoinfoCWOTЩгй6м);
/*     */     
/* 347 */     if (((FlatSpinnerUI$Handler)super).nextButton == null && ((FlatSpinnerUI$Handler)super).previousButton == null) {
/* 348 */       if (((FlatSpinnerUI$Handler)super).editor != null) {
/* 349 */         ((FlatSpinnerUI$Handler)super).editor.setBounds((Rectangle)youcangetnoinfoCWOUиКгЖэ);
/*     */       }
/*     */       return;
/*     */     } 
/* 353 */     Object youcangetnoinfoCWOVлЯЗС1 = new Rectangle((Rectangle)youcangetnoinfoCWOUиКгЖэ);
/* 354 */     Object youcangetnoinfoCWOWШИрzт = new Rectangle((Rectangle)youcangetnoinfoCWOUиКгЖэ);
/*     */ 
/*     */     
/* 357 */     int i = ((Rectangle)youcangetnoinfoCWOUиКгЖэ).height;
/* 358 */     ((Rectangle)youcangetnoinfoCWOWШИрzт).width = i;
/*     */     
/* 360 */     if (youcangetnoinfoCWOR8еНиЧ.getComponentOrientation().isLeftToRight()) {
/* 361 */       ((Rectangle)youcangetnoinfoCWOVлЯЗС1).width -= i;
/* 362 */       ((Rectangle)youcangetnoinfoCWOWШИрzт).x += ((Rectangle)youcangetnoinfoCWOVлЯЗС1).width;
/*     */     } else {
/* 364 */       ((Rectangle)youcangetnoinfoCWOVлЯЗС1).x += i;
/* 365 */       ((Rectangle)youcangetnoinfoCWOVлЯЗС1).width -= i;
/*     */     } 
/*     */     
/* 368 */     if (((FlatSpinnerUI$Handler)super).editor != null) {
/* 369 */       ((FlatSpinnerUI$Handler)super).editor.setBounds(FlatUIUtils.subtractInsets((Rectangle)youcangetnoinfoCWOVлЯЗС1, FlatSpinnerUI.this.padding));
/*     */     }
/* 371 */     int j = Math.round(((Rectangle)youcangetnoinfoCWOWШИрzт).height / 2.0F);
/* 372 */     if (((FlatSpinnerUI$Handler)super).nextButton != null)
/* 373 */       ((FlatSpinnerUI$Handler)super).nextButton.setBounds(((Rectangle)youcangetnoinfoCWOWШИрzт).x, ((Rectangle)youcangetnoinfoCWOWШИрzт).y, ((Rectangle)youcangetnoinfoCWOWШИрzт).width, j); 
/* 374 */     if (((FlatSpinnerUI$Handler)super).previousButton != null) {
/* 375 */       ((FlatSpinnerUI$Handler)super).previousButton.setBounds(((Rectangle)youcangetnoinfoCWOWШИрzт).x, ((Rectangle)youcangetnoinfoCWOWШИрzт).y + j, ((Rectangle)youcangetnoinfoCWOWШИрzт).width, ((Rectangle)youcangetnoinfoCWOWШИрzт).height - j);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void focusGained(Object youcangetnoinfoCNA20БмУ) {
/* 384 */     FlatSpinnerUI.access$300(FlatSpinnerUI.this).repaint();
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost(Object youcangetnoinfoEBFI0ьаР4) {
/* 389 */     FlatSpinnerUI.access$400(FlatSpinnerUI.this).repaint();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void propertyChange(Object youcangetnoinfoDIWBДИ8шЧ) {
/* 396 */     switch (youcangetnoinfoDIWBДИ8шЧ.getPropertyName()) {
/*     */       case "foreground":
/*     */       case "enabled":
/* 399 */         FlatSpinnerUI.access$500(FlatSpinnerUI.this);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatSpinnerUI$Handler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */