/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.plaf.basic.BasicMenuUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatMenuUI$1
/*     */   extends BasicMenuUI.MouseInputHandler
/*     */ {
/*     */   public final FlatMenuUI this$0;
/*     */   
/*     */   public FlatMenuUI$1() {
/* 109 */     super((BasicMenuUI)youcangetnoinfoBVUPВъ9ЩН);
/*     */   }
/*     */   public void mouseEntered(Object youcangetnoinfoEJNNёМЖф9) {
/* 112 */     super.mouseEntered((MouseEvent)youcangetnoinfoEJNNёМЖф9);
/* 113 */     super.rollover((MouseEvent)youcangetnoinfoEJNNёМЖф9, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseExited(Object youcangetnoinfoBSVIФФщдЖ) {
/* 118 */     super.mouseExited((MouseEvent)youcangetnoinfoBSVIФФщдЖ);
/* 119 */     super.rollover((MouseEvent)youcangetnoinfoBSVIФФщдЖ, false);
/*     */   }
/*     */   
/*     */   public void rollover(Object youcangetnoinfoBQAB9Щр4н, Object youcangetnoinfoBQACяшш2в) {
/* 123 */     Object youcangetnoinfoBQADэЗйбг = youcangetnoinfoBQAB9Щр4н.getSource();
/* 124 */     if (youcangetnoinfoBQADэЗйбг.isTopLevelMenu() && youcangetnoinfoBQADэЗйбг.isRolloverEnabled()) {
/* 125 */       youcangetnoinfoBQADэЗйбг.getModel().setRollover(youcangetnoinfoBQACяшш2в);
/* 126 */       youcangetnoinfoBQADэЗйбг.repaint();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatMenuUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */