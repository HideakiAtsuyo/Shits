/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.FlatLaf;
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicMenuItemUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatMenuItemUI
/*     */   extends BasicMenuItemUI
/*     */ {
/*     */   public static ComponentUI createUI(Object youcangetnoinfoDLQLяЦРСК) {
/*  62 */     return new FlatMenuItemUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  67 */     super.installDefaults();
/*     */ 
/*     */     
/*  70 */     ((FlatMenuItemUI)this).defaultTextIconGap = UIScale.scale(((FlatMenuItemUI)this).defaultTextIconGap);
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyChangeListener createPropertyChangeListener(Object youcangetnoinfoCPMJИцдТЪ) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokespecial createPropertyChangeListener : (Ljavax/swing/JComponent;)Ljava/beans/PropertyChangeListener;
/*     */     //   5: astore_2
/*     */     //   6: aload_0
/*     */     //   7: aload_2
/*     */     //   8: <illegal opcode> propertyChange : (Lcom/formdev/flatlaf/ui/FlatMenuItemUI;Ljava/beans/PropertyChangeListener;)Ljava/beans/PropertyChangeListener;
/*     */     //   13: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #78	-> 0
/*     */     //   #79	-> 6
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   0	14	0	youcangetnoinfoCPMIЙ9Ц8р	Ljava/lang/Object;
/*     */     //   0	14	1	youcangetnoinfoCPMJИцдТЪ	Ljava/lang/Object;
/*     */     //   6	8	2	youcangetnoinfoCPMKНбРЩМ	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */   
/*     */   public void lambda$createPropertyChangeListener$0(Object youcangetnoinfoEINWОЦД63, Object youcangetnoinfoEINXЗБ3Рр) {
/*  80 */     youcangetnoinfoEINWОЦД63.propertyChange((PropertyChangeEvent)youcangetnoinfoEINXЗБ3Рр);
/*  81 */     if (youcangetnoinfoEINXЗБ3Рр.getPropertyName() == "iconTextGap") {
/*  82 */       ((FlatMenuItemUI)this).defaultTextIconGap = UIScale.scale(((FlatMenuItemUI)this).defaultTextIconGap);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintText(Object youcangetnoinfoAVGQщйчzБ, Object youcangetnoinfoAVGRвОи6б, Object youcangetnoinfoAVGS0ёоЙи, Object youcangetnoinfoAVGT0МЭzТ) {
/*  88 */     paintText((Graphics)youcangetnoinfoAVGQщйчzБ, (JMenuItem)youcangetnoinfoAVGRвОи6б, (Rectangle)youcangetnoinfoAVGS0ёоЙи, (String)youcangetnoinfoAVGT0МЭzТ, ((FlatMenuItemUI)this).disabledForeground, ((FlatMenuItemUI)this).selectionForeground);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void paintText(Object youcangetnoinfoBWTUШо1Фб, Object youcangetnoinfoBWTVНЙъЛЬ, Object youcangetnoinfoBWTWЭАнвЫ, Object youcangetnoinfoBWTX6СоёР, Object youcangetnoinfoBWTYл6ёь3, Object youcangetnoinfoBWTZПжэНв) {
/*  94 */     Object youcangetnoinfoBWUAЦОуу0 = youcangetnoinfoBWTVНЙъЛЬ.getFontMetrics(youcangetnoinfoBWTVНЙъЛЬ.getFont());
/*  95 */     boolean bool = FlatLaf.isShowMnemonics() ? youcangetnoinfoBWTVНЙъЛЬ.getDisplayedMnemonicIndex() : true;
/*     */     
/*  97 */     Object youcangetnoinfoBWUCтчбн0 = youcangetnoinfoBWTVНЙъЛЬ.getModel();
/*  98 */     youcangetnoinfoBWTUШо1Фб.setColor(!youcangetnoinfoBWUCтчбн0.isEnabled() ? 
/*  99 */         (Color)youcangetnoinfoBWTYл6ёь3 : (
/* 100 */         (youcangetnoinfoBWUCтчбн0.isArmed() || (youcangetnoinfoBWTVНЙъЛЬ instanceof javax.swing.JMenu && youcangetnoinfoBWUCтчбн0.isSelected())) ? 
/* 101 */         (Color)youcangetnoinfoBWTZПжэНв : 
/* 102 */         youcangetnoinfoBWTVНЙъЛЬ.getForeground()));
/*     */     
/* 104 */     FlatUIUtils.drawStringUnderlineCharAt((JComponent)youcangetnoinfoBWTVНЙъЛЬ, (Graphics)youcangetnoinfoBWTUШо1Фб, (String)youcangetnoinfoBWTX6СоёР, bool, ((Rectangle)youcangetnoinfoBWTWЭАнвЫ).x, ((Rectangle)youcangetnoinfoBWTWЭАнвЫ).y + youcangetnoinfoBWUAЦОуу0
/* 105 */         .getAscent());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatMenuItemUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */