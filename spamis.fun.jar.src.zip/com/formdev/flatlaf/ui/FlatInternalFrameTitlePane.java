/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.LayoutManager;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatInternalFrameTitlePane
/*     */   extends BasicInternalFrameTitlePane
/*     */ {
/*     */   public JLabel titleLabel;
/*     */   public JPanel buttonPanel;
/*     */   
/*     */   public FlatInternalFrameTitlePane(Object youcangetnoinfoKPTи6УУы) {
/*  50 */     super((JInternalFrame)youcangetnoinfoKPTи6УУы);
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  55 */     super.installDefaults();
/*     */     
/*  57 */     LookAndFeel.installBorder((JComponent)this, "InternalFrameTitlePane.border");
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyChangeListener createPropertyChangeListener() {
/*  62 */     return new FlatInternalFrameTitlePane$FlatPropertyChangeHandler((FlatInternalFrameTitlePane)this, null);
/*     */   }
/*     */ 
/*     */   
/*     */   public LayoutManager createLayout() {
/*  67 */     return new BorderLayout(UIScale.scale(4), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void createButtons() {
/*  72 */     super.createButtons();
/*     */     
/*  74 */     ((FlatInternalFrameTitlePane)this).iconButton.setContentAreaFilled(false);
/*  75 */     ((FlatInternalFrameTitlePane)this).maxButton.setContentAreaFilled(false);
/*  76 */     ((FlatInternalFrameTitlePane)this).closeButton.setContentAreaFilled(false);
/*     */     
/*  78 */     Object youcangetnoinfoDJVDЙасЩб = BorderFactory.createEmptyBorder();
/*  79 */     ((FlatInternalFrameTitlePane)this).iconButton.setBorder((Border)youcangetnoinfoDJVDЙасЩб);
/*  80 */     ((FlatInternalFrameTitlePane)this).maxButton.setBorder((Border)youcangetnoinfoDJVDЙасЩб);
/*  81 */     ((FlatInternalFrameTitlePane)this).closeButton.setBorder((Border)youcangetnoinfoDJVDЙасЩб);
/*     */     
/*  83 */     super.updateButtonsVisibility();
/*     */   }
/*     */ 
/*     */   
/*     */   public void addSubComponents() {
/*  88 */     ((FlatInternalFrameTitlePane)super).titleLabel = new JLabel(((FlatInternalFrameTitlePane)this).frame.getTitle());
/*  89 */     ((FlatInternalFrameTitlePane)super).titleLabel.setFont(FlatUIUtils.nonUIResource(getFont()));
/*  90 */     ((FlatInternalFrameTitlePane)super).titleLabel.setMinimumSize(new Dimension(UIScale.scale(32), 1));
/*  91 */     super.updateFrameIcon();
/*  92 */     super.updateColors();
/*     */     
/*  94 */     ((FlatInternalFrameTitlePane)super).buttonPanel = new JPanel();
/*  95 */     ((FlatInternalFrameTitlePane)super).buttonPanel.setLayout(new BoxLayout(((FlatInternalFrameTitlePane)super).buttonPanel, 2));
/*  96 */     ((FlatInternalFrameTitlePane)super).buttonPanel.setOpaque(false);
/*     */     
/*  98 */     ((FlatInternalFrameTitlePane)super).buttonPanel.add(((FlatInternalFrameTitlePane)this).iconButton);
/*  99 */     ((FlatInternalFrameTitlePane)super).buttonPanel.add(((FlatInternalFrameTitlePane)this).maxButton);
/* 100 */     ((FlatInternalFrameTitlePane)super).buttonPanel.add(((FlatInternalFrameTitlePane)this).closeButton);
/*     */     
/* 102 */     add(((FlatInternalFrameTitlePane)super).titleLabel, "Center");
/* 103 */     add(((FlatInternalFrameTitlePane)super).buttonPanel, "After");
/*     */   }
/*     */   
/*     */   public void updateFrameIcon() {
/* 107 */     Object youcangetnoinfoKALАМэЫм = ((FlatInternalFrameTitlePane)this).frame.getFrameIcon();
/* 108 */     if (youcangetnoinfoKALАМэЫм == UIManager.getIcon("InternalFrame.icon"))
/* 109 */       youcangetnoinfoKALАМэЫм = null; 
/* 110 */     ((FlatInternalFrameTitlePane)super).titleLabel.setIcon((Icon)youcangetnoinfoKALАМэЫм);
/*     */   }
/*     */   
/*     */   public void updateColors() {
/* 114 */     Object youcangetnoinfoUUTшКМтч = FlatUIUtils.nonUIResource(((FlatInternalFrameTitlePane)this).frame.isSelected() ? ((FlatInternalFrameTitlePane)this).selectedTitleColor : ((FlatInternalFrameTitlePane)this).notSelectedTitleColor);
/* 115 */     Object youcangetnoinfoUUUВгжЗФ = FlatUIUtils.nonUIResource(((FlatInternalFrameTitlePane)this).frame.isSelected() ? ((FlatInternalFrameTitlePane)this).selectedTextColor : ((FlatInternalFrameTitlePane)this).notSelectedTextColor);
/*     */     
/* 117 */     ((FlatInternalFrameTitlePane)super).titleLabel.setForeground((Color)youcangetnoinfoUUUВгжЗФ);
/* 118 */     ((FlatInternalFrameTitlePane)this).iconButton.setBackground((Color)youcangetnoinfoUUTшКМтч);
/* 119 */     ((FlatInternalFrameTitlePane)this).iconButton.setForeground((Color)youcangetnoinfoUUUВгжЗФ);
/* 120 */     ((FlatInternalFrameTitlePane)this).maxButton.setBackground((Color)youcangetnoinfoUUTшКМтч);
/* 121 */     ((FlatInternalFrameTitlePane)this).maxButton.setForeground((Color)youcangetnoinfoUUUВгжЗФ);
/* 122 */     ((FlatInternalFrameTitlePane)this).closeButton.setBackground((Color)youcangetnoinfoUUTшКМтч);
/* 123 */     ((FlatInternalFrameTitlePane)this).closeButton.setForeground((Color)youcangetnoinfoUUUВгжЗФ);
/*     */   }
/*     */   
/*     */   public void updateButtonsVisibility() {
/* 127 */     ((FlatInternalFrameTitlePane)this).iconButton.setVisible(((FlatInternalFrameTitlePane)this).frame.isIconifiable());
/* 128 */     ((FlatInternalFrameTitlePane)this).maxButton.setVisible(((FlatInternalFrameTitlePane)this).frame.isMaximizable());
/* 129 */     ((FlatInternalFrameTitlePane)this).closeButton.setVisible(((FlatInternalFrameTitlePane)this).frame.isClosable());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void assembleSystemMenu() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void showSystemMenu() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintComponent(Object youcangetnoinfoESPмЩЧ1л) {
/* 148 */     paintTitleBackground((Graphics)youcangetnoinfoESPмЩЧ1л);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatInternalFrameTitlePane.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */