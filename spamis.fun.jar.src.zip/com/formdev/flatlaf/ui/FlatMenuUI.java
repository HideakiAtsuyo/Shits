/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicMenuUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatMenuUI
/*     */   extends BasicMenuUI
/*     */ {
/*     */   public Color hoverBackground;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoBXVWрЩ2ти) {
/*  72 */     return new FlatMenuUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  77 */     super.installDefaults();
/*     */     
/*  79 */     ((FlatMenuUI)this).menuItem.setRolloverEnabled(true);
/*     */     
/*  81 */     ((FlatMenuUI)super).hoverBackground = UIManager.getColor("MenuBar.hoverBackground");
/*     */ 
/*     */     
/*  84 */     ((FlatMenuUI)this).defaultTextIconGap = UIScale.scale(((FlatMenuUI)this).defaultTextIconGap);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/*  89 */     super.uninstallDefaults();
/*     */     
/*  91 */     ((FlatMenuUI)super).hoverBackground = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyChangeListener createPropertyChangeListener(Object youcangetnoinfoSDHОгУЙГ) {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: aload_1
/*     */     //   2: invokespecial createPropertyChangeListener : (Ljavax/swing/JComponent;)Ljava/beans/PropertyChangeListener;
/*     */     //   5: astore_2
/*     */     //   6: aload_0
/*     */     //   7: aload_2
/*     */     //   8: <illegal opcode> propertyChange : (Lcom/formdev/flatlaf/ui/FlatMenuUI;Ljava/beans/PropertyChangeListener;)Ljava/beans/PropertyChangeListener;
/*     */     //   13: areturn
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #99	-> 0
/*     */     //   #100	-> 6
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   6	8	2	youcangetnoinfoSDIШтЭЫж	Ljava/lang/Object;
/*     */     //   0	14	0	youcangetnoinfoSDGЪё9хЕ	Ljava/lang/Object;
/*     */     //   0	14	1	youcangetnoinfoSDHОгУЙГ	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */   
/*     */   public void lambda$createPropertyChangeListener$0(Object youcangetnoinfoDQFKЪъбеМ, Object youcangetnoinfoDQFLяЩпън) {
/* 101 */     youcangetnoinfoDQFKЪъбеМ.propertyChange((PropertyChangeEvent)youcangetnoinfoDQFLяЩпън);
/* 102 */     if (youcangetnoinfoDQFLяЩпън.getPropertyName() == "iconTextGap") {
/* 103 */       ((FlatMenuUI)this).defaultTextIconGap = UIScale.scale(((FlatMenuUI)this).defaultTextIconGap);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public MouseInputListener createMouseInputListener(Object youcangetnoinfoBOCFЭюЗри) {
/* 109 */     return new FlatMenuUI$1((FlatMenuUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoCUFPЬ5Вцё, Object youcangetnoinfoCUFQ4Ьлщк, Object youcangetnoinfoCUFRхЧпбЯ) {
/* 134 */     Object youcangetnoinfoCUFSсЮсьБ = youcangetnoinfoCUFQ4Ьлщк.getModel();
/* 135 */     if (youcangetnoinfoCUFSсЮсьБ.isArmed() || youcangetnoinfoCUFSсЮсьБ.isSelected()) {
/* 136 */       super.paintBackground((Graphics)youcangetnoinfoCUFPЬ5Вцё, (JMenuItem)youcangetnoinfoCUFQ4Ьлщк, (Color)youcangetnoinfoCUFRхЧпбЯ);
/* 137 */     } else if (youcangetnoinfoCUFSсЮсьБ.isRollover() && youcangetnoinfoCUFSсЮсьБ.isEnabled() && ((JMenu)youcangetnoinfoCUFQ4Ьлщк).isTopLevelMenu()) {
/* 138 */       FlatUIUtils.setColor((Graphics)youcangetnoinfoCUFPЬ5Вцё, ((FlatMenuUI)super).hoverBackground, youcangetnoinfoCUFQ4Ьлщк.getBackground());
/* 139 */       youcangetnoinfoCUFPЬ5Вцё.fillRect(0, 0, youcangetnoinfoCUFQ4Ьлщк.getWidth(), youcangetnoinfoCUFQ4Ьлщк.getHeight());
/*     */     } else {
/* 141 */       super.paintBackground((Graphics)youcangetnoinfoCUFPЬ5Вцё, (JMenuItem)youcangetnoinfoCUFQ4Ьлщк, (Color)youcangetnoinfoCUFRхЧпбЯ);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintText(Object youcangetnoinfoBCBOЕсНтЕ, Object youcangetnoinfoBCBP9ъ41К, Object youcangetnoinfoBCBQЭишХа, Object youcangetnoinfoBCBRдЙЪёь) {
/* 146 */     FlatMenuItemUI.paintText((Graphics)youcangetnoinfoBCBOЕсНтЕ, (JMenuItem)youcangetnoinfoBCBP9ъ41К, (Rectangle)youcangetnoinfoBCBQЭишХа, (String)youcangetnoinfoBCBRдЙЪёь, ((FlatMenuUI)this).disabledForeground, ((FlatMenuUI)this).selectionForeground);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatMenuUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */