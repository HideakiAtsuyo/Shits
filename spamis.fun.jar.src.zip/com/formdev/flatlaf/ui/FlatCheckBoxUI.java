/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatCheckBoxUI
/*    */   extends FlatRadioButtonUI
/*    */ {
/*    */   public static ComponentUI instance;
/*    */   
/*    */   public static ComponentUI createUI(Object youcangetnoinfoDGAVЛВ3У1) {
/* 48 */     if (instance == null)
/* 49 */       instance = new FlatCheckBoxUI(); 
/* 50 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPropertyPrefix() {
/* 55 */     return "CheckBox.";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatCheckBoxUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */