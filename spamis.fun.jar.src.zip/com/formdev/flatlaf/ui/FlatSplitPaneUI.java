/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import javax.swing.UIManager;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*    */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatSplitPaneUI
/*    */   extends BasicSplitPaneUI
/*    */ {
/*    */   public Color oneTouchHoverArrowColor;
/*    */   public Color oneTouchArrowColor;
/*    */   public Boolean continuousLayout;
/*    */   public String arrowType;
/*    */   
/*    */   public static ComponentUI createUI(Object youcangetnoinfoENHUКФдБР) {
/* 61 */     return new FlatSplitPaneUI();
/*    */   }
/*    */ 
/*    */   
/*    */   public void installDefaults() {
/* 66 */     ((FlatSplitPaneUI)super).arrowType = UIManager.getString("Component.arrowType");
/*    */ 
/*    */ 
/*    */     
/* 70 */     ((FlatSplitPaneUI)super).oneTouchArrowColor = UIManager.getColor("SplitPaneDivider.oneTouchArrowColor");
/* 71 */     ((FlatSplitPaneUI)super).oneTouchHoverArrowColor = UIManager.getColor("SplitPaneDivider.oneTouchHoverArrowColor");
/*    */     
/* 73 */     super.installDefaults();
/*    */     
/* 75 */     ((FlatSplitPaneUI)super).continuousLayout = (Boolean)UIManager.get("SplitPane.continuousLayout");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean isContinuousLayout() {
/* 80 */     return (super.isContinuousLayout() || (((FlatSplitPaneUI)super).continuousLayout != null && Boolean.TRUE.equals(((FlatSplitPaneUI)super).continuousLayout)));
/*    */   }
/*    */ 
/*    */   
/*    */   public BasicSplitPaneDivider createDefaultDivider() {
/* 85 */     return new FlatSplitPaneUI$FlatSplitPaneDivider((FlatSplitPaneUI)this, (BasicSplitPaneUI)this);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatSplitPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */