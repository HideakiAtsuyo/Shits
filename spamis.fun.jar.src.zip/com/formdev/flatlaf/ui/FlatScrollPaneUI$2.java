/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.plaf.basic.BasicScrollPaneUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatScrollPaneUI$2
/*     */   extends BasicScrollPaneUI.PropertyChangeHandler
/*     */ {
/*     */   public final FlatScrollPaneUI this$0;
/*     */   
/*     */   public FlatScrollPaneUI$2() {
/* 238 */     super((BasicScrollPaneUI)youcangetnoinfoDSTHтлтКХ);
/*     */   } public void propertyChange(Object youcangetnoinfoEIEQШаятС) {
/*     */     Object youcangetnoinfoEIEMгМГёч, youcangetnoinfoEIEN0ыл92, youcangetnoinfoEIEO2НАъв;
/* 241 */     super.propertyChange((PropertyChangeEvent)youcangetnoinfoEIEQШаятС);
/*     */     
/* 243 */     switch (youcangetnoinfoEIEQШаятС.getPropertyName()) {
/*     */       case "JScrollBar.showButtons":
/* 245 */         youcangetnoinfoEIEMгМГёч = FlatScrollPaneUI.access$200(((FlatScrollPaneUI$2)super).this$0).getVerticalScrollBar();
/* 246 */         youcangetnoinfoEIEN0ыл92 = FlatScrollPaneUI.access$300(((FlatScrollPaneUI$2)super).this$0).getHorizontalScrollBar();
/* 247 */         if (youcangetnoinfoEIEMгМГёч != null) {
/* 248 */           youcangetnoinfoEIEMгМГёч.revalidate();
/* 249 */           youcangetnoinfoEIEMгМГёч.repaint();
/*     */         } 
/* 251 */         if (youcangetnoinfoEIEN0ыл92 != null) {
/* 252 */           youcangetnoinfoEIEN0ыл92.revalidate();
/* 253 */           youcangetnoinfoEIEN0ыл92.repaint();
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case "LOWER_LEFT_CORNER":
/*     */       case "LOWER_RIGHT_CORNER":
/*     */       case "UPPER_LEFT_CORNER":
/*     */       case "UPPER_RIGHT_CORNER":
/* 262 */         youcangetnoinfoEIEO2НАъв = youcangetnoinfoEIEQШаятС.getNewValue();
/* 263 */         if (youcangetnoinfoEIEO2НАъв instanceof JButton && ((JButton)youcangetnoinfoEIEO2НАъв)
/* 264 */           .getBorder() instanceof FlatButtonBorder && 
/* 265 */           FlatScrollPaneUI.access$400(((FlatScrollPaneUI$2)super).this$0).getViewport() != null && 
/* 266 */           FlatScrollPaneUI.access$500(((FlatScrollPaneUI$2)super).this$0).getViewport().getView() instanceof javax.swing.JTable) {
/*     */           
/* 268 */           ((JButton)youcangetnoinfoEIEO2НАъв).setBorder(BorderFactory.createEmptyBorder());
/* 269 */           ((JButton)youcangetnoinfoEIEO2НАъв).setFocusable(false);
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatScrollPaneUI$2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */