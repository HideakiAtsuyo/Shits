/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.util.Objects;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTableHeaderUI;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableCellRenderer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTableHeaderUI
/*     */   extends BasicTableHeaderUI
/*     */ {
/*     */   public int sortIconPosition;
/*     */   public int height;
/*     */   public Color bottomSeparatorColor;
/*     */   public Color separatorColor;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoAEIсимха) {
/*  72 */     return new FlatTableHeaderUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  77 */     super.installDefaults();
/*     */     
/*  79 */     ((FlatTableHeaderUI)super).separatorColor = UIManager.getColor("TableHeader.separatorColor");
/*  80 */     ((FlatTableHeaderUI)super).bottomSeparatorColor = UIManager.getColor("TableHeader.bottomSeparatorColor");
/*  81 */     ((FlatTableHeaderUI)super).height = UIManager.getInt("TableHeader.height");
/*  82 */     switch (Objects.toString(UIManager.getString("TableHeader.sortIconPosition"), "right")) {
/*     */       default:
/*  84 */         ((FlatTableHeaderUI)super).sortIconPosition = 4; break;
/*  85 */       case "left": ((FlatTableHeaderUI)super).sortIconPosition = 2; break;
/*  86 */       case "top": ((FlatTableHeaderUI)super).sortIconPosition = 1; break;
/*  87 */       case "bottom": ((FlatTableHeaderUI)super).sortIconPosition = 3;
/*     */         break;
/*     */     } 
/*     */     
/*  91 */     if (((FlatTableHeaderUI)super).sortIconPosition != 4) {
/*  92 */       Object youcangetnoinfoABQAдФыгР = ((FlatTableHeaderUI)this).header.getDefaultRenderer();
/*  93 */       if (youcangetnoinfoABQAдФыгР instanceof javax.swing.plaf.UIResource) {
/*  94 */         ((FlatTableHeaderUI)this).header.setDefaultRenderer(new FlatTableHeaderUI$FlatTableCellHeaderRenderer((FlatTableHeaderUI)this, (TableCellRenderer)youcangetnoinfoABQAдФыгР));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void uninstallDefaults() {
/* 100 */     super.uninstallDefaults();
/*     */ 
/*     */     
/* 103 */     Object youcangetnoinfoEFJй7п5ч = ((FlatTableHeaderUI)this).header.getDefaultRenderer();
/* 104 */     if (youcangetnoinfoEFJй7п5ч instanceof FlatTableHeaderUI$FlatTableCellHeaderRenderer) {
/* 105 */       ((FlatTableHeaderUI$FlatTableCellHeaderRenderer)youcangetnoinfoEFJй7п5ч).reset();
/* 106 */       ((FlatTableHeaderUI)this).header.setDefaultRenderer(FlatTableHeaderUI$FlatTableCellHeaderRenderer.access$000((FlatTableHeaderUI$FlatTableCellHeaderRenderer)youcangetnoinfoEFJй7п5ч));
/*     */     } 
/*     */     
/* 109 */     ((FlatTableHeaderUI)super).separatorColor = null;
/* 110 */     ((FlatTableHeaderUI)super).bottomSeparatorColor = null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Object youcangetnoinfoBVFCщйиХд, Object youcangetnoinfoBVFDДэЦйю) {
/* 116 */     Object youcangetnoinfoBVFEтюрФЮ = ((FlatTableHeaderUI)this).header.getDefaultRenderer();
/* 117 */     boolean bool = super.isSystemDefaultRenderer(youcangetnoinfoBVFEтюрФЮ);
/* 118 */     if (!bool && ((FlatTableHeaderUI)this).header.getColumnModel().getColumnCount() > 0) {
/*     */       
/* 120 */       Object youcangetnoinfoBVFAГСяГС = youcangetnoinfoBVFEтюрФЮ.getTableCellRendererComponent(((FlatTableHeaderUI)this).header
/* 121 */           .getTable(), "", false, false, -1, 0);
/* 122 */       bool = super.isSystemDefaultRenderer(youcangetnoinfoBVFAГСяГС);
/*     */     } 
/*     */     
/* 125 */     if (bool) {
/* 126 */       super.paintColumnBorders((Graphics)youcangetnoinfoBVFCщйиХд, (JComponent)youcangetnoinfoBVFDДэЦйю);
/*     */     }
/* 128 */     super.paint((Graphics)youcangetnoinfoBVFCщйиХд, (JComponent)youcangetnoinfoBVFDДэЦйю);
/*     */     
/* 130 */     if (bool)
/* 131 */       super.paintDraggedColumnBorders((Graphics)youcangetnoinfoBVFCщйиХд, (JComponent)youcangetnoinfoBVFDДэЦйю); 
/*     */   }
/*     */   
/*     */   public boolean isSystemDefaultRenderer(Object youcangetnoinfoCHBZГКЧвж) {
/* 135 */     Object youcangetnoinfoCHCAчЕХгч = youcangetnoinfoCHBZГКЧвж.getClass().getName();
/* 136 */     return (youcangetnoinfoCHCAчЕХгч.equals("sun.swing.table.DefaultTableCellHeaderRenderer") || youcangetnoinfoCHCAчЕХгч
/* 137 */       .equals("sun.swing.FilePane$AlignableTableHeaderRenderer"));
/*     */   }
/*     */   
/*     */   public void paintColumnBorders(Object youcangetnoinfoHOLиэЗтГ, Object youcangetnoinfoHOMсоД9ж) {
/* 141 */     int i = youcangetnoinfoHOMсоД9ж.getWidth();
/* 142 */     int j = youcangetnoinfoHOMсоД9ж.getHeight();
/* 143 */     float f1 = UIScale.scale(1.0F);
/* 144 */     float f2 = f1;
/* 145 */     float f3 = f1 * 3.0F;
/* 146 */     Object youcangetnoinfoHOSж4тНъ = ((FlatTableHeaderUI)this).header.getColumnModel();
/* 147 */     int k = youcangetnoinfoHOSж4тНъ.getColumnCount();
/*     */     
/* 149 */     Object youcangetnoinfoHOUЩАбЛл = youcangetnoinfoHOLиэЗтГ.create();
/*     */     try {
/* 151 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoHOUЩАбЛл);
/*     */ 
/*     */       
/* 154 */       youcangetnoinfoHOUЩАбЛл.setColor(((FlatTableHeaderUI)super).bottomSeparatorColor);
/* 155 */       youcangetnoinfoHOUЩАбЛл.fill(new Rectangle2D.Float(0.0F, j - f1, i, f1));
/*     */ 
/*     */       
/* 158 */       youcangetnoinfoHOUЩАбЛл.setColor(((FlatTableHeaderUI)super).separatorColor);
/*     */       
/* 160 */       int m = k;
/* 161 */       if (((FlatTableHeaderUI)this).header.getTable().getAutoResizeMode() != 0 && !super.isVerticalScrollBarVisible()) {
/* 162 */         m--;
/*     */       }
/* 164 */       if (((FlatTableHeaderUI)this).header.getComponentOrientation().isLeftToRight()) {
/* 165 */         int n = 0;
/* 166 */         for (byte b = 0; b < m; b++) {
/* 167 */           n += youcangetnoinfoHOSж4тНъ.getColumn(b).getWidth();
/* 168 */           youcangetnoinfoHOUЩАбЛл.fill(new Rectangle2D.Float(n - f1, f2, f1, j - f3));
/*     */         } 
/*     */       } else {
/* 171 */         int n = i;
/* 172 */         for (byte b = 0; b < m; b++) {
/* 173 */           n -= youcangetnoinfoHOSж4тНъ.getColumn(b).getWidth();
/* 174 */           youcangetnoinfoHOUЩАбЛл.fill(new Rectangle2D.Float(n - ((b < m - 1) ? f1 : 0.0F), f2, f1, j - f3));
/*     */         } 
/*     */       } 
/*     */     } finally {
/*     */       
/* 179 */       youcangetnoinfoHOUЩАбЛл.dispose();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintDraggedColumnBorders(Object youcangetnoinfoENLPхёАЮЗ, Object youcangetnoinfoENLQПн98У) {
/* 184 */     Object youcangetnoinfoENLRвиьРь = ((FlatTableHeaderUI)this).header.getDraggedColumn();
/* 185 */     if (youcangetnoinfoENLRвиьРь == null) {
/*     */       return;
/*     */     }
/*     */     
/* 189 */     Object youcangetnoinfoENLSЧжС0Ю = ((FlatTableHeaderUI)this).header.getColumnModel();
/* 190 */     int i = youcangetnoinfoENLSЧжС0Ю.getColumnCount();
/* 191 */     byte b = -1;
/* 192 */     for (byte b1 = 0; b1 < i; b1++) {
/* 193 */       if (youcangetnoinfoENLSЧжС0Ю.getColumn(b1) == youcangetnoinfoENLRвиьРь) {
/* 194 */         b = b1;
/*     */         
/*     */         break;
/*     */       } 
/*     */     } 
/* 199 */     if (b < 0) {
/*     */       return;
/*     */     }
/* 202 */     float f1 = UIScale.scale(1.0F);
/* 203 */     float f2 = f1;
/* 204 */     float f3 = f1 * 3.0F;
/* 205 */     Object youcangetnoinfoENLYощьЮк = ((FlatTableHeaderUI)this).header.getHeaderRect(b);
/* 206 */     ((Rectangle)youcangetnoinfoENLYощьЮк).x += ((FlatTableHeaderUI)this).header.getDraggedDistance();
/*     */     
/* 208 */     Object youcangetnoinfoENLZРюьуф = youcangetnoinfoENLPхёАЮЗ.create();
/*     */     try {
/* 210 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoENLZРюьуф);
/*     */ 
/*     */       
/* 213 */       youcangetnoinfoENLZРюьуф.setColor(((FlatTableHeaderUI)super).bottomSeparatorColor);
/* 214 */       youcangetnoinfoENLZРюьуф.fill(new Rectangle2D.Float(((Rectangle)youcangetnoinfoENLYощьЮк).x, (((Rectangle)youcangetnoinfoENLYощьЮк).y + ((Rectangle)youcangetnoinfoENLYощьЮк).height) - f1, ((Rectangle)youcangetnoinfoENLYощьЮк).width, f1));
/*     */ 
/*     */       
/* 217 */       youcangetnoinfoENLZРюьуф.setColor(((FlatTableHeaderUI)super).separatorColor);
/* 218 */       youcangetnoinfoENLZРюьуф.fill(new Rectangle2D.Float(((Rectangle)youcangetnoinfoENLYощьЮк).x, f2, f1, ((Rectangle)youcangetnoinfoENLYощьЮк).height - f3));
/* 219 */       youcangetnoinfoENLZРюьуф.fill(new Rectangle2D.Float((((Rectangle)youcangetnoinfoENLYощьЮк).x + ((Rectangle)youcangetnoinfoENLYощьЮк).width) - f1, ((Rectangle)youcangetnoinfoENLYощьЮк).y + f2, f1, ((Rectangle)youcangetnoinfoENLYощьЮк).height - f3));
/*     */     } finally {
/* 221 */       youcangetnoinfoENLZРюьуф.dispose();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoCDUYеТФя8) {
/* 227 */     Object youcangetnoinfoCDUZпрДбд = super.getPreferredSize((JComponent)youcangetnoinfoCDUYеТФя8);
/* 228 */     if (((Dimension)youcangetnoinfoCDUZпрДбд).height > 0)
/* 229 */       ((Dimension)youcangetnoinfoCDUZпрДбд).height = Math.max(((Dimension)youcangetnoinfoCDUZпрДбд).height, UIScale.scale(((FlatTableHeaderUI)super).height)); 
/* 230 */     return (Dimension)youcangetnoinfoCDUZпрДбд;
/*     */   }
/*     */   
/*     */   public boolean isVerticalScrollBarVisible() {
/* 234 */     Object youcangetnoinfoCIDвЕЮЩл = super.getScrollPane();
/* 235 */     return (youcangetnoinfoCIDвЕЮЩл != null && youcangetnoinfoCIDвЕЮЩл.getVerticalScrollBar() != null) ? 
/* 236 */       youcangetnoinfoCIDвЕЮЩл.getVerticalScrollBar().isVisible() : false;
/*     */   }
/*     */ 
/*     */   
/*     */   public JScrollPane getScrollPane() {
/* 241 */     Object youcangetnoinfoDCKIхzе0ю = ((FlatTableHeaderUI)this).header.getParent();
/* 242 */     if (youcangetnoinfoDCKIхzе0ю == null) {
/* 243 */       return null;
/*     */     }
/* 245 */     youcangetnoinfoDCKIхzе0ю = youcangetnoinfoDCKIхzе0ю.getParent();
/* 246 */     return (youcangetnoinfoDCKIхzе0ю instanceof JScrollPane) ? (JScrollPane)youcangetnoinfoDCKIхzе0ю : null;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTableHeaderUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */