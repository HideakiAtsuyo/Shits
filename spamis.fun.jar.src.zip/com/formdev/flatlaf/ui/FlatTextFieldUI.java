/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTextFieldUI;
/*     */ import javax.swing.text.Caret;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTextFieldUI
/*     */   extends BasicTextFieldUI
/*     */ {
/*     */   public int focusWidth;
/*     */   public boolean isIntelliJTheme;
/*     */   public Color placeholderForeground;
/*     */   public int arc;
/*     */   public FocusListener focusListener;
/*     */   public int minimumWidth;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoAGDCыХЦпс) {
/*  84 */     return new FlatTextFieldUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  89 */     super.installDefaults();
/*     */     
/*  91 */     Object youcangetnoinfoIHAКфхЫЪ = getPropertyPrefix();
/*  92 */     ((FlatTextFieldUI)super).arc = UIManager.getInt("TextComponent.arc");
/*  93 */     ((FlatTextFieldUI)super).focusWidth = UIManager.getInt("Component.focusWidth");
/*  94 */     ((FlatTextFieldUI)super).minimumWidth = UIManager.getInt("Component.minimumWidth");
/*  95 */     ((FlatTextFieldUI)super).isIntelliJTheme = UIManager.getBoolean("Component.isIntelliJTheme");
/*  96 */     ((FlatTextFieldUI)super).placeholderForeground = UIManager.getColor(youcangetnoinfoIHAКфхЫЪ + ".placeholderForeground");
/*     */     
/*  98 */     LookAndFeel.installProperty(getComponent(), "opaque", Boolean.valueOf((((FlatTextFieldUI)super).focusWidth == 0)));
/*     */     
/* 100 */     MigLayoutVisualPadding.install(getComponent(), ((FlatTextFieldUI)super).focusWidth);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/* 105 */     super.uninstallDefaults();
/*     */     
/* 107 */     ((FlatTextFieldUI)super).placeholderForeground = null;
/*     */     
/* 109 */     MigLayoutVisualPadding.uninstall(getComponent());
/*     */   }
/*     */ 
/*     */   
/*     */   public void installListeners() {
/* 114 */     super.installListeners();
/*     */     
/* 116 */     ((FlatTextFieldUI)super).focusListener = new FlatUIUtils$RepaintFocusListener(getComponent());
/* 117 */     getComponent().addFocusListener(((FlatTextFieldUI)super).focusListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners() {
/* 122 */     super.uninstallListeners();
/*     */     
/* 124 */     getComponent().removeFocusListener(((FlatTextFieldUI)super).focusListener);
/* 125 */     ((FlatTextFieldUI)super).focusListener = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Caret createCaret() {
/* 130 */     return new FlatCaret(UIManager.getString("TextComponent.selectAllOnFocusPolicy"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(Object youcangetnoinfoDZAрёЫ8М) {
/* 135 */     super.propertyChange((PropertyChangeEvent)youcangetnoinfoDZAрёЫ8М);
/*     */     
/* 137 */     if ("JTextField.placeholderText".equals(youcangetnoinfoDZAрёЫ8М.getPropertyName())) {
/* 138 */       getComponent().repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   public void paintSafely(Object youcangetnoinfoDZCVЯЖВсе) {
/* 143 */     paintBackground((Graphics)youcangetnoinfoDZCVЯЖВсе, getComponent(), ((FlatTextFieldUI)super).focusWidth, ((FlatTextFieldUI)super).arc, ((FlatTextFieldUI)super).isIntelliJTheme);
/* 144 */     paintPlaceholder((Graphics)youcangetnoinfoDZCVЯЖВсе, getComponent(), ((FlatTextFieldUI)super).placeholderForeground);
/* 145 */     super.paintSafely((Graphics)youcangetnoinfoDZCVЯЖВсе);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoEIGIЮ1РхК) {}
/*     */ 
/*     */   
/*     */   public static void paintBackground(Object youcangetnoinfoVSKЕЕНУ4, Object youcangetnoinfoVSLёаПеЦ, Object youcangetnoinfoVSM2омё8, Object youcangetnoinfoVSNсТпБЧ, Object youcangetnoinfoVSO1Рбсл) {
/* 154 */     Object youcangetnoinfoVSPщЁч1в = youcangetnoinfoVSLёаПеЦ.getBorder();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (!youcangetnoinfoVSLёаПеЦ.isOpaque() && !(youcangetnoinfoVSPщЁч1в instanceof FlatBorder) && FlatUIUtils.hasOpaqueBeenExplicitlySet((JComponent)youcangetnoinfoVSLёаПеЦ)) {
/*     */       return;
/*     */     }
/*     */     
/* 165 */     if (youcangetnoinfoVSLёаПеЦ.isOpaque() && youcangetnoinfoVSM2омё8 > null) {
/* 166 */       FlatUIUtils.paintParentBackground((Graphics)youcangetnoinfoVSKЕЕНУ4, (JComponent)youcangetnoinfoVSLёаПеЦ);
/*     */     }
/*     */     
/* 169 */     Object youcangetnoinfoVSQЭпИЙЖ = youcangetnoinfoVSKЕЕНУ4.create();
/*     */     try {
/* 171 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoVSQЭпИЙЖ);
/*     */       
/* 173 */       float f1 = (youcangetnoinfoVSPщЁч1в instanceof FlatBorder) ? UIScale.scale(youcangetnoinfoVSM2омё8) : 0.0F;
/* 174 */       float f2 = (youcangetnoinfoVSPщЁч1в instanceof FlatTextBorder) ? UIScale.scale(youcangetnoinfoVSNсТпБЧ) : 0.0F;
/*     */       
/* 176 */       Object youcangetnoinfoVSJавмЮЁ = youcangetnoinfoVSLёаПеЦ.getBackground();
/* 177 */       youcangetnoinfoVSQЭпИЙЖ.setColor(!(youcangetnoinfoVSJавмЮЁ instanceof javax.swing.plaf.UIResource) ? 
/* 178 */           (Color)youcangetnoinfoVSJавмЮЁ : (
/* 179 */           (youcangetnoinfoVSO1Рбсл != null && (!youcangetnoinfoVSLёаПеЦ.isEnabled() || !youcangetnoinfoVSLёаПеЦ.isEditable())) ? 
/* 180 */           FlatUIUtils.getParentBackground((JComponent)youcangetnoinfoVSLёаПеЦ) : 
/* 181 */           (Color)youcangetnoinfoVSJавмЮЁ));
/* 182 */       FlatUIUtils.paintComponentBackground((Graphics2D)youcangetnoinfoVSQЭпИЙЖ, 0, 0, youcangetnoinfoVSLёаПеЦ.getWidth(), youcangetnoinfoVSLёаПеЦ.getHeight(), f1, f2);
/*     */     } finally {
/* 184 */       youcangetnoinfoVSQЭпИЙЖ.dispose();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void paintPlaceholder(Object youcangetnoinfoAUBB0ЪКнп, Object youcangetnoinfoAUBCедсюе, Object youcangetnoinfoAUBDЫъйБО) {
/* 190 */     if (youcangetnoinfoAUBCедсюе.getDocument().getLength() > 0) {
/*     */       return;
/*     */     }
/*     */     
/* 194 */     Object youcangetnoinfoAUBEЛЕибВ = youcangetnoinfoAUBCедсюе.getParent();
/* 195 */     Object youcangetnoinfoAUBFап1ьд = (youcangetnoinfoAUBEЛЕибВ instanceof javax.swing.JComboBox) ? youcangetnoinfoAUBEЛЕибВ : youcangetnoinfoAUBCедсюе;
/*     */ 
/*     */     
/* 198 */     Object youcangetnoinfoAUBGТГйщ1 = youcangetnoinfoAUBFап1ьд.getClientProperty("JTextField.placeholderText");
/* 199 */     if (!(youcangetnoinfoAUBGТГйщ1 instanceof String)) {
/*     */       return;
/*     */     }
/*     */     
/* 203 */     Object youcangetnoinfoAUBH2еЛЭЁ = youcangetnoinfoAUBCедсюе.getInsets();
/* 204 */     Object youcangetnoinfoAUBIрСИа9 = youcangetnoinfoAUBCедсюе.getFontMetrics(youcangetnoinfoAUBCедсюе.getFont());
/* 205 */     int i = ((Insets)youcangetnoinfoAUBH2еЛЭЁ).left;
/* 206 */     int j = ((Insets)youcangetnoinfoAUBH2еЛЭЁ).top + youcangetnoinfoAUBIрСИа9.getAscent() + (youcangetnoinfoAUBCедсюе.getHeight() - ((Insets)youcangetnoinfoAUBH2еЛЭЁ).top - ((Insets)youcangetnoinfoAUBH2еЛЭЁ).bottom - youcangetnoinfoAUBIрСИа9.getHeight()) / 2;
/*     */ 
/*     */     
/* 209 */     youcangetnoinfoAUBB0ЪКнп.setColor((Color)youcangetnoinfoAUBDЫъйБО);
/* 210 */     FlatUIUtils.drawString((JComponent)youcangetnoinfoAUBCедсюе, (Graphics)youcangetnoinfoAUBB0ЪКнп, (String)youcangetnoinfoAUBGТГйщ1, i, j);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoLCZУфСОО) {
/* 215 */     return super.applyMinimumWidth(super.getPreferredSize((JComponent)youcangetnoinfoLCZУфСОО), (JComponent)youcangetnoinfoLCZУфСОО);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(Object youcangetnoinfoBJYPКчБшЬ) {
/* 220 */     return super.applyMinimumWidth(super.getMinimumSize((JComponent)youcangetnoinfoBJYPКчБшЬ), (JComponent)youcangetnoinfoBJYPКчБшЬ);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension applyMinimumWidth(Object youcangetnoinfoAFGCпюниф, Object youcangetnoinfoAFGDТблоБ) {
/* 225 */     if (youcangetnoinfoAFGDТблоБ instanceof JTextField && ((JTextField)youcangetnoinfoAFGDТблоБ).getColumns() > 0) {
/* 226 */       return (Dimension)youcangetnoinfoAFGCпюниф;
/*     */     }
/* 228 */     Object youcangetnoinfoAFGEиО34Ж = youcangetnoinfoAFGDТблоБ.getParent();
/* 229 */     if (youcangetnoinfoAFGEиО34Ж instanceof javax.swing.JComboBox || youcangetnoinfoAFGEиО34Ж instanceof javax.swing.JSpinner || (youcangetnoinfoAFGEиО34Ж != null && youcangetnoinfoAFGEиО34Ж
/*     */       
/* 231 */       .getParent() instanceof javax.swing.JSpinner)) {
/* 232 */       return (Dimension)youcangetnoinfoAFGCпюниф;
/*     */     }
/* 234 */     int i = FlatUIUtils.minimumWidth(getComponent(), ((FlatTextFieldUI)super).minimumWidth);
/* 235 */     byte b = (youcangetnoinfoAFGDТблоБ.getBorder() instanceof FlatBorder) ? ((FlatTextFieldUI)super).focusWidth : 0;
/* 236 */     ((Dimension)youcangetnoinfoAFGCпюниф).width = Math.max(((Dimension)youcangetnoinfoAFGCпюниф).width, UIScale.scale(i + b * 2));
/* 237 */     return (Dimension)youcangetnoinfoAFGCпюниф;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTextFieldUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */