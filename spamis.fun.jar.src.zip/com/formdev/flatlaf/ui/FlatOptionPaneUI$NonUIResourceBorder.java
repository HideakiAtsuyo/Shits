/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.border.Border;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatOptionPaneUI$NonUIResourceBorder
/*     */   implements Border
/*     */ {
/*     */   public final Border delegate;
/*     */   
/*     */   public FlatOptionPaneUI$NonUIResourceBorder(Object youcangetnoinfoAVXKащЙлЬ) {
/* 207 */     this();
/* 208 */     ((FlatOptionPaneUI$NonUIResourceBorder)super).delegate = (Border)youcangetnoinfoAVXKащЙлЬ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBorder(Object youcangetnoinfoCEZVЪЪдКд, Object youcangetnoinfoCEZWЯё4мв, Object youcangetnoinfoCEZXюБ5уЬ, Object youcangetnoinfoCEZYЮ5УыЯ, Object youcangetnoinfoCEZZ9ОЦРК, Object youcangetnoinfoCFAAНПгжФ) {
/* 213 */     ((FlatOptionPaneUI$NonUIResourceBorder)super).delegate.paintBorder((Component)youcangetnoinfoCEZVЪЪдКд, (Graphics)youcangetnoinfoCEZWЯё4мв, youcangetnoinfoCEZXюБ5уЬ, youcangetnoinfoCEZYЮ5УыЯ, youcangetnoinfoCEZZ9ОЦРК, youcangetnoinfoCFAAНПгжФ);
/*     */   }
/*     */ 
/*     */   
/*     */   public Insets getBorderInsets(Object youcangetnoinfoRETЦЪфЩЮ) {
/* 218 */     return ((FlatOptionPaneUI$NonUIResourceBorder)super).delegate.getBorderInsets((Component)youcangetnoinfoRETЦЪфЩЮ);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isBorderOpaque() {
/* 223 */     return ((FlatOptionPaneUI$NonUIResourceBorder)super).delegate.isBorderOpaque();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatOptionPaneUI$NonUIResourceBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */