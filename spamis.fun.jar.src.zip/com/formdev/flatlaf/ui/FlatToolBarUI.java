/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import java.awt.Insets;
/*    */ import java.awt.event.ContainerListener;
/*    */ import javax.swing.border.Border;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicToolBarUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatToolBarUI
/*    */   extends BasicToolBarUI
/*    */ {
/*    */   public static ComponentUI createUI(Object youcangetnoinfoAYXZяугиб) {
/* 50 */     return new FlatToolBarUI();
/*    */   }
/*    */ 
/*    */   
/*    */   public ContainerListener createToolBarContListener() {
/* 55 */     return new FlatToolBarUI$1((FlatToolBarUI)this);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBorderToRollover(Object youcangetnoinfoANEJюа7ГН) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBorderToNonRollover(Object youcangetnoinfoEGQHЙМхНЫ) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void setBorderToNormal(Object youcangetnoinfoBFDL25ЪвИ) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void installRolloverBorders(Object youcangetnoinfoBLXGёбгЩУ) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public void installNonRolloverBorders(Object youcangetnoinfoEIMJШЦ8жш) {}
/*    */ 
/*    */   
/*    */   public void installNormalBorders(Object youcangetnoinfoCLVNЁщШЪ3) {}
/*    */ 
/*    */   
/*    */   public Border createRolloverBorder() {
/* 83 */     return null; } public Border createNonRolloverBorder() {
/* 84 */     return null;
/*    */   }
/*    */   
/*    */   public void setOrientation(Object youcangetnoinfoDXZXо82уВ) {
/* 88 */     if (youcangetnoinfoDXZXо82уВ != ((FlatToolBarUI)this).toolBar.getOrientation()) {
/*    */       
/* 90 */       Object youcangetnoinfoDXZUАкГеz = ((FlatToolBarUI)this).toolBar.getMargin();
/* 91 */       Object youcangetnoinfoDXZVУвцуЙ = new Insets(((Insets)youcangetnoinfoDXZUАкГеz).left, ((Insets)youcangetnoinfoDXZUАкГеz).top, ((Insets)youcangetnoinfoDXZUАкГеz).right, ((Insets)youcangetnoinfoDXZUАкГеz).bottom);
/* 92 */       if (!youcangetnoinfoDXZVУвцуЙ.equals(youcangetnoinfoDXZUАкГеz)) {
/* 93 */         ((FlatToolBarUI)this).toolBar.setMargin((Insets)youcangetnoinfoDXZVУвцуЙ);
/*    */       }
/*    */     } 
/* 96 */     super.setOrientation(youcangetnoinfoDXZXо82уВ);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatToolBarUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */