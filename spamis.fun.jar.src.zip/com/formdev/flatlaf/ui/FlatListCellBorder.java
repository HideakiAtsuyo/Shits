/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatListCellBorder
/*    */   extends FlatLineBorder
/*    */ {
/*    */   public final boolean showCellFocusIndicator;
/*    */   
/*    */   public FlatListCellBorder() {
/* 39 */     super(UIManager.getInsets("List.cellMargins"), UIManager.getColor("List.cellFocusColor"));
/*    */     ((FlatListCellBorder)super).showCellFocusIndicator = UIManager.getBoolean("List.showCellFocusIndicator");
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatListCellBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */