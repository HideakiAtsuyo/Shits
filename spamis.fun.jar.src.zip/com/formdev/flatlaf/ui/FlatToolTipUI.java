/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.StringUtils;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToolTip;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicToolTipUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatToolTipUI
/*     */   extends BasicToolTipUI
/*     */ {
/*     */   public static PropertyChangeListener sharedPropertyChangedListener;
/*     */   public static ComponentUI instance;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoCBEJх9жПЧ) {
/*  56 */     if (instance == null)
/*  57 */       instance = new FlatToolTipUI(); 
/*  58 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installUI(Object youcangetnoinfoEERAФцьЙъ) {
/*  63 */     super.installUI((JComponent)youcangetnoinfoEERAФцьЙъ);
/*     */ 
/*     */     
/*  66 */     FlatLabelUI.updateHTMLRenderer((JComponent)youcangetnoinfoEERAФцьЙъ, ((JToolTip)youcangetnoinfoEERAФцьЙъ).getTipText(), false);
/*     */   }
/*     */   
/*     */   public void installListeners(Object youcangetnoinfoDEQQэОкМд)
/*     */   {
/*  71 */     super.installListeners((JComponent)youcangetnoinfoDEQQэОкМд);
/*     */     
/*  73 */     if (sharedPropertyChangedListener == null) {
/*  74 */       sharedPropertyChangedListener = FlatToolTipUI::lambda$installListeners$0;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     youcangetnoinfoDEQQэОкМд.addPropertyChangeListener(sharedPropertyChangedListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners(Object youcangetnoinfoDEBЖТКтМ) {
/*  88 */     super.uninstallListeners((JComponent)youcangetnoinfoDEBЖТКтМ);
/*     */     
/*  90 */     youcangetnoinfoDEBЖТКтМ.removePropertyChangeListener(sharedPropertyChangedListener); }
/*     */   public static void lambda$installListeners$0(Object youcangetnoinfoBMUXШэОЯР) { Object youcangetnoinfoBMUYтгз2Я = youcangetnoinfoBMUXШэОЯР.getPropertyName();
/*     */     if (youcangetnoinfoBMUYтгз2Я == "text" || youcangetnoinfoBMUYтгз2Я == "font" || youcangetnoinfoBMUYтгз2Я == "foreground") {
/*     */       Object youcangetnoinfoBMUWъЦ8Ин = youcangetnoinfoBMUXШэОЯР.getSource();
/*     */       FlatLabelUI.updateHTMLRenderer((JComponent)youcangetnoinfoBMUWъЦ8Ин, youcangetnoinfoBMUWъЦ8Ин.getTipText(), false);
/*  95 */     }  } public Dimension getPreferredSize(Object youcangetnoinfoADXJ018ы8) { if (super.isMultiLine((JComponent)youcangetnoinfoADXJ018ы8)) {
/*  96 */       Object youcangetnoinfoADXDХьИрИ = youcangetnoinfoADXJ018ы8.getFontMetrics(youcangetnoinfoADXJ018ы8.getFont());
/*  97 */       Object youcangetnoinfoADXEфаЧХр = youcangetnoinfoADXJ018ы8.getInsets();
/*     */       
/*  99 */       Object youcangetnoinfoADXF2кзЛв = StringUtils.split(((JToolTip)youcangetnoinfoADXJ018ы8).getTipText(), '\n');
/* 100 */       int i = 0;
/* 101 */       int j = youcangetnoinfoADXDХьИрИ.getHeight() * Math.max(youcangetnoinfoADXF2кзЛв.size(), 1);
/* 102 */       for (Object youcangetnoinfoADXC0тГЮ9 : youcangetnoinfoADXF2кзЛв) {
/* 103 */         i = Math.max(i, SwingUtilities.computeStringWidth((FontMetrics)youcangetnoinfoADXDХьИрИ, (String)youcangetnoinfoADXC0тГЮ9));
/*     */       }
/* 105 */       return new Dimension(((Insets)youcangetnoinfoADXEфаЧХр).left + i + ((Insets)youcangetnoinfoADXEфаЧХр).right, ((Insets)youcangetnoinfoADXEфаЧХр).top + j + ((Insets)youcangetnoinfoADXEфаЧХр).bottom);
/*     */     } 
/* 107 */     return super.getPreferredSize((JComponent)youcangetnoinfoADXJ018ы8); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paint(Object youcangetnoinfoOXBИъеа9, Object youcangetnoinfoOXCчянщя) {
/* 112 */     if (super.isMultiLine((JComponent)youcangetnoinfoOXCчянщя)) {
/* 113 */       Object youcangetnoinfoOWRЫпчхС = youcangetnoinfoOXCчянщя.getFontMetrics(youcangetnoinfoOXCчянщя.getFont());
/* 114 */       Object youcangetnoinfoOWSьШ8кЯ = youcangetnoinfoOXCчянщя.getInsets();
/*     */       
/* 116 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoOXBИъеа9);
/* 117 */       youcangetnoinfoOXBИъеа9.setColor(youcangetnoinfoOXCчянщя.getForeground());
/*     */       
/* 119 */       Object youcangetnoinfoOWTИнцЫц = StringUtils.split(((JToolTip)youcangetnoinfoOXCчянщя).getTipText(), '\n');
/*     */       
/* 121 */       int i = ((Insets)youcangetnoinfoOWSьШ8кЯ).left;
/* 122 */       int j = youcangetnoinfoOXCчянщя.getWidth() - ((Insets)youcangetnoinfoOWSьШ8кЯ).right;
/* 123 */       int k = ((Insets)youcangetnoinfoOWSьШ8кЯ).top - youcangetnoinfoOWRЫпчхС.getDescent();
/* 124 */       int m = youcangetnoinfoOWRЫпчхС.getHeight();
/* 125 */       Object youcangetnoinfoOWYыДцдй = ((JToolTip)youcangetnoinfoOXCчянщя).getComponent();
/* 126 */       boolean bool = ((youcangetnoinfoOWYыДцдй != null) ? youcangetnoinfoOWYыДцдй : youcangetnoinfoOXCчянщя).getComponentOrientation().isLeftToRight();
/* 127 */       for (Object youcangetnoinfoOWQЪПzяш : youcangetnoinfoOWTИнцЫц) {
/* 128 */         k += m;
/* 129 */         FlatUIUtils.drawString((JComponent)youcangetnoinfoOXCчянщя, (Graphics)youcangetnoinfoOXBИъеа9, (String)youcangetnoinfoOWQЪПzяш, bool ? i : (j - SwingUtilities.computeStringWidth((FontMetrics)youcangetnoinfoOWRЫпчхС, (String)youcangetnoinfoOWQЪПzяш)), k);
/*     */       } 
/*     */     } else {
/* 132 */       super.paint((Graphics)youcangetnoinfoOXBИъеа9, (JComponent)youcangetnoinfoOXCчянщя);
/*     */     } 
/*     */   }
/*     */   public boolean isMultiLine(Object youcangetnoinfoEEEYыМАд3) {
/* 136 */     Object youcangetnoinfoEEEZЗЧНОА = ((JToolTip)youcangetnoinfoEEEYыМАд3).getTipText();
/* 137 */     return (youcangetnoinfoEEEYыМАд3.getClientProperty("html") == null && youcangetnoinfoEEEZЗЧНОА != null && youcangetnoinfoEEEZЗЧНОА.indexOf('\n') >= 0);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatToolTipUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */