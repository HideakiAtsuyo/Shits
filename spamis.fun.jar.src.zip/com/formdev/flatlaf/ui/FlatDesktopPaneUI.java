/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicDesktopPaneUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatDesktopPaneUI
/*    */   extends BasicDesktopPaneUI
/*    */ {
/*    */   public static ComponentUI createUI(Object youcangetnoinfoCAEZпО1щв) {
/* 40 */     return new FlatDesktopPaneUI();
/*    */   }
/*    */ 
/*    */   
/*    */   public void installDesktopManager() {
/* 45 */     ((FlatDesktopPaneUI)this).desktopManager = ((FlatDesktopPaneUI)this).desktop.getDesktopManager();
/* 46 */     if (((FlatDesktopPaneUI)this).desktopManager == null) {
/* 47 */       ((FlatDesktopPaneUI)this).desktopManager = new FlatDesktopPaneUI$FlatDesktopManager((FlatDesktopPaneUI)this, null);
/* 48 */       ((FlatDesktopPaneUI)this).desktop.setDesktopManager(((FlatDesktopPaneUI)this).desktopManager);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatDesktopPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */