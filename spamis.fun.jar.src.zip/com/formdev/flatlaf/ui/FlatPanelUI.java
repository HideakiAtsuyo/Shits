/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicPanelUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatPanelUI
/*    */   extends BasicPanelUI
/*    */ {
/*    */   public static ComponentUI instance;
/*    */   
/*    */   public static ComponentUI createUI(Object youcangetnoinfoDMTRеРфпь) {
/* 41 */     if (instance == null)
/* 42 */       instance = new FlatPanelUI(); 
/* 43 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatPanelUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */