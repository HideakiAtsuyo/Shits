/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Rectangle;
/*    */ import java.beans.PropertyChangeEvent;
/*    */ import java.beans.PropertyChangeListener;
/*    */ import javax.swing.JMenuItem;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicCheckBoxMenuItemUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatCheckBoxMenuItemUI
/*    */   extends BasicCheckBoxMenuItemUI
/*    */ {
/*    */   public static ComponentUI createUI(Object youcangetnoinfoVZWЛРкРМ) {
/* 57 */     return new FlatCheckBoxMenuItemUI();
/*    */   }
/*    */ 
/*    */   
/*    */   public void installDefaults() {
/* 62 */     super.installDefaults();
/*    */ 
/*    */     
/* 65 */     ((FlatCheckBoxMenuItemUI)this).defaultTextIconGap = UIScale.scale(((FlatCheckBoxMenuItemUI)this).defaultTextIconGap);
/*    */   }
/*    */ 
/*    */   
/*    */   public PropertyChangeListener createPropertyChangeListener(Object youcangetnoinfoECJQВАлРв) {
/*    */     // Byte code:
/*    */     //   0: aload_0
/*    */     //   1: aload_1
/*    */     //   2: invokespecial createPropertyChangeListener : (Ljavax/swing/JComponent;)Ljava/beans/PropertyChangeListener;
/*    */     //   5: astore_2
/*    */     //   6: aload_0
/*    */     //   7: aload_2
/*    */     //   8: <illegal opcode> propertyChange : (Lcom/formdev/flatlaf/ui/FlatCheckBoxMenuItemUI;Ljava/beans/PropertyChangeListener;)Ljava/beans/PropertyChangeListener;
/*    */     //   13: areturn
/*    */     // Line number table:
/*    */     //   Java source line number -> byte code offset
/*    */     //   #73	-> 0
/*    */     //   #74	-> 6
/*    */     // Local variable table:
/*    */     //   start	length	slot	name	descriptor
/*    */     //   6	8	2	youcangetnoinfoECJRЧъ3БП	Ljava/lang/Object;
/*    */     //   0	14	0	youcangetnoinfoECJPн3леп	Ljava/lang/Object;
/*    */     //   0	14	1	youcangetnoinfoECJQВАлРв	Ljava/lang/Object;
/*    */   }
/*    */ 
/*    */   
/*    */   public void lambda$createPropertyChangeListener$0(Object youcangetnoinfoDOTHВzухш, Object youcangetnoinfoDOTIжМмещ) {
/* 75 */     youcangetnoinfoDOTHВzухш.propertyChange((PropertyChangeEvent)youcangetnoinfoDOTIжМмещ);
/* 76 */     if (youcangetnoinfoDOTIжМмещ.getPropertyName() == "iconTextGap") {
/* 77 */       ((FlatCheckBoxMenuItemUI)this).defaultTextIconGap = UIScale.scale(((FlatCheckBoxMenuItemUI)this).defaultTextIconGap);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintText(Object youcangetnoinfoDGLTюz1эЬ, Object youcangetnoinfoDGLUфд6ПР, Object youcangetnoinfoDGLVамеъо, Object youcangetnoinfoDGLWъюzЗЗ) {
/* 83 */     FlatMenuItemUI.paintText((Graphics)youcangetnoinfoDGLTюz1эЬ, (JMenuItem)youcangetnoinfoDGLUфд6ПР, (Rectangle)youcangetnoinfoDGLVамеъо, (String)youcangetnoinfoDGLWъюzЗЗ, ((FlatCheckBoxMenuItemUI)this).disabledForeground, ((FlatCheckBoxMenuItemUI)this).selectionForeground);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatCheckBoxMenuItemUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */