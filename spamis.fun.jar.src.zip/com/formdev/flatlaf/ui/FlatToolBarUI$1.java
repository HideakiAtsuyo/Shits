/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import java.awt.event.ContainerEvent;
/*    */ import javax.swing.plaf.basic.BasicToolBarUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatToolBarUI$1
/*    */   extends BasicToolBarUI.ToolBarContListener
/*    */ {
/*    */   public final FlatToolBarUI this$0;
/*    */   
/*    */   public FlatToolBarUI$1() {
/* 55 */     super((BasicToolBarUI)youcangetnoinfoLBM8Кячч);
/*    */   }
/*    */   public void componentAdded(Object youcangetnoinfoAGFY3Б94Ц) {
/* 58 */     super.componentAdded((ContainerEvent)youcangetnoinfoAGFY3Б94Ц);
/*    */     
/* 60 */     Object youcangetnoinfoAGFZйгчьД = youcangetnoinfoAGFY3Б94Ц.getChild();
/* 61 */     if (youcangetnoinfoAGFZйгчьД instanceof javax.swing.AbstractButton) {
/* 62 */       youcangetnoinfoAGFZйгчьД.setFocusable(false);
/*    */     }
/*    */   }
/*    */   
/*    */   public void componentRemoved(Object youcangetnoinfoASQZнгСВж) {
/* 67 */     super.componentRemoved((ContainerEvent)youcangetnoinfoASQZнгСВж);
/*    */     
/* 69 */     Object youcangetnoinfoASRAОсТЯЬ = youcangetnoinfoASQZнгСВж.getChild();
/* 70 */     if (youcangetnoinfoASRAОсТЯЬ instanceof javax.swing.AbstractButton)
/* 71 */       youcangetnoinfoASRAОсТЯЬ.setFocusable(true); 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatToolBarUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */