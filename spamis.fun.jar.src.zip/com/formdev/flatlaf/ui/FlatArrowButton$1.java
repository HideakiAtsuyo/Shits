/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import java.awt.event.MouseAdapter;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatArrowButton$1
/*    */   extends MouseAdapter
/*    */ {
/*    */   public final FlatArrowButton this$0;
/*    */   
/*    */   public void mouseEntered(Object youcangetnoinfoCPEzёеАО) {
/* 73 */     FlatArrowButton.access$002(((FlatArrowButton$1)super).this$0, true);
/* 74 */     ((FlatArrowButton$1)super).this$0.repaint();
/*    */   }
/*    */ 
/*    */   
/*    */   public void mouseExited(Object youcangetnoinfoDAGFбЙ3З8) {
/* 79 */     FlatArrowButton.access$002(((FlatArrowButton$1)super).this$0, false);
/* 80 */     ((FlatArrowButton$1)super).this$0.repaint();
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatArrowButton$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */