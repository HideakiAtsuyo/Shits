/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Shape;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicSliderUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatSliderUI
/*     */   extends BasicSliderUI
/*     */ {
/*     */   public boolean hover;
/*     */   public MouseListener hoverListener;
/*     */   public int thumbWidth;
/*     */   public Color hoverColor;
/*     */   public Color disabledForeground;
/*     */   public Color trackColor;
/*     */   public int trackWidth;
/*     */   public Color thumbColor;
/*     */   public Color focusColor;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoATYCФ18рё) {
/*  77 */     return new FlatSliderUI();
/*     */   }
/*     */   
/*     */   public FlatSliderUI() {
/*  81 */     super(null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void installListeners(Object youcangetnoinfoDCJAКЯодх) {
/*  86 */     super.installListeners((JSlider)youcangetnoinfoDCJAКЯодх);
/*     */     
/*  88 */     ((FlatSliderUI)super).hoverListener = new FlatUIUtils$HoverListener((Component)youcangetnoinfoDCJAКЯодх, this::lambda$installListeners$0);
/*     */ 
/*     */     
/*  91 */     youcangetnoinfoDCJAКЯодх.addMouseListener(((FlatSliderUI)super).hoverListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners(Object youcangetnoinfoDHSGыФьБи) {
/*  96 */     super.uninstallListeners((JSlider)youcangetnoinfoDHSGыФьБи);
/*     */     
/*  98 */     youcangetnoinfoDHSGыФьБи.removeMouseListener(((FlatSliderUI)super).hoverListener);
/*  99 */     ((FlatSliderUI)super).hoverListener = null;
/*     */   } public void lambda$installListeners$0(Object youcangetnoinfoALXQВЧЩТв) {
/*     */     ((FlatSliderUI)super).hover = youcangetnoinfoALXQВЧЩТв.booleanValue();
/*     */   }
/*     */   public void installDefaults(Object youcangetnoinfoDURCоЩцЬш) {
/* 104 */     super.installDefaults((JSlider)youcangetnoinfoDURCоЩцЬш);
/*     */     
/* 106 */     LookAndFeel.installProperty((JComponent)youcangetnoinfoDURCоЩцЬш, "opaque", Boolean.valueOf(false));
/*     */     
/* 108 */     ((FlatSliderUI)super).trackWidth = UIManager.getInt("Slider.trackWidth");
/* 109 */     ((FlatSliderUI)super).thumbWidth = UIManager.getInt("Slider.thumbWidth");
/*     */     
/* 111 */     ((FlatSliderUI)super).trackColor = UIManager.getColor("Slider.trackColor");
/* 112 */     ((FlatSliderUI)super).thumbColor = UIManager.getColor("Slider.thumbColor");
/* 113 */     ((FlatSliderUI)super).focusColor = FlatUIUtils.getUIColor("Slider.focusedColor", "Component.focusColor");
/* 114 */     ((FlatSliderUI)super).hoverColor = FlatUIUtils.getUIColor("Slider.hoverColor", ((FlatSliderUI)super).focusColor);
/* 115 */     ((FlatSliderUI)super).disabledForeground = UIManager.getColor("Slider.disabledForeground");
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults(Object youcangetnoinfoEHIDьвмzх) {
/* 120 */     super.uninstallDefaults((JSlider)youcangetnoinfoEHIDьвмzх);
/*     */     
/* 122 */     ((FlatSliderUI)super).trackColor = null;
/* 123 */     ((FlatSliderUI)super).thumbColor = null;
/* 124 */     ((FlatSliderUI)super).focusColor = null;
/* 125 */     ((FlatSliderUI)super).hoverColor = null;
/* 126 */     ((FlatSliderUI)super).disabledForeground = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredHorizontalSize() {
/* 131 */     return UIScale.scale(super.getPreferredHorizontalSize());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredVerticalSize() {
/* 136 */     return UIScale.scale(super.getPreferredVerticalSize());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumHorizontalSize() {
/* 141 */     return UIScale.scale(super.getMinimumHorizontalSize());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumVerticalSize() {
/* 146 */     return UIScale.scale(super.getMinimumVerticalSize());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTickLength() {
/* 151 */     return UIScale.scale(super.getTickLength());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getThumbSize() {
/* 156 */     return new Dimension(UIScale.scale(((FlatSliderUI)super).thumbWidth), UIScale.scale(((FlatSliderUI)super).thumbWidth));
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Object youcangetnoinfoCSWKшИжзш, Object youcangetnoinfoCSWLЪбмЬЪ) {
/* 161 */     FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoCSWKшИжзш);
/*     */     
/* 163 */     super.paint((Graphics)youcangetnoinfoCSWKшИжзш, (JComponent)youcangetnoinfoCSWLЪбмЬЪ);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintFocus(Object youcangetnoinfoCTLOЩцФШz) {}
/*     */ 
/*     */   
/*     */   public void paintTrack(Object youcangetnoinfoBXBCпч2ЪЛ) {
/*     */     Object youcangetnoinfoBXBHРШ2ьи;
/* 173 */     boolean bool = ((FlatSliderUI)this).slider.isEnabled();
/* 174 */     float f1 = UIScale.scale(((FlatSliderUI)super).trackWidth);
/* 175 */     float f2 = f1;
/*     */     
/* 177 */     Object youcangetnoinfoBXBGрУ0юА = null;
/*     */     
/* 179 */     if (((FlatSliderUI)this).slider.getOrientation() == 0)
/* 180 */     { float f = ((FlatSliderUI)this).trackRect.y + (((FlatSliderUI)this).trackRect.height - f1) / 2.0F;
/* 181 */       if (bool && super.isRoundThumb()) {
/* 182 */         if (((FlatSliderUI)this).slider.getComponentOrientation().isLeftToRight()) {
/* 183 */           int i = ((FlatSliderUI)this).thumbRect.x + ((FlatSliderUI)this).thumbRect.width / 2 - ((FlatSliderUI)this).trackRect.x;
/* 184 */           youcangetnoinfoBXBGрУ0юА = new RoundRectangle2D.Float(((FlatSliderUI)this).trackRect.x, f, i, f1, f2, f2);
/* 185 */           Object youcangetnoinfoBXATфюГш1 = new RoundRectangle2D.Float((((FlatSliderUI)this).trackRect.x + i), f, (((FlatSliderUI)this).trackRect.width - i), f1, f2, f2);
/*     */         } else {
/* 187 */           int i = ((FlatSliderUI)this).trackRect.x + ((FlatSliderUI)this).trackRect.width - ((FlatSliderUI)this).thumbRect.x - ((FlatSliderUI)this).thumbRect.width / 2;
/* 188 */           youcangetnoinfoBXBGрУ0юА = new RoundRectangle2D.Float((((FlatSliderUI)this).trackRect.x + ((FlatSliderUI)this).trackRect.width - i), f, i, f1, f2, f2);
/* 189 */           Object youcangetnoinfoBXAVкмЪйШ = new RoundRectangle2D.Float(((FlatSliderUI)this).trackRect.x, f, (((FlatSliderUI)this).trackRect.width - i), f1, f2, f2);
/*     */         } 
/*     */       } else {
/* 192 */         Object youcangetnoinfoBXAX2ТЮщы = new RoundRectangle2D.Float(((FlatSliderUI)this).trackRect.x, f, ((FlatSliderUI)this).trackRect.width, f1, f2, f2);
/*     */       }  }
/* 194 */     else { float f = ((FlatSliderUI)this).trackRect.x + (((FlatSliderUI)this).trackRect.width - f1) / 2.0F;
/* 195 */       if (bool && super.isRoundThumb()) {
/* 196 */         int i = ((FlatSliderUI)this).thumbRect.y + ((FlatSliderUI)this).thumbRect.height / 2 - ((FlatSliderUI)this).trackRect.y;
/* 197 */         Object youcangetnoinfoBXAZДсЦТЦ = new RoundRectangle2D.Float(f, ((FlatSliderUI)this).trackRect.y, f1, i, f2, f2);
/* 198 */         youcangetnoinfoBXBGрУ0юА = new RoundRectangle2D.Float(f, (((FlatSliderUI)this).trackRect.y + i), f1, (((FlatSliderUI)this).trackRect.height - i), f2, f2);
/*     */       } else {
/* 200 */         youcangetnoinfoBXBHРШ2ьи = new RoundRectangle2D.Float(f, ((FlatSliderUI)this).trackRect.y, f1, ((FlatSliderUI)this).trackRect.height, f2, f2);
/*     */       }  }
/*     */     
/* 203 */     if (youcangetnoinfoBXBGрУ0юА != null) {
/* 204 */       FlatUIUtils.setColor((Graphics)youcangetnoinfoBXBCпч2ЪЛ, ((FlatSliderUI)this).slider.hasFocus() ? ((FlatSliderUI)super).focusColor : (((FlatSliderUI)super).hover ? ((FlatSliderUI)super).hoverColor : ((FlatSliderUI)super).thumbColor), ((FlatSliderUI)super).thumbColor);
/* 205 */       ((Graphics2D)youcangetnoinfoBXBCпч2ЪЛ).fill((Shape)youcangetnoinfoBXBGрУ0юА);
/*     */     } 
/*     */     
/* 208 */     youcangetnoinfoBXBCпч2ЪЛ.setColor(bool ? ((FlatSliderUI)super).trackColor : ((FlatSliderUI)super).disabledForeground);
/* 209 */     ((Graphics2D)youcangetnoinfoBXBCпч2ЪЛ).fill((Shape)youcangetnoinfoBXBHРШ2ьи);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintThumb(Object youcangetnoinfoBBQN7чКБй) {
/* 214 */     FlatUIUtils.setColor((Graphics)youcangetnoinfoBBQN7чКБй, ((FlatSliderUI)this).slider.isEnabled() ? (
/* 215 */         ((FlatSliderUI)this).slider.hasFocus() ? ((FlatSliderUI)super).focusColor : (((FlatSliderUI)super).hover ? ((FlatSliderUI)super).hoverColor : ((FlatSliderUI)super).thumbColor)) : 
/* 216 */         ((FlatSliderUI)super).disabledForeground, ((FlatSliderUI)super).thumbColor);
/*     */ 
/*     */     
/* 219 */     if (super.isRoundThumb()) {
/* 220 */       youcangetnoinfoBBQN7чКБй.fillOval(((FlatSliderUI)this).thumbRect.x, ((FlatSliderUI)this).thumbRect.y, ((FlatSliderUI)this).thumbRect.width, ((FlatSliderUI)this).thumbRect.height);
/*     */     } else {
/* 222 */       double d1 = ((FlatSliderUI)this).thumbRect.width;
/* 223 */       double d2 = ((FlatSliderUI)this).thumbRect.height;
/* 224 */       double d3 = d1 / 2.0D;
/*     */       
/* 226 */       Object youcangetnoinfoBBQKь5еФЩ = FlatUIUtils.createPath(new double[] { 0.0D, 0.0D, d1, 0.0D, d1, d2 - d3, d3, d2, 0.0D, d2 - d3 });
/*     */       
/* 228 */       Object youcangetnoinfoBBQL0мЧём = youcangetnoinfoBBQN7чКБй.create();
/*     */       try {
/* 230 */         youcangetnoinfoBBQL0мЧём.translate(((FlatSliderUI)this).thumbRect.x, ((FlatSliderUI)this).thumbRect.y);
/* 231 */         if (((FlatSliderUI)this).slider.getOrientation() == 1) {
/* 232 */           if (((FlatSliderUI)this).slider.getComponentOrientation().isLeftToRight()) {
/* 233 */             youcangetnoinfoBBQL0мЧём.translate(0, ((FlatSliderUI)this).thumbRect.height);
/* 234 */             youcangetnoinfoBBQL0мЧём.rotate(Math.toRadians(270.0D));
/*     */           } else {
/* 236 */             youcangetnoinfoBBQL0мЧём.translate(((FlatSliderUI)this).thumbRect.width, 0);
/* 237 */             youcangetnoinfoBBQL0мЧём.rotate(Math.toRadians(90.0D));
/*     */           } 
/*     */         }
/* 240 */         youcangetnoinfoBBQL0мЧём.fill((Shape)youcangetnoinfoBBQKь5еФЩ);
/*     */       } finally {
/* 242 */         youcangetnoinfoBBQL0мЧём.dispose();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isRoundThumb() {
/* 248 */     return (!((FlatSliderUI)this).slider.getPaintTicks() && !((FlatSliderUI)this).slider.getPaintLabels());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatSliderUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */