/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.FlatClientProperties;
/*     */ import com.formdev.flatlaf.FlatLaf;
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.geom.RoundRectangle2D;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicButtonListener;
/*     */ import javax.swing.plaf.basic.BasicButtonUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatButtonUI
/*     */   extends BasicButtonUI
/*     */ {
/*     */   public Color defaultEndBackground;
/*     */   public int arc;
/*     */   public Color shadowColor;
/*     */   public boolean defaults_initialized;
/*     */   public Color disabledText;
/*     */   public Insets toolbarSpacingInsets;
/*     */   public Color toolbarHoverBackground;
/*     */   public int minimumWidth;
/*     */   public int shadowWidth;
/*     */   public Color hoverBackground;
/*     */   public static ComponentUI instance;
/*     */   public int iconTextGap;
/*     */   public Color defaultShadowColor;
/*     */   public int focusWidth;
/*     */   public Icon helpButtonIcon;
/*     */   public Color pressedBackground;
/*     */   public Color defaultBackground;
/*     */   public Color endBackground;
/*     */   public Color defaultHoverBackground;
/*     */   public Color defaultForeground;
/*     */   public Color defaultFocusedBackground;
/*     */   public Color defaultPressedBackground;
/*     */   public Color focusedBackground;
/*     */   public Color startBackground;
/*     */   public boolean defaultBoldText;
/*     */   public Color toolbarPressedBackground;
/*     */   
/*     */   public FlatButtonUI() {
/* 125 */     ((FlatButtonUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoBAPMЯХБРй) {
/* 130 */     if (instance == null)
/* 131 */       instance = new FlatButtonUI(); 
/* 132 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults(Object youcangetnoinfoDSBMПвОяю) {
/* 137 */     super.installDefaults((AbstractButton)youcangetnoinfoDSBMПвОяю);
/*     */     
/* 139 */     if (!((FlatButtonUI)super).defaults_initialized) {
/* 140 */       Object youcangetnoinfoDSBJ0ЁН0Б = getPropertyPrefix();
/*     */       
/* 142 */       ((FlatButtonUI)super).focusWidth = UIManager.getInt("Component.focusWidth");
/* 143 */       ((FlatButtonUI)super).arc = UIManager.getInt("Button.arc");
/* 144 */       ((FlatButtonUI)super).minimumWidth = UIManager.getInt(youcangetnoinfoDSBJ0ЁН0Б + "minimumWidth");
/* 145 */       ((FlatButtonUI)super).iconTextGap = FlatUIUtils.getUIInt(youcangetnoinfoDSBJ0ЁН0Б + "iconTextGap", 4);
/*     */       
/* 147 */       ((FlatButtonUI)super).startBackground = UIManager.getColor(youcangetnoinfoDSBJ0ЁН0Б + "startBackground");
/* 148 */       ((FlatButtonUI)super).endBackground = UIManager.getColor(youcangetnoinfoDSBJ0ЁН0Б + "endBackground");
/* 149 */       ((FlatButtonUI)super).focusedBackground = UIManager.getColor(youcangetnoinfoDSBJ0ЁН0Б + "focusedBackground");
/* 150 */       ((FlatButtonUI)super).hoverBackground = UIManager.getColor(youcangetnoinfoDSBJ0ЁН0Б + "hoverBackground");
/* 151 */       ((FlatButtonUI)super).pressedBackground = UIManager.getColor(youcangetnoinfoDSBJ0ЁН0Б + "pressedBackground");
/* 152 */       ((FlatButtonUI)super).disabledText = UIManager.getColor(youcangetnoinfoDSBJ0ЁН0Б + "disabledText");
/*     */       
/* 154 */       if (UIManager.getBoolean("Button.paintShadow")) {
/* 155 */         ((FlatButtonUI)super).shadowWidth = FlatUIUtils.getUIInt("Button.shadowWidth", 2);
/* 156 */         ((FlatButtonUI)super).shadowColor = UIManager.getColor("Button.shadowColor");
/* 157 */         ((FlatButtonUI)super).defaultShadowColor = UIManager.getColor("Button.default.shadowColor");
/*     */       } else {
/* 159 */         ((FlatButtonUI)super).shadowWidth = 0;
/* 160 */         ((FlatButtonUI)super).shadowColor = null;
/* 161 */         ((FlatButtonUI)super).defaultShadowColor = null;
/*     */       } 
/*     */       
/* 164 */       ((FlatButtonUI)super).defaultBackground = FlatUIUtils.getUIColor("Button.default.startBackground", "Button.default.background");
/* 165 */       ((FlatButtonUI)super).defaultEndBackground = UIManager.getColor("Button.default.endBackground");
/* 166 */       ((FlatButtonUI)super).defaultForeground = UIManager.getColor("Button.default.foreground");
/* 167 */       ((FlatButtonUI)super).defaultFocusedBackground = UIManager.getColor("Button.default.focusedBackground");
/* 168 */       ((FlatButtonUI)super).defaultHoverBackground = UIManager.getColor("Button.default.hoverBackground");
/* 169 */       ((FlatButtonUI)super).defaultPressedBackground = UIManager.getColor("Button.default.pressedBackground");
/* 170 */       ((FlatButtonUI)super).defaultBoldText = UIManager.getBoolean("Button.default.boldText");
/*     */       
/* 172 */       ((FlatButtonUI)super).toolbarSpacingInsets = UIManager.getInsets("Button.toolbar.spacingInsets");
/* 173 */       ((FlatButtonUI)super).toolbarHoverBackground = UIManager.getColor(youcangetnoinfoDSBJ0ЁН0Б + "toolbar.hoverBackground");
/* 174 */       ((FlatButtonUI)super).toolbarPressedBackground = UIManager.getColor(youcangetnoinfoDSBJ0ЁН0Б + "toolbar.pressedBackground");
/*     */       
/* 176 */       ((FlatButtonUI)super).helpButtonIcon = UIManager.getIcon("HelpButton.icon");
/*     */       
/* 178 */       ((FlatButtonUI)super).defaults_initialized = true;
/*     */     } 
/*     */     
/* 181 */     if (((FlatButtonUI)super).startBackground != null) {
/* 182 */       Object youcangetnoinfoDSBKёТмлв = youcangetnoinfoDSBMПвОяю.getBackground();
/* 183 */       if (youcangetnoinfoDSBKёТмлв == null || youcangetnoinfoDSBKёТмлв instanceof javax.swing.plaf.UIResource) {
/* 184 */         youcangetnoinfoDSBMПвОяю.setBackground(((FlatButtonUI)super).startBackground);
/*     */       }
/*     */     } 
/* 187 */     LookAndFeel.installProperty((JComponent)youcangetnoinfoDSBMПвОяю, "opaque", Boolean.valueOf(false));
/* 188 */     LookAndFeel.installProperty((JComponent)youcangetnoinfoDSBMПвОяю, "iconTextGap", Integer.valueOf(UIScale.scale(((FlatButtonUI)super).iconTextGap)));
/*     */     
/* 190 */     MigLayoutVisualPadding.install((JComponent)youcangetnoinfoDSBMПвОяю, super.getFocusWidth((JComponent)youcangetnoinfoDSBMПвОяю));
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults(Object youcangetnoinfoV8zуЧЧ) {
/* 195 */     super.uninstallDefaults((AbstractButton)youcangetnoinfoV8zуЧЧ);
/*     */     
/* 197 */     MigLayoutVisualPadding.uninstall((JComponent)youcangetnoinfoV8zуЧЧ);
/* 198 */     ((FlatButtonUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public BasicButtonListener createButtonListener(Object youcangetnoinfoKFMхЩру9) {
/* 203 */     return new FlatButtonUI$1((FlatButtonUI)this, (AbstractButton)youcangetnoinfoKFMхЩру9, (AbstractButton)youcangetnoinfoKFMхЩру9);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void propertyChange(Object youcangetnoinfoCVJPуЪ1ЬИ, Object youcangetnoinfoCVJQъэсЬ6) {
/* 213 */     switch (youcangetnoinfoCVJQъэсЬ6.getPropertyName()) {
/*     */       case "JComponent.minimumWidth":
/*     */       case "JComponent.minimumHeight":
/* 216 */         youcangetnoinfoCVJPуЪ1ЬИ.revalidate();
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isContentAreaFilled(Object youcangetnoinfoBJAJЧЬф5п) {
/* 222 */     return (!(youcangetnoinfoBJAJЧЬф5п instanceof AbstractButton) || ((AbstractButton)youcangetnoinfoBJAJЧЬф5п).isContentAreaFilled());
/*     */   }
/*     */   
/*     */   public static boolean isDefaultButton(Object youcangetnoinfoBUGH9пянД) {
/* 226 */     return (youcangetnoinfoBUGH9пянД instanceof JButton && ((JButton)youcangetnoinfoBUGH9пянД).isDefaultButton());
/*     */   }
/*     */   
/*     */   public static boolean isIconOnlyButton(Object youcangetnoinfoCAVV5Флб3) {
/* 230 */     if (!(youcangetnoinfoCAVV5Флб3 instanceof JButton) && !(youcangetnoinfoCAVV5Флб3 instanceof javax.swing.JToggleButton)) {
/* 231 */       return false;
/*     */     }
/* 233 */     Object youcangetnoinfoCAVWЁЦ1Хм = ((AbstractButton)youcangetnoinfoCAVV5Флб3).getIcon();
/* 234 */     Object youcangetnoinfoCAVXzюМрЯ = ((AbstractButton)youcangetnoinfoCAVV5Флб3).getText();
/* 235 */     return ((youcangetnoinfoCAVWЁЦ1Хм != null && (youcangetnoinfoCAVXzюМрЯ == null || youcangetnoinfoCAVXzюМрЯ.isEmpty())) || (youcangetnoinfoCAVWЁЦ1Хм == null && youcangetnoinfoCAVXzюМрЯ != null && ("..."
/* 236 */       .equals(youcangetnoinfoCAVXzюМрЯ) || youcangetnoinfoCAVXzюМрЯ.length() == 1)));
/*     */   }
/*     */   
/*     */   public static boolean isSquareButton(Object youcangetnoinfoGCQВл1аб) {
/* 240 */     return (youcangetnoinfoGCQВл1аб instanceof AbstractButton && FlatClientProperties.clientPropertyEquals((AbstractButton)youcangetnoinfoGCQВл1аб, "JButton.buttonType", "square"));
/*     */   }
/*     */   
/*     */   public static boolean isHelpButton(Object youcangetnoinfoAHOHЕщеЗЭ) {
/* 244 */     return (youcangetnoinfoAHOHЕщеЗЭ instanceof JButton && FlatClientProperties.clientPropertyEquals((JButton)youcangetnoinfoAHOHЕщеЗЭ, "JButton.buttonType", "help"));
/*     */   }
/*     */   
/*     */   public static boolean isToolBarButton(Object youcangetnoinfoEHXZИДъШ4) {
/* 248 */     return youcangetnoinfoEHXZИДъШ4.getParent() instanceof javax.swing.JToolBar;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Object youcangetnoinfoATDOЖПеРэ, Object youcangetnoinfoATDPЭгб2г) {
/* 254 */     if (youcangetnoinfoATDPЭгб2г.isOpaque()) {
/* 255 */       FlatUIUtils.paintParentBackground((Graphics)youcangetnoinfoATDOЖПеРэ, (JComponent)youcangetnoinfoATDPЭгб2г);
/*     */     }
/* 257 */     if (isHelpButton((Component)youcangetnoinfoATDPЭгб2г)) {
/* 258 */       ((FlatButtonUI)super).helpButtonIcon.paintIcon((Component)youcangetnoinfoATDPЭгб2г, (Graphics)youcangetnoinfoATDOЖПеРэ, 0, 0);
/*     */       
/*     */       return;
/*     */     } 
/* 262 */     if (isContentAreaFilled((Component)youcangetnoinfoATDPЭгб2г)) {
/* 263 */       super.paintBackground((Graphics)youcangetnoinfoATDOЖПеРэ, (JComponent)youcangetnoinfoATDPЭгб2г);
/*     */     }
/* 265 */     paint((Graphics)youcangetnoinfoATDOЖПеРэ, (JComponent)youcangetnoinfoATDPЭгб2г);
/*     */   }
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoAUKJЬ9чкК, Object youcangetnoinfoAUKKПо5фЧ) {
/* 269 */     Object youcangetnoinfoAUKL3уАЙе = super.getBackground((JComponent)youcangetnoinfoAUKKПо5фЧ);
/* 270 */     if (youcangetnoinfoAUKL3уАЙе != null) {
/* 271 */       Object youcangetnoinfoAUKHуЙБ5т = youcangetnoinfoAUKJЬ9чкК.create();
/*     */       try {
/* 273 */         FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoAUKHуЙБ5т);
/*     */         
/* 275 */         Object youcangetnoinfoAUJVЕТъуЧ = youcangetnoinfoAUKKПо5фЧ.getBorder();
/* 276 */         boolean bool1 = isToolBarButton((Component)youcangetnoinfoAUKKПо5фЧ);
/* 277 */         float f1 = (youcangetnoinfoAUJVЕТъуЧ instanceof FlatBorder && !bool1) ? UIScale.scale(super.getFocusWidth((JComponent)youcangetnoinfoAUKKПо5фЧ)) : 0.0F;
/*     */         
/* 279 */         float f2 = ((youcangetnoinfoAUJVЕТъуЧ instanceof FlatButtonBorder && !isSquareButton((Component)youcangetnoinfoAUKKПо5фЧ)) || bool1) ? UIScale.scale(((FlatButtonUI)super).arc) : 0.0F;
/* 280 */         boolean bool2 = isDefaultButton((Component)youcangetnoinfoAUKKПо5фЧ);
/*     */         
/* 282 */         int i = 0;
/* 283 */         int j = 0;
/* 284 */         int k = youcangetnoinfoAUKKПо5фЧ.getWidth();
/* 285 */         int m = youcangetnoinfoAUKKПо5фЧ.getHeight();
/*     */         
/* 287 */         if (bool1) {
/* 288 */           Object youcangetnoinfoAUJU0Лн0е = UIScale.scale(((FlatButtonUI)super).toolbarSpacingInsets);
/* 289 */           i += ((Insets)youcangetnoinfoAUJU0Лн0е).left;
/* 290 */           j += ((Insets)youcangetnoinfoAUJU0Лн0е).top;
/* 291 */           k -= ((Insets)youcangetnoinfoAUJU0Лн0е).left + ((Insets)youcangetnoinfoAUJU0Лн0е).right;
/* 292 */           m -= ((Insets)youcangetnoinfoAUJU0Лн0е).top + ((Insets)youcangetnoinfoAUJU0Лн0е).bottom;
/*     */         } 
/*     */ 
/*     */         
/* 296 */         Object youcangetnoinfoAUKE3ешЗщ = bool2 ? ((FlatButtonUI)super).defaultShadowColor : ((FlatButtonUI)super).shadowColor;
/* 297 */         if (!bool1 && youcangetnoinfoAUKE3ешЗщ != null && ((FlatButtonUI)super).shadowWidth > 0 && f1 > 0.0F && !youcangetnoinfoAUKKПо5фЧ.hasFocus() && youcangetnoinfoAUKKПо5фЧ.isEnabled()) {
/* 298 */           youcangetnoinfoAUKHуЙБ5т.setColor((Color)youcangetnoinfoAUKE3ешЗщ);
/* 299 */           youcangetnoinfoAUKHуЙБ5т.fill(new RoundRectangle2D.Float(f1, f1 + UIScale.scale(((FlatButtonUI)super).shadowWidth), k - f1 * 2.0F, m - f1 * 2.0F, f2, f2));
/*     */         } 
/*     */ 
/*     */ 
/*     */         
/* 304 */         Object youcangetnoinfoAUKFО4КАН = bool2 ? ((FlatButtonUI)super).defaultBackground : ((FlatButtonUI)super).startBackground;
/* 305 */         Object youcangetnoinfoAUKGтрИкЦ = bool2 ? ((FlatButtonUI)super).defaultEndBackground : ((FlatButtonUI)super).endBackground;
/* 306 */         if (youcangetnoinfoAUKL3уАЙе == youcangetnoinfoAUKFО4КАН && youcangetnoinfoAUKGтрИкЦ != null && !youcangetnoinfoAUKFО4КАН.equals(youcangetnoinfoAUKGтрИкЦ)) {
/* 307 */           youcangetnoinfoAUKHуЙБ5т.setPaint(new GradientPaint(0.0F, 0.0F, (Color)youcangetnoinfoAUKFО4КАН, 0.0F, m, (Color)youcangetnoinfoAUKGтрИкЦ));
/*     */         } else {
/* 309 */           FlatUIUtils.setColor((Graphics)youcangetnoinfoAUKHуЙБ5т, (Color)youcangetnoinfoAUKL3уАЙе, bool2 ? ((FlatButtonUI)super).defaultBackground : youcangetnoinfoAUKKПо5фЧ.getBackground());
/*     */         } 
/* 311 */         FlatUIUtils.paintComponentBackground((Graphics2D)youcangetnoinfoAUKHуЙБ5т, i, j, k, m, f1, f2);
/*     */       } finally {
/* 313 */         youcangetnoinfoAUKHуЙБ5т.dispose();
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintText(Object youcangetnoinfoEONVЬТцнп, Object youcangetnoinfoEONWеЫцБЯ, Object youcangetnoinfoEONXлкоСЬ, Object youcangetnoinfoEONYоzшИС) {
/* 320 */     if (isHelpButton((Component)youcangetnoinfoEONWеЫцБЯ)) {
/*     */       return;
/*     */     }
/* 323 */     if (((FlatButtonUI)super).defaultBoldText && isDefaultButton((Component)youcangetnoinfoEONWеЫцБЯ) && youcangetnoinfoEONWеЫцБЯ.getFont() instanceof javax.swing.plaf.UIResource) {
/* 324 */       Object youcangetnoinfoEONSйШЛКб = youcangetnoinfoEONVЬТцнп.getFont().deriveFont(1);
/* 325 */       youcangetnoinfoEONVЬТцнп.setFont((Font)youcangetnoinfoEONSйШЛКб);
/*     */       
/* 327 */       int i = youcangetnoinfoEONWеЫцБЯ.getFontMetrics((Font)youcangetnoinfoEONSйШЛКб).stringWidth((String)youcangetnoinfoEONYоzшИС);
/* 328 */       if (i > ((Rectangle)youcangetnoinfoEONXлкоСЬ).width) {
/* 329 */         ((Rectangle)youcangetnoinfoEONXлкоСЬ).x -= (i - ((Rectangle)youcangetnoinfoEONXлкоСЬ).width) / 2;
/* 330 */         ((Rectangle)youcangetnoinfoEONXлкоСЬ).width = i;
/*     */       } 
/*     */     } 
/*     */     
/* 334 */     paintText((Graphics)youcangetnoinfoEONVЬТцнп, (AbstractButton)youcangetnoinfoEONWеЫцБЯ, (Rectangle)youcangetnoinfoEONXлкоСЬ, (String)youcangetnoinfoEONYоzшИС, youcangetnoinfoEONWеЫцБЯ.isEnabled() ? super.getForeground((JComponent)youcangetnoinfoEONWеЫцБЯ) : ((FlatButtonUI)super).disabledText);
/*     */   }
/*     */   
/*     */   public static void paintText(Object youcangetnoinfoQZУОДнЗ, Object youcangetnoinfoRAГцЧПЦ, Object youcangetnoinfoRBИр87z, Object youcangetnoinfoRCБспЭв, Object youcangetnoinfoRD2КЦМВ) {
/* 338 */     Object youcangetnoinfoREр7ЮШЗ = youcangetnoinfoRAГцЧПЦ.getFontMetrics(youcangetnoinfoRAГцЧПЦ.getFont());
/* 339 */     boolean bool = FlatLaf.isShowMnemonics() ? youcangetnoinfoRAГцЧПЦ.getDisplayedMnemonicIndex() : true;
/*     */     
/* 341 */     youcangetnoinfoQZУОДнЗ.setColor((Color)youcangetnoinfoRD2КЦМВ);
/* 342 */     FlatUIUtils.drawStringUnderlineCharAt((JComponent)youcangetnoinfoRAГцЧПЦ, (Graphics)youcangetnoinfoQZУОДнЗ, (String)youcangetnoinfoRCБспЭв, bool, ((Rectangle)youcangetnoinfoRBИр87z).x, ((Rectangle)youcangetnoinfoRBИр87z).y + youcangetnoinfoREр7ЮШЗ
/* 343 */         .getAscent());
/*     */   }
/*     */   
/*     */   public Color getBackground(Object youcangetnoinfoFHPэ1нсб) {
/* 347 */     if (!youcangetnoinfoFHPэ1нсб.isEnabled()) {
/* 348 */       return null;
/*     */     }
/*     */     
/* 351 */     if (isToolBarButton((Component)youcangetnoinfoFHPэ1нсб)) {
/* 352 */       Object youcangetnoinfoFHNЯ8ьМэ = ((AbstractButton)youcangetnoinfoFHPэ1нсб).getModel();
/* 353 */       if (youcangetnoinfoFHNЯ8ьМэ.isPressed())
/* 354 */         return ((FlatButtonUI)super).toolbarPressedBackground; 
/* 355 */       if (youcangetnoinfoFHNЯ8ьМэ.isRollover()) {
/* 356 */         return ((FlatButtonUI)super).toolbarHoverBackground;
/*     */       }
/*     */       
/* 359 */       return youcangetnoinfoFHPэ1нсб.getParent().getBackground();
/*     */     } 
/*     */     
/* 362 */     boolean bool = isDefaultButton((Component)youcangetnoinfoFHPэ1нсб);
/* 363 */     return buttonStateColor((Component)youcangetnoinfoFHPэ1нсб, 
/* 364 */         bool ? ((FlatButtonUI)super).defaultBackground : youcangetnoinfoFHPэ1нсб.getBackground(), (Color)null, 
/*     */         
/* 366 */         bool ? ((FlatButtonUI)super).defaultFocusedBackground : ((FlatButtonUI)super).focusedBackground, 
/* 367 */         bool ? ((FlatButtonUI)super).defaultHoverBackground : ((FlatButtonUI)super).hoverBackground, 
/* 368 */         bool ? ((FlatButtonUI)super).defaultPressedBackground : ((FlatButtonUI)super).pressedBackground);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static Color buttonStateColor(Object youcangetnoinfoONJСш2Н3, Object youcangetnoinfoONKЗ2НЧР, Object youcangetnoinfoONLИЁоВе, Object youcangetnoinfoONMё7бДЙ, Object youcangetnoinfoONN3ФзЩУ, Object youcangetnoinfoONO1нйБ2) {
/* 374 */     Object youcangetnoinfoONP8фя9с = (youcangetnoinfoONJСш2Н3 instanceof AbstractButton) ? youcangetnoinfoONJСш2Н3 : null;
/*     */     
/* 376 */     if (!youcangetnoinfoONJСш2Н3.isEnabled()) {
/* 377 */       return (Color)youcangetnoinfoONLИЁоВе;
/*     */     }
/* 379 */     if (youcangetnoinfoONO1нйБ2 != null && youcangetnoinfoONP8фя9с != null && youcangetnoinfoONP8фя9с.getModel().isPressed()) {
/* 380 */       return (Color)youcangetnoinfoONO1нйБ2;
/*     */     }
/* 382 */     if (youcangetnoinfoONN3ФзЩУ != null && youcangetnoinfoONP8фя9с != null && youcangetnoinfoONP8фя9с.getModel().isRollover()) {
/* 383 */       return (Color)youcangetnoinfoONN3ФзЩУ;
/*     */     }
/* 385 */     if (youcangetnoinfoONMё7бДЙ != null && youcangetnoinfoONJСш2Н3.hasFocus()) {
/* 386 */       return (Color)youcangetnoinfoONMё7бДЙ;
/*     */     }
/* 388 */     return (Color)youcangetnoinfoONKЗ2НЧР;
/*     */   }
/*     */   
/*     */   public Color getForeground(Object youcangetnoinfoAVZHъзшуд) {
/* 392 */     boolean bool = isDefaultButton((Component)youcangetnoinfoAVZHъзшуд);
/* 393 */     return bool ? ((FlatButtonUI)super).defaultForeground : youcangetnoinfoAVZHъзшуд.getForeground();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoDKZNЧЧфхИ) {
/* 398 */     if (isHelpButton((Component)youcangetnoinfoDKZNЧЧфхИ)) {
/* 399 */       return new Dimension(((FlatButtonUI)super).helpButtonIcon.getIconWidth(), ((FlatButtonUI)super).helpButtonIcon.getIconHeight());
/*     */     }
/* 401 */     Object youcangetnoinfoDKZOФКЫыЩ = super.getPreferredSize((JComponent)youcangetnoinfoDKZNЧЧфхИ);
/* 402 */     if (youcangetnoinfoDKZOФКЫыЩ == null) {
/* 403 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 407 */     if (isIconOnlyButton((Component)youcangetnoinfoDKZNЧЧфхИ)) {
/* 408 */       ((Dimension)youcangetnoinfoDKZOФКЫыЩ).width = Math.max(((Dimension)youcangetnoinfoDKZOФКЫыЩ).width, ((Dimension)youcangetnoinfoDKZOФКЫыЩ).height);
/* 409 */     } else if (!isToolBarButton((Component)youcangetnoinfoDKZNЧЧфхИ) && youcangetnoinfoDKZNЧЧфхИ.getBorder() instanceof FlatButtonBorder) {
/* 410 */       int i = super.getFocusWidth((JComponent)youcangetnoinfoDKZNЧЧфхИ);
/* 411 */       ((Dimension)youcangetnoinfoDKZOФКЫыЩ).width = Math.max(((Dimension)youcangetnoinfoDKZOФКЫыЩ).width, UIScale.scale(FlatUIUtils.minimumWidth((JComponent)youcangetnoinfoDKZNЧЧфхИ, ((FlatButtonUI)super).minimumWidth) + i * 2));
/* 412 */       ((Dimension)youcangetnoinfoDKZOФКЫыЩ).height = Math.max(((Dimension)youcangetnoinfoDKZOФКЫыЩ).height, UIScale.scale(FlatUIUtils.minimumHeight((JComponent)youcangetnoinfoDKZNЧЧфхИ, 0) + i * 2));
/*     */     } 
/*     */     
/* 415 */     return (Dimension)youcangetnoinfoDKZOФКЫыЩ;
/*     */   }
/*     */   
/*     */   public int getFocusWidth(Object youcangetnoinfoLTZъё5уэ) {
/* 419 */     return ((FlatButtonUI)super).focusWidth;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatButtonUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */