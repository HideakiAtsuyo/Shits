/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.SystemInfo;
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.Shape;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.lang.ref.WeakReference;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.DefaultListCellRenderer;
/*     */ import javax.swing.InputMap;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicComboBoxUI;
/*     */ import javax.swing.plaf.basic.ComboPopup;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatComboBoxUI
/*     */   extends BasicComboBoxUI
/*     */ {
/*     */   public Color borderColor;
/*     */   public WeakReference<Component> lastRendererComponent;
/*     */   public Color buttonDisabledArrowColor;
/*     */   public Color disabledBackground;
/*     */   public Color buttonArrowColor;
/*     */   public Color buttonBackground;
/*     */   public String arrowType;
/*     */   public int focusWidth;
/*     */   public MouseListener hoverListener;
/*     */   public Color disabledForeground;
/*     */   public Color editableBackground;
/*     */   public boolean hover;
/*     */   public Color buttonHoverArrowColor;
/*     */   public boolean isIntelliJTheme;
/*     */   public Color disabledBorderColor;
/*     */   public Color buttonEditableBackground;
/*     */   public int arc;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoASZUкшТЪГ) {
/* 122 */     return new FlatComboBoxUI();
/*     */   }
/*     */   
/*     */   public void installListeners()
/*     */   {
/* 127 */     super.installListeners();
/*     */     
/* 129 */     ((FlatComboBoxUI)super).hoverListener = new FlatUIUtils$HoverListener(null, this::lambda$installListeners$0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 136 */     ((FlatComboBoxUI)this).comboBox.addMouseListener(((FlatComboBoxUI)super).hoverListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners() {
/* 141 */     super.uninstallListeners();
/*     */     
/* 143 */     ((FlatComboBoxUI)this).comboBox.removeMouseListener(((FlatComboBoxUI)super).hoverListener);
/* 144 */     ((FlatComboBoxUI)super).hoverListener = null; }
/*     */   public void lambda$installListeners$0(Object youcangetnoinfoUMFПхЭ1О) { if (!((FlatComboBoxUI)this).comboBox.isEditable()) {
/*     */       ((FlatComboBoxUI)super).hover = youcangetnoinfoUMFПхЭ1О.booleanValue();
/*     */       if (((FlatComboBoxUI)this).arrowButton != null)
/*     */         ((FlatComboBoxUI)this).arrowButton.repaint(); 
/* 149 */     }  } public void installDefaults() { super.installDefaults();
/*     */     
/* 151 */     LookAndFeel.installProperty(((FlatComboBoxUI)this).comboBox, "opaque", Boolean.valueOf(false));
/*     */     
/* 153 */     ((FlatComboBoxUI)super).focusWidth = UIManager.getInt("Component.focusWidth");
/* 154 */     ((FlatComboBoxUI)super).arc = UIManager.getInt("Component.arc");
/* 155 */     ((FlatComboBoxUI)super).arrowType = UIManager.getString("Component.arrowType");
/* 156 */     ((FlatComboBoxUI)super).isIntelliJTheme = UIManager.getBoolean("Component.isIntelliJTheme");
/* 157 */     ((FlatComboBoxUI)super).borderColor = UIManager.getColor("Component.borderColor");
/* 158 */     ((FlatComboBoxUI)super).disabledBorderColor = UIManager.getColor("Component.disabledBorderColor");
/*     */     
/* 160 */     ((FlatComboBoxUI)super).editableBackground = UIManager.getColor("ComboBox.editableBackground");
/* 161 */     ((FlatComboBoxUI)super).disabledBackground = UIManager.getColor("ComboBox.disabledBackground");
/* 162 */     ((FlatComboBoxUI)super).disabledForeground = UIManager.getColor("ComboBox.disabledForeground");
/*     */     
/* 164 */     ((FlatComboBoxUI)super).buttonBackground = UIManager.getColor("ComboBox.buttonBackground");
/* 165 */     ((FlatComboBoxUI)super).buttonEditableBackground = UIManager.getColor("ComboBox.buttonEditableBackground");
/* 166 */     ((FlatComboBoxUI)super).buttonArrowColor = UIManager.getColor("ComboBox.buttonArrowColor");
/* 167 */     ((FlatComboBoxUI)super).buttonDisabledArrowColor = UIManager.getColor("ComboBox.buttonDisabledArrowColor");
/* 168 */     ((FlatComboBoxUI)super).buttonHoverArrowColor = UIManager.getColor("ComboBox.buttonHoverArrowColor");
/*     */ 
/*     */     
/* 171 */     ((FlatComboBoxUI)this).padding = UIScale.scale(((FlatComboBoxUI)this).padding);
/*     */     
/* 173 */     MigLayoutVisualPadding.install(((FlatComboBoxUI)this).comboBox, ((FlatComboBoxUI)super).focusWidth); }
/*     */ 
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/* 178 */     super.uninstallDefaults();
/*     */     
/* 180 */     ((FlatComboBoxUI)super).borderColor = null;
/* 181 */     ((FlatComboBoxUI)super).disabledBorderColor = null;
/*     */     
/* 183 */     ((FlatComboBoxUI)super).editableBackground = null;
/* 184 */     ((FlatComboBoxUI)super).disabledBackground = null;
/* 185 */     ((FlatComboBoxUI)super).disabledForeground = null;
/*     */     
/* 187 */     ((FlatComboBoxUI)super).buttonBackground = null;
/* 188 */     ((FlatComboBoxUI)super).buttonEditableBackground = null;
/* 189 */     ((FlatComboBoxUI)super).buttonArrowColor = null;
/* 190 */     ((FlatComboBoxUI)super).buttonDisabledArrowColor = null;
/* 191 */     ((FlatComboBoxUI)super).buttonHoverArrowColor = null;
/*     */     
/* 193 */     MigLayoutVisualPadding.uninstall(((FlatComboBoxUI)this).comboBox);
/*     */   }
/*     */ 
/*     */   
/*     */   public LayoutManager createLayoutManager() {
/* 198 */     return new FlatComboBoxUI$1((FlatComboBoxUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FocusListener createFocusListener() {
/* 214 */     return new FlatComboBoxUI$2((FlatComboBoxUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyChangeListener createPropertyChangeListener() {
/* 233 */     return new FlatComboBoxUI$3((FlatComboBoxUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ComboPopup createPopup() {
/* 258 */     return new FlatComboBoxUI$FlatComboPopup((FlatComboBoxUI)this, ((FlatComboBoxUI)this).comboBox);
/*     */   }
/*     */ 
/*     */   
/*     */   public void configureEditor() {
/* 263 */     super.configureEditor();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 270 */     if (((FlatComboBoxUI)this).editor instanceof JTextComponent) {
/* 271 */       ((JTextComponent)((FlatComboBoxUI)this).editor).setBorder(BorderFactory.createEmptyBorder());
/*     */     }
/*     */     
/* 274 */     if (((FlatComboBoxUI)this).editor instanceof JComponent) {
/* 275 */       ((JComponent)((FlatComboBoxUI)this).editor).setOpaque(false);
/*     */     }
/* 277 */     ((FlatComboBoxUI)this).editor.applyComponentOrientation(((FlatComboBoxUI)this).comboBox.getComponentOrientation());
/*     */     
/* 279 */     super.updateEditorColors();
/*     */ 
/*     */     
/* 282 */     if (SystemInfo.IS_MAC && ((FlatComboBoxUI)this).editor instanceof JTextComponent) {
/*     */ 
/*     */       
/* 285 */       Object youcangetnoinfoBNLEбиЦиЮ = ((JTextComponent)((FlatComboBoxUI)this).editor).getInputMap();
/* 286 */       new FlatComboBoxUI$EditorDelegateAction((FlatComboBoxUI)this, (InputMap)youcangetnoinfoBNLEбиЦиЮ, KeyStroke.getKeyStroke("UP"));
/* 287 */       new FlatComboBoxUI$EditorDelegateAction((FlatComboBoxUI)this, (InputMap)youcangetnoinfoBNLEбиЦиЮ, KeyStroke.getKeyStroke("KP_UP"));
/* 288 */       new FlatComboBoxUI$EditorDelegateAction((FlatComboBoxUI)this, (InputMap)youcangetnoinfoBNLEбиЦиЮ, KeyStroke.getKeyStroke("DOWN"));
/* 289 */       new FlatComboBoxUI$EditorDelegateAction((FlatComboBoxUI)this, (InputMap)youcangetnoinfoBNLEбиЦиЮ, KeyStroke.getKeyStroke("KP_DOWN"));
/* 290 */       new FlatComboBoxUI$EditorDelegateAction((FlatComboBoxUI)this, (InputMap)youcangetnoinfoBNLEбиЦиЮ, KeyStroke.getKeyStroke("HOME"));
/* 291 */       new FlatComboBoxUI$EditorDelegateAction((FlatComboBoxUI)this, (InputMap)youcangetnoinfoBNLEбиЦиЮ, KeyStroke.getKeyStroke("END"));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateEditorColors() {
/* 299 */     boolean bool = ((FlatComboBoxUI)this).editor.isEnabled();
/* 300 */     ((FlatComboBoxUI)this).editor.setForeground(FlatUIUtils.nonUIResource((bool || ((FlatComboBoxUI)this).editor instanceof JTextComponent) ? 
/* 301 */           ((FlatComboBoxUI)this).comboBox.getForeground() : 
/* 302 */           ((FlatComboBoxUI)super).disabledForeground));
/* 303 */     if (((FlatComboBoxUI)this).editor instanceof JTextComponent) {
/* 304 */       ((JTextComponent)((FlatComboBoxUI)this).editor).setDisabledTextColor(FlatUIUtils.nonUIResource(((FlatComboBoxUI)super).disabledForeground));
/*     */     }
/*     */   }
/*     */   
/*     */   public JButton createArrowButton() {
/* 309 */     return new FlatComboBoxUI$4((FlatComboBoxUI)this, 5, ((FlatComboBoxUI)super).arrowType, ((FlatComboBoxUI)super).buttonArrowColor, ((FlatComboBoxUI)super).buttonDisabledArrowColor, ((FlatComboBoxUI)super).buttonHoverArrowColor, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Object youcangetnoinfoACXRъхаМж, Object youcangetnoinfoACXSбАУФж) {
/* 322 */     if (youcangetnoinfoACXSбАУФж.isOpaque() && (((FlatComboBoxUI)super).focusWidth > 0 || ((FlatComboBoxUI)super).arc != 0)) {
/* 323 */       FlatUIUtils.paintParentBackground((Graphics)youcangetnoinfoACXRъхаМж, (JComponent)youcangetnoinfoACXSбАУФж);
/*     */     }
/* 325 */     Object youcangetnoinfoACXTАЭЗЯв = youcangetnoinfoACXRъхаМж;
/* 326 */     FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoACXTАЭЗЯв);
/*     */     
/* 328 */     int i = youcangetnoinfoACXSбАУФж.getWidth();
/* 329 */     int j = youcangetnoinfoACXSбАУФж.getHeight();
/* 330 */     float f1 = (youcangetnoinfoACXSбАУФж.getBorder() instanceof FlatBorder) ? UIScale.scale(((FlatComboBoxUI)super).focusWidth) : 0.0F;
/* 331 */     float f2 = (youcangetnoinfoACXSбАУФж.getBorder() instanceof FlatRoundBorder) ? UIScale.scale(((FlatComboBoxUI)super).arc) : 0.0F;
/* 332 */     int k = ((FlatComboBoxUI)this).arrowButton.getX();
/* 333 */     int m = ((FlatComboBoxUI)this).arrowButton.getWidth();
/* 334 */     boolean bool1 = ((FlatComboBoxUI)this).comboBox.isEnabled();
/* 335 */     boolean bool2 = ((FlatComboBoxUI)this).comboBox.getComponentOrientation().isLeftToRight();
/*     */ 
/*     */     
/* 338 */     youcangetnoinfoACXTАЭЗЯв.setColor(bool1 ? (
/* 339 */         (((FlatComboBoxUI)super).editableBackground != null && ((FlatComboBoxUI)this).comboBox.isEditable()) ? ((FlatComboBoxUI)super).editableBackground : youcangetnoinfoACXSбАУФж.getBackground()) : 
/* 340 */         super.getDisabledBackground(((FlatComboBoxUI)this).comboBox));
/* 341 */     FlatUIUtils.paintComponentBackground((Graphics2D)youcangetnoinfoACXTАЭЗЯв, 0, 0, i, j, f1, f2);
/*     */ 
/*     */     
/* 344 */     if (bool1) {
/* 345 */       youcangetnoinfoACXTАЭЗЯв.setColor(((FlatComboBoxUI)this).comboBox.isEditable() ? ((FlatComboBoxUI)super).buttonEditableBackground : ((FlatComboBoxUI)super).buttonBackground);
/* 346 */       Object youcangetnoinfoACXNУпяДМ = youcangetnoinfoACXTАЭЗЯв.getClip();
/* 347 */       if (bool2) {
/* 348 */         youcangetnoinfoACXTАЭЗЯв.clipRect(k, 0, i - k, j);
/*     */       } else {
/* 350 */         youcangetnoinfoACXTАЭЗЯв.clipRect(0, 0, k + m, j);
/* 351 */       }  FlatUIUtils.paintComponentBackground((Graphics2D)youcangetnoinfoACXTАЭЗЯв, 0, 0, i, j, f1, f2);
/* 352 */       youcangetnoinfoACXTАЭЗЯв.setClip((Shape)youcangetnoinfoACXNУпяДМ);
/*     */     } 
/*     */ 
/*     */     
/* 356 */     if (((FlatComboBoxUI)this).comboBox.isEditable()) {
/* 357 */       youcangetnoinfoACXTАЭЗЯв.setColor(bool1 ? ((FlatComboBoxUI)super).borderColor : ((FlatComboBoxUI)super).disabledBorderColor);
/* 358 */       float f3 = UIScale.scale(1.0F);
/* 359 */       float f4 = bool2 ? k : ((k + m) - f3);
/* 360 */       youcangetnoinfoACXTАЭЗЯв.fill(new Rectangle2D.Float(f4, f1, f3, (j - 1) - f1 * 2.0F));
/*     */     } 
/*     */     
/* 363 */     paint((Graphics)youcangetnoinfoACXRъхаМж, (JComponent)youcangetnoinfoACXSбАУФж);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintCurrentValue(Object youcangetnoinfoQNIю3ёвz, Object youcangetnoinfoQNJлсМЩШ, Object youcangetnoinfoQNKЩБм3Щ) {
/* 369 */     Object youcangetnoinfoQNLв7Ав9 = ((FlatComboBoxUI)this).comboBox.getRenderer();
/* 370 */     super.uninstallCellPaddingBorder(youcangetnoinfoQNLв7Ав9);
/* 371 */     if (youcangetnoinfoQNLв7Ав9 == null)
/* 372 */       youcangetnoinfoQNLв7Ав9 = new DefaultListCellRenderer(); 
/* 373 */     Object youcangetnoinfoQNMюДСЯ0 = youcangetnoinfoQNLв7Ав9.getListCellRendererComponent(((FlatComboBoxUI)this).listBox, ((FlatComboBoxUI)this).comboBox.getSelectedItem(), -1, false, false);
/* 374 */     youcangetnoinfoQNMюДСЯ0.setFont(((FlatComboBoxUI)this).comboBox.getFont());
/* 375 */     youcangetnoinfoQNMюДСЯ0.applyComponentOrientation(((FlatComboBoxUI)this).comboBox.getComponentOrientation());
/* 376 */     super.uninstallCellPaddingBorder(youcangetnoinfoQNMюДСЯ0);
/*     */     
/* 378 */     boolean bool1 = ((FlatComboBoxUI)this).comboBox.isEnabled();
/* 379 */     youcangetnoinfoQNMюДСЯ0.setForeground(bool1 ? ((FlatComboBoxUI)this).comboBox.getForeground() : ((FlatComboBoxUI)super).disabledForeground);
/* 380 */     youcangetnoinfoQNMюДСЯ0.setBackground(bool1 ? ((FlatComboBoxUI)this).comboBox.getBackground() : super.getDisabledBackground(((FlatComboBoxUI)this).comboBox));
/*     */     
/* 382 */     boolean bool2 = youcangetnoinfoQNMюДСЯ0 instanceof javax.swing.JPanel;
/* 383 */     if (((FlatComboBoxUI)this).padding != null) {
/* 384 */       youcangetnoinfoQNJлсМЩШ = FlatUIUtils.subtractInsets((Rectangle)youcangetnoinfoQNJлсМЩШ, ((FlatComboBoxUI)this).padding);
/*     */     }
/*     */ 
/*     */     
/* 388 */     Object youcangetnoinfoQNPzБПаВ = super.getRendererComponentInsets((Component)youcangetnoinfoQNMюДСЯ0);
/* 389 */     if (youcangetnoinfoQNPzБПаВ != null) {
/* 390 */       youcangetnoinfoQNJлсМЩШ = FlatUIUtils.addInsets((Rectangle)youcangetnoinfoQNJлсМЩШ, (Insets)youcangetnoinfoQNPzБПаВ);
/*     */     }
/* 392 */     ((FlatComboBoxUI)this).currentValuePane.paintComponent((Graphics)youcangetnoinfoQNIю3ёвz, (Component)youcangetnoinfoQNMюДСЯ0, ((FlatComboBoxUI)this).comboBox, ((Rectangle)youcangetnoinfoQNJлсМЩШ).x, ((Rectangle)youcangetnoinfoQNJлсМЩШ).y, ((Rectangle)youcangetnoinfoQNJлсМЩШ).width, ((Rectangle)youcangetnoinfoQNJлсМЩШ).height, bool2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintCurrentValueBackground(Object youcangetnoinfoEPEMЭръзЯ, Object youcangetnoinfoEPENЩрк9ъ, Object youcangetnoinfoEPEOЩц98Р) {
/* 397 */     youcangetnoinfoEPEMЭръзЯ.setColor(((FlatComboBoxUI)this).comboBox.isEnabled() ? ((FlatComboBoxUI)this).comboBox.getBackground() : super.getDisabledBackground(((FlatComboBoxUI)this).comboBox));
/* 398 */     youcangetnoinfoEPEMЭръзЯ.fillRect(((Rectangle)youcangetnoinfoEPENЩрк9ъ).x, ((Rectangle)youcangetnoinfoEPENЩрк9ъ).y, ((Rectangle)youcangetnoinfoEPENЩрк9ъ).width, ((Rectangle)youcangetnoinfoEPENЩрк9ъ).height);
/*     */   }
/*     */   
/*     */   public Color getDisabledBackground(Object youcangetnoinfoBCGP11х8Й) {
/* 402 */     return ((FlatComboBoxUI)super).isIntelliJTheme ? FlatUIUtils.getParentBackground((JComponent)youcangetnoinfoBCGP11х8Й) : ((FlatComboBoxUI)super).disabledBackground;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getDefaultSize() {
/* 408 */     Object youcangetnoinfoEBABыъЕЗМ = ((FlatComboBoxUI)this).comboBox.getRenderer();
/* 409 */     super.uninstallCellPaddingBorder(youcangetnoinfoEBABыъЕЗМ);
/*     */     
/* 411 */     Object youcangetnoinfoEBAC9л2дэ = super.getDefaultSize();
/*     */     
/* 413 */     super.uninstallCellPaddingBorder(youcangetnoinfoEBABыъЕЗМ);
/* 414 */     return (Dimension)youcangetnoinfoEBAC9л2дэ;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getDisplaySize() {
/* 420 */     Object youcangetnoinfoDBHTЬЯф7д = ((FlatComboBoxUI)this).comboBox.getRenderer();
/* 421 */     super.uninstallCellPaddingBorder(youcangetnoinfoDBHTЬЯф7д);
/*     */     
/* 423 */     Object youcangetnoinfoDBHUБчмоШ = super.getDisplaySize();
/*     */     
/* 425 */     super.uninstallCellPaddingBorder(youcangetnoinfoDBHTЬЯф7д);
/* 426 */     return (Dimension)youcangetnoinfoDBHUБчмоШ;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getSizeForComponent(Object youcangetnoinfoCDSF6дЛеО) {
/* 431 */     Object youcangetnoinfoCDSGЪё3Пи = super.getSizeForComponent((Component)youcangetnoinfoCDSF6дЛеО);
/*     */ 
/*     */ 
/*     */     
/* 435 */     Object youcangetnoinfoCDSHь08аИ = super.getRendererComponentInsets((Component)youcangetnoinfoCDSF6дЛеО);
/* 436 */     if (youcangetnoinfoCDSHь08аИ != null) {
/* 437 */       youcangetnoinfoCDSGЪё3Пи = new Dimension(((Dimension)youcangetnoinfoCDSGЪё3Пи).width, ((Dimension)youcangetnoinfoCDSGЪё3Пи).height - ((Insets)youcangetnoinfoCDSHь08аИ).top - ((Insets)youcangetnoinfoCDSHь08аИ).bottom);
/*     */     }
/* 439 */     return (Dimension)youcangetnoinfoCDSGЪё3Пи;
/*     */   }
/*     */   
/*     */   public Insets getRendererComponentInsets(Object youcangetnoinfoECJOзЛэЫё) {
/* 443 */     if (youcangetnoinfoECJOзЛэЫё instanceof JComponent) {
/* 444 */       Object youcangetnoinfoECJMеа1оТ = ((JComponent)youcangetnoinfoECJOзЛэЫё).getBorder();
/* 445 */       if (youcangetnoinfoECJMеа1оТ != null) {
/* 446 */         return youcangetnoinfoECJMеа1оТ.getBorderInsets((Component)youcangetnoinfoECJOзЛэЫё);
/*     */       }
/*     */     } 
/* 449 */     return null;
/*     */   }
/*     */   
/*     */   public void uninstallCellPaddingBorder(Object youcangetnoinfoNWBЕ4ЧЮ3) {
/* 453 */     FlatComboBoxUI$CellPaddingBorder.uninstall(youcangetnoinfoNWBЕ4ЧЮ3);
/* 454 */     if (((FlatComboBoxUI)super).lastRendererComponent != null) {
/* 455 */       FlatComboBoxUI$CellPaddingBorder.uninstall(((FlatComboBoxUI)super).lastRendererComponent);
/* 456 */       ((FlatComboBoxUI)super).lastRendererComponent = null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatComboBoxUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */