/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Cursor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton
/*     */   extends FlatArrowButton
/*     */ {
/*     */   public final boolean left;
/*     */   public final FlatSplitPaneUI$FlatSplitPaneDivider this$1;
/*     */   
/*     */   public FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton(Object youcangetnoinfoBSORялбФз) {
/* 120 */     super(1, paramFlatSplitPaneUI$FlatSplitPaneDivider.this$0.arrowType, FlatSplitPaneUI.access$000(paramFlatSplitPaneUI$FlatSplitPaneDivider.this$0), (Color)null, FlatSplitPaneUI.access$100(paramFlatSplitPaneUI$FlatSplitPaneDivider.this$0), (Color)null);
/* 121 */     setCursor(Cursor.getPredefinedCursor(0));
/*     */     
/* 123 */     ((FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton)super).left = youcangetnoinfoBSORялбФз;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDirection() {
/* 128 */     return (FlatSplitPaneUI$FlatSplitPaneDivider.access$200(FlatSplitPaneUI$FlatSplitPaneDivider.this) == 0) ? (
/* 129 */       ((FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton)super).left ? 1 : 5) : (
/* 130 */       ((FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton)super).left ? 7 : 3);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */