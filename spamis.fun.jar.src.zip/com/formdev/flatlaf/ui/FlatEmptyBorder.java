/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.BorderUIResource;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatEmptyBorder
/*    */   extends BorderUIResource.EmptyBorderUIResource
/*    */ {
/*    */   public FlatEmptyBorder() {
/* 35 */     super(0, 0, 0, 0);
/*    */   }
/*    */   
/*    */   public FlatEmptyBorder(Object youcangetnoinfoBAJD8Зтёй, Object youcangetnoinfoBAJE2СохЧ, Object youcangetnoinfoBAJFнПаДЙ, Object youcangetnoinfoBAJGЪЮ2Ец) {
/* 39 */     super(youcangetnoinfoBAJD8Зтёй, youcangetnoinfoBAJE2СохЧ, youcangetnoinfoBAJFнПаДЙ, youcangetnoinfoBAJGЪЮ2Ец);
/*    */   }
/*    */   
/*    */   public FlatEmptyBorder(Object youcangetnoinfoAJKVё3СТЛ) {
/* 43 */     super((Insets)youcangetnoinfoAJKVё3СТЛ);
/*    */   }
/*    */ 
/*    */   
/*    */   public Insets getBorderInsets() {
/* 48 */     return new Insets(UIScale.scale(((FlatEmptyBorder)this).top), UIScale.scale(((FlatEmptyBorder)this).left), UIScale.scale(((FlatEmptyBorder)this).bottom), UIScale.scale(((FlatEmptyBorder)this).right));
/*    */   }
/*    */ 
/*    */   
/*    */   public Insets getBorderInsets(Object youcangetnoinfoEBVNр9Ь6Й, Object youcangetnoinfoEBVOзвху2) {
/* 53 */     boolean bool = (((FlatEmptyBorder)this).left == ((FlatEmptyBorder)this).right || youcangetnoinfoEBVNр9Ь6Й.getComponentOrientation().isLeftToRight()) ? true : false;
/* 54 */     ((Insets)youcangetnoinfoEBVOзвху2).left = UIScale.scale(bool ? ((FlatEmptyBorder)this).left : ((FlatEmptyBorder)this).right);
/* 55 */     ((Insets)youcangetnoinfoEBVOзвху2).top = UIScale.scale(((FlatEmptyBorder)this).top);
/* 56 */     ((Insets)youcangetnoinfoEBVOзвху2).right = UIScale.scale(bool ? ((FlatEmptyBorder)this).right : ((FlatEmptyBorder)this).left);
/* 57 */     ((Insets)youcangetnoinfoEBVOзвху2).bottom = UIScale.scale(((FlatEmptyBorder)this).bottom);
/* 58 */     return (Insets)youcangetnoinfoEBVOзвху2;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatEmptyBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */