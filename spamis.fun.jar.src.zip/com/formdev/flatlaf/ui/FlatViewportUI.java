/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import javax.swing.JComponent;
/*    */ import javax.swing.JViewport;
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ import javax.swing.plaf.basic.BasicViewportUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatViewportUI
/*    */   extends BasicViewportUI
/*    */ {
/*    */   public static ComponentUI instance;
/*    */   
/*    */   public static ComponentUI createUI(Object youcangetnoinfoBZLUЙЕ1З8) {
/* 44 */     if (instance == null)
/* 45 */       instance = new FlatViewportUI(); 
/* 46 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public void update(Object youcangetnoinfoCMZKЛйЩЖВ, Object youcangetnoinfoCMZLП8ГХщ) {
/* 51 */     Object youcangetnoinfoCMZMа9Ь2х = ((JViewport)youcangetnoinfoCMZLП8ГХщ).getView();
/* 52 */     if (youcangetnoinfoCMZLП8ГХщ.isOpaque() && youcangetnoinfoCMZMа9Ь2х instanceof javax.swing.JTable) {
/*    */       
/* 54 */       youcangetnoinfoCMZKЛйЩЖВ.setColor(youcangetnoinfoCMZMа9Ь2х.getBackground());
/* 55 */       youcangetnoinfoCMZKЛйЩЖВ.fillRect(0, 0, youcangetnoinfoCMZLП8ГХщ.getWidth(), youcangetnoinfoCMZLП8ГХщ.getHeight());
/*    */       
/* 57 */       paint((Graphics)youcangetnoinfoCMZKЛйЩЖВ, (JComponent)youcangetnoinfoCMZLП8ГХщ);
/*    */     } else {
/* 59 */       super.update((Graphics)youcangetnoinfoCMZKЛйЩЖВ, (JComponent)youcangetnoinfoCMZLП8ГХщ);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatViewportUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */