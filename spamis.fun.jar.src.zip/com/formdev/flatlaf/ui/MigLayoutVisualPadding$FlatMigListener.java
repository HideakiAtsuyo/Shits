package com.formdev.flatlaf.ui;

import java.beans.PropertyChangeListener;

public interface MigLayoutVisualPadding$FlatMigListener extends PropertyChangeListener {}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\MigLayoutVisualPadding$FlatMigListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */