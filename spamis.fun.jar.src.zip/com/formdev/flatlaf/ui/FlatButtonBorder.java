/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.GradientPaint;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Paint;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatButtonBorder
/*     */   extends FlatBorder
/*     */ {
/*     */   public final Color focusedBorderColor;
/*     */   public final Color defaultFocusColor;
/*     */   public final Color disabledBorderColor;
/*     */   public final Color defaultFocusedBorderColor;
/*     */   public final Color endBorderColor;
/*     */   public final Color hoverBorderColor;
/*     */   public final Color defaultBorderColor;
/*     */   public final Insets toolbarSpacingInsets;
/*     */   public final Color defaultEndBorderColor;
/*     */   public final Color borderColor;
/*     */   public final int defaultBorderWidth;
/*     */   public final int arc;
/*     */   public final Insets toolbarMargin;
/*     */   public final Color defaultHoverBorderColor;
/*     */   
/*     */   public FlatButtonBorder() {
/*  56 */     ((FlatButtonBorder)super).borderColor = FlatUIUtils.getUIColor("Button.startBorderColor", "Button.borderColor");
/*  57 */     ((FlatButtonBorder)super).endBorderColor = UIManager.getColor("Button.endBorderColor");
/*  58 */     ((FlatButtonBorder)super).disabledBorderColor = UIManager.getColor("Button.disabledBorderColor");
/*  59 */     ((FlatButtonBorder)super).focusedBorderColor = UIManager.getColor("Button.focusedBorderColor");
/*  60 */     ((FlatButtonBorder)super).hoverBorderColor = UIManager.getColor("Button.hoverBorderColor");
/*  61 */     ((FlatButtonBorder)super).defaultBorderColor = FlatUIUtils.getUIColor("Button.default.startBorderColor", "Button.default.borderColor");
/*  62 */     ((FlatButtonBorder)super).defaultEndBorderColor = UIManager.getColor("Button.default.endBorderColor");
/*  63 */     ((FlatButtonBorder)super).defaultHoverBorderColor = UIManager.getColor("Button.default.hoverBorderColor");
/*  64 */     ((FlatButtonBorder)super).defaultFocusedBorderColor = UIManager.getColor("Button.default.focusedBorderColor");
/*  65 */     ((FlatButtonBorder)super).defaultFocusColor = UIManager.getColor("Button.default.focusColor");
/*  66 */     ((FlatButtonBorder)super).defaultBorderWidth = UIManager.getInt("Button.default.borderWidth");
/*  67 */     ((FlatButtonBorder)super).toolbarMargin = UIManager.getInsets("Button.toolbar.margin");
/*  68 */     ((FlatButtonBorder)super).toolbarSpacingInsets = UIManager.getInsets("Button.toolbar.spacingInsets");
/*  69 */     ((FlatButtonBorder)super).arc = UIManager.getInt("Button.arc");
/*     */   }
/*     */   
/*     */   public void paintBorder(Object youcangetnoinfoATLX1хЯть, Object youcangetnoinfoATLYязъЕк, Object youcangetnoinfoATLZсмцЮэ, Object youcangetnoinfoATMAшгЙёЖ, Object youcangetnoinfoATMBТЁгРЯ, Object youcangetnoinfoATMCНЦкко) {
/*  73 */     if (FlatButtonUI.isContentAreaFilled((Component)youcangetnoinfoATLX1хЯть) && 
/*  74 */       !FlatButtonUI.isToolBarButton((Component)youcangetnoinfoATLX1хЯть) && 
/*  75 */       !FlatButtonUI.isHelpButton((Component)youcangetnoinfoATLX1хЯть) && 
/*  76 */       !FlatToggleButtonUI.isTabButton((Component)youcangetnoinfoATLX1хЯть)) {
/*  77 */       super.paintBorder((Component)youcangetnoinfoATLX1хЯть, (Graphics)youcangetnoinfoATLYязъЕк, youcangetnoinfoATLZсмцЮэ, youcangetnoinfoATMAшгЙёЖ, youcangetnoinfoATMBТЁгРЯ, youcangetnoinfoATMCНЦкко);
/*     */     }
/*     */   }
/*     */   
/*     */   public Color getFocusColor(Object youcangetnoinfoTNKезЯкР) {
/*  82 */     return FlatButtonUI.isDefaultButton((Component)youcangetnoinfoTNKезЯкР) ? ((FlatButtonBorder)super).defaultFocusColor : super.getFocusColor((Component)youcangetnoinfoTNKезЯкР);
/*     */   }
/*     */ 
/*     */   
/*     */   public Paint getBorderColor(Object youcangetnoinfoAXMPки8УО) {
/*  87 */     boolean bool = FlatButtonUI.isDefaultButton((Component)youcangetnoinfoAXMPки8УО);
/*  88 */     Object youcangetnoinfoAXMRкНм9В = FlatButtonUI.buttonStateColor((Component)youcangetnoinfoAXMPки8УО, 
/*  89 */         bool ? ((FlatButtonBorder)super).defaultBorderColor : ((FlatButtonBorder)super).borderColor, ((FlatButtonBorder)super).disabledBorderColor, 
/*     */         
/*  91 */         bool ? ((FlatButtonBorder)super).defaultFocusedBorderColor : ((FlatButtonBorder)super).focusedBorderColor, 
/*  92 */         bool ? ((FlatButtonBorder)super).defaultHoverBorderColor : ((FlatButtonBorder)super).hoverBorderColor, null);
/*     */ 
/*     */ 
/*     */     
/*  96 */     Object youcangetnoinfoAXMSЭдцЭр = bool ? ((FlatButtonBorder)super).defaultBorderColor : ((FlatButtonBorder)super).borderColor;
/*  97 */     Object youcangetnoinfoAXMTЁщИП9 = bool ? ((FlatButtonBorder)super).defaultEndBorderColor : ((FlatButtonBorder)super).endBorderColor;
/*  98 */     if (youcangetnoinfoAXMRкНм9В == youcangetnoinfoAXMSЭдцЭр && youcangetnoinfoAXMTЁщИП9 != null && !youcangetnoinfoAXMSЭдцЭр.equals(youcangetnoinfoAXMTЁщИП9)) {
/*  99 */       youcangetnoinfoAXMRкНм9В = new GradientPaint(0.0F, 0.0F, (Color)youcangetnoinfoAXMSЭдцЭр, 0.0F, youcangetnoinfoAXMPки8УО.getHeight(), (Color)youcangetnoinfoAXMTЁщИП9);
/*     */     }
/* 101 */     return (Paint)youcangetnoinfoAXMRкНм9В;
/*     */   }
/*     */ 
/*     */   
/*     */   public Insets getBorderInsets(Object youcangetnoinfoAAQD2Дк3м, Object youcangetnoinfoAAQEВИ4иЪ) {
/* 106 */     if (FlatButtonUI.isToolBarButton((Component)youcangetnoinfoAAQD2Дк3м)) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 111 */       Object youcangetnoinfoAAQB6эТХР = (youcangetnoinfoAAQD2Дк3м instanceof AbstractButton) ? ((AbstractButton)youcangetnoinfoAAQD2Дк3м).getMargin() : null;
/*     */       
/* 113 */       FlatUIUtils.setInsets((Insets)youcangetnoinfoAAQEВИ4иЪ, UIScale.scale(FlatUIUtils.addInsets(((FlatButtonBorder)super).toolbarSpacingInsets, (
/* 114 */               youcangetnoinfoAAQB6эТХР != null && !(youcangetnoinfoAAQB6эТХР instanceof javax.swing.plaf.UIResource)) ? (Insets)youcangetnoinfoAAQB6эТХР : ((FlatButtonBorder)super).toolbarMargin)));
/*     */     } else {
/* 116 */       youcangetnoinfoAAQEВИ4иЪ = super.getBorderInsets((Component)youcangetnoinfoAAQD2Дк3м, (Insets)youcangetnoinfoAAQEВИ4иЪ);
/*     */ 
/*     */       
/* 119 */       if (FlatButtonUI.isIconOnlyButton((Component)youcangetnoinfoAAQD2Дк3м) && ((AbstractButton)youcangetnoinfoAAQD2Дк3м).getMargin() instanceof javax.swing.plaf.UIResource) {
/* 120 */         ((Insets)youcangetnoinfoAAQEВИ4иЪ).left = ((Insets)youcangetnoinfoAAQEВИ4иЪ).right = Math.min(((Insets)youcangetnoinfoAAQEВИ4иЪ).top, ((Insets)youcangetnoinfoAAQEВИ4иЪ).bottom);
/*     */       }
/*     */     } 
/* 123 */     return (Insets)youcangetnoinfoAAQEВИ4иЪ;
/*     */   }
/*     */ 
/*     */   
/*     */   public float getFocusWidth(Object youcangetnoinfoBTRIпЁ0жв) {
/* 128 */     return FlatToggleButtonUI.isTabButton((Component)youcangetnoinfoBTRIпЁ0жв) ? 0.0F : super.getFocusWidth((Component)youcangetnoinfoBTRIпЁ0жв);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getBorderWidth(Object youcangetnoinfoBKKCНх1иЮ) {
/* 133 */     return FlatButtonUI.isDefaultButton((Component)youcangetnoinfoBKKCНх1иЮ) ? UIScale.scale(((FlatButtonBorder)super).defaultBorderWidth) : super.getBorderWidth((Component)youcangetnoinfoBKKCНх1иЮ);
/*     */   }
/*     */ 
/*     */   
/*     */   public float getArc(Object youcangetnoinfoDVINЫияРн) {
/* 138 */     return FlatButtonUI.isSquareButton((Component)youcangetnoinfoDVINЫияРн) ? 0.0F : UIScale.scale(((FlatButtonBorder)super).arc);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatButtonBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */