/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatScrollBarUI$2
/*     */   extends FlatArrowButton
/*     */ {
/*     */   public final FlatScrollBarUI this$0;
/*     */   
/*     */   public FlatScrollBarUI$2(Object youcangetnoinfoEPEEиЧдйФ, Object youcangetnoinfoEPEFезьпш, Object youcangetnoinfoEPEGЁzъЧС, Object youcangetnoinfoEPEHЯОцва, Object youcangetnoinfoEPEIЫФРМй, Object youcangetnoinfoEPEJбг2Сю) {
/* 173 */     super(youcangetnoinfoEPEEиЧдйФ, (String)youcangetnoinfoEPEFезьпш, (Color)youcangetnoinfoEPEGЁzъЧС, (Color)youcangetnoinfoEPEHЯОцва, (Color)youcangetnoinfoEPEIЫФРМй, (Color)youcangetnoinfoEPEJбг2Сю);
/*     */   }
/*     */   public Dimension getPreferredSize() {
/* 176 */     if (FlatScrollBarUI.access$500(((FlatScrollBarUI$2)super).this$0)) {
/* 177 */       int i = UIScale.scale(FlatScrollBarUI.access$600(((FlatScrollBarUI$2)super).this$0));
/* 178 */       return new Dimension(i, i);
/*     */     } 
/* 180 */     return new Dimension();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize() {
/* 185 */     return FlatScrollBarUI.access$500(((FlatScrollBarUI$2)super).this$0) ? super.getMinimumSize() : new Dimension();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumSize() {
/* 190 */     return FlatScrollBarUI.access$500(((FlatScrollBarUI$2)super).this$0) ? super.getMaximumSize() : new Dimension();
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatScrollBarUI$2.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */