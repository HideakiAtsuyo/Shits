/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import javax.swing.plaf.ComponentUI;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatPopupMenuSeparatorUI
/*    */   extends FlatSeparatorUI
/*    */ {
/*    */   public static ComponentUI instance;
/*    */   
/*    */   public static ComponentUI createUI(Object youcangetnoinfoEPUY4юуЬ0) {
/* 44 */     if (instance == null)
/* 45 */       instance = new FlatPopupMenuSeparatorUI(); 
/* 46 */     return instance;
/*    */   }
/*    */ 
/*    */   
/*    */   public String getPropertyPrefix() {
/* 51 */     return "PopupMenuSeparator";
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatPopupMenuSeparatorUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */