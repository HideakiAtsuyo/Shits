/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.FlatLaf;
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicHTML;
/*     */ import javax.swing.plaf.basic.BasicLabelUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatLabelUI
/*     */   extends BasicLabelUI
/*     */ {
/*     */   public Color disabledForeground;
/*     */   public static ComponentUI instance;
/*     */   public boolean defaults_initialized;
/*     */   
/*     */   public FlatLabelUI() {
/*  55 */     ((FlatLabelUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoBECTсЪВЙН) {
/*  60 */     if (instance == null)
/*  61 */       instance = new FlatLabelUI(); 
/*  62 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults(Object youcangetnoinfoAQPSвДУГГ) {
/*  67 */     super.installDefaults((JLabel)youcangetnoinfoAQPSвДУГГ);
/*     */     
/*  69 */     if (!((FlatLabelUI)super).defaults_initialized) {
/*  70 */       ((FlatLabelUI)super).disabledForeground = UIManager.getColor("Label.disabledForeground");
/*     */       
/*  72 */       ((FlatLabelUI)super).defaults_initialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults(Object youcangetnoinfoAUSBа1хуП) {
/*  78 */     super.uninstallDefaults((JLabel)youcangetnoinfoAUSBа1хуП);
/*  79 */     ((FlatLabelUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installComponents(Object youcangetnoinfoDAFBЬяфИн) {
/*  84 */     super.installComponents((JLabel)youcangetnoinfoDAFBЬяфИн);
/*     */ 
/*     */     
/*  87 */     updateHTMLRenderer((JComponent)youcangetnoinfoDAFBЬяфИн, youcangetnoinfoDAFBЬяфИн.getText(), false);
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(Object youcangetnoinfoCGZDр9ввА) {
/*  92 */     Object youcangetnoinfoCGZEцсчжм = youcangetnoinfoCGZDр9ввА.getPropertyName();
/*  93 */     if (youcangetnoinfoCGZEцсчжм == "text" || youcangetnoinfoCGZEцсчжм == "font" || youcangetnoinfoCGZEцсчжм == "foreground") {
/*  94 */       Object youcangetnoinfoCGZBпГсдз = youcangetnoinfoCGZDр9ввА.getSource();
/*  95 */       updateHTMLRenderer((JComponent)youcangetnoinfoCGZBпГсдз, youcangetnoinfoCGZBпГсдз.getText(), true);
/*     */     } else {
/*  97 */       super.propertyChange((PropertyChangeEvent)youcangetnoinfoCGZDр9ввА);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void updateHTMLRenderer(Object youcangetnoinfoEKYTЦЫгьЧ, Object youcangetnoinfoEKYUх9zлг, Object youcangetnoinfoEKYVлщДЖу) {
/* 105 */     if (BasicHTML.isHTMLString((String)youcangetnoinfoEKYUх9zлг) && youcangetnoinfoEKYTЦЫгьЧ
/* 106 */       .getClientProperty("html.disable") != Boolean.TRUE && youcangetnoinfoEKYUх9zлг
/* 107 */       .contains("<h") && (youcangetnoinfoEKYUх9zлг
/* 108 */       .contains("<h1") || youcangetnoinfoEKYUх9zлг.contains("<h2") || youcangetnoinfoEKYUх9zлг.contains("<h3") || youcangetnoinfoEKYUх9zлг
/* 109 */       .contains("<h4") || youcangetnoinfoEKYUх9zлг.contains("<h5") || youcangetnoinfoEKYUх9zлг.contains("<h6"))) {
/*     */       
/* 111 */       int i = youcangetnoinfoEKYUх9zлг.indexOf("<head>");
/*     */       
/* 113 */       Object youcangetnoinfoEKYRПЧЙ12 = "<style>BASE_SIZE " + youcangetnoinfoEKYTЦЫгьЧ.getFont().getSize() + "</style>";
/* 114 */       if (i < 0) {
/* 115 */         youcangetnoinfoEKYRПЧЙ12 = "<head>" + youcangetnoinfoEKYRПЧЙ12 + "</head>";
/*     */       }
/* 117 */       int j = (i >= 0) ? (i + "<head>".length()) : "<html>".length();
/*     */ 
/*     */       
/* 120 */       youcangetnoinfoEKYUх9zлг = youcangetnoinfoEKYUх9zлг.substring(0, j) + youcangetnoinfoEKYRПЧЙ12 + youcangetnoinfoEKYUх9zлг.substring(j);
/* 121 */     } else if (youcangetnoinfoEKYVлщДЖу == null) {
/*     */       return;
/*     */     } 
/* 124 */     BasicHTML.updateRenderer((JComponent)youcangetnoinfoEKYTЦЫгьЧ, (String)youcangetnoinfoEKYUх9zлг);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintEnabledText(Object youcangetnoinfoAKXLЁРузш, Object youcangetnoinfoAKXMзффЁЩ, Object youcangetnoinfoAKXNЙШлчь, Object youcangetnoinfoAKXOсЙДщЙ, Object youcangetnoinfoAKXPйЩЫЙг) {
/* 129 */     boolean bool = FlatLaf.isShowMnemonics() ? youcangetnoinfoAKXLЁРузш.getDisplayedMnemonicIndex() : true;
/* 130 */     youcangetnoinfoAKXMзффЁЩ.setColor(youcangetnoinfoAKXLЁРузш.getForeground());
/* 131 */     FlatUIUtils.drawStringUnderlineCharAt((JComponent)youcangetnoinfoAKXLЁРузш, (Graphics)youcangetnoinfoAKXMзффЁЩ, (String)youcangetnoinfoAKXNЙШлчь, bool, youcangetnoinfoAKXOсЙДщЙ, youcangetnoinfoAKXPйЩЫЙг);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintDisabledText(Object youcangetnoinfoDZMF03бп4, Object youcangetnoinfoDZMGанюЖЩ, Object youcangetnoinfoDZMHгиСПь, Object youcangetnoinfoDZMIФф52м, Object youcangetnoinfoDZMJпМХпУ) {
/* 136 */     boolean bool = FlatLaf.isShowMnemonics() ? youcangetnoinfoDZMF03бп4.getDisplayedMnemonicIndex() : true;
/* 137 */     youcangetnoinfoDZMGанюЖЩ.setColor(((FlatLabelUI)super).disabledForeground);
/* 138 */     FlatUIUtils.drawStringUnderlineCharAt((JComponent)youcangetnoinfoDZMF03бп4, (Graphics)youcangetnoinfoDZMGанюЖЩ, (String)youcangetnoinfoDZMHгиСПь, bool, youcangetnoinfoDZMIФф52м, youcangetnoinfoDZMJпМХпУ);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String layoutCL(Object youcangetnoinfoABFAаЮм7н, Object youcangetnoinfoABFBшку5Ю, Object youcangetnoinfoABFCхБк6ш, Object youcangetnoinfoABFDмБЦЧ7, Object youcangetnoinfoABFE4щЫщф, Object youcangetnoinfoABFFлЩ1ПТ, Object youcangetnoinfoABFG8В7ьЩ) {
/* 148 */     return SwingUtilities.layoutCompoundLabel((JComponent)youcangetnoinfoABFAаЮм7н, (FontMetrics)youcangetnoinfoABFBшку5Ю, (String)youcangetnoinfoABFCхБк6ш, (Icon)youcangetnoinfoABFDмБЦЧ7, youcangetnoinfoABFAаЮм7н
/* 149 */         .getVerticalAlignment(), youcangetnoinfoABFAаЮм7н.getHorizontalAlignment(), youcangetnoinfoABFAаЮм7н
/* 150 */         .getVerticalTextPosition(), youcangetnoinfoABFAаЮм7н.getHorizontalTextPosition(), (Rectangle)youcangetnoinfoABFE4щЫщф, (Rectangle)youcangetnoinfoABFFлЩ1ПТ, (Rectangle)youcangetnoinfoABFG8В7ьЩ, 
/*     */         
/* 152 */         UIScale.scale(youcangetnoinfoABFAаЮм7н.getIconTextGap()));
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatLabelUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */