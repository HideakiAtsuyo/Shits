/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.event.FocusEvent;
/*     */ import javax.swing.plaf.basic.BasicListUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatListUI$1
/*     */   extends BasicListUI.FocusHandler
/*     */ {
/*     */   public final FlatListUI this$0;
/*     */   
/*     */   public FlatListUI$1() {
/*  99 */     super((BasicListUI)youcangetnoinfoCNGBЙИ3фП);
/*     */   }
/*     */   public void focusGained(Object youcangetnoinfoDJNFЗЙянЯ) {
/* 102 */     super.focusGained((FocusEvent)youcangetnoinfoDJNFЗЙянЯ);
/* 103 */     FlatListUI.access$000(((FlatListUI$1)super).this$0, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost(Object youcangetnoinfoVLAЩкОае) {
/* 108 */     super.focusLost((FocusEvent)youcangetnoinfoVLAЩкОае);
/* 109 */     FlatListUI.access$000(((FlatListUI$1)super).this$0, false);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatListUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */