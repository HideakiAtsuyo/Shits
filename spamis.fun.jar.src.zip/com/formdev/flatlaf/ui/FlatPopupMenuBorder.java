/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import java.awt.Component;
/*    */ import java.awt.Container;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatPopupMenuBorder
/*    */   extends FlatLineBorder
/*    */ {
/*    */   public FlatPopupMenuBorder() {
/* 38 */     super(UIManager.getInsets("PopupMenu.borderInsets"), 
/* 39 */         UIManager.getColor("PopupMenu.borderColor"));
/*    */   }
/*    */ 
/*    */   
/*    */   public Insets getBorderInsets(Object youcangetnoinfoALFH2НсаЦ, Object youcangetnoinfoALFI7еВzЪ) {
/* 44 */     if (youcangetnoinfoALFH2НсаЦ instanceof Container && ((Container)youcangetnoinfoALFH2НсаЦ)
/* 45 */       .getComponentCount() > 0 && ((Container)youcangetnoinfoALFH2НсаЦ)
/* 46 */       .getComponent(0) instanceof javax.swing.JScrollPane) {
/*    */ 
/*    */       
/* 49 */       ((Insets)youcangetnoinfoALFI7еВzЪ).left = ((Insets)youcangetnoinfoALFI7еВzЪ).top = ((Insets)youcangetnoinfoALFI7еВzЪ).right = ((Insets)youcangetnoinfoALFI7еВzЪ).bottom = UIScale.scale(1);
/* 50 */       return (Insets)youcangetnoinfoALFI7еВzЪ;
/*    */     } 
/*    */     
/* 53 */     return super.getBorderInsets((Component)youcangetnoinfoALFH2НсаЦ, (Insets)youcangetnoinfoALFI7еВzЪ);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatPopupMenuBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */