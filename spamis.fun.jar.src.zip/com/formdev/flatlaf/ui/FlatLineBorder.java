/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import java.awt.Color;
/*    */ import java.awt.Graphics2D;
/*    */ import java.awt.Insets;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatLineBorder
/*    */   extends FlatEmptyBorder
/*    */ {
/*    */   public final Color lineColor;
/*    */   public final float lineThickness;
/*    */   
/*    */   public FlatLineBorder(Object youcangetnoinfoDLEZжВг5ю, Object youcangetnoinfoDLFAиЦЁбя) {
/* 42 */     super((Insets)youcangetnoinfoDLEZжВг5ю, (Color)youcangetnoinfoDLFAиЦЁбя, 1.0F);
/*    */   }
/*    */   
/*    */   public FlatLineBorder(Object youcangetnoinfoDQZCЕщЯЙв, Object youcangetnoinfoDQZDёБКЪЪ, Object youcangetnoinfoDQZEйэ3нО) {
/* 46 */     super((Insets)youcangetnoinfoDQZCЕщЯЙв);
/* 47 */     ((FlatLineBorder)super).lineColor = (Color)youcangetnoinfoDQZDёБКЪЪ;
/* 48 */     ((FlatLineBorder)super).lineThickness = youcangetnoinfoDQZEйэ3нО;
/*    */   }
/*    */ 
/*    */   
/*    */   public void paintBorder(Object youcangetnoinfoDNMOПЗЪНБ, Object youcangetnoinfoDNMPшГтЪИ, Object youcangetnoinfoDNMQхм8нк, Object youcangetnoinfoDNMRХочаы, Object youcangetnoinfoDNMSжВёПъ, Object youcangetnoinfoDNMTжршГг) {
/* 53 */     Object youcangetnoinfoDNMUдГzэс = youcangetnoinfoDNMPшГтЪИ.create();
/*    */     try {
/* 55 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoDNMUдГzэс);
/* 56 */       youcangetnoinfoDNMUдГzэс.setColor(((FlatLineBorder)super).lineColor);
/* 57 */       FlatUIUtils.paintComponentBorder((Graphics2D)youcangetnoinfoDNMUдГzэс, youcangetnoinfoDNMQхм8нк, youcangetnoinfoDNMRХочаы, youcangetnoinfoDNMSжВёПъ, youcangetnoinfoDNMTжршГг, 0.0F, UIScale.scale(((FlatLineBorder)super).lineThickness), 0.0F);
/*    */     } finally {
/* 59 */       youcangetnoinfoDNMUдГzэс.dispose();
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatLineBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */