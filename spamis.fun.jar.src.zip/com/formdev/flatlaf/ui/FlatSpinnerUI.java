/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Shape;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicSpinnerUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatSpinnerUI
/*     */   extends BasicSpinnerUI
/*     */ {
/*     */   public int arc;
/*     */   public int focusWidth;
/*     */   public Color disabledBackground;
/*     */   public boolean isIntelliJTheme;
/*     */   public Color borderColor;
/*     */   public Color buttonDisabledArrowColor;
/*     */   public Color buttonHoverArrowColor;
/*     */   public FlatSpinnerUI$Handler handler;
/*     */   public Insets padding;
/*     */   public String arrowType;
/*     */   public Color disabledForeground;
/*     */   public Color buttonBackground;
/*     */   public Color buttonArrowColor;
/*     */   public Color disabledBorderColor;
/*     */   public int minimumWidth;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoCEDVКГхОЁ) {
/*  97 */     return new FlatSpinnerUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/* 102 */     super.installDefaults();
/*     */     
/* 104 */     LookAndFeel.installProperty(((FlatSpinnerUI)this).spinner, "opaque", Boolean.valueOf(false));
/*     */     
/* 106 */     ((FlatSpinnerUI)super).focusWidth = UIManager.getInt("Component.focusWidth");
/* 107 */     ((FlatSpinnerUI)super).arc = UIManager.getInt("Component.arc");
/* 108 */     ((FlatSpinnerUI)super).minimumWidth = UIManager.getInt("Component.minimumWidth");
/* 109 */     ((FlatSpinnerUI)super).arrowType = UIManager.getString("Component.arrowType");
/* 110 */     ((FlatSpinnerUI)super).isIntelliJTheme = UIManager.getBoolean("Component.isIntelliJTheme");
/* 111 */     ((FlatSpinnerUI)super).borderColor = UIManager.getColor("Component.borderColor");
/* 112 */     ((FlatSpinnerUI)super).disabledBorderColor = UIManager.getColor("Component.disabledBorderColor");
/* 113 */     ((FlatSpinnerUI)super).disabledBackground = UIManager.getColor("Spinner.disabledBackground");
/* 114 */     ((FlatSpinnerUI)super).disabledForeground = UIManager.getColor("Spinner.disabledForeground");
/* 115 */     ((FlatSpinnerUI)super).buttonBackground = UIManager.getColor("Spinner.buttonBackground");
/* 116 */     ((FlatSpinnerUI)super).buttonArrowColor = UIManager.getColor("Spinner.buttonArrowColor");
/* 117 */     ((FlatSpinnerUI)super).buttonDisabledArrowColor = UIManager.getColor("Spinner.buttonDisabledArrowColor");
/* 118 */     ((FlatSpinnerUI)super).buttonHoverArrowColor = UIManager.getColor("Spinner.buttonHoverArrowColor");
/* 119 */     ((FlatSpinnerUI)super).padding = UIManager.getInsets("Spinner.padding");
/*     */ 
/*     */     
/* 122 */     ((FlatSpinnerUI)super).padding = UIScale.scale(((FlatSpinnerUI)super).padding);
/*     */     
/* 124 */     MigLayoutVisualPadding.install(((FlatSpinnerUI)this).spinner, ((FlatSpinnerUI)super).focusWidth);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/* 129 */     super.uninstallDefaults();
/*     */     
/* 131 */     ((FlatSpinnerUI)super).borderColor = null;
/* 132 */     ((FlatSpinnerUI)super).disabledBorderColor = null;
/* 133 */     ((FlatSpinnerUI)super).disabledBackground = null;
/* 134 */     ((FlatSpinnerUI)super).disabledForeground = null;
/* 135 */     ((FlatSpinnerUI)super).buttonBackground = null;
/* 136 */     ((FlatSpinnerUI)super).buttonArrowColor = null;
/* 137 */     ((FlatSpinnerUI)super).buttonDisabledArrowColor = null;
/* 138 */     ((FlatSpinnerUI)super).buttonHoverArrowColor = null;
/* 139 */     ((FlatSpinnerUI)super).padding = null;
/*     */     
/* 141 */     MigLayoutVisualPadding.uninstall(((FlatSpinnerUI)this).spinner);
/*     */   }
/*     */ 
/*     */   
/*     */   public void installListeners() {
/* 146 */     super.installListeners();
/*     */     
/* 148 */     super.addEditorFocusListener(((FlatSpinnerUI)this).spinner.getEditor());
/* 149 */     ((FlatSpinnerUI)this).spinner.addPropertyChangeListener(super.getHandler());
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners() {
/* 154 */     super.uninstallListeners();
/*     */     
/* 156 */     super.removeEditorFocusListener(((FlatSpinnerUI)this).spinner.getEditor());
/* 157 */     ((FlatSpinnerUI)this).spinner.removePropertyChangeListener(super.getHandler());
/*     */     
/* 159 */     ((FlatSpinnerUI)super).handler = null;
/*     */   }
/*     */   
/*     */   public FlatSpinnerUI$Handler getHandler() {
/* 163 */     if (((FlatSpinnerUI)super).handler == null)
/* 164 */       ((FlatSpinnerUI)super).handler = new FlatSpinnerUI$Handler((FlatSpinnerUI)this, null); 
/* 165 */     return ((FlatSpinnerUI)super).handler;
/*     */   }
/*     */ 
/*     */   
/*     */   public JComponent createEditor() {
/* 170 */     Object youcangetnoinfoAAZIапЦ4ь = super.createEditor();
/*     */ 
/*     */     
/* 173 */     youcangetnoinfoAAZIапЦ4ь.setOpaque(false);
/* 174 */     Object youcangetnoinfoAAZJ3еуцО = super.getEditorTextField((JComponent)youcangetnoinfoAAZIапЦ4ь);
/* 175 */     if (youcangetnoinfoAAZJ3еуцО != null) {
/* 176 */       youcangetnoinfoAAZJ3еуцО.setOpaque(false);
/*     */     }
/* 178 */     super.updateEditorColors();
/* 179 */     return (JComponent)youcangetnoinfoAAZIапЦ4ь;
/*     */   }
/*     */ 
/*     */   
/*     */   public void replaceEditor(Object youcangetnoinfoBVJXл2Окё, Object youcangetnoinfoBVJY6ЖВА1) {
/* 184 */     super.replaceEditor((JComponent)youcangetnoinfoBVJXл2Окё, (JComponent)youcangetnoinfoBVJY6ЖВА1);
/*     */     
/* 186 */     super.removeEditorFocusListener((JComponent)youcangetnoinfoBVJXл2Окё);
/* 187 */     super.addEditorFocusListener((JComponent)youcangetnoinfoBVJY6ЖВА1);
/* 188 */     super.updateEditorColors();
/*     */   }
/*     */   
/*     */   public void addEditorFocusListener(Object youcangetnoinfoBRBBПвйЫя) {
/* 192 */     Object youcangetnoinfoBRBCП1ъжД = super.getEditorTextField((JComponent)youcangetnoinfoBRBBПвйЫя);
/* 193 */     if (youcangetnoinfoBRBCП1ъжД != null)
/* 194 */       youcangetnoinfoBRBCП1ъжД.addFocusListener(super.getHandler()); 
/*     */   }
/*     */   
/*     */   public void removeEditorFocusListener(Object youcangetnoinfoDLVEШз9В8) {
/* 198 */     Object youcangetnoinfoDLVF5МИЙЫ = super.getEditorTextField((JComponent)youcangetnoinfoDLVEШз9В8);
/* 199 */     if (youcangetnoinfoDLVF5МИЙЫ != null)
/* 200 */       youcangetnoinfoDLVF5МИЙЫ.removeFocusListener(super.getHandler()); 
/*     */   }
/*     */   
/*     */   public void updateEditorColors() {
/* 204 */     Object youcangetnoinfoTKCШФдПч = super.getEditorTextField(((FlatSpinnerUI)this).spinner.getEditor());
/* 205 */     if (youcangetnoinfoTKCШФдПч != null) {
/*     */ 
/*     */ 
/*     */       
/* 209 */       youcangetnoinfoTKCШФдПч.setForeground(FlatUIUtils.nonUIResource(((FlatSpinnerUI)this).spinner.getForeground()));
/* 210 */       youcangetnoinfoTKCШФдПч.setDisabledTextColor(FlatUIUtils.nonUIResource(((FlatSpinnerUI)super).disabledForeground));
/*     */     } 
/*     */   }
/*     */   
/*     */   public JTextField getEditorTextField(Object youcangetnoinfoDRVUкКЖЬн) {
/* 215 */     return (youcangetnoinfoDRVUкКЖЬн instanceof JSpinner.DefaultEditor) ? (
/* 216 */       (JSpinner.DefaultEditor)youcangetnoinfoDRVUкКЖЬн).getTextField() : 
/* 217 */       null;
/*     */   }
/*     */ 
/*     */   
/*     */   public LayoutManager createLayout() {
/* 222 */     return super.getHandler();
/*     */   }
/*     */ 
/*     */   
/*     */   public Component createNextButton() {
/* 227 */     return super.createArrowButton(1, "Spinner.nextButton");
/*     */   }
/*     */ 
/*     */   
/*     */   public Component createPreviousButton() {
/* 232 */     return super.createArrowButton(5, "Spinner.previousButton");
/*     */   }
/*     */   
/*     */   public Component createArrowButton(Object youcangetnoinfoBWADУрЮъМ, Object youcangetnoinfoBWAEжКБЕи) {
/* 236 */     Object youcangetnoinfoBWAFёхЯПи = new FlatArrowButton(youcangetnoinfoBWADУрЮъМ, ((FlatSpinnerUI)super).arrowType, ((FlatSpinnerUI)super).buttonArrowColor, ((FlatSpinnerUI)super).buttonDisabledArrowColor, ((FlatSpinnerUI)super).buttonHoverArrowColor, null);
/*     */     
/* 238 */     youcangetnoinfoBWAFёхЯПи.setName((String)youcangetnoinfoBWAEжКБЕи);
/* 239 */     youcangetnoinfoBWAFёхЯПи.setYOffset((youcangetnoinfoBWADУрЮъМ == true) ? 1 : -1);
/* 240 */     if (youcangetnoinfoBWADУрЮъМ == true) {
/* 241 */       installNextButtonListeners((Component)youcangetnoinfoBWAFёхЯПи);
/*     */     } else {
/* 243 */       installPreviousButtonListeners((Component)youcangetnoinfoBWAFёхЯПи);
/* 244 */     }  return (Component)youcangetnoinfoBWAFёхЯПи;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void update(Object youcangetnoinfoCDNQщЯъПН, Object youcangetnoinfoCDNR6УПЬш) {
/* 250 */     if (youcangetnoinfoCDNR6УПЬш.isOpaque() && (((FlatSpinnerUI)super).focusWidth > 0 || ((FlatSpinnerUI)super).arc != 0)) {
/* 251 */       FlatUIUtils.paintParentBackground((Graphics)youcangetnoinfoCDNQщЯъПН, (JComponent)youcangetnoinfoCDNR6УПЬш);
/*     */     }
/* 253 */     Object youcangetnoinfoCDNSХшОчэ = youcangetnoinfoCDNQщЯъПН;
/* 254 */     FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoCDNSХшОчэ);
/*     */     
/* 256 */     int i = youcangetnoinfoCDNR6УПЬш.getWidth();
/* 257 */     int j = youcangetnoinfoCDNR6УПЬш.getHeight();
/* 258 */     float f1 = (youcangetnoinfoCDNR6УПЬш.getBorder() instanceof FlatBorder) ? UIScale.scale(((FlatSpinnerUI)super).focusWidth) : 0.0F;
/* 259 */     float f2 = (youcangetnoinfoCDNR6УПЬш.getBorder() instanceof FlatRoundBorder) ? UIScale.scale(((FlatSpinnerUI)super).arc) : 0.0F;
/* 260 */     Object youcangetnoinfoCDNXхВЕкд = FlatSpinnerUI$Handler.access$100(super.getHandler());
/* 261 */     int k = youcangetnoinfoCDNXхВЕкд.getX();
/* 262 */     int m = youcangetnoinfoCDNXхВЕкд.getWidth();
/* 263 */     boolean bool1 = ((FlatSpinnerUI)this).spinner.isEnabled();
/* 264 */     boolean bool2 = ((FlatSpinnerUI)this).spinner.getComponentOrientation().isLeftToRight();
/*     */ 
/*     */     
/* 267 */     youcangetnoinfoCDNSХшОчэ.setColor(bool1 ? 
/* 268 */         youcangetnoinfoCDNR6УПЬш.getBackground() : (
/* 269 */         ((FlatSpinnerUI)super).isIntelliJTheme ? FlatUIUtils.getParentBackground((JComponent)youcangetnoinfoCDNR6УПЬш) : ((FlatSpinnerUI)super).disabledBackground));
/* 270 */     FlatUIUtils.paintComponentBackground((Graphics2D)youcangetnoinfoCDNSХшОчэ, 0, 0, i, j, f1, f2);
/*     */ 
/*     */     
/* 273 */     if (bool1) {
/* 274 */       youcangetnoinfoCDNSХшОчэ.setColor(((FlatSpinnerUI)super).buttonBackground);
/* 275 */       Object youcangetnoinfoCDNOКОжвэ = youcangetnoinfoCDNSХшОчэ.getClip();
/* 276 */       if (bool2) {
/* 277 */         youcangetnoinfoCDNSХшОчэ.clipRect(k, 0, i - k, j);
/*     */       } else {
/* 279 */         youcangetnoinfoCDNSХшОчэ.clipRect(0, 0, k + m, j);
/* 280 */       }  FlatUIUtils.paintComponentBackground((Graphics2D)youcangetnoinfoCDNSХшОчэ, 0, 0, i, j, f1, f2);
/* 281 */       youcangetnoinfoCDNSХшОчэ.setClip((Shape)youcangetnoinfoCDNOКОжвэ);
/*     */     } 
/*     */ 
/*     */     
/* 285 */     youcangetnoinfoCDNSХшОчэ.setColor(bool1 ? ((FlatSpinnerUI)super).borderColor : ((FlatSpinnerUI)super).disabledBorderColor);
/* 286 */     float f3 = UIScale.scale(1.0F);
/* 287 */     float f4 = bool2 ? k : ((k + m) - f3);
/* 288 */     youcangetnoinfoCDNSХшОчэ.fill(new Rectangle2D.Float(f4, f1, f3, (j - 1) - f1 * 2.0F));
/*     */     
/* 290 */     paint((Graphics)youcangetnoinfoCDNQщЯъПН, (JComponent)youcangetnoinfoCDNR6УПЬш);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatSpinnerUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */