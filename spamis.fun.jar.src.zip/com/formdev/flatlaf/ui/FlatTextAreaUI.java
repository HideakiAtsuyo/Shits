/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTextAreaUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTextAreaUI
/*     */   extends BasicTextAreaUI
/*     */ {
/*     */   public Color inactiveBackground;
/*     */   public Color disabledBackground;
/*     */   public int minimumWidth;
/*     */   public boolean isIntelliJTheme;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoAXLUввБ8Ж) {
/*  65 */     return new FlatTextAreaUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  70 */     super.installDefaults();
/*     */     
/*  72 */     ((FlatTextAreaUI)super).minimumWidth = UIManager.getInt("Component.minimumWidth");
/*  73 */     ((FlatTextAreaUI)super).isIntelliJTheme = UIManager.getBoolean("Component.isIntelliJTheme");
/*  74 */     ((FlatTextAreaUI)super).disabledBackground = UIManager.getColor("TextArea.disabledBackground");
/*  75 */     ((FlatTextAreaUI)super).inactiveBackground = UIManager.getColor("TextArea.inactiveBackground");
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/*  80 */     super.uninstallDefaults();
/*     */     
/*  82 */     ((FlatTextAreaUI)super).disabledBackground = null;
/*  83 */     ((FlatTextAreaUI)super).inactiveBackground = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoDALAёТЕйя) {
/*  88 */     Object youcangetnoinfoDALBхщШАю = getComponent();
/*     */     
/*  90 */     Object youcangetnoinfoDALCЧФБЦм = youcangetnoinfoDALBхщШАю.getBackground();
/*  91 */     youcangetnoinfoDALAёТЕйя.setColor(!(youcangetnoinfoDALCЧФБЦм instanceof javax.swing.plaf.UIResource) ? 
/*  92 */         (Color)youcangetnoinfoDALCЧФБЦм : (
/*  93 */         (((FlatTextAreaUI)super).isIntelliJTheme && (!youcangetnoinfoDALBхщШАю.isEnabled() || !youcangetnoinfoDALBхщШАю.isEditable())) ? 
/*  94 */         FlatUIUtils.getParentBackground((JComponent)youcangetnoinfoDALBхщШАю) : (
/*  95 */         !youcangetnoinfoDALBхщШАю.isEnabled() ? 
/*  96 */         ((FlatTextAreaUI)super).disabledBackground : (
/*  97 */         !youcangetnoinfoDALBхщШАю.isEditable() ? ((FlatTextAreaUI)super).inactiveBackground : (Color)youcangetnoinfoDALCЧФБЦм))));
/*  98 */     youcangetnoinfoDALAёТЕйя.fillRect(0, 0, youcangetnoinfoDALBхщШАю.getWidth(), youcangetnoinfoDALBхщШАю.getHeight());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoDUZSоЗЮ1ч) {
/* 103 */     return super.applyMinimumWidth(super.getPreferredSize((JComponent)youcangetnoinfoDUZSоЗЮ1ч), (JComponent)youcangetnoinfoDUZSоЗЮ1ч);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(Object youcangetnoinfoDUН8Цz6) {
/* 108 */     return super.applyMinimumWidth(super.getMinimumSize((JComponent)youcangetnoinfoDUН8Цz6), (JComponent)youcangetnoinfoDUН8Цz6);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension applyMinimumWidth(Object youcangetnoinfoCNVKыА58ь, Object youcangetnoinfoCNVLыяИ7Б) {
/* 113 */     if (youcangetnoinfoCNVLыяИ7Б instanceof JTextArea && ((JTextArea)youcangetnoinfoCNVLыяИ7Б).getColumns() > 0) {
/* 114 */       return (Dimension)youcangetnoinfoCNVKыА58ь;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     int i = FlatUIUtils.minimumWidth(getComponent(), ((FlatTextAreaUI)super).minimumWidth);
/* 121 */     ((Dimension)youcangetnoinfoCNVKыА58ь).width = Math.max(((Dimension)youcangetnoinfoCNVKыА58ь).width, UIScale.scale(i) - UIScale.scale(1) * 2);
/* 122 */     return (Dimension)youcangetnoinfoCNVKыА58ь;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTextAreaUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */