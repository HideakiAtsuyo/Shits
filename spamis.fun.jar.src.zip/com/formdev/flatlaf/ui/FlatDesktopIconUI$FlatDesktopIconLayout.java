/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatDesktopIconUI$FlatDesktopIconLayout
/*     */   implements LayoutManager
/*     */ {
/*     */   public final FlatDesktopIconUI this$0;
/*     */   
/*     */   public FlatDesktopIconUI$FlatDesktopIconLayout() {
/* 278 */     this(); } public FlatDesktopIconUI$FlatDesktopIconLayout(Object youcangetnoinfoDZNIзНСпЦ) { super((FlatDesktopIconUI)youcangetnoinfoDZNHЖ88Еч); }
/*     */ 
/*     */   
/*     */   public void addLayoutComponent(Object youcangetnoinfoCBFWнЙМЙх, Object youcangetnoinfoCBFXЕсСЖЕ) {}
/*     */   
/*     */   public void removeLayoutComponent(Object youcangetnoinfoBHFYАЖЮщя) {}
/*     */   
/*     */   public Dimension preferredLayoutSize(Object youcangetnoinfoNJJНееО9) {
/* 286 */     return FlatDesktopIconUI.access$800(FlatDesktopIconUI.this).getPreferredSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension minimumLayoutSize(Object youcangetnoinfoCBGLЗчКоМ) {
/* 291 */     return FlatDesktopIconUI.access$800(FlatDesktopIconUI.this).getMinimumSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public void layoutContainer(Object youcangetnoinfoANPNсАШюИ) {
/* 296 */     Object youcangetnoinfoANPOИЛвшГ = youcangetnoinfoANPNсАШюИ.getInsets();
/*     */ 
/*     */     
/* 299 */     FlatDesktopIconUI.access$800(FlatDesktopIconUI.this).setBounds(((Insets)youcangetnoinfoANPOИЛвшГ).left, ((Insets)youcangetnoinfoANPOИЛвшГ).top, youcangetnoinfoANPNсАШюИ
/* 300 */         .getWidth() - ((Insets)youcangetnoinfoANPOИЛвшГ).left - ((Insets)youcangetnoinfoANPOИЛвшГ).right, youcangetnoinfoANPNсАШюИ
/* 301 */         .getHeight() - ((Insets)youcangetnoinfoANPOИЛвшГ).top - ((Insets)youcangetnoinfoANPOИЛвшГ).bottom);
/*     */ 
/*     */     
/* 304 */     Object youcangetnoinfoANPPчщЖ3д = UIScale.scale(FlatDesktopIconUI.access$900(FlatDesktopIconUI.this));
/* 305 */     FlatDesktopIconUI.access$400(FlatDesktopIconUI.this).setBounds(youcangetnoinfoANPNсАШюИ.getWidth() - ((Dimension)youcangetnoinfoANPPчщЖ3д).width, 0, ((Dimension)youcangetnoinfoANPPчщЖ3д).width, ((Dimension)youcangetnoinfoANPPчщЖ3д).height);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatDesktopIconUI$FlatDesktopIconLayout.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */