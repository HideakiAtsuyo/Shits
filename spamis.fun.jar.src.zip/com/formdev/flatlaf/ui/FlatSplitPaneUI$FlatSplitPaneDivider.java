/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.plaf.basic.BasicSplitPaneDivider;
/*     */ import javax.swing.plaf.basic.BasicSplitPaneUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatSplitPaneUI$FlatSplitPaneDivider
/*     */   extends BasicSplitPaneDivider
/*     */ {
/*     */   public final FlatSplitPaneUI this$0;
/*     */   
/*     */   public FlatSplitPaneUI$FlatSplitPaneDivider(Object youcangetnoinfoCPVCИЬиЦе) {
/*  94 */     super((BasicSplitPaneUI)youcangetnoinfoCPVCИЬиЦе);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setDividerSize(Object youcangetnoinfoCZFGкрОюё) {
/*  99 */     super.setDividerSize(UIScale.scale(youcangetnoinfoCZFGкрОюё));
/*     */   }
/*     */ 
/*     */   
/*     */   public JButton createLeftOneTouchButton() {
/* 104 */     return new FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton((FlatSplitPaneUI$FlatSplitPaneDivider)this, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public JButton createRightOneTouchButton() {
/* 109 */     return new FlatSplitPaneUI$FlatSplitPaneDivider$FlatOneTouchButton((FlatSplitPaneUI$FlatSplitPaneDivider)this, false);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatSplitPaneUI$FlatSplitPaneDivider.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */