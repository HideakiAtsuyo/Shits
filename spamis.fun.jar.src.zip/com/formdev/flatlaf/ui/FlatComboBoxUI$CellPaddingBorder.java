/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.lang.ref.WeakReference;
/*     */ import javax.swing.border.AbstractBorder;
/*     */ import javax.swing.border.Border;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatComboBoxUI$CellPaddingBorder
/*     */   extends AbstractBorder
/*     */ {
/*     */   public final Insets padding;
/*     */   public Border rendererBorder;
/*     */   
/*     */   public FlatComboBoxUI$CellPaddingBorder(Object youcangetnoinfoBDFFэРк9Ш) {
/* 575 */     ((FlatComboBoxUI$CellPaddingBorder)super).padding = (Insets)youcangetnoinfoBDFFэРк9Ш;
/*     */   }
/*     */   
/*     */   public void install(Object youcangetnoinfoCAQC9цтню) {
/* 579 */     Object youcangetnoinfoCAQDБсгиу = youcangetnoinfoCAQC9цтню.getBorder();
/* 580 */     if (!(youcangetnoinfoCAQDБсгиу instanceof FlatComboBoxUI$CellPaddingBorder)) {
/* 581 */       ((FlatComboBoxUI$CellPaddingBorder)super).rendererBorder = (Border)youcangetnoinfoCAQDБсгиу;
/* 582 */       youcangetnoinfoCAQC9цтню.setBorder((Border)this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void uninstall(Object youcangetnoinfoCGUS59эЛЬ) {
/* 587 */     if (youcangetnoinfoCGUS59эЛЬ instanceof WeakReference) {
/* 588 */       youcangetnoinfoCGUS59эЛЬ = ((WeakReference)youcangetnoinfoCGUS59эЛЬ).get();
/*     */     }
/* 590 */     if (!(youcangetnoinfoCGUS59эЛЬ instanceof javax.swing.JComponent)) {
/*     */       return;
/*     */     }
/* 593 */     Object youcangetnoinfoCGUT31ЁХ1 = youcangetnoinfoCGUS59эЛЬ;
/* 594 */     Object youcangetnoinfoCGUUамКЦи = youcangetnoinfoCGUT31ЁХ1.getBorder();
/* 595 */     if (youcangetnoinfoCGUUамКЦи instanceof FlatComboBoxUI$CellPaddingBorder) {
/* 596 */       Object youcangetnoinfoCGURмбг5г = youcangetnoinfoCGUUамКЦи;
/* 597 */       youcangetnoinfoCGUT31ЁХ1.setBorder(((FlatComboBoxUI$CellPaddingBorder)youcangetnoinfoCGURмбг5г).rendererBorder);
/* 598 */       ((FlatComboBoxUI$CellPaddingBorder)youcangetnoinfoCGURмбг5г).rendererBorder = null;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Insets getBorderInsets(Object youcangetnoinfoBQJDйБ7аС, Object youcangetnoinfoBQJEыЯХгч) {
/* 604 */     if (((FlatComboBoxUI$CellPaddingBorder)super).rendererBorder != null) {
/* 605 */       Object youcangetnoinfoBQJBбААюш = ((FlatComboBoxUI$CellPaddingBorder)super).rendererBorder.getBorderInsets((Component)youcangetnoinfoBQJDйБ7аС);
/* 606 */       ((Insets)youcangetnoinfoBQJEыЯХгч).top = Math.max(((FlatComboBoxUI$CellPaddingBorder)super).padding.top, ((Insets)youcangetnoinfoBQJBбААюш).top);
/* 607 */       ((Insets)youcangetnoinfoBQJEыЯХгч).left = Math.max(((FlatComboBoxUI$CellPaddingBorder)super).padding.left, ((Insets)youcangetnoinfoBQJBбААюш).left);
/* 608 */       ((Insets)youcangetnoinfoBQJEыЯХгч).bottom = Math.max(((FlatComboBoxUI$CellPaddingBorder)super).padding.bottom, ((Insets)youcangetnoinfoBQJBбААюш).bottom);
/* 609 */       ((Insets)youcangetnoinfoBQJEыЯХгч).right = Math.max(((FlatComboBoxUI$CellPaddingBorder)super).padding.right, ((Insets)youcangetnoinfoBQJBбААюш).right);
/*     */     } else {
/* 611 */       ((Insets)youcangetnoinfoBQJEыЯХгч).top = ((FlatComboBoxUI$CellPaddingBorder)super).padding.top;
/* 612 */       ((Insets)youcangetnoinfoBQJEыЯХгч).left = ((FlatComboBoxUI$CellPaddingBorder)super).padding.left;
/* 613 */       ((Insets)youcangetnoinfoBQJEыЯХгч).bottom = ((FlatComboBoxUI$CellPaddingBorder)super).padding.bottom;
/* 614 */       ((Insets)youcangetnoinfoBQJEыЯХгч).right = ((FlatComboBoxUI$CellPaddingBorder)super).padding.right;
/*     */     } 
/* 616 */     return (Insets)youcangetnoinfoBQJEыЯХгч;
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBorder(Object youcangetnoinfoAEOWяЦпйф, Object youcangetnoinfoAEOX89лРа, Object youcangetnoinfoAEOY4РфнЪ, Object youcangetnoinfoAEOZщёВат, Object youcangetnoinfoAEPAТлпчо, Object youcangetnoinfoAEPBхжСгР) {
/* 621 */     if (((FlatComboBoxUI$CellPaddingBorder)super).rendererBorder != null)
/* 622 */       ((FlatComboBoxUI$CellPaddingBorder)super).rendererBorder.paintBorder((Component)youcangetnoinfoAEOWяЦпйф, (Graphics)youcangetnoinfoAEOX89лРа, youcangetnoinfoAEOY4РфнЪ, youcangetnoinfoAEOZщёВат, youcangetnoinfoAEPAТлпчо, youcangetnoinfoAEPBхжСгР); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatComboBoxUI$CellPaddingBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */