/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.event.KeyAdapter;
/*     */ import java.awt.event.KeyEvent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatPasswordFieldUI$1
/*     */   extends KeyAdapter
/*     */ {
/*     */   public final FlatPasswordFieldUI this$0;
/*     */   
/*     */   public void keyPressed(Object youcangetnoinfoADNAУЭ0Щг) {
/* 122 */     super.repaint((KeyEvent)youcangetnoinfoADNAУЭ0Щг);
/*     */   }
/*     */   
/*     */   public void keyReleased(Object youcangetnoinfoAMRHяН9фР) {
/* 126 */     super.repaint((KeyEvent)youcangetnoinfoAMRHяН9фР);
/*     */   }
/*     */   public void repaint(Object youcangetnoinfoHTHчуЛ71) {
/* 129 */     if (youcangetnoinfoHTHчуЛ71.getKeyCode() == 20)
/* 130 */       youcangetnoinfoHTHчуЛ71.getComponent().repaint(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatPasswordFieldUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */