/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.event.MouseAdapter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatScrollBarUI$ScrollBarHoverListener
/*     */   extends MouseAdapter
/*     */ {
/*     */   public final FlatScrollBarUI this$0;
/*     */   
/*     */   public FlatScrollBarUI$ScrollBarHoverListener() {}
/*     */   
/*     */   public FlatScrollBarUI$ScrollBarHoverListener(Object youcangetnoinfoFOCЮуЯдК) {
/* 246 */     super((FlatScrollBarUI)youcangetnoinfoFOBг1ЦИЬ);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseExited(Object youcangetnoinfoBYXDн5яЗы) {
/* 251 */     if (!FlatScrollBarUI.access$700()) {
/* 252 */       FlatScrollBarUI.access$802(FlatScrollBarUI.this, FlatScrollBarUI.access$902(FlatScrollBarUI.this, false));
/* 253 */       super.repaint();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseMoved(Object youcangetnoinfoEMMLтЕёёН) {
/* 259 */     if (!FlatScrollBarUI.access$700()) {
/* 260 */       super.update(youcangetnoinfoEMMLтЕёёН.getX(), youcangetnoinfoEMMLтЕёёН.getY());
/*     */     }
/*     */   }
/*     */   
/*     */   public void mousePressed(Object youcangetnoinfoEBBSКСпюб) {
/* 265 */     FlatScrollBarUI.access$702(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseReleased(Object youcangetnoinfoBLAWЧйЁСп) {
/* 270 */     FlatScrollBarUI.access$702(false);
/* 271 */     super.update(youcangetnoinfoBLAWЧйЁСп.getX(), youcangetnoinfoBLAWЧйЁСп.getY());
/*     */   }
/*     */   
/*     */   public void update(Object youcangetnoinfoENYUфяЁ7Ю, Object youcangetnoinfoENYVниДцх) {
/* 275 */     boolean bool1 = FlatScrollBarUI.access$1000(FlatScrollBarUI.this).contains(youcangetnoinfoENYUфяЁ7Ю, youcangetnoinfoENYVниДцх);
/* 276 */     boolean bool2 = FlatScrollBarUI.access$1100(FlatScrollBarUI.this).contains(youcangetnoinfoENYUфяЁ7Ю, youcangetnoinfoENYVниДцх);
/* 277 */     if (bool1 != FlatScrollBarUI.access$800(FlatScrollBarUI.this) || bool2 != FlatScrollBarUI.access$900(FlatScrollBarUI.this)) {
/* 278 */       FlatScrollBarUI.access$802(FlatScrollBarUI.this, bool1);
/* 279 */       FlatScrollBarUI.access$902(FlatScrollBarUI.this, bool2);
/* 280 */       super.repaint();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void repaint() {
/* 285 */     if (FlatScrollBarUI.access$1200(FlatScrollBarUI.this).isEnabled())
/* 286 */       FlatScrollBarUI.access$1300(FlatScrollBarUI.this).repaint(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatScrollBarUI$ScrollBarHoverListener.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */