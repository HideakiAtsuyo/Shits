/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import java.awt.KeyboardFocusManager;
/*     */ import java.awt.Paint;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.basic.BasicBorders;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatBorder
/*     */   extends BasicBorders.MarginBorder
/*     */ {
/*     */   public final Color focusColor;
/*     */   public final Color borderColor;
/*     */   public final int focusWidth;
/*     */   public final Color focusedBorderColor;
/*     */   public final float innerFocusWidth;
/*     */   public final Color disabledBorderColor;
/*     */   
/*     */   public FlatBorder() {
/*  62 */     ((FlatBorder)super).focusWidth = UIManager.getInt("Component.focusWidth");
/*  63 */     ((FlatBorder)super).innerFocusWidth = FlatUIUtils.getUIFloat("Component.innerFocusWidth", 0.0F);
/*  64 */     ((FlatBorder)super).focusColor = UIManager.getColor("Component.focusColor");
/*  65 */     ((FlatBorder)super).borderColor = UIManager.getColor("Component.borderColor");
/*  66 */     ((FlatBorder)super).disabledBorderColor = UIManager.getColor("Component.disabledBorderColor");
/*  67 */     ((FlatBorder)super).focusedBorderColor = UIManager.getColor("Component.focusedBorderColor");
/*     */   }
/*     */   
/*     */   public void paintBorder(Object youcangetnoinfoANRVхб70Ч, Object youcangetnoinfoANRWщ0щАЮ, Object youcangetnoinfoANRXНхПСГ, Object youcangetnoinfoANRYЩях90, Object youcangetnoinfoANRZвзzнС, Object youcangetnoinfoANSAбВэшЬ) {
/*  71 */     Object youcangetnoinfoANSBЯЙбыК = youcangetnoinfoANRWщ0щАЮ.create();
/*     */     try {
/*  73 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoANSBЯЙбыК);
/*     */       
/*  75 */       boolean bool = super.isTableCellEditor((Component)youcangetnoinfoANRVхб70Ч);
/*  76 */       float f1 = bool ? 0.0F : super.getFocusWidth((Component)youcangetnoinfoANRVхб70Ч);
/*  77 */       float f2 = super.getBorderWidth((Component)youcangetnoinfoANRVхб70Ч);
/*  78 */       float f3 = bool ? 0.0F : super.getArc((Component)youcangetnoinfoANRVхб70Ч);
/*     */       
/*  80 */       if (super.isFocused((Component)youcangetnoinfoANRVхб70Ч)) {
/*  81 */         float f = !(youcangetnoinfoANRVхб70Ч instanceof JScrollPane) ? ((FlatBorder)super).innerFocusWidth : 0.0F;
/*     */         
/*  83 */         youcangetnoinfoANSBЯЙбыК.setColor(super.getFocusColor((Component)youcangetnoinfoANRVхб70Ч));
/*  84 */         FlatUIUtils.paintComponentOuterBorder((Graphics2D)youcangetnoinfoANSBЯЙбыК, youcangetnoinfoANRXНхПСГ, youcangetnoinfoANRYЩях90, youcangetnoinfoANRZвзzнС, youcangetnoinfoANSAбВэшЬ, f1, super
/*  85 */             .getLineWidth((Component)youcangetnoinfoANRVхб70Ч) + UIScale.scale(f), f3);
/*     */       } 
/*     */       
/*  88 */       youcangetnoinfoANSBЯЙбыК.setPaint(super.getBorderColor((Component)youcangetnoinfoANRVхб70Ч));
/*  89 */       FlatUIUtils.paintComponentBorder((Graphics2D)youcangetnoinfoANSBЯЙбыК, youcangetnoinfoANRXНхПСГ, youcangetnoinfoANRYЩях90, youcangetnoinfoANRZвзzнС, youcangetnoinfoANSAбВэшЬ, f1, f2, f3);
/*     */     } finally {
/*  91 */       youcangetnoinfoANSBЯЙбыК.dispose();
/*     */     } 
/*     */   }
/*     */   
/*     */   public Color getFocusColor(Object youcangetnoinfoATOяЭБФЙ) {
/*  96 */     return ((FlatBorder)super).focusColor;
/*     */   }
/*     */   
/*     */   public Paint getBorderColor(Object youcangetnoinfoBBJVНуйЛй) {
/* 100 */     return super.isEnabled((Component)youcangetnoinfoBBJVНуйЛй) ? (
/* 101 */       super.isFocused((Component)youcangetnoinfoBBJVНуйЛй) ? ((FlatBorder)super).focusedBorderColor : ((FlatBorder)super).borderColor) : 
/* 102 */       ((FlatBorder)super).disabledBorderColor;
/*     */   }
/*     */   
/*     */   public boolean isEnabled(Object youcangetnoinfoAWBЬШПЪы) {
/* 106 */     if (youcangetnoinfoAWBЬШПЪы instanceof JScrollPane) {
/*     */       
/* 108 */       Object youcangetnoinfoAVYьЁЮ4Ю = ((JScrollPane)youcangetnoinfoAWBЬШПЪы).getViewport();
/* 109 */       Object youcangetnoinfoAVZЗЗшом = (youcangetnoinfoAVYьЁЮ4Ю != null) ? youcangetnoinfoAVYьЁЮ4Ю.getView() : null;
/* 110 */       if (youcangetnoinfoAVZЗЗшом != null && !super.isEnabled((Component)youcangetnoinfoAVZЗЗшом)) {
/* 111 */         return false;
/*     */       }
/*     */     } 
/* 114 */     return (youcangetnoinfoAWBЬШПЪы.isEnabled() && (!(youcangetnoinfoAWBЬШПЪы instanceof JTextComponent) || ((JTextComponent)youcangetnoinfoAWBЬШПЪы).isEditable()));
/*     */   }
/*     */   
/*     */   public boolean isFocused(Object youcangetnoinfoCESЙъЙВв) {
/* 118 */     if (youcangetnoinfoCESЙъЙВв instanceof JScrollPane) {
/* 119 */       Object youcangetnoinfoCEMЗ8хяУ = ((JScrollPane)youcangetnoinfoCESЙъЙВв).getViewport();
/* 120 */       Object youcangetnoinfoCENг8ЫЭФ = (youcangetnoinfoCEMЗ8хяУ != null) ? youcangetnoinfoCEMЗ8хяУ.getView() : null;
/* 121 */       if (youcangetnoinfoCENг8ЫЭФ != null) {
/* 122 */         if (youcangetnoinfoCENг8ЫЭФ.hasFocus()) {
/* 123 */           return true;
/*     */         }
/* 125 */         if ((youcangetnoinfoCENг8ЫЭФ instanceof JTable && ((JTable)youcangetnoinfoCENг8ЫЭФ).isEditing()) || (youcangetnoinfoCENг8ЫЭФ instanceof JTree && ((JTree)youcangetnoinfoCENг8ЫЭФ)
/* 126 */           .isEditing())) {
/*     */           
/* 128 */           Object youcangetnoinfoCELоМЪяв = KeyboardFocusManager.getCurrentKeyboardFocusManager().getFocusOwner();
/* 129 */           if (youcangetnoinfoCELоМЪяв != null)
/* 130 */             return SwingUtilities.isDescendingFrom((Component)youcangetnoinfoCELоМЪяв, (Component)youcangetnoinfoCENг8ЫЭФ); 
/*     */         } 
/*     */       } 
/* 133 */       return false;
/* 134 */     }  if (youcangetnoinfoCESЙъЙВв instanceof JComboBox && ((JComboBox)youcangetnoinfoCESЙъЙВв).isEditable()) {
/* 135 */       Object youcangetnoinfoCEOс2кне = ((JComboBox)youcangetnoinfoCESЙъЙВв).getEditor().getEditorComponent();
/* 136 */       return (youcangetnoinfoCEOс2кне != null) ? youcangetnoinfoCEOс2кне.hasFocus() : false;
/* 137 */     }  if (youcangetnoinfoCESЙъЙВв instanceof JSpinner) {
/* 138 */       Object youcangetnoinfoCEQБйэЮ0 = ((JSpinner)youcangetnoinfoCESЙъЙВв).getEditor();
/* 139 */       if (youcangetnoinfoCEQБйэЮ0 instanceof JSpinner.DefaultEditor) {
/* 140 */         Object youcangetnoinfoCEPЯЦясМ = ((JSpinner.DefaultEditor)youcangetnoinfoCEQБйэЮ0).getTextField();
/* 141 */         if (youcangetnoinfoCEPЯЦясМ != null)
/* 142 */           return youcangetnoinfoCEPЯЦясМ.hasFocus(); 
/*     */       } 
/* 144 */       return false;
/*     */     } 
/* 146 */     return youcangetnoinfoCESЙъЙВв.hasFocus();
/*     */   }
/*     */   
/*     */   public boolean isTableCellEditor(Object youcangetnoinfoCVOKДзЙЕъ) {
/* 150 */     return FlatUIUtils.isTableCellEditor((Component)youcangetnoinfoCVOKДзЙЕъ);
/*     */   }
/*     */ 
/*     */   
/*     */   public Insets getBorderInsets(Object youcangetnoinfoKBXкм3Пы, Object youcangetnoinfoKBYГ3Чёй) {
/* 155 */     boolean bool = super.isTableCellEditor((Component)youcangetnoinfoKBXкм3Пы);
/* 156 */     float f = (bool ? 0.0F : super.getFocusWidth((Component)youcangetnoinfoKBXкм3Пы)) + super.getLineWidth((Component)youcangetnoinfoKBXкм3Пы);
/*     */     
/* 158 */     youcangetnoinfoKBYГ3Чёй = super.getBorderInsets((Component)youcangetnoinfoKBXкм3Пы, (Insets)youcangetnoinfoKBYГ3Чёй);
/* 159 */     ((Insets)youcangetnoinfoKBYГ3Чёй).top = Math.round(UIScale.scale(((Insets)youcangetnoinfoKBYГ3Чёй).top) + f);
/* 160 */     ((Insets)youcangetnoinfoKBYГ3Чёй).left = Math.round(UIScale.scale(((Insets)youcangetnoinfoKBYГ3Чёй).left) + f);
/* 161 */     ((Insets)youcangetnoinfoKBYГ3Чёй).bottom = Math.round(UIScale.scale(((Insets)youcangetnoinfoKBYГ3Чёй).bottom) + f);
/* 162 */     ((Insets)youcangetnoinfoKBYГ3Чёй).right = Math.round(UIScale.scale(((Insets)youcangetnoinfoKBYГ3Чёй).right) + f);
/* 163 */     return (Insets)youcangetnoinfoKBYГ3Чёй;
/*     */   }
/*     */   
/*     */   public float getFocusWidth(Object youcangetnoinfoBTUEфсСЗ2) {
/* 167 */     return UIScale.scale(((FlatBorder)super).focusWidth);
/*     */   }
/*     */   
/*     */   public float getLineWidth(Object youcangetnoinfoDKBMЗЛШЧ1) {
/* 171 */     return UIScale.scale(1.0F);
/*     */   }
/*     */   
/*     */   public float getBorderWidth(Object youcangetnoinfoCPCу6ВНб) {
/* 175 */     return super.getLineWidth((Component)youcangetnoinfoCPCу6ВНб);
/*     */   }
/*     */   
/*     */   public float getArc(Object youcangetnoinfoCRPGЬ5ГгМ) {
/* 179 */     return 0.0F;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */