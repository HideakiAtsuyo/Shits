/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatInternalFrameUI$FlatInternalFrameBorder
/*     */   extends FlatEmptyBorder
/*     */ {
/*     */   public final int borderLineWidth;
/*     */   public final Color activeBorderColor;
/*     */   public final Color inactiveBorderColor;
/*     */   
/*     */   public FlatInternalFrameUI$FlatInternalFrameBorder() {
/* 117 */     super(UIManager.getInsets("InternalFrame.borderMargins"));
/*     */     ((FlatInternalFrameUI$FlatInternalFrameBorder)super).activeBorderColor = UIManager.getColor("InternalFrame.activeBorderColor");
/*     */     ((FlatInternalFrameUI$FlatInternalFrameBorder)super).inactiveBorderColor = UIManager.getColor("InternalFrame.inactiveBorderColor");
/*     */     ((FlatInternalFrameUI$FlatInternalFrameBorder)super).borderLineWidth = FlatUIUtils.getUIInt("InternalFrame.borderLineWidth", 1);
/*     */   } public Insets getBorderInsets(Object youcangetnoinfoEXHттмЗЮ, Object youcangetnoinfoEXI8ЩыЯ8) {
/* 122 */     if (youcangetnoinfoEXHттмЗЮ instanceof JInternalFrame && ((JInternalFrame)youcangetnoinfoEXHттмЗЮ).isMaximum()) {
/* 123 */       ((Insets)youcangetnoinfoEXI8ЩыЯ8).left = UIScale.scale(Math.min(((FlatInternalFrameUI$FlatInternalFrameBorder)super).borderLineWidth, ((FlatInternalFrameUI$FlatInternalFrameBorder)this).left));
/* 124 */       ((Insets)youcangetnoinfoEXI8ЩыЯ8).top = UIScale.scale(Math.min(((FlatInternalFrameUI$FlatInternalFrameBorder)super).borderLineWidth, ((FlatInternalFrameUI$FlatInternalFrameBorder)this).top));
/* 125 */       ((Insets)youcangetnoinfoEXI8ЩыЯ8).right = UIScale.scale(Math.min(((FlatInternalFrameUI$FlatInternalFrameBorder)super).borderLineWidth, ((FlatInternalFrameUI$FlatInternalFrameBorder)this).right));
/* 126 */       ((Insets)youcangetnoinfoEXI8ЩыЯ8).bottom = UIScale.scale(Math.min(((FlatInternalFrameUI$FlatInternalFrameBorder)super).borderLineWidth, ((FlatInternalFrameUI$FlatInternalFrameBorder)this).bottom));
/* 127 */       return (Insets)youcangetnoinfoEXI8ЩыЯ8;
/*     */     } 
/*     */     
/* 130 */     return super.getBorderInsets((Component)youcangetnoinfoEXHттмЗЮ, (Insets)youcangetnoinfoEXI8ЩыЯ8);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBorder(Object youcangetnoinfoDSEBФи420, Object youcangetnoinfoDSECРп29б, Object youcangetnoinfoDSEDРи1Шс, Object youcangetnoinfoDSEEч7ДбХ, Object youcangetnoinfoDSEFЦИРтЬ, Object youcangetnoinfoDSEG7Из9ц) {
/* 135 */     Object youcangetnoinfoDSEHжЭф7й = youcangetnoinfoDSEBФи420;
/*     */     
/* 137 */     Object youcangetnoinfoDSEI52Сы7 = getBorderInsets((Component)youcangetnoinfoDSEBФи420);
/* 138 */     float f = UIScale.scale(((FlatInternalFrameUI$FlatInternalFrameBorder)super).borderLineWidth);
/*     */     
/* 140 */     Object youcangetnoinfoDSEKухБРз = youcangetnoinfoDSECРп29б.create();
/*     */     try {
/* 142 */       FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoDSEKухБРз);
/* 143 */       youcangetnoinfoDSEKухБРз.setColor(youcangetnoinfoDSEHжЭф7й.isSelected() ? ((FlatInternalFrameUI$FlatInternalFrameBorder)super).activeBorderColor : ((FlatInternalFrameUI$FlatInternalFrameBorder)super).inactiveBorderColor);
/* 144 */       youcangetnoinfoDSEKухБРз.fill(FlatUIUtils.createRectangle((youcangetnoinfoDSEDРи1Шс + ((Insets)youcangetnoinfoDSEI52Сы7).left) - f, (youcangetnoinfoDSEEч7ДбХ + ((Insets)youcangetnoinfoDSEI52Сы7).top) - f, (youcangetnoinfoDSEFЦИРтЬ - ((Insets)youcangetnoinfoDSEI52Сы7).left - ((Insets)youcangetnoinfoDSEI52Сы7).right) + f * 2.0F, (youcangetnoinfoDSEG7Из9ц - ((Insets)youcangetnoinfoDSEI52Сы7).top - ((Insets)youcangetnoinfoDSEI52Сы7).bottom) + f * 2.0F, f));
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 151 */       youcangetnoinfoDSEKухБРз.dispose();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatInternalFrameUI$FlatInternalFrameBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */