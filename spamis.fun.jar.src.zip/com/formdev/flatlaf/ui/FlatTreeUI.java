/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JTree;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTreeUI;
/*     */ import javax.swing.tree.DefaultTreeCellRenderer;
/*     */ import javax.swing.tree.TreePath;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTreeUI
/*     */   extends BasicTreeUI
/*     */ {
/*     */   public boolean wideSelection;
/*     */   public Color selectionInactiveBackground;
/*     */   public Color selectionInactiveForeground;
/*     */   public Color selectionBackground;
/*     */   public Color selectionBorderColor;
/*     */   public Color selectionForeground;
/*     */   public boolean showCellFocusIndicator;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoCXVVс8ФлВ) {
/* 102 */     return new FlatTreeUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/* 107 */     super.installDefaults();
/*     */     
/* 109 */     LookAndFeel.installBorder(((FlatTreeUI)this).tree, "Tree.border");
/*     */     
/* 111 */     ((FlatTreeUI)super).selectionBackground = UIManager.getColor("Tree.selectionBackground");
/* 112 */     ((FlatTreeUI)super).selectionForeground = UIManager.getColor("Tree.selectionForeground");
/* 113 */     ((FlatTreeUI)super).selectionInactiveBackground = UIManager.getColor("Tree.selectionInactiveBackground");
/* 114 */     ((FlatTreeUI)super).selectionInactiveForeground = UIManager.getColor("Tree.selectionInactiveForeground");
/* 115 */     ((FlatTreeUI)super).selectionBorderColor = UIManager.getColor("Tree.selectionBorderColor");
/* 116 */     ((FlatTreeUI)super).wideSelection = UIManager.getBoolean("Tree.wideSelection");
/* 117 */     ((FlatTreeUI)super).showCellFocusIndicator = UIManager.getBoolean("Tree.showCellFocusIndicator");
/*     */ 
/*     */     
/* 120 */     int i = FlatUIUtils.getUIInt("Tree.rowHeight", 16);
/* 121 */     if (i > 0)
/* 122 */       LookAndFeel.installProperty(((FlatTreeUI)this).tree, "rowHeight", Integer.valueOf(UIScale.scale(i))); 
/* 123 */     setLeftChildIndent(UIScale.scale(getLeftChildIndent()));
/* 124 */     setRightChildIndent(UIScale.scale(getRightChildIndent()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/* 129 */     super.uninstallDefaults();
/*     */     
/* 131 */     LookAndFeel.uninstallBorder(((FlatTreeUI)this).tree);
/*     */     
/* 133 */     ((FlatTreeUI)super).selectionBackground = null;
/* 134 */     ((FlatTreeUI)super).selectionForeground = null;
/* 135 */     ((FlatTreeUI)super).selectionInactiveBackground = null;
/* 136 */     ((FlatTreeUI)super).selectionInactiveForeground = null;
/* 137 */     ((FlatTreeUI)super).selectionBorderColor = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public MouseListener createMouseListener() {
/* 142 */     if (!((FlatTreeUI)super).wideSelection) {
/* 143 */       return super.createMouseListener();
/*     */     }
/* 145 */     return new FlatTreeUI$1((FlatTreeUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyChangeListener createPropertyChangeListener() {
/* 189 */     if (!((FlatTreeUI)super).wideSelection) {
/* 190 */       return super.createPropertyChangeListener();
/*     */     }
/* 192 */     return new FlatTreeUI$2((FlatTreeUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintRow(Object youcangetnoinfoCZRUМ4ЩШб, Object youcangetnoinfoCZRVЛюБэТ, Object youcangetnoinfoCZRWФХГЬб, Object youcangetnoinfoCZRX9ГКВш, Object youcangetnoinfoCZRYяЬ6Ич, Object youcangetnoinfoCZRZцЦЗу6, Object youcangetnoinfoCZSAндяzк, Object youcangetnoinfoCZSBвиЧ2Щ, Object youcangetnoinfoCZSCzг0чю) {
/* 223 */     boolean bool1 = (((FlatTreeUI)this).editingComponent != null && ((FlatTreeUI)this).editingRow == youcangetnoinfoCZRZцЦЗу6) ? true : false;
/* 224 */     boolean bool2 = ((FlatTreeUI)this).tree.hasFocus();
/* 225 */     boolean bool3 = (bool2 && youcangetnoinfoCZRZцЦЗу6 == getLeadSelectionRow()) ? true : false;
/* 226 */     boolean bool4 = ((FlatTreeUI)this).tree.isRowSelected(youcangetnoinfoCZRZцЦЗу6);
/* 227 */     boolean bool5 = super.isDropRow(youcangetnoinfoCZRZцЦЗу6);
/*     */ 
/*     */     
/* 230 */     if (((FlatTreeUI)super).wideSelection && (bool4 || bool5)) {
/*     */       
/* 232 */       youcangetnoinfoCZRUМ4ЩШб.setColor(bool5 ? 
/* 233 */           UIManager.getColor("Tree.dropCellBackground") : (
/* 234 */           bool2 ? ((FlatTreeUI)super).selectionBackground : ((FlatTreeUI)super).selectionInactiveBackground));
/* 235 */       youcangetnoinfoCZRUМ4ЩШб.fillRect(0, ((Rectangle)youcangetnoinfoCZRX9ГКВш).y, ((FlatTreeUI)this).tree.getWidth(), ((Rectangle)youcangetnoinfoCZRX9ГКВш).height);
/*     */ 
/*     */       
/* 238 */       if (shouldPaintExpandControl((TreePath)youcangetnoinfoCZRYяЬ6Ич, youcangetnoinfoCZRZцЦЗу6, youcangetnoinfoCZSAндяzк, youcangetnoinfoCZSBвиЧ2Щ, youcangetnoinfoCZSCzг0чю)) {
/* 239 */         paintExpandControl((Graphics)youcangetnoinfoCZRUМ4ЩШб, (Rectangle)youcangetnoinfoCZRVЛюБэТ, (Insets)youcangetnoinfoCZRWФХГЬб, (Rectangle)youcangetnoinfoCZRX9ГКВш, (TreePath)youcangetnoinfoCZRYяЬ6Ич, youcangetnoinfoCZRZцЦЗу6, youcangetnoinfoCZSAндяzк, youcangetnoinfoCZSBвиЧ2Щ, youcangetnoinfoCZSCzг0чю);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 244 */     if (bool1) {
/*     */       return;
/*     */     }
/*     */     
/* 248 */     Object youcangetnoinfoCZSIНв0пъ = ((FlatTreeUI)this).currentCellRenderer.getTreeCellRendererComponent(((FlatTreeUI)this).tree, youcangetnoinfoCZRYяЬ6Ич
/* 249 */         .getLastPathComponent(), bool4, youcangetnoinfoCZSAндяzк, youcangetnoinfoCZSCzг0чю, youcangetnoinfoCZRZцЦЗу6, bool3);
/*     */ 
/*     */     
/* 252 */     Object youcangetnoinfoCZSJЖбтлМ = null;
/* 253 */     if (bool4 && !bool2 && !bool5) {
/* 254 */       if (youcangetnoinfoCZSIНв0пъ instanceof DefaultTreeCellRenderer) {
/* 255 */         Object youcangetnoinfoCZRRФ6ХаА = youcangetnoinfoCZSIНв0пъ;
/* 256 */         if (youcangetnoinfoCZRRФ6ХаА.getBackgroundSelectionColor() == ((FlatTreeUI)super).selectionBackground) {
/* 257 */           youcangetnoinfoCZSJЖбтлМ = youcangetnoinfoCZRRФ6ХаА.getBackgroundSelectionColor();
/* 258 */           youcangetnoinfoCZRRФ6ХаА.setBackgroundSelectionColor(((FlatTreeUI)super).selectionInactiveBackground);
/*     */         }
/*     */       
/* 261 */       } else if (youcangetnoinfoCZSIНв0пъ.getBackground() == ((FlatTreeUI)super).selectionBackground) {
/* 262 */         youcangetnoinfoCZSIНв0пъ.setBackground(((FlatTreeUI)super).selectionInactiveBackground);
/*     */       } 
/*     */       
/* 265 */       if (youcangetnoinfoCZSIНв0пъ.getForeground() == ((FlatTreeUI)super).selectionForeground) {
/* 266 */         youcangetnoinfoCZSIНв0пъ.setForeground(((FlatTreeUI)super).selectionInactiveForeground);
/*     */       }
/*     */     } 
/*     */     
/* 270 */     Object youcangetnoinfoCZSK8Лzьп = null;
/* 271 */     if (bool4 && bool2 && (!((FlatTreeUI)super).showCellFocusIndicator || ((FlatTreeUI)this).tree
/* 272 */       .getMinSelectionRow() == ((FlatTreeUI)this).tree.getMaxSelectionRow()) && youcangetnoinfoCZSIНв0пъ instanceof DefaultTreeCellRenderer) {
/*     */ 
/*     */       
/* 275 */       Object youcangetnoinfoCZRSрлЧшФ = youcangetnoinfoCZSIНв0пъ;
/* 276 */       if (youcangetnoinfoCZRSрлЧшФ.getBorderSelectionColor() == ((FlatTreeUI)super).selectionBorderColor) {
/* 277 */         youcangetnoinfoCZSK8Лzьп = youcangetnoinfoCZRSрлЧшФ.getBorderSelectionColor();
/* 278 */         youcangetnoinfoCZRSрлЧшФ.setBorderSelectionColor(null);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 283 */     ((FlatTreeUI)this).rendererPane.paintComponent((Graphics)youcangetnoinfoCZRUМ4ЩШб, (Component)youcangetnoinfoCZSIНв0пъ, ((FlatTreeUI)this).tree, ((Rectangle)youcangetnoinfoCZRX9ГКВш).x, ((Rectangle)youcangetnoinfoCZRX9ГКВш).y, ((Rectangle)youcangetnoinfoCZRX9ГКВш).width, ((Rectangle)youcangetnoinfoCZRX9ГКВш).height, true);
/*     */ 
/*     */     
/* 286 */     if (youcangetnoinfoCZSJЖбтлМ != null)
/* 287 */       ((DefaultTreeCellRenderer)youcangetnoinfoCZSIНв0пъ).setBackgroundSelectionColor((Color)youcangetnoinfoCZSJЖбтлМ); 
/* 288 */     if (youcangetnoinfoCZSK8Лzьп != null) {
/* 289 */       ((DefaultTreeCellRenderer)youcangetnoinfoCZSIНв0пъ).setBorderSelectionColor((Color)youcangetnoinfoCZSK8Лzьп);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDropRow(Object youcangetnoinfoCJPOАСЩУЕ) {
/* 297 */     Object youcangetnoinfoCJPPЙбВжф = ((FlatTreeUI)this).tree.getDropLocation();
/* 298 */     return (youcangetnoinfoCJPPЙбВжф != null && youcangetnoinfoCJPPЙбВжф
/* 299 */       .getChildIndex() == -1 && ((FlatTreeUI)this).tree
/* 300 */       .getRowForPath(youcangetnoinfoCJPPЙбВжф.getPath()) == youcangetnoinfoCJPOАСЩУЕ);
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle getDropLineRect(Object youcangetnoinfoAOQIтЩрьр) {
/* 305 */     Object youcangetnoinfoAOQJБЁдВС = super.getDropLineRect((JTree.DropLocation)youcangetnoinfoAOQIтЩрьр);
/* 306 */     return ((FlatTreeUI)super).wideSelection ? new Rectangle(0, ((Rectangle)youcangetnoinfoAOQJБЁдВС).y, ((FlatTreeUI)this).tree.getWidth(), ((Rectangle)youcangetnoinfoAOQJБЁдВС).height) : (Rectangle)youcangetnoinfoAOQJБЁдВС;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTreeUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */