/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.FlatClientProperties;
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.AbstractButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JToggleButton;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatToggleButtonUI
/*     */   extends FlatButtonUI
/*     */ {
/*     */   public Color tabFocusBackground;
/*     */   public Color selectedBackground;
/*     */   public Color tabUnderlineColor;
/*     */   public Color tabSelectedBackground;
/*     */   public Color selectedForeground;
/*     */   public int tabUnderlineHeight;
/*     */   public Color tabHoverBackground;
/*     */   public static ComponentUI instance;
/*     */   public Color tabDisabledUnderlineColor;
/*     */   public Color toolbarSelectedBackground;
/*     */   public Color disabledSelectedBackground;
/*     */   public boolean defaults_initialized;
/*     */   
/*     */   public FlatToggleButtonUI() {
/*  90 */     ((FlatToggleButtonUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoCQQZЦСонф) {
/*  95 */     if (instance == null)
/*  96 */       instance = new FlatToggleButtonUI(); 
/*  97 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getPropertyPrefix() {
/* 102 */     return "ToggleButton.";
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults(Object youcangetnoinfoBKLSфХжЪд) {
/* 107 */     super.installDefaults((AbstractButton)youcangetnoinfoBKLSфХжЪд);
/*     */     
/* 109 */     if (!((FlatToggleButtonUI)super).defaults_initialized) {
/* 110 */       ((FlatToggleButtonUI)super).selectedBackground = UIManager.getColor("ToggleButton.selectedBackground");
/* 111 */       ((FlatToggleButtonUI)super).selectedForeground = UIManager.getColor("ToggleButton.selectedForeground");
/* 112 */       ((FlatToggleButtonUI)super).disabledSelectedBackground = UIManager.getColor("ToggleButton.disabledSelectedBackground");
/*     */       
/* 114 */       ((FlatToggleButtonUI)super).toolbarSelectedBackground = UIManager.getColor("ToggleButton.toolbar.selectedBackground");
/*     */       
/* 116 */       ((FlatToggleButtonUI)super).tabUnderlineHeight = UIManager.getInt("ToggleButton.tab.underlineHeight");
/* 117 */       ((FlatToggleButtonUI)super).tabUnderlineColor = UIManager.getColor("ToggleButton.tab.underlineColor");
/* 118 */       ((FlatToggleButtonUI)super).tabDisabledUnderlineColor = UIManager.getColor("ToggleButton.tab.disabledUnderlineColor");
/* 119 */       ((FlatToggleButtonUI)super).tabSelectedBackground = UIManager.getColor("ToggleButton.tab.selectedBackground");
/* 120 */       ((FlatToggleButtonUI)super).tabHoverBackground = UIManager.getColor("ToggleButton.tab.hoverBackground");
/* 121 */       ((FlatToggleButtonUI)super).tabFocusBackground = UIManager.getColor("ToggleButton.tab.focusBackground");
/*     */       
/* 123 */       ((FlatToggleButtonUI)super).defaults_initialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults(Object youcangetnoinfoAEENбМАпИ) {
/* 129 */     super.uninstallDefaults((AbstractButton)youcangetnoinfoAEENбМАпИ);
/* 130 */     ((FlatToggleButtonUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(Object youcangetnoinfoBMRP6БЪzЦ, Object youcangetnoinfoBMRQжфвЬЩ) {
/* 135 */     super.propertyChange((AbstractButton)youcangetnoinfoBMRP6БЪzЦ, (PropertyChangeEvent)youcangetnoinfoBMRQжфвЬЩ);
/*     */     
/* 137 */     switch (youcangetnoinfoBMRQжфвЬЩ.getPropertyName()) {
/*     */       case "JButton.buttonType":
/* 139 */         if ("tab".equals(youcangetnoinfoBMRQжфвЬЩ.getOldValue()) || "tab".equals(youcangetnoinfoBMRQжфвЬЩ.getNewValue())) {
/* 140 */           MigLayoutVisualPadding.uninstall((JComponent)youcangetnoinfoBMRP6БЪzЦ);
/* 141 */           MigLayoutVisualPadding.install((JComponent)youcangetnoinfoBMRP6БЪzЦ, super.getFocusWidth((JComponent)youcangetnoinfoBMRP6БЪzЦ));
/* 142 */           youcangetnoinfoBMRP6БЪzЦ.revalidate();
/*     */         } 
/*     */         
/* 145 */         youcangetnoinfoBMRP6БЪzЦ.repaint();
/*     */         break;
/*     */       
/*     */       case "JToggleButton.tab.underlineHeight":
/*     */       case "JToggleButton.tab.underlineColor":
/*     */       case "JToggleButton.tab.selectedBackground":
/* 151 */         youcangetnoinfoBMRP6БЪzЦ.repaint();
/*     */         break;
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean isTabButton(Object youcangetnoinfoYZS7юфхГ) {
/* 157 */     return (youcangetnoinfoYZS7юфхГ instanceof JToggleButton && FlatClientProperties.clientPropertyEquals((JToggleButton)youcangetnoinfoYZS7юфхГ, "JButton.buttonType", "tab"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoEESL7Ёъч2, Object youcangetnoinfoEESM8Кж62) {
/* 162 */     if (isTabButton((Component)youcangetnoinfoEESM8Кж62)) {
/* 163 */       int i = youcangetnoinfoEESM8Кж62.getHeight();
/* 164 */       int j = youcangetnoinfoEESM8Кж62.getWidth();
/* 165 */       boolean bool = ((AbstractButton)youcangetnoinfoEESM8Кж62).isSelected();
/*     */ 
/*     */       
/* 168 */       Object youcangetnoinfoEESJт8ТМ0 = buttonStateColor((Component)youcangetnoinfoEESM8Кж62, 
/* 169 */           bool ? FlatClientProperties.clientPropertyColor((JComponent)youcangetnoinfoEESM8Кж62, "JToggleButton.tab.selectedBackground", ((FlatToggleButtonUI)super).tabSelectedBackground) : null, null, ((FlatToggleButtonUI)super).tabFocusBackground, ((FlatToggleButtonUI)super).tabHoverBackground, null);
/*     */       
/* 171 */       if (youcangetnoinfoEESJт8ТМ0 != null) {
/* 172 */         youcangetnoinfoEESL7Ёъч2.setColor((Color)youcangetnoinfoEESJт8ТМ0);
/* 173 */         youcangetnoinfoEESL7Ёъч2.fillRect(0, 0, j, i);
/*     */       } 
/*     */ 
/*     */       
/* 177 */       if (bool) {
/* 178 */         int k = UIScale.scale(FlatClientProperties.clientPropertyInt((JComponent)youcangetnoinfoEESM8Кж62, "JToggleButton.tab.underlineHeight", ((FlatToggleButtonUI)super).tabUnderlineHeight));
/* 179 */         youcangetnoinfoEESL7Ёъч2.setColor(youcangetnoinfoEESM8Кж62.isEnabled() ? 
/* 180 */             FlatClientProperties.clientPropertyColor((JComponent)youcangetnoinfoEESM8Кж62, "JToggleButton.tab.underlineColor", ((FlatToggleButtonUI)super).tabUnderlineColor) : 
/* 181 */             ((FlatToggleButtonUI)super).tabDisabledUnderlineColor);
/* 182 */         youcangetnoinfoEESL7Ёъч2.fillRect(0, i - k, j, k);
/*     */       } 
/*     */     } else {
/* 185 */       super.paintBackground((Graphics)youcangetnoinfoEESL7Ёъч2, (JComponent)youcangetnoinfoEESM8Кж62);
/*     */     } 
/*     */   }
/*     */   
/*     */   public Color getBackground(Object youcangetnoinfoCVJMфЛипН) {
/* 190 */     Object youcangetnoinfoCVJNба0жш = ((AbstractButton)youcangetnoinfoCVJMфЛипН).getModel();
/*     */     
/* 192 */     if (youcangetnoinfoCVJNба0жш.isSelected()) {
/*     */ 
/*     */       
/* 195 */       boolean bool = isToolBarButton((Component)youcangetnoinfoCVJMфЛипН);
/* 196 */       return buttonStateColor((Component)youcangetnoinfoCVJMфЛипН, 
/* 197 */           bool ? ((FlatToggleButtonUI)super).toolbarSelectedBackground : ((FlatToggleButtonUI)super).selectedBackground, 
/* 198 */           bool ? ((FlatToggleButtonUI)super).toolbarSelectedBackground : ((FlatToggleButtonUI)super).disabledSelectedBackground, null, null, 
/*     */           
/* 200 */           bool ? ((FlatToggleButtonUI)this).toolbarPressedBackground : ((FlatToggleButtonUI)this).pressedBackground);
/*     */     } 
/*     */     
/* 203 */     return super.getBackground((JComponent)youcangetnoinfoCVJMфЛипН);
/*     */   }
/*     */ 
/*     */   
/*     */   public Color getForeground(Object youcangetnoinfoXWQкоиЕ1) {
/* 208 */     Object youcangetnoinfoXWRЗДЕёо = ((AbstractButton)youcangetnoinfoXWQкоиЕ1).getModel();
/*     */     
/* 210 */     if (youcangetnoinfoXWRЗДЕёо.isSelected() && !isToolBarButton((Component)youcangetnoinfoXWQкоиЕ1)) {
/* 211 */       return ((FlatToggleButtonUI)super).selectedForeground;
/*     */     }
/* 213 */     return super.getForeground((JComponent)youcangetnoinfoXWQкоиЕ1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int getFocusWidth(Object youcangetnoinfoDFTHзтЛТН) {
/* 218 */     return isTabButton((Component)youcangetnoinfoDFTHзтЛТН) ? 0 : super.getFocusWidth((JComponent)youcangetnoinfoDFTHзтЛТН);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatToggleButtonUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */