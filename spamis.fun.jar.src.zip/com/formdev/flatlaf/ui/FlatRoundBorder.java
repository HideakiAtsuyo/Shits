/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatRoundBorder
/*    */   extends FlatBorder
/*    */ {
/*    */   public final int arc;
/*    */   
/*    */   public FlatRoundBorder() {
/* 33 */     ((FlatRoundBorder)super).arc = UIManager.getInt("Component.arc");
/*    */   }
/*    */   
/*    */   public float getArc(Object youcangetnoinfoDVMVвжСВ5) {
/* 37 */     return UIScale.scale(((FlatRoundBorder)super).arc);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatRoundBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */