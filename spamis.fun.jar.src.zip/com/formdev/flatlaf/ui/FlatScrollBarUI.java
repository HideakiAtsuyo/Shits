/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import java.util.Objects;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollBar;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicScrollBarUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatScrollBarUI
/*     */   extends BasicScrollBarUI
/*     */ {
/*     */   public Color buttonArrowColor;
/*     */   public static boolean isPressed;
/*     */   public boolean hoverTrack;
/*     */   public Color hoverThumbColor;
/*     */   public Color hoverTrackColor;
/*     */   public boolean showButtons;
/*     */   public String arrowType;
/*     */   public MouseAdapter hoverListener;
/*     */   public Color buttonDisabledArrowColor;
/*     */   public boolean hoverThumb;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoAVXхэц5Я) {
/*  80 */     return new FlatScrollBarUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installListeners() {
/*  85 */     super.installListeners();
/*     */     
/*  87 */     ((FlatScrollBarUI)super).hoverListener = new FlatScrollBarUI$ScrollBarHoverListener((FlatScrollBarUI)this, null);
/*  88 */     ((FlatScrollBarUI)this).scrollbar.addMouseListener(((FlatScrollBarUI)super).hoverListener);
/*  89 */     ((FlatScrollBarUI)this).scrollbar.addMouseMotionListener(((FlatScrollBarUI)super).hoverListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners() {
/*  94 */     super.uninstallListeners();
/*     */     
/*  96 */     ((FlatScrollBarUI)this).scrollbar.removeMouseListener(((FlatScrollBarUI)super).hoverListener);
/*  97 */     ((FlatScrollBarUI)this).scrollbar.removeMouseMotionListener(((FlatScrollBarUI)super).hoverListener);
/*  98 */     ((FlatScrollBarUI)super).hoverListener = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/* 103 */     super.installDefaults();
/*     */     
/* 105 */     ((FlatScrollBarUI)super).hoverTrackColor = UIManager.getColor("ScrollBar.hoverTrackColor");
/* 106 */     ((FlatScrollBarUI)super).hoverThumbColor = UIManager.getColor("ScrollBar.hoverThumbColor");
/*     */     
/* 108 */     ((FlatScrollBarUI)super).showButtons = UIManager.getBoolean("ScrollBar.showButtons");
/* 109 */     ((FlatScrollBarUI)super).arrowType = UIManager.getString("Component.arrowType");
/* 110 */     ((FlatScrollBarUI)super).buttonArrowColor = UIManager.getColor("ScrollBar.buttonArrowColor");
/* 111 */     ((FlatScrollBarUI)super).buttonDisabledArrowColor = UIManager.getColor("ScrollBar.buttonDisabledArrowColor");
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/* 116 */     super.uninstallDefaults();
/*     */     
/* 118 */     ((FlatScrollBarUI)super).hoverTrackColor = null;
/* 119 */     ((FlatScrollBarUI)super).hoverThumbColor = null;
/*     */     
/* 121 */     ((FlatScrollBarUI)super).buttonArrowColor = null;
/* 122 */     ((FlatScrollBarUI)super).buttonDisabledArrowColor = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyChangeListener createPropertyChangeListener() {
/* 127 */     return new FlatScrollBarUI$1((FlatScrollBarUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoIHXЙДёПш) {
/* 157 */     return UIScale.scale(super.getPreferredSize((JComponent)youcangetnoinfoIHXЙДёПш));
/*     */   }
/*     */ 
/*     */   
/*     */   public JButton createDecreaseButton(Object youcangetnoinfoDFFGЯк6Ща) {
/* 162 */     return super.createArrowButton(youcangetnoinfoDFFGЯк6Ща);
/*     */   }
/*     */ 
/*     */   
/*     */   public JButton createIncreaseButton(Object youcangetnoinfoEECLП5цЗТ) {
/* 167 */     return super.createArrowButton(youcangetnoinfoEECLП5цЗТ);
/*     */   }
/*     */   
/*     */   public JButton createArrowButton(Object youcangetnoinfoDNGJБРюРЭ) {
/* 171 */     Object youcangetnoinfoDNGKчуЛчП = new FlatScrollBarUI$2((FlatScrollBarUI)this, youcangetnoinfoDNGJБРюРЭ, ((FlatScrollBarUI)super).arrowType, ((FlatScrollBarUI)super).buttonArrowColor, ((FlatScrollBarUI)super).buttonDisabledArrowColor, null, ((FlatScrollBarUI)super).hoverTrackColor);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 193 */     youcangetnoinfoDNGKчуЛчП.setArrowWidth(6);
/* 194 */     youcangetnoinfoDNGKчуЛчП.setFocusable(false);
/* 195 */     youcangetnoinfoDNGKчуЛчП.setRequestFocusEnabled(false);
/* 196 */     return (JButton)youcangetnoinfoDNGKчуЛчП;
/*     */   }
/*     */   
/*     */   public boolean isShowButtons() {
/* 200 */     Object youcangetnoinfoAJHZефво1 = ((FlatScrollBarUI)this).scrollbar.getClientProperty("JScrollBar.showButtons");
/* 201 */     if (youcangetnoinfoAJHZефво1 == null && ((FlatScrollBarUI)this).scrollbar.getParent() instanceof JScrollPane)
/* 202 */       youcangetnoinfoAJHZефво1 = ((JScrollPane)((FlatScrollBarUI)this).scrollbar.getParent()).getClientProperty("JScrollBar.showButtons"); 
/* 203 */     return (youcangetnoinfoAJHZефво1 != null) ? Objects.equals(youcangetnoinfoAJHZефво1, Boolean.valueOf(true)) : ((FlatScrollBarUI)super).showButtons;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintDecreaseHighlight(Object youcangetnoinfoCXAY9Гьё6) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintIncreaseHighlight(Object youcangetnoinfoDWTZжЫОЁж) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintTrack(Object youcangetnoinfoDLWDйомЗо, Object youcangetnoinfoDLWEсэЛ6р, Object youcangetnoinfoDLWFСоПКТ) {
/* 218 */     youcangetnoinfoDLWDйомЗо.setColor(((FlatScrollBarUI)super).hoverTrack ? ((FlatScrollBarUI)super).hoverTrackColor : ((FlatScrollBarUI)this).trackColor);
/* 219 */     youcangetnoinfoDLWDйомЗо.fillRect(((Rectangle)youcangetnoinfoDLWFСоПКТ).x, ((Rectangle)youcangetnoinfoDLWFСоПКТ).y, ((Rectangle)youcangetnoinfoDLWFСоПКТ).width, ((Rectangle)youcangetnoinfoDLWFСоПКТ).height);
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintThumb(Object youcangetnoinfoDOHSтиДХМ, Object youcangetnoinfoDOHTzПаМЮ, Object youcangetnoinfoDOHUУ4пцЦ) {
/* 224 */     if (youcangetnoinfoDOHUУ4пцЦ.isEmpty() || !((FlatScrollBarUI)this).scrollbar.isEnabled()) {
/*     */       return;
/*     */     }
/* 227 */     youcangetnoinfoDOHSтиДХМ.setColor(((FlatScrollBarUI)super).hoverThumb ? ((FlatScrollBarUI)super).hoverThumbColor : ((FlatScrollBarUI)this).thumbColor);
/* 228 */     youcangetnoinfoDOHSтиДХМ.fillRect(((Rectangle)youcangetnoinfoDOHUУ4пцЦ).x, ((Rectangle)youcangetnoinfoDOHUУ4пцЦ).y, ((Rectangle)youcangetnoinfoDOHUУ4пцЦ).width, ((Rectangle)youcangetnoinfoDOHUУ4пцЦ).height);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumThumbSize() {
/* 233 */     return UIScale.scale(super.getMinimumThumbSize());
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumThumbSize() {
/* 238 */     return UIScale.scale(super.getMaximumThumbSize());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatScrollBarUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */