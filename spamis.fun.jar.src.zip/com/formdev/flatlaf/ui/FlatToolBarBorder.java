/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.JToolBar;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatToolBarBorder
/*     */   extends FlatMarginBorder
/*     */ {
/*     */   public static final int DOT_SIZE = 2;
/*     */   public final Color gripColor;
/*     */   public static final int DOT_COUNT = 4;
/*     */   public static final int GRIP_WIDTH = 6;
/*     */   
/*     */   public FlatToolBarBorder() {
/*  47 */     super(UIManager.getInsets("ToolBar.borderMargins"));
/*     */     ((FlatToolBarBorder)super).gripColor = UIManager.getColor("ToolBar.gripColor");
/*     */   }
/*     */ 
/*     */   
/*     */   public void paintBorder(Object youcangetnoinfoHHSЕОРхИ, Object youcangetnoinfoHHTП8кяс, Object youcangetnoinfoHHUюЗ7ёб, Object youcangetnoinfoHHVсзИя1, Object youcangetnoinfoHHWчТЯкФ, Object youcangetnoinfoHHX9ЦНпй) {
/*  53 */     if (youcangetnoinfoHHSЕОРхИ instanceof JToolBar && ((JToolBar)youcangetnoinfoHHSЕОРхИ).isFloatable()) {
/*  54 */       Object youcangetnoinfoHHQжёХМч = youcangetnoinfoHHTП8кяс.create();
/*     */       try {
/*  56 */         FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoHHQжёХМч);
/*     */         
/*  58 */         youcangetnoinfoHHQжёХМч.setColor(((FlatToolBarBorder)super).gripColor);
/*  59 */         super.paintGrip((Component)youcangetnoinfoHHSЕОРхИ, (Graphics)youcangetnoinfoHHQжёХМч, youcangetnoinfoHHUюЗ7ёб, youcangetnoinfoHHVсзИя1, youcangetnoinfoHHWчТЯкФ, youcangetnoinfoHHX9ЦНпй);
/*     */       } finally {
/*  61 */         youcangetnoinfoHHQжёХМч.dispose();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void paintGrip(Object youcangetnoinfoCTJAНшчЮт, Object youcangetnoinfoCTJBя3пюВ, Object youcangetnoinfoCTJCЩ0ш2z, Object youcangetnoinfoCTJD9ОХЦП, Object youcangetnoinfoCTJEфГвАЧ, Object youcangetnoinfoCTJFмяа4П) {
/*  67 */     int i, j, k = UIScale.scale(2);
/*  68 */     int m = k;
/*  69 */     int n = k * 4 + m * 3;
/*     */ 
/*     */     
/*  72 */     Object youcangetnoinfoCTJJезБрю = getBorderInsets((Component)youcangetnoinfoCTJAНшчЮт);
/*     */ 
/*     */     
/*  75 */     boolean bool = (((JToolBar)youcangetnoinfoCTJAНшчЮт).getOrientation() == 0) ? true : false;
/*  76 */     if (bool) {
/*  77 */       if (youcangetnoinfoCTJAНшчЮт.getComponentOrientation().isLeftToRight()) {
/*  78 */         i = youcangetnoinfoCTJCЩ0ш2z + ((Insets)youcangetnoinfoCTJJезБрю).left - k * 2;
/*     */       } else {
/*  80 */         i += youcangetnoinfoCTJEфГвАЧ - ((Insets)youcangetnoinfoCTJJезБрю).right + k;
/*  81 */       }  j = youcangetnoinfoCTJD9ОХЦП + Math.round((youcangetnoinfoCTJFмяа4П - n) / 2.0F);
/*     */     } else {
/*     */       
/*  84 */       i += Math.round((youcangetnoinfoCTJEфГвАЧ - n) / 2.0F);
/*  85 */       j += ((Insets)youcangetnoinfoCTJJезБрю).top - k * 2;
/*     */     } 
/*     */ 
/*     */     
/*  89 */     for (byte b = 0; b < 4; b++) {
/*  90 */       youcangetnoinfoCTJBя3пюВ.fillOval(i, j, k, k);
/*  91 */       if (bool) {
/*  92 */         j += k + m;
/*     */       } else {
/*  94 */         i += k + m;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Insets getBorderInsets(Object youcangetnoinfoBOIMЩёьА9, Object youcangetnoinfoBOINГсzчг) {
/* 100 */     youcangetnoinfoBOINГсzчг = super.getBorderInsets((Component)youcangetnoinfoBOIMЩёьА9, (Insets)youcangetnoinfoBOINГсzчг);
/*     */ 
/*     */     
/* 103 */     if (youcangetnoinfoBOIMЩёьА9 instanceof JToolBar && ((JToolBar)youcangetnoinfoBOIMЩёьА9).isFloatable()) {
/* 104 */       int i = UIScale.scale(6);
/* 105 */       if (((JToolBar)youcangetnoinfoBOIMЩёьА9).getOrientation() == 0)
/* 106 */       { if (youcangetnoinfoBOIMЩёьА9.getComponentOrientation().isLeftToRight()) {
/* 107 */           ((Insets)youcangetnoinfoBOINГсzчг).left += i;
/*     */         } else {
/* 109 */           ((Insets)youcangetnoinfoBOINГсzчг).right += i;
/*     */         }  }
/* 111 */       else { ((Insets)youcangetnoinfoBOINГсzчг).top += i; }
/*     */     
/*     */     } 
/* 114 */     return (Insets)youcangetnoinfoBOINГсzчг;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatToolBarBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */