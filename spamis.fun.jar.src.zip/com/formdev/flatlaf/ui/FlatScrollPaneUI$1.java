/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.event.MouseWheelEvent;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.basic.BasicScrollPaneUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatScrollPaneUI$1
/*     */   extends BasicScrollPaneUI.MouseWheelHandler
/*     */ {
/*     */   public final FlatScrollPaneUI this$0;
/*     */   
/*     */   public FlatScrollPaneUI$1() {
/* 114 */     super((BasicScrollPaneUI)youcangetnoinfoBATNzдьвш);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseWheelMoved(Object youcangetnoinfoCIBQ1Т3ъХ) {
/* 120 */     if (UIManager.getBoolean("ScrollPane.smoothScrolling") && 
/* 121 */       FlatScrollPaneUI.access$000(((FlatScrollPaneUI$1)super).this$0).isWheelScrollingEnabled() && youcangetnoinfoCIBQ1Т3ъХ
/* 122 */       .getScrollType() == 0 && youcangetnoinfoCIBQ1Т3ъХ
/* 123 */       .getPreciseWheelRotation() != 0.0D && youcangetnoinfoCIBQ1Т3ъХ
/* 124 */       .getPreciseWheelRotation() != youcangetnoinfoCIBQ1Т3ъХ.getWheelRotation()) {
/*     */       
/* 126 */       FlatScrollPaneUI.access$100(((FlatScrollPaneUI$1)super).this$0, (MouseWheelEvent)youcangetnoinfoCIBQ1Т3ъХ);
/*     */     } else {
/* 128 */       super.mouseWheelMoved((MouseWheelEvent)youcangetnoinfoCIBQ1Т3ъХ);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatScrollPaneUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */