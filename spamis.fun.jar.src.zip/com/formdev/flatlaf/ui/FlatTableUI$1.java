/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.event.FocusEvent;
/*     */ import javax.swing.plaf.basic.BasicTableUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTableUI$1
/*     */   extends BasicTableUI.FocusHandler
/*     */ {
/*     */   public final FlatTableUI this$0;
/*     */   
/*     */   public FlatTableUI$1() {
/* 159 */     super((BasicTableUI)youcangetnoinfoATFCХБ5Гс);
/*     */   }
/*     */   public void focusGained(Object youcangetnoinfoEGMG2жщРБ) {
/* 162 */     super.focusGained((FocusEvent)youcangetnoinfoEGMG2жщРБ);
/* 163 */     FlatTableUI.access$000(((FlatTableUI$1)super).this$0, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost(Object youcangetnoinfoCQMLДТуыР) {
/* 168 */     super.focusLost((FocusEvent)youcangetnoinfoCQMLДТуыР);
/* 169 */     FlatTableUI.access$000(((FlatTableUI$1)super).this$0, false);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTableUI$1.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */