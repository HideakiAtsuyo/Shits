/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatInternalFrameUI
/*     */   extends BasicInternalFrameUI
/*     */ {
/*     */   public static ComponentUI createUI(Object youcangetnoinfoCCVVАэИ0ъ) {
/*  88 */     return new FlatInternalFrameUI((JInternalFrame)youcangetnoinfoCCVVАэИ0ъ);
/*     */   }
/*     */   
/*     */   public FlatInternalFrameUI(Object youcangetnoinfoBOEWКЕдт3) {
/*  92 */     super((JInternalFrame)youcangetnoinfoBOEWКЕдт3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void installUI(Object youcangetnoinfoBFDR6с7ЬЩ) {
/*  97 */     super.installUI((JComponent)youcangetnoinfoBFDR6с7ЬЩ);
/*     */     
/*  99 */     LookAndFeel.installProperty(((FlatInternalFrameUI)this).frame, "opaque", Boolean.valueOf(false));
/*     */   }
/*     */ 
/*     */   
/*     */   public JComponent createNorthPane(Object youcangetnoinfoCKKBпцм2г) {
/* 104 */     return new FlatInternalFrameTitlePane((JInternalFrame)youcangetnoinfoCKKBпцм2г);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatInternalFrameUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */