/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import javax.swing.JSeparator;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicSeparatorUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatSeparatorUI
/*     */   extends BasicSeparatorUI
/*     */ {
/*     */   public int stripeIndent;
/*     */   public static ComponentUI instance;
/*     */   public int height;
/*     */   public boolean defaults_initialized;
/*     */   public int stripeWidth;
/*     */   
/*     */   public FlatSeparatorUI() {
/*  53 */     ((FlatSeparatorUI)super).defaults_initialized = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoBITEЛЩьЯЩ) {
/*  58 */     if (instance == null)
/*  59 */       instance = new FlatSeparatorUI(); 
/*  60 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults(Object youcangetnoinfoAPWOы3ЫнХ) {
/*  65 */     super.installDefaults((JSeparator)youcangetnoinfoAPWOы3ЫнХ);
/*     */     
/*  67 */     if (!((FlatSeparatorUI)super).defaults_initialized) {
/*  68 */       Object youcangetnoinfoAPWMЭуХzь = super.getPropertyPrefix();
/*  69 */       ((FlatSeparatorUI)super).height = UIManager.getInt(youcangetnoinfoAPWMЭуХzь + ".height");
/*  70 */       ((FlatSeparatorUI)super).stripeWidth = UIManager.getInt(youcangetnoinfoAPWMЭуХzь + ".stripeWidth");
/*  71 */       ((FlatSeparatorUI)super).stripeIndent = UIManager.getInt(youcangetnoinfoAPWMЭуХzь + ".stripeIndent");
/*     */       
/*  73 */       ((FlatSeparatorUI)super).defaults_initialized = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults(Object youcangetnoinfoAVZFЁпаЮЮ) {
/*  79 */     super.uninstallDefaults((JSeparator)youcangetnoinfoAVZFЁпаЮЮ);
/*  80 */     ((FlatSeparatorUI)super).defaults_initialized = false;
/*     */   }
/*     */   
/*     */   public String getPropertyPrefix() {
/*  84 */     return "Separator";
/*     */   }
/*     */ 
/*     */   
/*     */   public void paint(Object youcangetnoinfoBAYKЪаяzЖ, Object youcangetnoinfoBAYLц9эРт) {
/*  89 */     Object youcangetnoinfoBAYMчжъЗю = youcangetnoinfoBAYKЪаяzЖ.create();
/*     */     
/*  91 */     try { FlatUIUtils.setRenderingHints((Graphics2D)youcangetnoinfoBAYMчжъЗю);
/*  92 */       youcangetnoinfoBAYMчжъЗю.setColor(youcangetnoinfoBAYLц9эРт.getForeground());
/*     */       
/*  94 */       float f1 = UIScale.scale(((FlatSeparatorUI)super).stripeWidth);
/*  95 */       float f2 = UIScale.scale(((FlatSeparatorUI)super).stripeIndent);
/*     */       
/*  97 */       if (((JSeparator)youcangetnoinfoBAYLц9эРт).getOrientation() == 1) {
/*  98 */         youcangetnoinfoBAYMчжъЗю.fill(new Rectangle2D.Float(f2, 0.0F, f1, youcangetnoinfoBAYLц9эРт.getHeight()));
/*     */       } else {
/* 100 */         youcangetnoinfoBAYMчжъЗю.fill(new Rectangle2D.Float(0.0F, f2, youcangetnoinfoBAYLц9эРт.getWidth(), f1));
/*     */       }  }
/* 102 */     finally { youcangetnoinfoBAYMчжъЗю.dispose(); }
/*     */   
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoVLEЗеёЕЕ) {
/* 108 */     if (((JSeparator)youcangetnoinfoVLEЗеёЕЕ).getOrientation() == 1) {
/* 109 */       return new Dimension(UIScale.scale(((FlatSeparatorUI)super).height), 0);
/*     */     }
/* 111 */     return new Dimension(0, UIScale.scale(((FlatSeparatorUI)super).height));
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatSeparatorUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */