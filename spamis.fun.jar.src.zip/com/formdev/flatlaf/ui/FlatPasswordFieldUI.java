/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.FocusListener;
/*     */ import java.awt.event.KeyListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.Icon;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicPasswordFieldUI;
/*     */ import javax.swing.text.Caret;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatPasswordFieldUI
/*     */   extends BasicPasswordFieldUI
/*     */ {
/*     */   public int arc;
/*     */   public KeyListener capsLockListener;
/*     */   public Color placeholderForeground;
/*     */   public int focusWidth;
/*     */   public boolean isIntelliJTheme;
/*     */   public Icon capsLockIcon;
/*     */   public FocusListener focusListener;
/*     */   public int minimumWidth;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoEIVU83Ё93) {
/*  84 */     return new FlatPasswordFieldUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/*  89 */     super.installDefaults();
/*     */     
/*  91 */     Object youcangetnoinfoENVMеШ3ФИ = getPropertyPrefix();
/*  92 */     ((FlatPasswordFieldUI)super).arc = UIManager.getInt("TextComponent.arc");
/*  93 */     ((FlatPasswordFieldUI)super).focusWidth = UIManager.getInt("Component.focusWidth");
/*  94 */     ((FlatPasswordFieldUI)super).minimumWidth = UIManager.getInt("Component.minimumWidth");
/*  95 */     ((FlatPasswordFieldUI)super).isIntelliJTheme = UIManager.getBoolean("Component.isIntelliJTheme");
/*  96 */     ((FlatPasswordFieldUI)super).placeholderForeground = UIManager.getColor(youcangetnoinfoENVMеШ3ФИ + ".placeholderForeground");
/*  97 */     ((FlatPasswordFieldUI)super).capsLockIcon = UIManager.getIcon("PasswordField.capsLockIcon");
/*     */     
/*  99 */     LookAndFeel.installProperty(getComponent(), "opaque", Boolean.valueOf((((FlatPasswordFieldUI)super).focusWidth == 0)));
/*     */     
/* 101 */     MigLayoutVisualPadding.install(getComponent(), ((FlatPasswordFieldUI)super).focusWidth);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/* 106 */     super.uninstallDefaults();
/*     */     
/* 108 */     ((FlatPasswordFieldUI)super).placeholderForeground = null;
/* 109 */     ((FlatPasswordFieldUI)super).capsLockIcon = null;
/*     */     
/* 111 */     MigLayoutVisualPadding.uninstall(getComponent());
/*     */   }
/*     */ 
/*     */   
/*     */   public void installListeners() {
/* 116 */     super.installListeners();
/*     */     
/* 118 */     ((FlatPasswordFieldUI)super).focusListener = new FlatUIUtils$RepaintFocusListener(getComponent());
/* 119 */     ((FlatPasswordFieldUI)super).capsLockListener = new FlatPasswordFieldUI$1((FlatPasswordFieldUI)this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 134 */     getComponent().addFocusListener(((FlatPasswordFieldUI)super).focusListener);
/* 135 */     getComponent().addKeyListener(((FlatPasswordFieldUI)super).capsLockListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners() {
/* 140 */     super.uninstallListeners();
/*     */     
/* 142 */     getComponent().removeFocusListener(((FlatPasswordFieldUI)super).focusListener);
/* 143 */     getComponent().removeKeyListener(((FlatPasswordFieldUI)super).capsLockListener);
/* 144 */     ((FlatPasswordFieldUI)super).focusListener = null;
/* 145 */     ((FlatPasswordFieldUI)super).capsLockListener = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Caret createCaret() {
/* 150 */     return new FlatCaret(UIManager.getString("TextComponent.selectAllOnFocusPolicy"));
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(Object youcangetnoinfoAYBNАфЮм3) {
/* 155 */     super.propertyChange((PropertyChangeEvent)youcangetnoinfoAYBNАфЮм3);
/*     */     
/* 157 */     if ("JTextField.placeholderText".equals(youcangetnoinfoAYBNАфЮм3.getPropertyName())) {
/* 158 */       getComponent().repaint();
/*     */     }
/*     */   }
/*     */   
/*     */   public void paintSafely(Object youcangetnoinfoARRVябИфл) {
/* 163 */     FlatTextFieldUI.paintBackground((Graphics)youcangetnoinfoARRVябИфл, getComponent(), ((FlatPasswordFieldUI)super).focusWidth, ((FlatPasswordFieldUI)super).arc, ((FlatPasswordFieldUI)super).isIntelliJTheme);
/* 164 */     FlatTextFieldUI.paintPlaceholder((Graphics)youcangetnoinfoARRVябИфл, getComponent(), ((FlatPasswordFieldUI)super).placeholderForeground);
/* 165 */     super.paintCapsLock((Graphics)youcangetnoinfoARRVябИфл);
/* 166 */     super.paintSafely((Graphics)youcangetnoinfoARRVябИфл);
/*     */   }
/*     */   
/*     */   public void paintCapsLock(Object youcangetnoinfoARNEУХНжФ) {
/* 170 */     Object youcangetnoinfoARNFДЦЙЁЦ = getComponent();
/* 171 */     if (!youcangetnoinfoARNFДЦЙЁЦ.isFocusOwner() || 
/* 172 */       !Toolkit.getDefaultToolkit().getLockingKeyState(20)) {
/*     */       return;
/*     */     }
/* 175 */     int i = (youcangetnoinfoARNFДЦЙЁЦ.getHeight() - ((FlatPasswordFieldUI)super).capsLockIcon.getIconHeight()) / 2;
/* 176 */     int j = youcangetnoinfoARNFДЦЙЁЦ.getWidth() - ((FlatPasswordFieldUI)super).capsLockIcon.getIconWidth() - i;
/* 177 */     ((FlatPasswordFieldUI)super).capsLockIcon.paintIcon((Component)youcangetnoinfoARNFДЦЙЁЦ, (Graphics)youcangetnoinfoARNEУХНжФ, j, i);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void paintBackground(Object youcangetnoinfoDECV3д9Ё4) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoCRXNЫ2швХ) {
/* 187 */     return super.applyMinimumWidth(super.getPreferredSize((JComponent)youcangetnoinfoCRXNЫ2швХ), (JComponent)youcangetnoinfoCRXNЫ2швХ);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(Object youcangetnoinfoEOTZл0Нуж) {
/* 192 */     return super.applyMinimumWidth(super.getMinimumSize((JComponent)youcangetnoinfoEOTZл0Нуж), (JComponent)youcangetnoinfoEOTZл0Нуж);
/*     */   }
/*     */   
/*     */   public Dimension applyMinimumWidth(Object youcangetnoinfoEBTWсХчЖ8, Object youcangetnoinfoEBTXыйСлф) {
/* 196 */     int i = FlatUIUtils.minimumWidth(getComponent(), ((FlatPasswordFieldUI)super).minimumWidth);
/* 197 */     byte b = (youcangetnoinfoEBTXыйСлф.getBorder() instanceof FlatBorder) ? ((FlatPasswordFieldUI)super).focusWidth : 0;
/* 198 */     ((Dimension)youcangetnoinfoEBTWсХчЖ8).width = Math.max(((Dimension)youcangetnoinfoEBTWсХчЖ8).width, UIScale.scale(i + b * 2));
/* 199 */     return (Dimension)youcangetnoinfoEBTWсХчЖ8;
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatPasswordFieldUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */