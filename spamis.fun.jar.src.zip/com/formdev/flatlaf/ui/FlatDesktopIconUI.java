/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Image;
/*     */ import java.awt.Insets;
/*     */ import java.awt.LayoutManager;
/*     */ import java.awt.Point;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.beans.PropertyVetoException;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JLayeredPane;
/*     */ import javax.swing.JToolTip;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.SwingUtilities;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.event.MouseInputListener;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicDesktopIconUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatDesktopIconUI
/*     */   extends BasicDesktopIconUI
/*     */ {
/*     */   public Dimension closeSize;
/*     */   public JToolTip titleTip;
/*     */   public JLabel dockIcon;
/*     */   public Dimension iconSize;
/*     */   public ActionListener closeListener;
/*     */   public MouseInputListener mouseInputListener;
/*     */   public JButton closeButton;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoDZZYРЩУЛн) {
/*  80 */     return new FlatDesktopIconUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallUI(Object youcangetnoinfoMDTхОЩХ3) {
/*  85 */     super.uninstallUI((JComponent)youcangetnoinfoMDTхОЩХ3);
/*     */     
/*  87 */     ((FlatDesktopIconUI)super).dockIcon = null;
/*  88 */     ((FlatDesktopIconUI)super).closeButton = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void installComponents() {
/*  93 */     ((FlatDesktopIconUI)super).dockIcon = new JLabel();
/*  94 */     ((FlatDesktopIconUI)super).dockIcon.setHorizontalAlignment(0);
/*     */     
/*  96 */     ((FlatDesktopIconUI)super).closeButton = new JButton();
/*  97 */     ((FlatDesktopIconUI)super).closeButton.setIcon(UIManager.getIcon("DesktopIcon.closeIcon"));
/*  98 */     ((FlatDesktopIconUI)super).closeButton.setFocusable(false);
/*  99 */     ((FlatDesktopIconUI)super).closeButton.setBorder(BorderFactory.createEmptyBorder());
/* 100 */     ((FlatDesktopIconUI)super).closeButton.setOpaque(true);
/* 101 */     ((FlatDesktopIconUI)super).closeButton.setBackground(FlatUIUtils.nonUIResource(((FlatDesktopIconUI)this).desktopIcon.getBackground()));
/* 102 */     ((FlatDesktopIconUI)super).closeButton.setForeground(FlatUIUtils.nonUIResource(((FlatDesktopIconUI)this).desktopIcon.getForeground()));
/* 103 */     ((FlatDesktopIconUI)super).closeButton.setVisible(false);
/*     */     
/* 105 */     ((FlatDesktopIconUI)this).desktopIcon.setLayout(new FlatDesktopIconUI$FlatDesktopIconLayout((FlatDesktopIconUI)this, null));
/* 106 */     ((FlatDesktopIconUI)this).desktopIcon.add(((FlatDesktopIconUI)super).closeButton);
/* 107 */     ((FlatDesktopIconUI)this).desktopIcon.add(((FlatDesktopIconUI)super).dockIcon);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallComponents() {
/* 112 */     super.hideTitleTip();
/*     */     
/* 114 */     ((FlatDesktopIconUI)this).desktopIcon.remove(((FlatDesktopIconUI)super).dockIcon);
/* 115 */     ((FlatDesktopIconUI)this).desktopIcon.remove(((FlatDesktopIconUI)super).closeButton);
/* 116 */     ((FlatDesktopIconUI)this).desktopIcon.setLayout((LayoutManager)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/* 121 */     super.installDefaults();
/*     */     
/* 123 */     LookAndFeel.installColors(((FlatDesktopIconUI)this).desktopIcon, "DesktopIcon.background", "DesktopIcon.foreground");
/*     */     
/* 125 */     ((FlatDesktopIconUI)super).iconSize = UIManager.getDimension("DesktopIcon.iconSize");
/* 126 */     ((FlatDesktopIconUI)super).closeSize = UIManager.getDimension("DesktopIcon.closeSize");
/*     */   }
/*     */ 
/*     */   
/*     */   public void installListeners() {
/* 131 */     super.installListeners();
/*     */     
/* 133 */     ((FlatDesktopIconUI)super).closeListener = this::lambda$installListeners$0;
/*     */ 
/*     */ 
/*     */     
/* 137 */     ((FlatDesktopIconUI)super).closeButton.addActionListener(((FlatDesktopIconUI)super).closeListener);
/* 138 */     ((FlatDesktopIconUI)super).closeButton.addMouseListener(((FlatDesktopIconUI)super).mouseInputListener);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners() {
/* 143 */     super.uninstallListeners();
/*     */     
/* 145 */     ((FlatDesktopIconUI)super).closeButton.removeActionListener(((FlatDesktopIconUI)super).closeListener);
/* 146 */     ((FlatDesktopIconUI)super).closeButton.removeMouseListener(((FlatDesktopIconUI)super).mouseInputListener);
/* 147 */     ((FlatDesktopIconUI)super).closeListener = null;
/* 148 */     ((FlatDesktopIconUI)super).mouseInputListener = null;
/*     */   } public void lambda$installListeners$0(Object youcangetnoinfoBAAAёБ1Нч) {
/*     */     if (((FlatDesktopIconUI)this).frame.isClosable())
/*     */       ((FlatDesktopIconUI)this).frame.doDefaultCloseAction(); 
/*     */   } public MouseInputListener createMouseInputListener() {
/* 153 */     ((FlatDesktopIconUI)super).mouseInputListener = new FlatDesktopIconUI$1((FlatDesktopIconUI)this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     return ((FlatDesktopIconUI)super).mouseInputListener;
/*     */   }
/*     */   
/*     */   public void showTitleTip() {
/* 185 */     Object youcangetnoinfoABYRзг5Ив = SwingUtilities.getRootPane(((FlatDesktopIconUI)this).desktopIcon);
/* 186 */     if (youcangetnoinfoABYRзг5Ив == null) {
/*     */       return;
/*     */     }
/* 189 */     if (((FlatDesktopIconUI)super).titleTip == null) {
/* 190 */       ((FlatDesktopIconUI)super).titleTip = new JToolTip();
/* 191 */       youcangetnoinfoABYRзг5Ив.getLayeredPane().add(((FlatDesktopIconUI)super).titleTip, JLayeredPane.POPUP_LAYER);
/*     */     } 
/* 193 */     ((FlatDesktopIconUI)super).titleTip.setTipText(((FlatDesktopIconUI)this).frame.getTitle());
/* 194 */     ((FlatDesktopIconUI)super).titleTip.setSize(((FlatDesktopIconUI)super).titleTip.getPreferredSize());
/*     */     
/* 196 */     int i = (((FlatDesktopIconUI)this).desktopIcon.getWidth() - ((FlatDesktopIconUI)super).titleTip.getWidth()) / 2;
/* 197 */     int j = -(((FlatDesktopIconUI)super).titleTip.getHeight() + UIScale.scale(4));
/* 198 */     Object youcangetnoinfoABYUмПВЫс = SwingUtilities.convertPoint(((FlatDesktopIconUI)this).desktopIcon, i, j, ((FlatDesktopIconUI)super).titleTip.getParent());
/* 199 */     if (((Point)youcangetnoinfoABYUмПВЫс).x + ((FlatDesktopIconUI)super).titleTip.getWidth() > youcangetnoinfoABYRзг5Ив.getWidth())
/* 200 */       ((Point)youcangetnoinfoABYUмПВЫс).x = youcangetnoinfoABYRзг5Ив.getWidth() - ((FlatDesktopIconUI)super).titleTip.getWidth(); 
/* 201 */     if (((Point)youcangetnoinfoABYUмПВЫс).x < 0)
/* 202 */       ((Point)youcangetnoinfoABYUмПВЫс).x = 0; 
/* 203 */     ((FlatDesktopIconUI)super).titleTip.setLocation((Point)youcangetnoinfoABYUмПВЫс);
/* 204 */     ((FlatDesktopIconUI)super).titleTip.repaint();
/*     */   }
/*     */   
/*     */   public void hideTitleTip() {
/* 208 */     if (((FlatDesktopIconUI)super).titleTip == null) {
/*     */       return;
/*     */     }
/* 211 */     ((FlatDesktopIconUI)super).titleTip.setVisible(false);
/* 212 */     ((FlatDesktopIconUI)super).titleTip.getParent().remove(((FlatDesktopIconUI)super).titleTip);
/* 213 */     ((FlatDesktopIconUI)super).titleTip = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getPreferredSize(Object youcangetnoinfoRUDэлЁщч) {
/* 218 */     return UIScale.scale(((FlatDesktopIconUI)super).iconSize);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMinimumSize(Object youcangetnoinfoBZRLЙ3ЮНщ) {
/* 223 */     return super.getPreferredSize((JComponent)youcangetnoinfoBZRLЙ3ЮНщ);
/*     */   }
/*     */ 
/*     */   
/*     */   public Dimension getMaximumSize(Object youcangetnoinfoEDXHин67и) {
/* 228 */     return super.getPreferredSize((JComponent)youcangetnoinfoEDXHин67и);
/*     */   }
/*     */   
/*     */   public void updateDockIcon()
/*     */   {
/* 233 */     EventQueue.invokeLater(this::lambda$updateDockIcon$1); } public void lambda$updateDockIcon$1() {
/* 234 */     if (((FlatDesktopIconUI)super).dockIcon != null) {
/* 235 */       super.updateDockIconLater();
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateDockIconLater() {
/* 241 */     if (((FlatDesktopIconUI)this).frame.isSelected()) {
/*     */       try {
/* 243 */         ((FlatDesktopIconUI)this).frame.setSelected(false);
/* 244 */       } catch (PropertyVetoException propertyVetoException) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     int i = Math.max(((FlatDesktopIconUI)this).frame.getWidth(), 1);
/* 251 */     int j = Math.max(((FlatDesktopIconUI)this).frame.getHeight(), 1);
/* 252 */     Object youcangetnoinfoCFQMеЮ4Кг = new BufferedImage(i, j, 2);
/* 253 */     Object youcangetnoinfoCFQNЬыТбЮ = youcangetnoinfoCFQMеЮ4Кг.createGraphics();
/*     */     
/*     */     try {
/* 256 */       ((FlatDesktopIconUI)this).frame.paint((Graphics)youcangetnoinfoCFQNЬыТбЮ);
/*     */     } finally {
/* 258 */       youcangetnoinfoCFQNЬыТбЮ.dispose();
/*     */     } 
/*     */ 
/*     */     
/* 262 */     Object youcangetnoinfoCFQOЧ6zЪЕ = ((FlatDesktopIconUI)this).desktopIcon.getInsets();
/* 263 */     int k = UIScale.scale(((FlatDesktopIconUI)super).iconSize.width) - ((Insets)youcangetnoinfoCFQOЧ6zЪЕ).left - ((Insets)youcangetnoinfoCFQOЧ6zЪЕ).right;
/* 264 */     int m = UIScale.scale(((FlatDesktopIconUI)super).iconSize.height) - ((Insets)youcangetnoinfoCFQOЧ6zЪЕ).top - ((Insets)youcangetnoinfoCFQOЧ6zЪЕ).bottom;
/* 265 */     float f = j / i;
/* 266 */     if (k / i > m / j) {
/* 267 */       k = Math.round(m / f);
/*     */     } else {
/* 269 */       m = Math.round(k * f);
/*     */     } 
/*     */     
/* 272 */     Object youcangetnoinfoCFQS68тфВ = youcangetnoinfoCFQMеЮ4Кг.getScaledInstance(k, m, 4);
/* 273 */     ((FlatDesktopIconUI)super).dockIcon.setIcon(new ImageIcon((Image)youcangetnoinfoCFQS68тфВ));
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatDesktopIconUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */