/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.event.FocusEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import javax.swing.plaf.UIResource;
/*     */ import javax.swing.text.DefaultCaret;
/*     */ import javax.swing.text.JTextComponent;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatCaret
/*     */   extends DefaultCaret
/*     */   implements UIResource
/*     */ {
/*     */   public boolean isMousePressed;
/*     */   public boolean wasTemporaryLost;
/*     */   public final String selectAllOnFocusPolicy;
/*     */   public boolean wasFocused;
/*     */   
/*     */   public FlatCaret(Object youcangetnoinfoASKLВНю94) {
/*  45 */     ((FlatCaret)super).selectAllOnFocusPolicy = (String)youcangetnoinfoASKLВНю94;
/*     */   }
/*     */ 
/*     */   
/*     */   public void install(Object youcangetnoinfoBELTЪФ7ЬН) {
/*  50 */     super.install((JTextComponent)youcangetnoinfoBELTЪФ7ЬН);
/*     */ 
/*     */ 
/*     */     
/*  54 */     Object youcangetnoinfoBELUЖzшФу = youcangetnoinfoBELTЪФ7ЬН.getDocument();
/*  55 */     if (youcangetnoinfoBELUЖzшФу != null && getDot() == 0 && getMark() == 0) {
/*  56 */       int i = youcangetnoinfoBELUЖzшФу.getLength();
/*  57 */       if (i > 0) {
/*  58 */         setDot(i);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void focusGained(Object youcangetnoinfoENKVЕщЯЧи) {
/*  64 */     if (!((FlatCaret)super).wasTemporaryLost && !((FlatCaret)super).isMousePressed)
/*  65 */       super.selectAllOnFocusGained(); 
/*  66 */     ((FlatCaret)super).wasTemporaryLost = false;
/*  67 */     ((FlatCaret)super).wasFocused = true;
/*     */     
/*  69 */     super.focusGained((FocusEvent)youcangetnoinfoENKVЕщЯЧи);
/*     */   }
/*     */ 
/*     */   
/*     */   public void focusLost(Object youcangetnoinfoAVXNЪВЕГ9) {
/*  74 */     ((FlatCaret)super).wasTemporaryLost = youcangetnoinfoAVXNЪВЕГ9.isTemporary();
/*  75 */     super.focusLost((FocusEvent)youcangetnoinfoAVXNЪВЕГ9);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mousePressed(Object youcangetnoinfoBWPRвТХЛП) {
/*  80 */     ((FlatCaret)super).isMousePressed = true;
/*  81 */     super.mousePressed((MouseEvent)youcangetnoinfoBWPRвТХЛП);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseReleased(Object youcangetnoinfoCUHXЪЛЁюП) {
/*  86 */     ((FlatCaret)super).isMousePressed = false;
/*  87 */     super.mouseReleased((MouseEvent)youcangetnoinfoCUHXЪЛЁюП);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void selectAllOnFocusGained() {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: invokevirtual getComponent : ()Ljavax/swing/text/JTextComponent;
/*     */     //   4: astore_1
/*     */     //   5: aload_1
/*     */     //   6: invokevirtual getDocument : ()Ljavax/swing/text/Document;
/*     */     //   9: astore_2
/*     */     //   10: aload_2
/*     */     //   11: ifnull -> 28
/*     */     //   14: aload_1
/*     */     //   15: invokevirtual isEnabled : ()Z
/*     */     //   18: ifeq -> 28
/*     */     //   21: aload_1
/*     */     //   22: invokevirtual isEditable : ()Z
/*     */     //   25: ifne -> 29
/*     */     //   28: return
/*     */     //   29: aload_1
/*     */     //   30: ldc 'JTextField.selectAllOnFocusPolicy'
/*     */     //   32: invokevirtual getClientProperty : (Ljava/lang/Object;)Ljava/lang/Object;
/*     */     //   35: astore_3
/*     */     //   36: aload_3
/*     */     //   37: ifnonnull -> 45
/*     */     //   40: aload_0
/*     */     //   41: getfield selectAllOnFocusPolicy : Ljava/lang/String;
/*     */     //   44: astore_3
/*     */     //   45: ldc 'never'
/*     */     //   47: aload_3
/*     */     //   48: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   51: ifeq -> 55
/*     */     //   54: return
/*     */     //   55: ldc 'always'
/*     */     //   57: aload_3
/*     */     //   58: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   61: ifne -> 103
/*     */     //   64: aload_0
/*     */     //   65: getfield wasFocused : Z
/*     */     //   68: ifeq -> 72
/*     */     //   71: return
/*     */     //   72: aload_0
/*     */     //   73: invokevirtual getDot : ()I
/*     */     //   76: istore #4
/*     */     //   78: aload_0
/*     */     //   79: invokevirtual getMark : ()I
/*     */     //   82: istore #5
/*     */     //   84: iload #4
/*     */     //   86: iload #5
/*     */     //   88: if_icmpne -> 102
/*     */     //   91: iload #4
/*     */     //   93: aload_2
/*     */     //   94: invokeinterface getLength : ()I
/*     */     //   99: if_icmpeq -> 103
/*     */     //   102: return
/*     */     //   103: aload_1
/*     */     //   104: instanceof javax/swing/JFormattedTextField
/*     */     //   107: ifeq -> 123
/*     */     //   110: aload_0
/*     */     //   111: aload_2
/*     */     //   112: <illegal opcode> run : (Lcom/formdev/flatlaf/ui/FlatCaret;Ljavax/swing/text/Document;)Ljava/lang/Runnable;
/*     */     //   117: invokestatic invokeLater : (Ljava/lang/Runnable;)V
/*     */     //   120: goto -> 138
/*     */     //   123: aload_0
/*     */     //   124: iconst_0
/*     */     //   125: invokevirtual setDot : (I)V
/*     */     //   128: aload_0
/*     */     //   129: aload_2
/*     */     //   130: invokeinterface getLength : ()I
/*     */     //   135: invokevirtual moveDot : (I)V
/*     */     //   138: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #91	-> 0
/*     */     //   #92	-> 5
/*     */     //   #93	-> 10
/*     */     //   #94	-> 28
/*     */     //   #96	-> 29
/*     */     //   #97	-> 36
/*     */     //   #98	-> 40
/*     */     //   #100	-> 45
/*     */     //   #101	-> 54
/*     */     //   #103	-> 55
/*     */     //   #107	-> 64
/*     */     //   #108	-> 71
/*     */     //   #111	-> 72
/*     */     //   #112	-> 78
/*     */     //   #113	-> 84
/*     */     //   #114	-> 102
/*     */     //   #118	-> 103
/*     */     //   #119	-> 110
/*     */     //   #124	-> 123
/*     */     //   #125	-> 128
/*     */     //   #127	-> 138
/*     */     // Local variable table:
/*     */     //   start	length	slot	name	descriptor
/*     */     //   5	134	1	youcangetnoinfoAVEPА8ЮЦн	Ljava/lang/Object;
/*     */     //   10	129	2	youcangetnoinfoAVEQИ66ыР	Ljava/lang/Object;
/*     */     //   36	103	3	youcangetnoinfoAVERкоО5З	Ljava/lang/Object;
/*     */     //   0	139	0	youcangetnoinfoAVEOюВБ7Г	Ljava/lang/Object;
/*     */     //   78	25	4	youcangetnoinfoAVEMЪРзыд	Ljava/lang/Object;
/*     */     //   84	19	5	youcangetnoinfoAVENтчгёи	Ljava/lang/Object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void lambda$selectAllOnFocusGained$0(Object youcangetnoinfoAPBOраЛВЗ) {
/* 120 */     setDot(0);
/* 121 */     moveDot(youcangetnoinfoAPBOраЛВЗ.getLength());
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatCaret.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */