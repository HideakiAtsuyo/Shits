/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import javax.swing.plaf.basic.BasicInternalFrameTitlePane;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatInternalFrameTitlePane$FlatPropertyChangeHandler
/*     */   extends BasicInternalFrameTitlePane.PropertyChangeHandler
/*     */ {
/*     */   public final FlatInternalFrameTitlePane this$0;
/*     */   
/*     */   public FlatInternalFrameTitlePane$FlatPropertyChangeHandler() {}
/*     */   
/*     */   public FlatInternalFrameTitlePane$FlatPropertyChangeHandler(Object youcangetnoinfoCTHX3уЁЫЪ) {
/* 153 */     super((FlatInternalFrameTitlePane)youcangetnoinfoCTHWУёХжф);
/*     */   }
/*     */ 
/*     */   
/*     */   public void propertyChange(Object youcangetnoinfoHJVЭЙЕшв) {
/* 158 */     switch (youcangetnoinfoHJVЭЙЕшв.getPropertyName()) {
/*     */       case "title":
/* 160 */         FlatInternalFrameTitlePane.access$200(FlatInternalFrameTitlePane.this).setText(FlatInternalFrameTitlePane.access$100(FlatInternalFrameTitlePane.this).getTitle());
/*     */         break;
/*     */       
/*     */       case "frameIcon":
/* 164 */         FlatInternalFrameTitlePane.access$300(FlatInternalFrameTitlePane.this);
/*     */         break;
/*     */       
/*     */       case "selected":
/* 168 */         FlatInternalFrameTitlePane.access$400(FlatInternalFrameTitlePane.this);
/*     */         break;
/*     */       
/*     */       case "iconable":
/*     */       case "maximizable":
/*     */       case "closable":
/* 174 */         FlatInternalFrameTitlePane.access$500(FlatInternalFrameTitlePane.this);
/* 175 */         FlatInternalFrameTitlePane.access$600(FlatInternalFrameTitlePane.this);
/* 176 */         FlatInternalFrameTitlePane.this.revalidate();
/* 177 */         FlatInternalFrameTitlePane.this.repaint();
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case "componentOrientation":
/* 183 */         FlatInternalFrameTitlePane.this.applyComponentOrientation(FlatInternalFrameTitlePane.access$700(FlatInternalFrameTitlePane.this).getComponentOrientation());
/*     */         break;
/*     */     } 
/*     */     
/* 187 */     super.propertyChange((PropertyChangeEvent)youcangetnoinfoHJVЭЙЕшв);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatInternalFrameTitlePane$FlatPropertyChangeHandler.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */