/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import java.awt.Component;
/*    */ import java.awt.Insets;
/*    */ import javax.swing.plaf.basic.BasicBorders;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatMarginBorder
/*    */   extends BasicBorders.MarginBorder
/*    */ {
/*    */   public final int right;
/*    */   public final int bottom;
/*    */   public final int left;
/*    */   public final int top;
/*    */   
/*    */   public FlatMarginBorder() {
/* 35 */     ((FlatMarginBorder)super).left = ((FlatMarginBorder)super).right = ((FlatMarginBorder)super).top = ((FlatMarginBorder)super).bottom = 0;
/*    */   }
/*    */   
/*    */   public FlatMarginBorder(Object youcangetnoinfoAUARЗяжфу) {
/* 39 */     ((FlatMarginBorder)super).left = ((Insets)youcangetnoinfoAUARЗяжфу).left;
/* 40 */     ((FlatMarginBorder)super).top = ((Insets)youcangetnoinfoAUARЗяжфу).top;
/* 41 */     ((FlatMarginBorder)super).right = ((Insets)youcangetnoinfoAUARЗяжфу).right;
/* 42 */     ((FlatMarginBorder)super).bottom = ((Insets)youcangetnoinfoAUARЗяжфу).bottom;
/*    */   }
/*    */ 
/*    */   
/*    */   public Insets getBorderInsets(Object youcangetnoinfoBDMC2ЫхжК, Object youcangetnoinfoBDMDzЛ6ЛН) {
/* 47 */     youcangetnoinfoBDMDzЛ6ЛН = super.getBorderInsets((Component)youcangetnoinfoBDMC2ЫхжК, (Insets)youcangetnoinfoBDMDzЛ6ЛН);
/* 48 */     ((Insets)youcangetnoinfoBDMDzЛ6ЛН).top = UIScale.scale(((Insets)youcangetnoinfoBDMDzЛ6ЛН).top + ((FlatMarginBorder)super).top);
/* 49 */     ((Insets)youcangetnoinfoBDMDzЛ6ЛН).left = UIScale.scale(((Insets)youcangetnoinfoBDMDzЛ6ЛН).left + ((FlatMarginBorder)super).left);
/* 50 */     ((Insets)youcangetnoinfoBDMDzЛ6ЛН).bottom = UIScale.scale(((Insets)youcangetnoinfoBDMDzЛ6ЛН).bottom + ((FlatMarginBorder)super).bottom);
/* 51 */     ((Insets)youcangetnoinfoBDMDzЛ6ЛН).right = UIScale.scale(((Insets)youcangetnoinfoBDMDzЛ6ЛН).right + ((FlatMarginBorder)super).right);
/* 52 */     return (Insets)youcangetnoinfoBDMDzЛ6ЛН;
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatMarginBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */