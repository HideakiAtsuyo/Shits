/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatTableCellBorder
/*    */   extends FlatLineBorder
/*    */ {
/*    */   public final boolean showCellFocusIndicator;
/*    */   
/*    */   public FlatTableCellBorder() {
/* 39 */     super(UIManager.getInsets("Table.cellMargins"), UIManager.getColor("Table.cellFocusColor"));
/*    */     ((FlatTableCellBorder)super).showCellFocusIndicator = UIManager.getBoolean("Table.showCellFocusIndicator");
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTableCellBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */