/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Insets;
/*     */ import java.awt.Rectangle;
/*     */ import java.awt.event.MouseWheelEvent;
/*     */ import java.awt.event.MouseWheelListener;
/*     */ import java.beans.PropertyChangeEvent;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JViewport;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicScrollPaneUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatScrollPaneUI
/*     */   extends BasicScrollPaneUI
/*     */ {
/*     */   public static final double EPSILON = 1.0E-5D;
/*     */   public FlatScrollPaneUI$Handler handler;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoARZUэЦ9Дь) {
/*  76 */     return new FlatScrollPaneUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installUI(Object youcangetnoinfoCASDЩяё0Р) {
/*  81 */     super.installUI((JComponent)youcangetnoinfoCASDЩяё0Р);
/*     */     
/*  83 */     int i = UIManager.getInt("Component.focusWidth");
/*  84 */     LookAndFeel.installProperty((JComponent)youcangetnoinfoCASDЩяё0Р, "opaque", Boolean.valueOf((i == 0)));
/*     */     
/*  86 */     MigLayoutVisualPadding.install(((FlatScrollPaneUI)this).scrollpane, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallUI(Object youcangetnoinfoBRQFсёешЗ) {
/*  91 */     MigLayoutVisualPadding.uninstall(((FlatScrollPaneUI)this).scrollpane);
/*     */     
/*  93 */     super.uninstallUI((JComponent)youcangetnoinfoBRQFсёешЗ);
/*     */   }
/*     */ 
/*     */   
/*     */   public void installListeners(Object youcangetnoinfoVPLйВгЗй) {
/*  98 */     super.installListeners((JScrollPane)youcangetnoinfoVPLйВгЗй);
/*     */     
/* 100 */     super.addViewportListeners(((FlatScrollPaneUI)this).scrollpane.getViewport());
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallListeners(Object youcangetnoinfoBXLIЛЛлЫи) {
/* 105 */     super.uninstallListeners((JComponent)youcangetnoinfoBXLIЛЛлЫи);
/*     */     
/* 107 */     super.removeViewportListeners(((FlatScrollPaneUI)this).scrollpane.getViewport());
/*     */     
/* 109 */     ((FlatScrollPaneUI)super).handler = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public MouseWheelListener createMouseWheelListener() {
/* 114 */     return new FlatScrollPaneUI$1((FlatScrollPaneUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mouseWheelMovedSmooth(Object youcangetnoinfoDHHPЫЧЗэ0) {
/*     */     int i, j;
/* 137 */     Object youcangetnoinfoDHHQеИТкэ = ((FlatScrollPaneUI)this).scrollpane.getViewport();
/* 138 */     if (youcangetnoinfoDHHQеИТкэ == null) {
/*     */       return;
/*     */     }
/*     */     
/* 142 */     Object youcangetnoinfoDHHRЛТипВ = ((FlatScrollPaneUI)this).scrollpane.getVerticalScrollBar();
/* 143 */     if (youcangetnoinfoDHHRЛТипВ == null || !youcangetnoinfoDHHRЛТипВ.isVisible() || youcangetnoinfoDHHPЫЧЗэ0.isShiftDown()) {
/* 144 */       youcangetnoinfoDHHRЛТипВ = ((FlatScrollPaneUI)this).scrollpane.getHorizontalScrollBar();
/* 145 */       if (youcangetnoinfoDHHRЛТипВ == null || !youcangetnoinfoDHHRЛТипВ.isVisible()) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */     
/* 150 */     youcangetnoinfoDHHPЫЧЗэ0.consume();
/*     */ 
/*     */     
/* 153 */     double d1 = youcangetnoinfoDHHPЫЧЗэ0.getPreciseWheelRotation();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 158 */     int k = youcangetnoinfoDHHRЛТипВ.getOrientation();
/* 159 */     Object youcangetnoinfoDHHWаасюо = youcangetnoinfoDHHQеИТкэ.getView();
/* 160 */     if (youcangetnoinfoDHHWаасюо instanceof javax.swing.Scrollable) {
/* 161 */       Object youcangetnoinfoDHHJzЦж2й = youcangetnoinfoDHHWаасюо;
/*     */ 
/*     */ 
/*     */       
/* 165 */       Object youcangetnoinfoDHHKбНФШЁ = new Rectangle(youcangetnoinfoDHHQеИТкэ.getViewSize());
/* 166 */       i = youcangetnoinfoDHHJzЦж2й.getScrollableUnitIncrement((Rectangle)youcangetnoinfoDHHKбНФШЁ, k, 1);
/* 167 */       j = youcangetnoinfoDHHJzЦж2й.getScrollableBlockIncrement((Rectangle)youcangetnoinfoDHHKбНФШЁ, k, 1);
/*     */       
/* 169 */       if (i > 0) {
/*     */ 
/*     */ 
/*     */         
/* 173 */         if (k == 1) {
/* 174 */           ((Rectangle)youcangetnoinfoDHHKбНФШЁ).y += i;
/* 175 */           ((Rectangle)youcangetnoinfoDHHKбНФШЁ).height -= i;
/*     */         } else {
/* 177 */           ((Rectangle)youcangetnoinfoDHHKбНФШЁ).x += i;
/* 178 */           ((Rectangle)youcangetnoinfoDHHKбНФШЁ).width -= i;
/*     */         } 
/* 180 */         int i3 = youcangetnoinfoDHHJzЦж2й.getScrollableUnitIncrement((Rectangle)youcangetnoinfoDHHKбНФШЁ, k, 1);
/* 181 */         if (i3 > 0)
/* 182 */           i = Math.min(i, i3); 
/*     */       } 
/*     */     } else {
/* 185 */       boolean bool1 = (d1 < 0.0D) ? true : true;
/* 186 */       i = youcangetnoinfoDHHRЛТипВ.getUnitIncrement(bool1);
/* 187 */       j = youcangetnoinfoDHHRЛТипВ.getBlockIncrement(bool1);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 192 */     int m = youcangetnoinfoDHHPЫЧЗэ0.getScrollAmount();
/*     */ 
/*     */     
/* 195 */     int n = (k == 1) ? youcangetnoinfoDHHQеИТкэ.getHeight() : youcangetnoinfoDHHQеИТкэ.getWidth();
/* 196 */     if (i * m > n) {
/* 197 */       m = Math.max(n / i, 1);
/*     */     }
/*     */     
/* 200 */     double d2 = d1 * m * i;
/* 201 */     boolean bool = (Math.abs(d1) < 1.00001D) ? true : false;
/*     */ 
/*     */     
/* 204 */     double d3 = bool ? Math.max(-j, Math.min(d2, j)) : d2;
/*     */ 
/*     */     
/* 207 */     int i1 = youcangetnoinfoDHHRЛТипВ.getValue();
/* 208 */     double d4 = (youcangetnoinfoDHHRЛТипВ.getMinimum() - i1);
/* 209 */     double d5 = (youcangetnoinfoDHHRЛТипВ.getMaximum() - youcangetnoinfoDHHRЛТипВ.getModel().getExtent() - i1);
/* 210 */     double d6 = Math.max(d4, Math.min(d3, d5));
/* 211 */     int i2 = i1 + (int)Math.round(d6);
/*     */ 
/*     */     
/* 214 */     if (i2 != i1) {
/* 215 */       youcangetnoinfoDHHRЛТипВ.setValue(i2);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertyChangeListener createPropertyChangeListener() {
/* 238 */     return new FlatScrollPaneUI$2((FlatScrollPaneUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FlatScrollPaneUI$Handler getHandler() {
/* 278 */     if (((FlatScrollPaneUI)super).handler == null)
/* 279 */       ((FlatScrollPaneUI)super).handler = new FlatScrollPaneUI$Handler((FlatScrollPaneUI)this, null); 
/* 280 */     return ((FlatScrollPaneUI)super).handler;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateViewport(Object youcangetnoinfoDJIHа1Ё8ш) {
/* 285 */     super.updateViewport((PropertyChangeEvent)youcangetnoinfoDJIHа1Ё8ш);
/*     */     
/* 287 */     Object youcangetnoinfoDJIIоШТШz = youcangetnoinfoDJIHа1Ё8ш.getOldValue();
/* 288 */     Object youcangetnoinfoDJIJ8ЩжНх = youcangetnoinfoDJIHа1Ё8ш.getNewValue();
/*     */     
/* 290 */     super.removeViewportListeners((JViewport)youcangetnoinfoDJIIоШТШz);
/* 291 */     super.addViewportListeners((JViewport)youcangetnoinfoDJIJ8ЩжНх);
/*     */   }
/*     */   
/*     */   public void addViewportListeners(Object youcangetnoinfoAWJWЩ2чЬб) {
/* 295 */     if (youcangetnoinfoAWJWЩ2чЬб == null) {
/*     */       return;
/*     */     }
/* 298 */     youcangetnoinfoAWJWЩ2чЬб.addContainerListener(super.getHandler());
/*     */     
/* 300 */     Object youcangetnoinfoAWJXп59Ле = youcangetnoinfoAWJWЩ2чЬб.getView();
/* 301 */     if (youcangetnoinfoAWJXп59Ле != null)
/* 302 */       youcangetnoinfoAWJXп59Ле.addFocusListener(super.getHandler()); 
/*     */   }
/*     */   
/*     */   public void removeViewportListeners(Object youcangetnoinfoEJXIпзzИК) {
/* 306 */     if (youcangetnoinfoEJXIпзzИК == null) {
/*     */       return;
/*     */     }
/* 309 */     youcangetnoinfoEJXIпзzИК.removeContainerListener(super.getHandler());
/*     */     
/* 311 */     Object youcangetnoinfoEJXJфЁ6цГ = youcangetnoinfoEJXIпзzИК.getView();
/* 312 */     if (youcangetnoinfoEJXJфЁ6цГ != null) {
/* 313 */       youcangetnoinfoEJXJфЁ6цГ.removeFocusListener(super.getHandler());
/*     */     }
/*     */   }
/*     */   
/*     */   public void update(Object youcangetnoinfoEESAВ7ршР, Object youcangetnoinfoEESB02жфХ) {
/* 318 */     if (youcangetnoinfoEESB02жфХ.isOpaque()) {
/* 319 */       FlatUIUtils.paintParentBackground((Graphics)youcangetnoinfoEESAВ7ршР, (JComponent)youcangetnoinfoEESB02жфХ);
/*     */ 
/*     */       
/* 322 */       Object youcangetnoinfoEERYЕжС66 = youcangetnoinfoEESB02жфХ.getInsets();
/* 323 */       youcangetnoinfoEESAВ7ршР.setColor(youcangetnoinfoEESB02жфХ.getBackground());
/* 324 */       youcangetnoinfoEESAВ7ршР.fillRect(((Insets)youcangetnoinfoEERYЕжС66).left, ((Insets)youcangetnoinfoEERYЕжС66).top, youcangetnoinfoEESB02жфХ
/* 325 */           .getWidth() - ((Insets)youcangetnoinfoEERYЕжС66).left - ((Insets)youcangetnoinfoEERYЕжС66).right, youcangetnoinfoEESB02жфХ
/* 326 */           .getHeight() - ((Insets)youcangetnoinfoEERYЕжС66).top - ((Insets)youcangetnoinfoEERYЕжС66).bottom);
/*     */     } 
/*     */     
/* 329 */     paint((Graphics)youcangetnoinfoEESAВ7ршР, (JComponent)youcangetnoinfoEESB02жфХ);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatScrollPaneUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */