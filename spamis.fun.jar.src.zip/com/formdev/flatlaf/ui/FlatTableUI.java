/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import com.formdev.flatlaf.util.UIScale;
/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.event.FocusListener;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.LookAndFeel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.plaf.ComponentUI;
/*     */ import javax.swing.plaf.basic.BasicTableUI;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatTableUI
/*     */   extends BasicTableUI
/*     */ {
/*     */   public boolean showHorizontalLines;
/*     */   public Color selectionBackground;
/*     */   public boolean showVerticalLines;
/*     */   public Color selectionInactiveBackground;
/*     */   public Dimension oldIntercellSpacing;
/*     */   public Color selectionInactiveForeground;
/*     */   public Color selectionForeground;
/*     */   public boolean oldShowVerticalLines;
/*     */   public boolean oldShowHorizontalLines;
/*     */   public Dimension intercellSpacing;
/*     */   
/*     */   public static ComponentUI createUI(Object youcangetnoinfoWHкйПАр) {
/*  90 */     return new FlatTableUI();
/*     */   }
/*     */ 
/*     */   
/*     */   public void installUI(Object youcangetnoinfoAGY99БЪЗ) {
/*  95 */     super.installUI((JComponent)youcangetnoinfoAGY99БЪЗ);
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallUI(Object youcangetnoinfoDFFQФОпЦу) {
/* 100 */     super.uninstallUI((JComponent)youcangetnoinfoDFFQФОпЦу);
/*     */   }
/*     */ 
/*     */   
/*     */   public void installDefaults() {
/* 105 */     super.installDefaults();
/*     */     
/* 107 */     ((FlatTableUI)super).showHorizontalLines = UIManager.getBoolean("Table.showHorizontalLines");
/* 108 */     ((FlatTableUI)super).showVerticalLines = UIManager.getBoolean("Table.showVerticalLines");
/* 109 */     ((FlatTableUI)super).intercellSpacing = UIManager.getDimension("Table.intercellSpacing");
/*     */     
/* 111 */     ((FlatTableUI)super).selectionBackground = UIManager.getColor("Table.selectionBackground");
/* 112 */     ((FlatTableUI)super).selectionForeground = UIManager.getColor("Table.selectionForeground");
/* 113 */     ((FlatTableUI)super).selectionInactiveBackground = UIManager.getColor("Table.selectionInactiveBackground");
/* 114 */     ((FlatTableUI)super).selectionInactiveForeground = UIManager.getColor("Table.selectionInactiveForeground");
/*     */     
/* 116 */     super.toggleSelectionColors(((FlatTableUI)this).table.hasFocus());
/*     */     
/* 118 */     int i = FlatUIUtils.getUIInt("Table.rowHeight", 16);
/* 119 */     if (i > 0) {
/* 120 */       LookAndFeel.installProperty(((FlatTableUI)this).table, "rowHeight", Integer.valueOf(UIScale.scale(i)));
/*     */     }
/* 122 */     if (!((FlatTableUI)super).showHorizontalLines) {
/* 123 */       ((FlatTableUI)super).oldShowHorizontalLines = ((FlatTableUI)this).table.getShowHorizontalLines();
/* 124 */       ((FlatTableUI)this).table.setShowHorizontalLines(false);
/*     */     } 
/* 126 */     if (!((FlatTableUI)super).showVerticalLines) {
/* 127 */       ((FlatTableUI)super).oldShowVerticalLines = ((FlatTableUI)this).table.getShowVerticalLines();
/* 128 */       ((FlatTableUI)this).table.setShowVerticalLines(false);
/*     */     } 
/*     */     
/* 131 */     if (((FlatTableUI)super).intercellSpacing != null) {
/* 132 */       ((FlatTableUI)super).oldIntercellSpacing = ((FlatTableUI)this).table.getIntercellSpacing();
/* 133 */       ((FlatTableUI)this).table.setIntercellSpacing(((FlatTableUI)super).intercellSpacing);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void uninstallDefaults() {
/* 139 */     super.uninstallDefaults();
/*     */     
/* 141 */     ((FlatTableUI)super).selectionBackground = null;
/* 142 */     ((FlatTableUI)super).selectionForeground = null;
/* 143 */     ((FlatTableUI)super).selectionInactiveBackground = null;
/* 144 */     ((FlatTableUI)super).selectionInactiveForeground = null;
/*     */ 
/*     */     
/* 147 */     if (!((FlatTableUI)super).showHorizontalLines && ((FlatTableUI)super).oldShowHorizontalLines && !((FlatTableUI)this).table.getShowHorizontalLines())
/* 148 */       ((FlatTableUI)this).table.setShowHorizontalLines(true); 
/* 149 */     if (!((FlatTableUI)super).showVerticalLines && ((FlatTableUI)super).oldShowVerticalLines && !((FlatTableUI)this).table.getShowVerticalLines()) {
/* 150 */       ((FlatTableUI)this).table.setShowVerticalLines(true);
/*     */     }
/*     */     
/* 153 */     if (((FlatTableUI)super).intercellSpacing != null && ((FlatTableUI)this).table.getIntercellSpacing().equals(((FlatTableUI)super).intercellSpacing)) {
/* 154 */       ((FlatTableUI)this).table.setIntercellSpacing(((FlatTableUI)super).oldIntercellSpacing);
/*     */     }
/*     */   }
/*     */   
/*     */   public FocusListener createFocusListener() {
/* 159 */     return new FlatTableUI$1((FlatTableUI)this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void toggleSelectionColors(Object youcangetnoinfoEDIY1шхГР) {
/* 184 */     if (youcangetnoinfoEDIY1шхГР != null) {
/* 185 */       if (((FlatTableUI)this).table.getSelectionBackground() == ((FlatTableUI)super).selectionInactiveBackground)
/* 186 */         ((FlatTableUI)this).table.setSelectionBackground(((FlatTableUI)super).selectionBackground); 
/* 187 */       if (((FlatTableUI)this).table.getSelectionForeground() == ((FlatTableUI)super).selectionInactiveForeground)
/* 188 */         ((FlatTableUI)this).table.setSelectionForeground(((FlatTableUI)super).selectionForeground); 
/*     */     } else {
/* 190 */       if (((FlatTableUI)this).table.getSelectionBackground() == ((FlatTableUI)super).selectionBackground)
/* 191 */         ((FlatTableUI)this).table.setSelectionBackground(((FlatTableUI)super).selectionInactiveBackground); 
/* 192 */       if (((FlatTableUI)this).table.getSelectionForeground() == ((FlatTableUI)super).selectionForeground)
/* 193 */         ((FlatTableUI)this).table.setSelectionForeground(((FlatTableUI)super).selectionInactiveForeground); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTableUI.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */