/*    */ package com.formdev.flatlaf.ui;
/*    */ 
/*    */ import com.formdev.flatlaf.util.UIScale;
/*    */ import javax.swing.UIManager;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FlatTextBorder
/*    */   extends FlatBorder
/*    */ {
/*    */   public final int arc;
/*    */   
/*    */   public FlatTextBorder() {
/* 33 */     ((FlatTextBorder)super).arc = UIManager.getInt("TextComponent.arc");
/*    */   }
/*    */   
/*    */   public float getArc(Object youcangetnoinfoADAGтп5Иz) {
/* 37 */     return UIScale.scale(((FlatTextBorder)super).arc);
/*    */   }
/*    */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatTextBorder.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */