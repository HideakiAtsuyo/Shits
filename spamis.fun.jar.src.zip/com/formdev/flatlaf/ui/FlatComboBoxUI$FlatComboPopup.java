/*     */ package com.formdev.flatlaf.ui;
/*     */ 
/*     */ import java.awt.ComponentOrientation;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Rectangle;
/*     */ import java.beans.PropertyChangeListener;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.border.Border;
/*     */ import javax.swing.plaf.basic.BasicComboPopup;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class FlatComboBoxUI$FlatComboPopup
/*     */   extends BasicComboPopup
/*     */ {
/*     */   public FlatComboBoxUI$CellPaddingBorder paddingBorder;
/*     */   public final FlatComboBoxUI this$0;
/*     */   
/*     */   public FlatComboBoxUI$FlatComboPopup(Object youcangetnoinfoBSUJЭч0еФ) {
/* 469 */     super((JComboBox)youcangetnoinfoBSUJЭч0еФ);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 475 */     Object youcangetnoinfoBSUKбЧш8У = ((FlatComboBoxUI$FlatComboPopup)this).comboBox.getComponentOrientation();
/* 476 */     ((FlatComboBoxUI$FlatComboPopup)this).list.setComponentOrientation((ComponentOrientation)youcangetnoinfoBSUKбЧш8У);
/* 477 */     ((FlatComboBoxUI$FlatComboPopup)this).scroller.setComponentOrientation((ComponentOrientation)youcangetnoinfoBSUKбЧш8У);
/* 478 */     setComponentOrientation((ComponentOrientation)youcangetnoinfoBSUKбЧш8У);
/*     */   }
/*     */ 
/*     */   
/*     */   public Rectangle computePopupBounds(Object youcangetnoinfoBYAR88жЁЪ, Object youcangetnoinfoBYASПьб1ъ, Object youcangetnoinfoBYATьБФЛМ, Object youcangetnoinfoBYAUъЭКяФ) {
/*     */     int i, j;
/* 484 */     Object youcangetnoinfoBYAVбЕлВ5 = ((FlatComboBoxUI$FlatComboPopup)super).this$0.getDisplaySize();
/*     */ 
/*     */     
/* 487 */     if (((Dimension)youcangetnoinfoBYAVбЕлВ5).width > youcangetnoinfoBYATьБФЛМ) {
/* 488 */       int k = ((Dimension)youcangetnoinfoBYAVбЕлВ5).width - youcangetnoinfoBYATьБФЛМ;
/* 489 */       j = ((Dimension)youcangetnoinfoBYAVбЕлВ5).width;
/*     */       
/* 491 */       if (!((FlatComboBoxUI$FlatComboPopup)this).comboBox.getComponentOrientation().isLeftToRight()) {
/* 492 */         i = youcangetnoinfoBYAR88жЁЪ - k;
/*     */       }
/*     */     } 
/* 495 */     return super.computePopupBounds(i, youcangetnoinfoBYASПьб1ъ, j, youcangetnoinfoBYAUъЭКяФ);
/*     */   }
/*     */ 
/*     */   
/*     */   public void configurePopup() {
/* 500 */     super.configurePopup();
/*     */     
/* 502 */     Object youcangetnoinfoCACOТмщЙН = UIManager.getBorder("PopupMenu.border");
/* 503 */     if (youcangetnoinfoCACOТмщЙН != null) {
/* 504 */       setBorder((Border)youcangetnoinfoCACOТмщЙН);
/*     */     }
/*     */   }
/*     */   
/*     */   public void configureList() {
/* 509 */     super.configureList();
/*     */     
/* 511 */     ((FlatComboBoxUI$FlatComboPopup)this).list.setCellRenderer(new FlatComboBoxUI$FlatComboPopup$PopupListCellRenderer((FlatComboBoxUI$FlatComboPopup)this, null));
/*     */   }
/*     */ 
/*     */   
/*     */   public PropertyChangeListener createPropertyChangeListener() {
/* 516 */     return new FlatComboBoxUI$FlatComboPopup$1((FlatComboBoxUI$FlatComboPopup)this);
/*     */   }
/*     */ }


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\ui\FlatComboBoxUI$FlatComboPopup.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */