package com.formdev.flatlaf.util;

public interface ColorFunctions$ColorFunction {
  void apply(float[] paramArrayOffloat);
}


/* Location:              C:\Users\HP\Downloads\ip-logger-master\Spamis.fun CRACKED\spamis.fun.jar!\com\formdev\flatla\\util\ColorFunctions$ColorFunction.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */